import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D1, vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double6 = vector1D5.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = vector1D2.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double9 = vector1D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.scalarMultiply(52.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = vector1D8.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        double double15 = vector1D8.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D17, vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D18.scalarMultiply((double) (-1L));
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = vector1D21.subtract(1.5707963267948966d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D26, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D29, vector1D30);
        double double32 = vector1D27.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D35, vector1D36);
        double double38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D34, vector1D36);
        double double39 = vector1D30.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D34);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D42, vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D45, vector1D46);
        double double48 = vector1D43.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D50.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = vector2D54.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double58 = vector2D53.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line60 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D53, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = vector2D61.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = vector2D65.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        double double69 = vector2D64.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Line line71 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D64, 0.0d);
        boolean boolean72 = line60.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line71);
        line60.setOriginOffset(0.0d);
        double[] doubleArray76 = new double[] {};
        double[] doubleArray79 = new double[] { 10.0d, '4' };
        double double80 = org.apache.commons.math3.util.MathArrays.distance(doubleArray76, doubleArray79);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray79);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray79);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = line60.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D82);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1102230246251565E-16d, vector1D43, (-1.6159951507025987d), vector1D83);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D85 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = vector1D84.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D85);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D87 = vector1D86.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D88 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 32L, vector1D8, 3.9269908169872414d, vector1D24, 0.0d, vector1D34, 3.9269908169872414d, vector1D87);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.POSITIVE_INFINITY + "'", double32 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertNotNull(vector1D85);
        org.junit.Assert.assertNotNull(vector1D86);
        org.junit.Assert.assertNotNull(vector1D87);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D1, vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D4, vector1D5);
        double double7 = vector1D2.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D9.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D13.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double17 = vector2D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Line line19 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D20.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double28 = vector2D23.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, 0.0d);
        boolean boolean31 = line19.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line30);
        line19.setOriginOffset(0.0d);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray38 = new double[] { 10.0d, '4' };
        double double39 = org.apache.commons.math3.util.MathArrays.distance(doubleArray35, doubleArray38);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = line19.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1102230246251565E-16d, vector1D2, (-1.6159951507025987d), vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D43.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D45.getZero();
        double double47 = vector1D45.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D48, vector1D49);
        double double51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D45, vector1D49);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector52 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = vector1D49.subtract(euclidean1DVector52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.POSITIVE_INFINITY + "'", double47 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D3, vector1D4);
        double double6 = vector1D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D9, vector1D10);
        double double12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D8, vector1D10);
        double double13 = vector1D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        boolean boolean14 = vector1D8.isNaN();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = vector2D1.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D5.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = vector2D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 1L, vector2D4);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion5 = intervalsSet4.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine6 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane1, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = intervalsSet4.buildNew(euclidean1DBSPTree7);
        double double9 = intervalsSet4.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree11 = intervalsSet4.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D12.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        euclidean1DBSPTree11.setAttribute((java.lang.Object) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D18.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane23 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet26 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion27 = intervalsSet26.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane23, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet26);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree29 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet30 = intervalsSet26.buildNew(euclidean1DBSPTree29);
        double double31 = intervalsSet26.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree33 = intervalsSet26.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = vector2D34.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        euclidean1DBSPTree33.setAttribute((java.lang.Object) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D40.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = vector2D44.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        double double48 = vector2D43.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D14, 90.0d, vector2D18, (double) (-1.0f), vector2D36, (double) (-100.0f), vector2D47);
        org.apache.commons.math3.geometry.Space space50 = vector2D36.getSpace();
        java.lang.String str51 = vector2D36.toString();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion5);
        org.junit.Assert.assertNotNull(intervalsSet8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-31.0d) + "'", double9 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion27);
        org.junit.Assert.assertNotNull(intervalsSet30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-31.0d) + "'", double31 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{(-Infinity); (-Infinity)}" + "'", str51.equals("{(-Infinity); (-Infinity)}"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(1833.4649444186343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 10.0d, '4' };
        double double4 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        double[] doubleArray7 = new double[] { 100.0d };
        double[] doubleArray9 = new double[] { 100.0d };
        double[] doubleArray11 = new double[] { 100.0d };
        double[] doubleArray13 = new double[] { 100.0d };
        double[] doubleArray15 = new double[] { 100.0d };
        double[][] doubleArray16 = new double[][] { doubleArray7, doubleArray9, doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, orderDirection5, doubleArray16);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection18 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1), (float) 52L, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        euclidean1DBSPTree10.setAttribute((java.lang.Object) vector2D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double21 = vector3D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D20.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Line line27 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D16, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = line27.pointAt((double) (-1.0f));
        euclidean1DBSPTree10.setAttribute((java.lang.Object) line27);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree31 = euclidean1DBSPTree10.copySelf();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree31);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double10 = vector3D8.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D9.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Line line16 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D5, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D3, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Line line18 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double21 = vector3D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D20.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        java.lang.Class<?> wildcardClass27 = vector3D20.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D20.scalarMultiply((double) 0.0f);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = line18.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D31.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D37.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D33.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D46.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D43.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        org.apache.commons.math3.geometry.Space space49 = vector3D43.getSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Line line50 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D20, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        double double56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D52, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D51.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        double double58 = vector3D43.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5384395393292852d + "'", double4 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(space49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.7071067811865475d + "'", double56 == 0.7071067811865475d);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        line10.setOriginOffset(0.0d);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray29 = new double[] { 10.0d, '4' };
        double double30 = org.apache.commons.math3.util.MathArrays.distance(doubleArray26, doubleArray29);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = line10.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        line10.setAngle(4.9E-324d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = vector2D36.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D40.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        double double44 = vector2D39.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = vector2D47.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = vector2D51.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        double double55 = vector2D50.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Line line57 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D50, 0.0d);
        boolean boolean58 = line46.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line57);
        line46.setOriginOffset(0.0d);
        double[] doubleArray62 = new double[] {};
        double[] doubleArray65 = new double[] { 10.0d, '4' };
        double double66 = org.apache.commons.math3.util.MathArrays.distance(doubleArray62, doubleArray65);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray65);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = line46.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Line line70 = line46.getReverse();
        double double71 = line10.getOffset(line70);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertNotNull(line70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 100.0f, (double) (-1L));
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector3 = intervalsSet2.getBarycenter();
        double double4 = intervalsSet2.getSup();
        org.junit.Assert.assertNotNull(euclidean1DVector3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D8.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 1, vector3D8 };
        org.apache.commons.math3.exception.MathInternalError mathInternalError15 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray14);
        java.lang.Throwable[] throwableArray16 = mathInternalError15.getSuppressed();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException17 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.9999999999999999d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = vector1D1.scalarMultiply((double) (short) -1);
        double double4 = vector1D3.getNorm();
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9999999999999999d + "'", double4 == 0.9999999999999999d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D1, vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D4, vector1D5);
        double double7 = vector1D2.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D9.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D13.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double17 = vector2D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Line line19 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D20.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double28 = vector2D23.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, 0.0d);
        boolean boolean31 = line19.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line30);
        line19.setOriginOffset(0.0d);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray38 = new double[] { 10.0d, '4' };
        double double39 = org.apache.commons.math3.util.MathArrays.distance(doubleArray35, doubleArray38);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = line19.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1102230246251565E-16d, vector1D2, (-1.6159951507025987d), vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D43.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double47 = vector1D46.getNorm1();
        double double48 = vector1D45.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        java.text.NumberFormat numberFormat49 = null;
        try {
            java.lang.String str50 = vector1D46.toString(numberFormat49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.2005766322266866d, (java.lang.Number) 0, false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double6 = vector3D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D8.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D5.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        java.lang.Class<?> wildcardClass12 = vector3D5.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D5.scalarMultiply((double) 0.0f);
        double double15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D3.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.8115262724608532d, vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9999999999999999d + "'", double15 == 0.9999999999999999d);
        org.junit.Assert.assertNotNull(vector3D16);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 48.0d, (java.lang.Number) 100L, true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) ' ', (int) ' ');
        int int3 = dimensionMismatchException2.getDimension();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        java.lang.Number number8 = nonMonotonicSequenceException7.getArgument();
        org.apache.commons.math3.exception.MathInternalError mathInternalError9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) nonMonotonicSequenceException7);
        dimensionMismatchException2.addSuppressed((java.lang.Throwable) mathInternalError9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double10 = vector3D8.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D9.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Line line16 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D5, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D3, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Line line18 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double21 = vector3D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D20.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        java.lang.Class<?> wildcardClass27 = vector3D20.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D20.scalarMultiply((double) 0.0f);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = line18.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Line line31 = new org.apache.commons.math3.geometry.euclidean.threed.Line(line18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D33, vector1D34);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D36, vector1D37);
        double double39 = vector1D34.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D45.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        double double49 = vector2D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Line line51 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D44, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = vector2D52.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = vector2D56.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        double double60 = vector2D55.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D59);
        org.apache.commons.math3.geometry.euclidean.twod.Line line62 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D55, 0.0d);
        boolean boolean63 = line51.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line62);
        line51.setOriginOffset(0.0d);
        double[] doubleArray67 = new double[] {};
        double[] doubleArray70 = new double[] { 10.0d, '4' };
        double double71 = org.apache.commons.math3.util.MathArrays.distance(doubleArray67, doubleArray70);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray70);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = line51.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D73);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1102230246251565E-16d, vector1D34, (-1.6159951507025987d), vector1D74);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = line18.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D34);
        double double77 = vector3D76.getY();
        org.apache.commons.math3.geometry.Space space78 = vector3D76.getSpace();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5384395393292852d + "'", double4 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D74);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space78);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double1 = vector1D0.getNormInf();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) 100, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double10 = vector3D8.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D9.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Line line16 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D5, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D3, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Line line18 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double24 = vector3D22.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D26.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D23.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Line line30 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D19, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Line line31 = line30.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = line18.closestPoint(line31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.Space space36 = vector3D35.getSpace();
        boolean boolean37 = line31.contains(vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = line31.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D39.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double44 = vector3D42.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D46.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D43.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Line line50 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D39, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = line31.intersection(line50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.scalarMultiply((double) 35.0f);
        double double55 = line50.getAbscissa(vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double60 = vector3D58.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D59);
        double double61 = vector3D59.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double64 = vector3D62.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = vector3D66.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = vector3D63.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        java.lang.Class<?> wildcardClass70 = vector3D63.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D63.scalarMultiply((double) 0.0f);
        double double73 = vector3D59.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double81 = vector3D80.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = vector3D82.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double87 = vector3D85.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D86);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D89 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = vector3D89.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D92 = vector3D86.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D91);
        org.apache.commons.math3.geometry.euclidean.threed.Line line93 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D82, vector3D92);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D94 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D80, vector3D92);
        org.apache.commons.math3.geometry.euclidean.threed.Line line95 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D77, vector3D80);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D96 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.5384395393292852d, vector3D72, 90.0d, vector3D75, 0.0d, vector3D77);
        try {
            line50.reset(vector3D56, vector3D72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5384395393292852d + "'", double4 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(line31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(space36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.5384395393292852d + "'", double81 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertNotNull(vector3D86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D89);
        org.junit.Assert.assertNotNull(vector3D91);
        org.junit.Assert.assertNotNull(vector3D92);
        org.junit.Assert.assertNotNull(vector3D94);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double5 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D4.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Line line11 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Line line12 = line11.revert();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D13, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double18 = vector1D17.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D14.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = line11.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double24 = vector3D22.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        line11.reset(vector3D22, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double31 = vector3D29.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        double double32 = vector3D27.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray35 = vector2D34.toArray();
        double[] doubleArray36 = new double[] {};
        double[] doubleArray39 = new double[] { 10.0d, '4' };
        double double40 = org.apache.commons.math3.util.MathArrays.distance(doubleArray36, doubleArray39);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray35, doubleArray39);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, 0.0d);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.scale((double) (byte) 100, doubleArray43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray46 = vector2D45.toArray();
        double[] doubleArray47 = new double[] {};
        double[] doubleArray50 = new double[] { 10.0d, '4' };
        double double51 = org.apache.commons.math3.util.MathArrays.distance(doubleArray47, doubleArray50);
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray50);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray50, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray50);
        boolean boolean56 = org.apache.commons.math3.util.MathArrays.equals(doubleArray44, doubleArray50);
        boolean boolean57 = vector3D27.equals((java.lang.Object) doubleArray44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray60 = vector2D59.toArray();
        double[] doubleArray61 = new double[] {};
        double[] doubleArray64 = new double[] { 10.0d, '4' };
        double double65 = org.apache.commons.math3.util.MathArrays.distance(doubleArray61, doubleArray64);
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray60, doubleArray64);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray64, 0.0d);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.scale((double) (byte) 100, doubleArray68);
        double double70 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray44, doubleArray68);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(line12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.8304627863460217d + "'", double32 == 0.8304627863460217d);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion3 = intervalsSet2.copySelf();
        double double4 = euclidean1DAbstractRegion3.getSize();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-31.0d) + "'", double4 == (-31.0d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D7.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D3.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D13.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double18 = vector3D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        double double19 = vector3D17.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double22 = vector3D20.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D24.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D21.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        java.lang.Class<?> wildcardClass28 = vector3D21.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D21.scalarMultiply((double) 0.0f);
        double double31 = vector3D17.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double37 = vector3D36.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double43 = vector3D41.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D45.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D42.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Line line49 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D38, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D36, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Line line51 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D33, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D14, (double) 0.0f, vector3D17, 1.0d, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D55.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D17.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D59);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.5384395393292852d + "'", double37 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion6 = intervalsSet5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine7 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree8 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet9 = intervalsSet5.buildNew(euclidean1DBSPTree8);
        double double10 = intervalsSet5.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = intervalsSet5.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D13.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        euclidean1DBSPTree12.setAttribute((java.lang.Object) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D19.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane24 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion28 = intervalsSet27.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree30 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet31 = intervalsSet27.buildNew(euclidean1DBSPTree30);
        double double32 = intervalsSet27.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree34 = intervalsSet27.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D35.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        euclidean1DBSPTree34.setAttribute((java.lang.Object) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D45.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        double double49 = vector2D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D15, 90.0d, vector2D19, (double) (-1.0f), vector2D37, (double) (-100.0f), vector2D48);
        org.apache.commons.math3.geometry.Space space51 = vector2D37.getSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = vector2D55.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = vector2D59.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        double double63 = vector2D58.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 10.000001f, vector2D37, 10.000000000000071d, vector2D53, 1.4210854715202004E-14d, vector2D62);
        double double65 = vector2D37.getNorm();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion6);
        org.junit.Assert.assertNotNull(intervalsSet9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-31.0d) + "'", double10 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion28);
        org.junit.Assert.assertNotNull(intervalsSet31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-31.0d) + "'", double32 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space51);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.POSITIVE_INFINITY + "'", double65 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) (short) 10);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane3 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet6 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion7 = intervalsSet6.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine8 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = intervalsSet6.buildNew(euclidean1DBSPTree9);
        double double11 = intervalsSet6.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree13 = intervalsSet6.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree14 = euclidean1DBSPTree13.getMinus();
        boolean boolean15 = intervalsSet2.isEmpty(euclidean1DBSPTree13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D19, vector1D20);
        double double22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D18, vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D28, vector1D29);
        double double31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D27, vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D24.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D18, (double) ' ', vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D36, vector1D37);
        double double39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D35, vector1D37);
        double double40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D18, vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint42 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D37, false);
        org.apache.commons.math3.geometry.partitioning.Side side43 = intervalsSet2.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D47, vector1D48);
        double double50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D46, vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double58 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D56, vector1D57);
        double double59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D55, vector1D57);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = vector1D52.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D55);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D46, (double) ' ', vector1D55);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D64, vector1D65);
        double double67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D63, vector1D65);
        double double68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D46, vector1D65);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint70 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D65, false);
        boolean boolean71 = orientedPoint42.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint70);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane72 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet75 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion76 = intervalsSet75.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine77 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane72, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet75);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree78 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet79 = intervalsSet75.buildNew(euclidean1DBSPTree78);
        double double80 = intervalsSet75.getSize();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList81 = intervalsSet75.asList();
        boolean boolean82 = intervalsSet75.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint83 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint42, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet75);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree85 = intervalsSet75.getTree(false);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion7);
        org.junit.Assert.assertNotNull(intervalsSet10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-31.0d) + "'", double11 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree13);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.POSITIVE_INFINITY + "'", double22 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + side43 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side43.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.POSITIVE_INFINITY + "'", double67 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.POSITIVE_INFINITY + "'", double68 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion76);
        org.junit.Assert.assertNotNull(intervalsSet79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + (-31.0d) + "'", double80 == (-31.0d));
        org.junit.Assert.assertNotNull(intervalList81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree85);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double2 = vector3D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D4.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D1.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D6);
        java.text.NumberFormat numberFormat8 = null;
        java.lang.String str9 = vector3D7.toString(numberFormat8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double15 = vector3D13.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D17.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D14.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Line line21 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D10, vector3D20);
        double double22 = vector3D20.getX();
        double double23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D7, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double28 = vector3D27.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D29.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double34 = vector3D32.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D36.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D33.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Line line40 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D29, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D27, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Line line42 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D24, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D43.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double48 = vector3D46.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D50.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D47.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Line line54 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D43, vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Line line55 = line54.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = line42.closestPoint(line55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.Space space60 = vector3D59.getSpace();
        boolean boolean61 = line55.contains(vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = line55.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D63.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double68 = vector3D66.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D70.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D67.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Line line74 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D63, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = line55.intersection(line74);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = line55.getOrigin();
        double double77 = vector3D76.getNorm1();
        double double78 = vector3D7.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D76);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{(NaN); (NaN); (NaN)}" + "'", str9.equals("{(NaN); (NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.5384395393292852d + "'", double28 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(line55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(space60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNull(vector3D75);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double78, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.geometry.euclidean.threed.Line line0 = null;
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion5 = intervalsSet4.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine6 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane1, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = intervalsSet4.buildNew(euclidean1DBSPTree7);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector9 = intervalsSet4.getBarycenter();
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.threed.SubLine(line0, intervalsSet4);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion5);
        org.junit.Assert.assertNotNull(intervalsSet8);
        org.junit.Assert.assertNotNull(euclidean1DVector9);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math3.util.FastMath.asin((-97.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        boolean boolean25 = line10.contains(vector2D24);
        line10.setOriginOffset(0.5403023058681338d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray29 = vector2D28.toArray();
        double[] doubleArray30 = new double[] {};
        double[] doubleArray33 = new double[] { 10.0d, '4' };
        double double34 = org.apache.commons.math3.util.MathArrays.distance(doubleArray30, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray29, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray33, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane42 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet45 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion46 = intervalsSet45.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine47 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane42, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet45);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree48 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet49 = intervalsSet45.buildNew(euclidean1DBSPTree48);
        double double50 = intervalsSet45.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree52 = intervalsSet45.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = vector2D53.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        euclidean1DBSPTree52.setAttribute((java.lang.Object) vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = vector2D59.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane64 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet67 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion68 = intervalsSet67.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine69 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane64, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet67);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree70 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet71 = intervalsSet67.buildNew(euclidean1DBSPTree70);
        double double72 = intervalsSet67.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree74 = intervalsSet67.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = vector2D75.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D77);
        euclidean1DBSPTree74.setAttribute((java.lang.Object) vector2D77);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = vector2D81.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D83);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = vector2D85.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D87);
        double double89 = vector2D84.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D88);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D55, 90.0d, vector2D59, (double) (-1.0f), vector2D77, (double) (-100.0f), vector2D88);
        double double91 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D40, vector2D77);
        org.apache.commons.math3.geometry.euclidean.twod.Line line92 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D93 = line10.intersection(line92);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet94 = line10.wholeSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion46);
        org.junit.Assert.assertNotNull(intervalsSet49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-31.0d) + "'", double50 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion68);
        org.junit.Assert.assertNotNull(intervalsSet71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + (-31.0d) + "'", double72 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertNotNull(vector2D83);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertNotNull(vector2D85);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertNotNull(vector2D88);
        org.junit.Assert.assertEquals((double) double89, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double91, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D93);
        org.junit.Assert.assertNotNull(polygonsSet94);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D28.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D32.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double36 = vector2D31.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        double double37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D27, vector2D31);
        boolean boolean38 = vector2D31.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray40 = vector2D39.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D39.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine46 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D31, vector2D39);
        line23.reset(vector2D39, (double) (short) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = vector2D49.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = vector2D53.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        double double57 = vector2D52.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Line line59 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D52, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = vector2D60.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = vector2D64.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D66);
        double double68 = vector2D63.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Line line70 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D63, 0.0d);
        boolean boolean71 = line59.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line70);
        double double72 = line23.getOffset(line70);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine73 = line23.wholeHyperplane();
        double double74 = subLine73.getSize();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subLine73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + Double.POSITIVE_INFINITY + "'", double74 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D3, vector1D4);
        double double6 = vector1D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D9, vector1D10);
        double double12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D8, vector1D10);
        double double13 = vector1D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = vector1D8.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree16 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((java.lang.Object) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D15.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D8.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D18);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = orientedPoint3.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion9 = intervalsSet8.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractRegion9);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet14 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion15 = intervalsSet14.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine16 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree17 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = intervalsSet14.buildNew(euclidean1DBSPTree17);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector19 = intervalsSet14.getBarycenter();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList20 = intervalsSet14.asList();
        boolean boolean21 = euclidean1DAbstractRegion9.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint22 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        org.junit.Assert.assertNotNull(intervalsSet4);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion9);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion15);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertNotNull(euclidean1DVector19);
        org.junit.Assert.assertNotNull(intervalList20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D3, vector1D4);
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D2, vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D12, vector1D13);
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D11, vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D8.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D2, (double) ' ', vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D20, vector1D21);
        double double23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D19, vector1D21);
        double double24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D2, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint26 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, false);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane27 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet30 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion31 = intervalsSet30.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine32 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane27, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet30);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion33 = subLine32.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint34 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint26, euclidean1DRegion33);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane35 = subOrientedPoint34.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane36 = euclidean1DAbstractSubHyperplane35.getHyperplane();
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion31);
        org.junit.Assert.assertNotNull(euclidean1DRegion33);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane35);
        org.junit.Assert.assertNotNull(euclidean1DHyperplane36);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        boolean boolean25 = line10.contains(vector2D24);
        line10.setOriginOffset(0.5403023058681338d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = line10.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = line10.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree31 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((java.lang.Object) vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D30.getZero();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = line10.getPointAt(vector1D30, (double) 0);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(line28);
        org.junit.Assert.assertNotNull(subLine29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector2D34);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        double[] doubleArray2 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, '4' };
        double double6 = org.apache.commons.math3.util.MathArrays.distance(doubleArray2, doubleArray5);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 0.0d);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray15 = new double[] { 10.0d, '4' };
        double double16 = org.apache.commons.math3.util.MathArrays.distance(doubleArray12, doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(0.0d, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray9, doubleArray15);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray24 = new double[] { 10.0d, '4' };
        double double25 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray27 = vector2D26.toArray();
        double[] doubleArray28 = new double[] {};
        double[] doubleArray31 = new double[] { 10.0d, '4' };
        double double32 = org.apache.commons.math3.util.MathArrays.distance(doubleArray28, doubleArray31);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray27, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray31, 0.0d);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray40 = new double[] { 10.0d, '4' };
        double double41 = org.apache.commons.math3.util.MathArrays.distance(doubleArray37, doubleArray40);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray40);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray31, doubleArray40);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray24, doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray15, doubleArray24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray49 = vector2D48.toArray();
        double[] doubleArray50 = org.apache.commons.math3.util.MathArrays.scale(0.0d, doubleArray49);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray24, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection52 = null;
        try {
            boolean boolean55 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray49, orderDirection52, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D7.negate();
        org.apache.commons.math3.geometry.Space space10 = vector2D9.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(space10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 1.1920929E-7f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 100.0f, (double) (-1L));
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector3 = intervalsSet2.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree4 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane5 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion9 = intervalsSet8.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane5, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet8);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = intervalsSet8.buildNew(euclidean1DBSPTree11);
        double double13 = intervalsSet8.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree15 = intervalsSet8.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree16 = euclidean1DBSPTree15.getMinus();
        euclidean1DBSPTree4.insertInTree(euclidean1DBSPTree16, true);
        java.lang.Object obj19 = euclidean1DBSPTree16.getAttribute();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet20 = intervalsSet2.buildNew(euclidean1DBSPTree16);
        org.junit.Assert.assertNotNull(euclidean1DVector3);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion9);
        org.junit.Assert.assertNotNull(intervalsSet12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-31.0d) + "'", double13 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree15);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree16);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNotNull(intervalsSet20);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double3 = vector3D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D2.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        java.text.NumberFormat numberFormat9 = null;
        java.lang.String str10 = vector3D8.toString(numberFormat9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D11.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double16 = vector3D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D18.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D15.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D11, vector3D21);
        double double23 = vector3D21.getX();
        double double24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D8, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D28.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D28.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D32.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D38.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D34.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D44.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D53.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = vector3D49.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D44.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double63 = vector3D61.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double66 = vector3D64.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double69 = vector3D67.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D71.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D68.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D73);
        double double75 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D65, vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Line line76 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D61, vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D61.getZero();
        double double78 = vector3D58.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D28.add((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(Double.NaN, vector3D21, 0.0d, vector3D28);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{(NaN); (NaN); (NaN)}" + "'", str10.equals("{(NaN); (NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertEquals((double) double75, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 13.606032382727053d + "'", double78 == 13.606032382727053d);
        org.junit.Assert.assertNotNull(vector3D79);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int[] intArray0 = new int[] {};
        int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, 0);
        int[] intArray3 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0);
        int[] intArray4 = null;
        double double5 = org.apache.commons.math3.util.MathArrays.distance(intArray3, intArray4);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion6 = intervalsSet5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine7 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree8 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet9 = intervalsSet5.buildNew(euclidean1DBSPTree8);
        double double10 = intervalsSet5.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = intervalsSet5.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D13.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        euclidean1DBSPTree12.setAttribute((java.lang.Object) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D19.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane24 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion28 = intervalsSet27.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree30 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet31 = intervalsSet27.buildNew(euclidean1DBSPTree30);
        double double32 = intervalsSet27.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree34 = intervalsSet27.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D35.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        euclidean1DBSPTree34.setAttribute((java.lang.Object) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D45.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        double double49 = vector2D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D15, 90.0d, vector2D19, (double) (-1.0f), vector2D37, (double) (-100.0f), vector2D48);
        double double51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = vector2D37.normalize();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion6);
        org.junit.Assert.assertNotNull(intervalsSet9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-31.0d) + "'", double10 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion28);
        org.junit.Assert.assertNotNull(intervalsSet31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-31.0d) + "'", double32 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D52);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        double double12 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D3, vector2D7);
        boolean boolean14 = vector2D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D17.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = vector2D15.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D15);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane23 = subLine22.copySelf();
        boolean boolean24 = subLine22.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = vector2D25.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D29.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double33 = vector2D28.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D28, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = vector2D36.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D40.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        double double44 = vector2D39.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, 0.0d);
        boolean boolean47 = line35.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line46);
        line35.setOriginOffset(0.0d);
        org.apache.commons.math3.geometry.partitioning.Side side50 = subLine22.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line35);
        java.util.List<org.apache.commons.math3.geometry.euclidean.twod.Segment> segmentList51 = subLine22.getSegments();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + side50 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side50.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(segmentList51);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 1.1920929E-7f, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1920928955078125E-7d + "'", double2 == 1.1920928955078125E-7d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-1.0f), 0.0f, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double2 = vector3D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double5 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double8 = vector3D6.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D7.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D4, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Line line15 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine16 = line15.wholeLine();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D20.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D29.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double37 = vector3D35.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D39.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D36.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        java.lang.Class<?> wildcardClass43 = vector3D36.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D36.scalarMultiply((double) 0.0f);
        double double46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D34, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.5384395393292852d, vector3D24, (double) 100.0f, vector3D30, (-1.0d), vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line49 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D30, vector3D48);
        boolean boolean50 = line15.isSimilarTo(line49);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double52 = vector1D51.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = line49.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double59 = vector3D57.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D61.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = vector3D58.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D63);
        java.lang.Class<?> wildcardClass65 = vector3D58.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D58.scalarMultiply((double) 0.0f);
        double double68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D56, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = vector3D56.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D70.scalarMultiply(0.0d);
        double double73 = vector3D72.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = vector3D72.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D74);
        try {
            line49.reset(vector3D69, vector3D72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subLine16);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.9999999999999999d + "'", double46 == 0.9999999999999999d);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.9999999999999999d + "'", double68 == 0.9999999999999999d);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(vector3D75);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector8 = intervalsSet3.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion13 = intervalsSet12.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine14 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane9, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet12);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree15 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet16 = intervalsSet12.buildNew(euclidean1DBSPTree15);
        double double17 = intervalsSet12.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree19 = intervalsSet12.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D20.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        euclidean1DBSPTree19.setAttribute((java.lang.Object) vector2D22);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree25 = null;
        euclidean1DBSPTree19.insertInTree(euclidean1DBSPTree25, true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet28 = intervalsSet3.buildNew(euclidean1DBSPTree25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D29, vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = vector1D30.scalarMultiply((double) (-1L));
        java.text.NumberFormat numberFormat34 = null;
        java.lang.String str35 = vector1D30.toString(numberFormat34);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint37 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D30, true);
        try {
            org.apache.commons.math3.geometry.partitioning.Side side38 = intervalsSet28.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertNotNull(euclidean1DVector8);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion13);
        org.junit.Assert.assertNotNull(intervalsSet16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-31.0d) + "'", double17 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(intervalsSet28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{(-Infinity)}" + "'", str35.equals("{(-Infinity)}"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((-97.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.732511156817248d + "'", double1 == 3.732511156817248d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(13.606032382727053d, (double) (-1.0f), 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 32, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 34.999996f, 8.429369702178807E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.581537154953786d) + "'", double2 == (-4.581537154953786d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(0.0d, 1.8115262724608532d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        double double12 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D3, vector2D7);
        boolean boolean14 = vector2D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D17.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = vector2D15.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D15);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane23 = subLine22.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane24 = subLine22.copySelf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform25 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane26 = euclidean2DAbstractSubHyperplane24.applyTransform(euclidean2DTransform25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane23);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane24);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D28.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D32.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double36 = vector2D31.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        double double37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D27, vector2D31);
        boolean boolean38 = vector2D31.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray40 = vector2D39.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D39.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine46 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D31, vector2D39);
        line23.reset(vector2D39, (double) (short) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = vector2D49.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = vector2D53.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = vector2D57.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D59);
        double double61 = vector2D56.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D60);
        double double62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D52, vector2D56);
        double double63 = line23.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.Space space64 = vector2D52.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space64);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D11, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double16 = vector1D15.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D12.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.partitioning.Region.Location location18 = intervalsSet3.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion19 = intervalsSet3.copySelf();
        double double20 = intervalsSet3.getSup();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + location18 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE + "'", location18.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE));
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line24 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree11 = euclidean1DBSPTree10.getMinus();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet14 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) (short) 10);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane15 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion19 = intervalsSet18.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine20 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane15, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree21 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = intervalsSet18.buildNew(euclidean1DBSPTree21);
        double double23 = intervalsSet18.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree25 = intervalsSet18.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree26 = euclidean1DBSPTree25.getMinus();
        boolean boolean27 = intervalsSet14.isEmpty(euclidean1DBSPTree25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D31, vector1D32);
        double double34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D30, vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D40, vector1D41);
        double double43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D39, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = vector1D36.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D30, (double) ' ', vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D48, vector1D49);
        double double51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D47, vector1D49);
        double double52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D30, vector1D49);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint54 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D49, false);
        org.apache.commons.math3.geometry.partitioning.Side side55 = intervalsSet14.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D59, vector1D60);
        double double62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D58, vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D68, vector1D69);
        double double71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D67, vector1D69);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = vector1D64.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D67);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D58, (double) ' ', vector1D67);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double78 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D76, vector1D77);
        double double79 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D75, vector1D77);
        double double80 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D58, vector1D77);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint82 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D77, false);
        boolean boolean83 = orientedPoint54.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint82);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane84 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet87 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion88 = intervalsSet87.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine89 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane84, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet87);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree90 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet91 = intervalsSet87.buildNew(euclidean1DBSPTree90);
        double double92 = intervalsSet87.getSize();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList93 = intervalsSet87.asList();
        boolean boolean94 = intervalsSet87.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint95 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint54, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet87);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree96 = euclidean1DBSPTree10.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint95);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane97 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane98 = subOrientedPoint95.split(euclidean1DHyperplane97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree11);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion19);
        org.junit.Assert.assertNotNull(intervalsSet22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-31.0d) + "'", double23 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree25);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + side55 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side55.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + Double.POSITIVE_INFINITY + "'", double62 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + Double.POSITIVE_INFINITY + "'", double71 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D72);
        org.junit.Assert.assertNotNull(vector1D76);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertEquals((double) double78, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + Double.POSITIVE_INFINITY + "'", double79 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + Double.POSITIVE_INFINITY + "'", double80 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion88);
        org.junit.Assert.assertNotNull(intervalsSet91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + (-31.0d) + "'", double92 == (-31.0d));
        org.junit.Assert.assertNotNull(intervalList93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree96);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector1 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.crossProduct(euclidean3DVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.5707963267948966d, 2.99822295029797d, (double) (short) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.negate();
        org.junit.Assert.assertNotNull(vector3D4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        boolean boolean9 = vector2D3.isNaN();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane1 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree2 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree3 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree5 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((java.lang.Object) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D4.getZero();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree7 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane1, spaceBSPTree2, spaceBSPTree3, (java.lang.Object) vector1D4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree8 = null;
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion13 = intervalsSet12.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine14 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane9, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet12);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree15 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet16 = intervalsSet12.buildNew(euclidean1DBSPTree15);
        double double17 = intervalsSet12.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree19 = intervalsSet12.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D20, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double25 = vector1D24.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = vector1D21.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.partitioning.Region.Location location27 = intervalsSet12.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion28 = intervalsSet12.copySelf();
        try {
            org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree29 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceBSPTree2, spaceBSPTree8, (java.lang.Object) euclidean1DAbstractRegion28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion13);
        org.junit.Assert.assertNotNull(intervalsSet16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-31.0d) + "'", double17 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree19);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + location27 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE + "'", location27.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE));
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion28);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double10 = vector3D8.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D9.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Line line16 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D5, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D3, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Line line18 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double24 = vector3D22.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D26.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D23.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Line line30 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D19, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Line line31 = line30.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = line18.closestPoint(line31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.Space space36 = vector3D35.getSpace();
        boolean boolean37 = line31.contains(vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = line31.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D39.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double44 = vector3D42.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D46.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D43.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Line line50 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D39, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = line31.intersection(line50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.scalarMultiply((double) 35.0f);
        double double55 = line50.getAbscissa(vector3D54);
        double double56 = vector3D54.getNorm1();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5384395393292852d + "'", double4 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(line31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(space36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double5 = vector1D4.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D1.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double8 = vector1D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D10.scalarMultiply(52.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D7.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        double double14 = vector1D12.getNormInf();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = orientedPoint3.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint5 = orientedPoint3.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform6 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane7 = subOrientedPoint5.applyTransform(euclidean1DTransform6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intervalsSet4);
        org.junit.Assert.assertNotNull(subOrientedPoint5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(7.105427357601002E-15d, (double) (-100.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        java.lang.String str1 = vector1D0.toString();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{(-Infinity)}" + "'", str1.equals("{(-Infinity)}"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D9.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        java.lang.Object[] objArray15 = new java.lang.Object[] { (byte) 1, vector3D9 };
        org.apache.commons.math3.exception.MathInternalError mathInternalError16 = new org.apache.commons.math3.exception.MathInternalError(localizable2, objArray15);
        org.apache.commons.math3.exception.MathInternalError mathInternalError17 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray15);
        org.apache.commons.math3.exception.util.Localizable localizable19 = null;
        org.apache.commons.math3.exception.util.Localizable localizable20 = null;
        long[] longArray24 = new long[] { (short) 1, '#', (short) 10 };
        long[] longArray28 = new long[] { (short) 1, '#', (short) 10 };
        long[] longArray32 = new long[] { (short) 1, '#', (short) 10 };
        long[] longArray36 = new long[] { (short) 1, '#', (short) 10 };
        long[] longArray40 = new long[] { (short) 1, '#', (short) 10 };
        long[][] longArray41 = new long[][] { longArray24, longArray28, longArray32, longArray36, longArray40 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray41);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray41);
        org.apache.commons.math3.exception.MathInternalError mathInternalError44 = new org.apache.commons.math3.exception.MathInternalError(localizable20, (java.lang.Object[]) longArray41);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray41);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException18, localizable19, (java.lang.Object[]) longArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertNotNull(longArray40);
        org.junit.Assert.assertNotNull(longArray41);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double5 = vector1D4.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D1.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = vector1D6.scalarMultiply(3.1415926535897927d);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane11 = euclidean1DBSPTree10.getCut();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(euclidean1DSubHyperplane11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.geometry.euclidean.threed.Segment segment0 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine1 = new org.apache.commons.math3.geometry.euclidean.threed.SubLine(segment0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(2.99822295029797d, 1.5117813758585614d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9982229502979694d + "'", double2 == 2.9982229502979694d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        float float2 = org.apache.commons.math3.util.FastMath.min(10.000001f, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(Double.POSITIVE_INFINITY, (double) (-1.0f));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        double[] doubleArray2 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, '4' };
        double double6 = org.apache.commons.math3.util.MathArrays.distance(doubleArray2, doubleArray5);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 0.0d);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray15 = new double[] { 10.0d, '4' };
        double double16 = org.apache.commons.math3.util.MathArrays.distance(doubleArray12, doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(0.0d, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray9, doubleArray15);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray24 = new double[] { 10.0d, '4' };
        double double25 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray27 = vector2D26.toArray();
        double[] doubleArray28 = new double[] {};
        double[] doubleArray31 = new double[] { 10.0d, '4' };
        double double32 = org.apache.commons.math3.util.MathArrays.distance(doubleArray28, doubleArray31);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray27, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray31, 0.0d);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray40 = new double[] { 10.0d, '4' };
        double double41 = org.apache.commons.math3.util.MathArrays.distance(doubleArray37, doubleArray40);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray40);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray31, doubleArray40);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray24, doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray15, doubleArray24);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (-0 >= -0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, number1);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        boolean boolean4 = notPositiveException2.getBoundIsAllowed();
        java.lang.Number number5 = notPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D11, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double16 = vector1D15.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D12.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.partitioning.Region.Location location18 = intervalsSet3.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion19 = intervalsSet3.copySelf();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList20 = intervalsSet3.asList();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + location18 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE + "'", location18.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE));
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion19);
        org.junit.Assert.assertNotNull(intervalList20);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        double[] doubleArray3 = new double[] {};
        double[] doubleArray6 = new double[] { 10.0d, '4' };
        double double7 = org.apache.commons.math3.util.MathArrays.distance(doubleArray3, doubleArray6);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray2, doubleArray6);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(1.000000000000007d, doubleArray8);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 10.0d, '4' };
        double double4 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        double[] doubleArray7 = new double[] { 100.0d };
        double[] doubleArray9 = new double[] { 100.0d };
        double[] doubleArray11 = new double[] { 100.0d };
        double[] doubleArray13 = new double[] { 100.0d };
        double[] doubleArray15 = new double[] { 100.0d };
        double[][] doubleArray16 = new double[][] { doubleArray7, doubleArray9, doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, orderDirection5, doubleArray16);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D28.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D32.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double36 = vector2D31.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        double double37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D27, vector2D31);
        boolean boolean38 = vector2D31.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray40 = vector2D39.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D39.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine46 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D31, vector2D39);
        line23.reset(vector2D39, (double) (short) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = vector2D49.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = vector2D53.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        double double57 = vector2D52.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Line line59 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D52, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = vector2D60.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = vector2D64.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D66);
        double double68 = vector2D63.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Line line70 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D63, 0.0d);
        boolean boolean71 = line59.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line70);
        double double72 = line23.getOffset(line70);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine73 = line23.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion74 = subLine73.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion75 = subLine73.getRemainingRegion();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subLine73);
        org.junit.Assert.assertNotNull(euclidean1DRegion74);
        org.junit.Assert.assertNotNull(euclidean1DRegion75);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D12.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        double double16 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D7, vector2D11);
        boolean boolean18 = vector2D11.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray20 = vector2D19.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = vector2D21.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        double double25 = vector2D19.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine26 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D28.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D32.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double36 = vector2D31.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = vector2D35.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D11.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double5 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D4.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Line line11 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Line line12 = line11.revert();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D13, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double18 = vector1D17.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D14.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = vector1D21.getZero();
        double double23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D19, vector1D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D24.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double29 = vector3D27.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D31.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D28.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Line line35 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D24, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Line line36 = line35.revert();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D37, vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double42 = vector1D41.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = vector1D38.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = line35.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D45.getZero();
        double double47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D43, vector1D46);
        double double48 = vector1D22.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D43);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(line12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(line36);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.POSITIVE_INFINITY + "'", double47 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D1, vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D4, vector1D5);
        double double7 = vector1D2.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D9.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D13.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double17 = vector2D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Line line19 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D20.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double28 = vector2D23.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, 0.0d);
        boolean boolean31 = line19.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line30);
        line19.setOriginOffset(0.0d);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray38 = new double[] { 10.0d, '4' };
        double double39 = org.apache.commons.math3.util.MathArrays.distance(doubleArray35, doubleArray38);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = line19.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1102230246251565E-16d, vector1D2, (-1.6159951507025987d), vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D43.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        double double46 = vector1D45.getNorm();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.POSITIVE_INFINITY + "'", double46 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane11 = null;
        try {
            boolean boolean12 = euclidean1DBSPTree10.insertCut(euclidean1DHyperplane11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion6 = subLine5.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree7 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) euclidean1DRegion6);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(euclidean1DRegion6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(10.000001f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.000001f + "'", float2 == 10.000001f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D1, vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D4, vector1D5);
        double double7 = vector1D2.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D9.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D13.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double17 = vector2D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Line line19 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D20.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        double double28 = vector2D23.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, 0.0d);
        boolean boolean31 = line19.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line30);
        line19.setOriginOffset(0.0d);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray38 = new double[] { 10.0d, '4' };
        double double39 = org.apache.commons.math3.util.MathArrays.distance(doubleArray35, doubleArray38);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = line19.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1102230246251565E-16d, vector1D2, (-1.6159951507025987d), vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D43.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D45.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D47, vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = vector1D48.scalarMultiply((double) (-1L));
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = vector1D53.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = vector1D51.subtract((double) 97.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double60 = vector3D59.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D61.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double66 = vector3D64.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = vector3D68.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D65.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Line line72 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D61, vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D59, vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Line line74 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D56, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double77 = vector3D75.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = vector3D79.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = vector3D76.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D81);
        java.lang.Class<?> wildcardClass83 = vector3D76.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = vector3D76.scalarMultiply((double) 0.0f);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = line74.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray88 = vector2D87.toArray();
        boolean boolean89 = vector1D86.equals((java.lang.Object) doubleArray88);
        double double90 = vector1D54.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D86);
        double double91 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D46, vector1D86);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.5384395393292852d + "'", double60 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertNotNull(vector1D86);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertEquals((double) double90, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double91, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = orientedPoint3.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D8, vector1D9);
        double double11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D7, vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D17, vector1D18);
        double double20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D16, vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D13.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7, (double) ' ', vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D25, vector1D26);
        double double28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D24, vector1D26);
        double double29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D7, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D26, false);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint32 = orientedPoint31.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.Side side33 = intervalsSet4.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint31);
        org.junit.Assert.assertNotNull(intervalsSet4);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(subOrientedPoint32);
        org.junit.Assert.assertTrue("'" + side33 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side33.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        double double12 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D3, vector2D7);
        boolean boolean14 = vector2D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D17.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = vector2D15.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D15);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane23 = subLine22.copySelf();
        boolean boolean24 = subLine22.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = vector2D25.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D29.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double33 = vector2D28.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D28, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = vector2D36.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D40.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        double double44 = vector2D39.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, 0.0d);
        boolean boolean47 = line35.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line46);
        line35.setOriginOffset(0.0d);
        org.apache.commons.math3.geometry.partitioning.Side side50 = subLine22.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line35);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform51 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane52 = subLine22.applyTransform(euclidean2DTransform51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + side50 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side50.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint14 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet15 = orientedPoint14.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint16 = orientedPoint14.wholeHyperplane();
        try {
            boolean boolean17 = euclidean1DBSPTree10.insertCut((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(intervalsSet15);
        org.junit.Assert.assertNotNull(subOrientedPoint16);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        double double12 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D3, vector2D7);
        boolean boolean14 = vector2D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D17.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = vector2D15.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D23.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D27.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        double double31 = vector2D26.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D26, 0.0d);
        boolean boolean35 = vector2D26.equals((java.lang.Object) Double.NEGATIVE_INFINITY);
        org.apache.commons.math3.geometry.euclidean.twod.Line line36 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D15, vector2D26);
        double[] doubleArray37 = vector2D15.toArray();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 192.2171757448326d + "'", double1 == 192.2171757448326d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion5 = intervalsSet4.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine6 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane1, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = intervalsSet4.buildNew(euclidean1DBSPTree7);
        double double9 = intervalsSet4.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree11 = intervalsSet4.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = euclidean1DBSPTree11.getMinus();
        euclidean1DBSPTree0.insertInTree(euclidean1DBSPTree12, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree15 = euclidean1DBSPTree0.getParent();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion5);
        org.junit.Assert.assertNotNull(intervalsSet8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-31.0d) + "'", double9 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree11);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double2 = vector3D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double5 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D4.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        double double11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D1, vector3D10);
        double double12 = vector3D10.getDelta();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector8 = intervalsSet3.getBarycenter();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList9 = intervalsSet3.asList();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion10 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform11 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion12 = euclidean1DAbstractRegion10.applyTransform(euclidean1DTransform11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertNotNull(euclidean1DVector8);
        org.junit.Assert.assertNotNull(intervalList9);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException1 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D10.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 1, vector3D10 };
        org.apache.commons.math3.exception.MathInternalError mathInternalError17 = new org.apache.commons.math3.exception.MathInternalError(localizable3, objArray16);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathArithmeticException1, localizable2, objArray16);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray16);
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException22 = new org.apache.commons.math3.exception.DimensionMismatchException(35, 0);
        nullArgumentException19.addSuppressed((java.lang.Throwable) dimensionMismatchException22);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        double double5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D1, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double11 = vector3D10.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double17 = vector3D15.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D16.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Line line23 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D12, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Line line25 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D7, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double28 = vector3D26.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D27.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        java.lang.Class<?> wildcardClass34 = vector3D27.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D27.scalarMultiply((double) 0.0f);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = line25.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D1.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7071067811865475d + "'", double5 == 0.7071067811865475d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5384395393292852d + "'", double11 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector3D38);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double5 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D4.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Line line11 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Line line12 = line11.revert();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D13, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double18 = vector1D17.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D14.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = line11.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double24 = vector3D22.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        line11.reset(vector3D22, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D29.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double34 = vector3D32.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D36.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D33.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Line line40 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D29, vector3D39);
        double double41 = line11.distance(line40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D46, vector1D47);
        double double49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D45, vector1D47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = vector1D42.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = line11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D42);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(line12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector3D51);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D8.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 1, vector3D8 };
        org.apache.commons.math3.exception.MathInternalError mathInternalError15 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = mathIllegalStateException16.getContext();
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(exceptionContext17);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D28.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D32.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double36 = vector2D31.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        double double37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D27, vector2D31);
        boolean boolean38 = vector2D31.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray40 = vector2D39.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D39.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine46 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D31, vector2D39);
        line23.reset(vector2D39, (double) (short) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = vector2D49.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D52.normalize();
        boolean boolean54 = line23.contains(vector2D53);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane55 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet58 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion59 = intervalsSet58.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint60 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane55, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractRegion59);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane61 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet64 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion65 = intervalsSet64.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine66 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane61, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet64);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree67 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet68 = intervalsSet64.buildNew(euclidean1DBSPTree67);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector69 = intervalsSet64.getBarycenter();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList70 = intervalsSet64.asList();
        boolean boolean71 = euclidean1DAbstractRegion59.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet64);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine72 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line23, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractRegion59);
        double double73 = subLine72.getSize();
        double double74 = subLine72.getSize();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion59);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion65);
        org.junit.Assert.assertNotNull(intervalsSet68);
        org.junit.Assert.assertNotNull(euclidean1DVector69);
        org.junit.Assert.assertNotNull(intervalList70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + (-31.0d) + "'", double73 == (-31.0d));
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + (-31.0d) + "'", double74 == (-31.0d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 7.105427357601002E-15d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = notStrictlyPositiveException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double20 = vector3D18.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D22.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D19.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        java.lang.Class<?> wildcardClass26 = vector3D19.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D19.scalarMultiply((double) 0.0f);
        double double29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D17, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.5384395393292852d, vector3D7, (double) 100.0f, vector3D13, (-1.0d), vector3D19);
        double double31 = vector3D19.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double36 = vector3D35.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D37.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double42 = vector3D40.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D44.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D41.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Line line48 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D37, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D35, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Line line50 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D32, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double53 = vector3D51.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D55.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D52.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        double double59 = vector3D57.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D32.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        boolean boolean61 = vector3D19.equals((java.lang.Object) vector3D60);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.9999999999999999d + "'", double29 == 0.9999999999999999d);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.5384395393292852d + "'", double36 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion6 = intervalsSet5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine7 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree8 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet9 = intervalsSet5.buildNew(euclidean1DBSPTree8);
        double double10 = intervalsSet5.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = intervalsSet5.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D13.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        euclidean1DBSPTree12.setAttribute((java.lang.Object) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D19.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane24 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion28 = intervalsSet27.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree30 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet31 = intervalsSet27.buildNew(euclidean1DBSPTree30);
        double double32 = intervalsSet27.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree34 = intervalsSet27.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D35.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        euclidean1DBSPTree34.setAttribute((java.lang.Object) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D45.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        double double49 = vector2D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D15, 90.0d, vector2D19, (double) (-1.0f), vector2D37, (double) (-100.0f), vector2D48);
        org.apache.commons.math3.geometry.Space space51 = vector2D37.getSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = vector2D55.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = vector2D59.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        double double63 = vector2D58.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 10.000001f, vector2D37, 10.000000000000071d, vector2D53, 1.4210854715202004E-14d, vector2D62);
        boolean boolean65 = vector2D62.isInfinite();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion6);
        org.junit.Assert.assertNotNull(intervalsSet9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-31.0d) + "'", double10 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion28);
        org.junit.Assert.assertNotNull(intervalsSet31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-31.0d) + "'", double32 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space51);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) (short) 10);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane4 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion8 = intervalsSet7.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet11 = intervalsSet7.buildNew(euclidean1DBSPTree10);
        double double12 = intervalsSet7.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree14 = intervalsSet7.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree15 = euclidean1DBSPTree14.getMinus();
        boolean boolean16 = intervalsSet3.isEmpty(euclidean1DBSPTree14);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint17 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform18 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane19 = subOrientedPoint17.applyTransform(euclidean1DTransform18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion8);
        org.junit.Assert.assertNotNull(intervalsSet11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-31.0d) + "'", double12 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree14);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int[] intArray0 = new int[] {};
        int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, 0);
        int[] intArray7 = new int[] { 1, (byte) 100, 'a', (-1) };
        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray7, 0);
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray0, intArray9);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int[] intArray0 = new int[] {};
        int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, 0);
        int[] intArray6 = new int[] { (byte) 100, 100, (byte) 1 };
        int int7 = org.apache.commons.math3.util.MathArrays.distance1(intArray0, intArray6);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet14 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion15 = intervalsSet14.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine16 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree17 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = intervalsSet14.buildNew(euclidean1DBSPTree17);
        double double19 = intervalsSet14.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree21 = intervalsSet14.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D22.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        euclidean1DBSPTree21.setAttribute((java.lang.Object) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D28.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane33 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet36 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion37 = intervalsSet36.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine38 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane33, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet36);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree39 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet40 = intervalsSet36.buildNew(euclidean1DBSPTree39);
        double double41 = intervalsSet36.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree43 = intervalsSet36.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = vector2D44.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        euclidean1DBSPTree43.setAttribute((java.lang.Object) vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D50.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = vector2D54.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double58 = vector2D53.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D24, 90.0d, vector2D28, (double) (-1.0f), vector2D46, (double) (-100.0f), vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = vector2D57.negate();
        boolean boolean61 = vector2D57.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = vector2D7.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion15);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-31.0d) + "'", double19 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion37);
        org.junit.Assert.assertNotNull(intervalsSet40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-31.0d) + "'", double41 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(vector2D63);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        double double4 = vector3D3.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) Float.NaN, vector3D3, (-3.355333228520146d), vector3D8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 52L, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D6.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D2.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D15.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D21.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D17.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D12.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D12.scalarMultiply((double) 32L);
        double double31 = vector3D12.getNorm1();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) (-100.0f), (double) (byte) 10);
        double double3 = intervalsSet2.getSup();
        double double4 = intervalsSet2.getInf();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList5 = intervalsSet2.asList();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-100.0d) + "'", double4 == (-100.0d));
        org.junit.Assert.assertNotNull(intervalList5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion6 = intervalsSet5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine7 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree8 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet9 = intervalsSet5.buildNew(euclidean1DBSPTree8);
        double double10 = intervalsSet5.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = intervalsSet5.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D13.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        euclidean1DBSPTree12.setAttribute((java.lang.Object) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D19.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane24 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion28 = intervalsSet27.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree30 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet31 = intervalsSet27.buildNew(euclidean1DBSPTree30);
        double double32 = intervalsSet27.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree34 = intervalsSet27.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D35.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        euclidean1DBSPTree34.setAttribute((java.lang.Object) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D45.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        double double49 = vector2D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D15, 90.0d, vector2D19, (double) (-1.0f), vector2D37, (double) (-100.0f), vector2D48);
        double double51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D37);
        double[] doubleArray52 = vector2D0.toArray();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion6);
        org.junit.Assert.assertNotNull(intervalsSet9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-31.0d) + "'", double10 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion28);
        org.junit.Assert.assertNotNull(intervalsSet31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-31.0d) + "'", double32 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(4.9E-324d, 0.432029264952178d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray3 = vector2D2.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray3, orderDirection4, false, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = nonMonotonicSequenceException11.getDirection();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection20 = nonMonotonicSequenceException19.getDirection();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-3.355333228520146d), (java.lang.Number) (-1L), (int) 'a', orderDirection20, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection[] orderDirectionArray23 = new org.apache.commons.math3.util.MathArrays.OrderDirection[] { orderDirection1, orderDirection4, orderDirection12, orderDirection20 };
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray25 = vector2D24.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray25, orderDirection26, false, false);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderDirectionArray23, orderDirection26, false);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException32 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) orderDirectionArray23);
        org.junit.Assert.assertTrue("'" + orderDirection1 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection1.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(orderDirectionArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.9999999999999999d, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = vector2D3.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = vector2D7.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double11 = vector2D6.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D10.negate();
        double double13 = vector2D2.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D2.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        double double6 = vector2D0.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        double[] doubleArray7 = vector2D4.toArray();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        double double12 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D3, vector2D7);
        boolean boolean14 = vector2D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D17.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = vector2D15.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D15);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane23 = subLine22.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane24 = subLine22.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane25 = subLine22.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = vector2D26.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D30.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double34 = vector2D29.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Line line36 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D29, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = vector2D37.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D40.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D40, 0.0d);
        boolean boolean48 = line36.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line47);
        org.apache.commons.math3.geometry.euclidean.twod.Line line49 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D50.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = vector2D54.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double58 = vector2D53.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line60 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D53, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = vector2D61.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = vector2D65.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        double double69 = vector2D64.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Line line71 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D64, 0.0d);
        boolean boolean72 = line60.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line71);
        line60.setOriginOffset(0.0d);
        double[] doubleArray76 = new double[] {};
        double[] doubleArray79 = new double[] { 10.0d, '4' };
        double double80 = org.apache.commons.math3.util.MathArrays.distance(doubleArray76, doubleArray79);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray79);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray79);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = line60.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D82);
        org.apache.commons.math3.geometry.euclidean.twod.Line line84 = line60.getReverse();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = line49.intersection(line84);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine86 = line49.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane87 = subLine22.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line49);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane23);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane24);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertNotNull(line84);
        org.junit.Assert.assertNull(vector2D85);
        org.junit.Assert.assertNotNull(subLine86);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane87);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double5 = vector1D4.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D1.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = vector1D1.scalarMultiply((double) (byte) 10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D10, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D13, vector1D14);
        double double16 = vector1D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D18.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D22.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        double double26 = vector2D21.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D21, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D29.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = vector2D33.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        double double37 = vector2D32.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Line line39 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D32, 0.0d);
        boolean boolean40 = line28.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line39);
        line28.setOriginOffset(0.0d);
        double[] doubleArray44 = new double[] {};
        double[] doubleArray47 = new double[] { 10.0d, '4' };
        double double48 = org.apache.commons.math3.util.MathArrays.distance(doubleArray44, doubleArray47);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray47);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = line28.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1102230246251565E-16d, vector1D11, (-1.6159951507025987d), vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = vector1D52.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D53);
        double double55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D1, vector1D54);
        double double56 = vector1D54.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = vector1D54.getZero();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D57);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double5 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D4.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Line line11 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Line line12 = line11.revert();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D13, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double18 = vector1D17.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D14.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = line11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = line11.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double24 = vector3D22.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        line11.reset(vector3D22, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = line11.pointAt((double) 100L);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet33 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 100.0f, (double) (-1L));
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane34 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet37 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion38 = intervalsSet37.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine39 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane34, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet37);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree40 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet41 = intervalsSet37.buildNew(euclidean1DBSPTree40);
        double double42 = intervalsSet37.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree44 = intervalsSet37.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D45.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        euclidean1DBSPTree44.setAttribute((java.lang.Object) vector2D47);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree50 = null;
        euclidean1DBSPTree44.insertInTree(euclidean1DBSPTree50, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree53 = euclidean1DBSPTree44.getPlus();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet54 = intervalsSet33.buildNew(euclidean1DBSPTree44);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine55 = new org.apache.commons.math3.geometry.euclidean.threed.SubLine(line11, intervalsSet54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D56.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double61 = vector3D59.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D63.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D60.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Line line67 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D56, vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = line67.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = line11.closestPoint(line67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = vector3D70.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double75 = vector3D73.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D77.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = vector3D74.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D79);
        org.apache.commons.math3.geometry.euclidean.threed.Line line81 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D70, vector3D80);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = line81.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = line81.pointAt(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        java.lang.String str88 = vector3D87.toString();
        double double89 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D84, vector3D87);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D90 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D93 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        double double94 = vector3D93.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D95 = vector3D93.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D96 = vector3D90.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D95);
        double double97 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance(vector3D84, vector3D95);
        double double98 = line11.getAbscissa(vector3D95);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(line12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion38);
        org.junit.Assert.assertNotNull(intervalsSet41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-31.0d) + "'", double42 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree53);
        org.junit.Assert.assertNotNull(intervalsSet54);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "{0.3820514244; 0.5950098395; 0.7071067812}" + "'", str88.equals("{0.3820514244; 0.5950098395; 0.7071067812}"));
        org.junit.Assert.assertEquals((double) double89, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D90);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 1.0d + "'", double94 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D95);
        org.junit.Assert.assertNotNull(vector3D96);
        org.junit.Assert.assertEquals((double) double97, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + (-0.738687059576518d) + "'", double98 == (-0.738687059576518d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D4.scalarMultiply(52.0d);
        double double7 = vector1D6.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D9, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double14 = vector1D13.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = vector1D10.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D10.scalarMultiply((double) (byte) 10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D19, vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D22, vector1D23);
        double double25 = vector1D20.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D27.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = vector2D31.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D33);
        double double35 = vector2D30.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Line line37 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D30, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D38.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = vector2D42.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        double double46 = vector2D41.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Line line48 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D41, 0.0d);
        boolean boolean49 = line37.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line48);
        line37.setOriginOffset(0.0d);
        double[] doubleArray53 = new double[] {};
        double[] doubleArray56 = new double[] { 10.0d, '4' };
        double double57 = org.apache.commons.math3.util.MathArrays.distance(doubleArray53, doubleArray56);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = line37.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D59);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1102230246251565E-16d, vector1D20, (-1.6159951507025987d), vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = vector1D61.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D62);
        double double64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D10, vector1D63);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 'a', vector1D6, (double) 1L, vector1D10);
        try {
            org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.5707963267948966d, vector1D1, (double) 6, vector1D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double2 = vector3D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double6 = vector3D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D1.subtract(0.8304627863460217d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D1, vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double6 = vector1D5.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = vector1D2.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double9 = vector1D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.9999999999999999d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.scalarMultiply((double) (short) -1);
        double double14 = vector1D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.4E-45f), vector1D2);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        java.lang.String str4 = vector3D3.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D3.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D8.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D18.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D14.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D24.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D27.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D33.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D29.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D24.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double43 = vector3D41.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double46 = vector3D44.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double49 = vector3D47.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D51.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D48.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D53);
        double double55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D45, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Line line56 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D41, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D41.getZero();
        double double58 = vector3D38.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = vector3D8.add((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        double double60 = vector3D5.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.220446049250313E-16d, vector3D5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0.3820514244; 0.5950098395; 0.7071067812}" + "'", str4.equals("{0.3820514244; 0.5950098395; 0.7071067812}"));
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 13.606032382727053d + "'", double58 == 13.606032382727053d);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + (-1.0d) + "'", double60 == (-1.0d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.2005766322266866d, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.20057663222668642d + "'", double2 == 0.20057663222668642d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(13.606032382727053d, 2.2250738585072014E-308d, 52.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(10.000000000000071d, (-0.9999999999999999d), (-23));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = mathInternalError2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) ' ', (float) 10L, (float) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree11 = null;
        euclidean1DBSPTree10.insertInTree(euclidean1DBSPTree11, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D18, vector1D19);
        double double21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D17, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = vector1D14.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D23, vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double28 = vector1D27.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = vector1D24.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        double double30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D14, vector1D29);
        double double31 = vector1D29.getX();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree32 = euclidean1DBSPTree10.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.NEGATIVE_INFINITY + "'", double31 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree32);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D2.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D4.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D10.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D6.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D16.negate();
        double double18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D17);
        boolean boolean19 = vector3D17.isInfinite();
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math3.util.FastMath.cos((-4.845955853963567d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13317008640075995d + "'", double1 == 0.13317008640075995d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        line10.setOriginOffset(0.0d);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray29 = new double[] { 10.0d, '4' };
        double double30 = org.apache.commons.math3.util.MathArrays.distance(doubleArray26, doubleArray29);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = line10.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion34 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine35 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line10, euclidean1DRegion34);
        try {
            boolean boolean36 = subLine35.isEmpty();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D33);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 10.0d, '4' };
        double double4 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray3);
        double[] doubleArray5 = new double[] {};
        double[] doubleArray8 = new double[] { 10.0d, '4' };
        double double9 = org.apache.commons.math3.util.MathArrays.distance(doubleArray5, doubleArray8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray11 = vector2D10.toArray();
        double[] doubleArray12 = new double[] {};
        double[] doubleArray15 = new double[] { 10.0d, '4' };
        double double16 = org.apache.commons.math3.util.MathArrays.distance(doubleArray12, doubleArray15);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray11, doubleArray15);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray15, 0.0d);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray24 = new double[] { 10.0d, '4' };
        double double25 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray24);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray24);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray15, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray8, doubleArray28);
        try {
            double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray0, doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: no data");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        double double12 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D3, vector2D7);
        boolean boolean14 = vector2D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D17.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = vector2D15.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D15);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane23 = subLine22.copySelf();
        boolean boolean24 = subLine22.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = vector2D25.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D29.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double33 = vector2D28.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D28, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = vector2D36.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D40.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        double double44 = vector2D39.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, 0.0d);
        boolean boolean47 = line35.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line46);
        line35.setOriginOffset(0.0d);
        org.apache.commons.math3.geometry.partitioning.Side side50 = subLine22.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D52, vector1D53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D55, vector1D56);
        double double58 = vector1D53.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = vector2D60.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = vector2D64.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D66);
        double double68 = vector2D63.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Line line70 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D63, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = vector2D71.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D73);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = vector2D75.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D77);
        double double79 = vector2D74.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D78);
        org.apache.commons.math3.geometry.euclidean.twod.Line line81 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D74, 0.0d);
        boolean boolean82 = line70.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line81);
        line70.setOriginOffset(0.0d);
        double[] doubleArray86 = new double[] {};
        double[] doubleArray89 = new double[] { 10.0d, '4' };
        double double90 = org.apache.commons.math3.util.MathArrays.distance(doubleArray86, doubleArray89);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray89);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D92 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray89);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D93 = line70.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D92);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D94 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1102230246251565E-16d, vector1D53, (-1.6159951507025987d), vector1D93);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D95 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D96 = vector1D94.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D95);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D97 = vector1D96.getZero();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D99 = line35.getPointAt(vector1D97, 2.154434690031884d);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + side50 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side50.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + Double.POSITIVE_INFINITY + "'", double58 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertEquals((double) double79, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D93);
        org.junit.Assert.assertNotNull(vector1D95);
        org.junit.Assert.assertNotNull(vector1D96);
        org.junit.Assert.assertNotNull(vector1D97);
        org.junit.Assert.assertNotNull(vector2D99);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D12.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        double double16 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D7, vector2D11);
        boolean boolean18 = vector2D11.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray20 = vector2D19.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = vector2D21.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        double double25 = vector2D19.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine26 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane29 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet32 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion33 = intervalsSet32.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine34 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane29, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet32);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree35 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet36 = intervalsSet32.buildNew(euclidean1DBSPTree35);
        double double37 = intervalsSet32.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree39 = intervalsSet32.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D40.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        euclidean1DBSPTree39.setAttribute((java.lang.Object) vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = vector2D46.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane51 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet54 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion55 = intervalsSet54.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine56 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane51, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet54);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree57 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet58 = intervalsSet54.buildNew(euclidean1DBSPTree57);
        double double59 = intervalsSet54.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree61 = intervalsSet54.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = vector2D62.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D64);
        euclidean1DBSPTree61.setAttribute((java.lang.Object) vector2D64);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = vector2D68.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = vector2D72.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D74);
        double double76 = vector2D71.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D75);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D42, 90.0d, vector2D46, (double) (-1.0f), vector2D64, (double) (-100.0f), vector2D75);
        double double78 = vector2D42.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine79 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D3, vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = vector2D42.add(1.4210854715202004E-14d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double84 = vector2D82.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D83);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = vector2D83.normalize();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion33);
        org.junit.Assert.assertNotNull(intervalsSet36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-31.0d) + "'", double37 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion55);
        org.junit.Assert.assertNotNull(intervalsSet58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + (-31.0d) + "'", double59 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertEquals((double) double76, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + Double.POSITIVE_INFINITY + "'", double78 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertNotNull(vector2D83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + Double.NEGATIVE_INFINITY + "'", double84 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D85);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 34.999996f, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 47.423619990161086d + "'", double2 == 47.423619990161086d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        float[] floatArray3 = new float[] { 100.0f, (short) -1, (byte) 100 };
        float[] floatArray5 = new float[] { 0.0f };
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.equals(floatArray3, floatArray5);
        float[] floatArray7 = null;
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equals(floatArray5, floatArray7);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(Double.POSITIVE_INFINITY, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((-0.7853981633974483d), 1.5117813758585614d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int int2 = org.apache.commons.math3.util.FastMath.max(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 'a', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 52L);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane6 = subLine5.getHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = vector2D7.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double15 = vector2D10.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Line line17 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D18.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D22.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        double double26 = vector2D21.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D21, 0.0d);
        boolean boolean29 = line17.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane33 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet36 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion37 = intervalsSet36.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine38 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane33, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet36);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree39 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet40 = intervalsSet36.buildNew(euclidean1DBSPTree39);
        double double41 = intervalsSet36.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree43 = intervalsSet36.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = vector2D44.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        euclidean1DBSPTree43.setAttribute((java.lang.Object) vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D50.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane55 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet58 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion59 = intervalsSet58.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine60 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane55, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet58);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree61 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet62 = intervalsSet58.buildNew(euclidean1DBSPTree61);
        double double63 = intervalsSet58.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree65 = intervalsSet58.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = vector2D66.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D68);
        euclidean1DBSPTree65.setAttribute((java.lang.Object) vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = vector2D72.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D74);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = vector2D76.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D78);
        double double80 = vector2D75.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D79);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D46, 90.0d, vector2D50, (double) (-1.0f), vector2D68, (double) (-100.0f), vector2D79);
        double double82 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D31, vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.1415926535897927d, vector2D68);
        line17.translateToPoint(vector2D83);
        try {
            org.apache.commons.math3.geometry.partitioning.Side side85 = subLine5.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNull(euclidean2DHyperplane6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion37);
        org.junit.Assert.assertNotNull(intervalsSet40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-31.0d) + "'", double41 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion59);
        org.junit.Assert.assertNotNull(intervalsSet62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + (-31.0d) + "'", double63 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree65);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(Double.NaN, (double) 0.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D4, vector1D5);
        double double7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D3, vector1D5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = vector1D0.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D9, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double14 = vector1D13.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = vector1D10.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        double double16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D0, vector1D15);
        double double17 = vector1D15.getNorm1();
        double double18 = vector1D15.getX();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector20 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D15.add(15.869991054396957d, euclidean1DVector20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        long[] longArray4 = new long[] { (short) 1, '#', (short) 10 };
        long[] longArray8 = new long[] { (short) 1, '#', (short) 10 };
        long[] longArray12 = new long[] { (short) 1, '#', (short) 10 };
        long[] longArray16 = new long[] { (short) 1, '#', (short) 10 };
        long[] longArray20 = new long[] { (short) 1, '#', (short) 10 };
        long[][] longArray21 = new long[][] { longArray4, longArray8, longArray12, longArray16, longArray20 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray21);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray21);
        org.apache.commons.math3.exception.MathInternalError mathInternalError24 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) longArray21);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray21);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray21);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray21);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        double double12 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D3, vector2D7);
        boolean boolean14 = vector2D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D17.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = vector2D15.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D23.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D27.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        double double31 = vector2D26.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D26, 0.0d);
        boolean boolean35 = vector2D26.equals((java.lang.Object) Double.NEGATIVE_INFINITY);
        org.apache.commons.math3.geometry.euclidean.twod.Line line36 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D15, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = vector2D37.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D40.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D40, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = vector2D48.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = vector2D52.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D54);
        double double56 = vector2D51.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Line line58 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D51, 0.0d);
        boolean boolean59 = line47.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line58);
        boolean boolean60 = line36.isParallelTo(line47);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector8 = intervalsSet3.getBarycenter();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList9 = intervalsSet3.asList();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion10 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) (short) 10);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane14 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet17 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion18 = intervalsSet17.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine19 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane14, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet17);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree20 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet21 = intervalsSet17.buildNew(euclidean1DBSPTree20);
        double double22 = intervalsSet17.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree24 = intervalsSet17.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree25 = euclidean1DBSPTree24.getMinus();
        boolean boolean26 = intervalsSet13.isEmpty(euclidean1DBSPTree24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D30, vector1D31);
        double double33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D29, vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D39, vector1D40);
        double double42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D38, vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = vector1D35.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D29, (double) ' ', vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D47, vector1D48);
        double double50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D46, vector1D48);
        double double51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D29, vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint53 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D48, false);
        org.apache.commons.math3.geometry.partitioning.Side side54 = intervalsSet13.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D58, vector1D59);
        double double61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D57, vector1D59);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double69 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D67, vector1D68);
        double double70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D66, vector1D68);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = vector1D63.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D57, (double) ' ', vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D75, vector1D76);
        double double78 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D74, vector1D76);
        double double79 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D57, vector1D76);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint81 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D76, false);
        boolean boolean82 = orientedPoint53.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint81);
        orientedPoint81.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = orientedPoint81.getLocation();
        org.apache.commons.math3.geometry.partitioning.Side side85 = euclidean1DAbstractRegion10.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint81);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertNotNull(euclidean1DVector8);
        org.junit.Assert.assertNotNull(intervalList9);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion10);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion18);
        org.junit.Assert.assertNotNull(intervalsSet21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-31.0d) + "'", double22 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree24);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.POSITIVE_INFINITY + "'", double42 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + side54 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side54.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.POSITIVE_INFINITY + "'", double61 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.POSITIVE_INFINITY + "'", double70 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(vector1D75);
        org.junit.Assert.assertNotNull(vector1D76);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + Double.POSITIVE_INFINITY + "'", double78 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + Double.POSITIVE_INFINITY + "'", double79 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(vector1D84);
        org.junit.Assert.assertTrue("'" + side85 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side85.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathInternalError0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D28.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        double double32 = vector2D27.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D27, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D35.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = vector2D39.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        double double43 = vector2D38.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D38, 0.0d);
        boolean boolean46 = line34.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line45);
        line34.setOriginOffset(0.0d);
        double[] doubleArray50 = new double[] {};
        double[] doubleArray53 = new double[] { 10.0d, '4' };
        double double54 = org.apache.commons.math3.util.MathArrays.distance(doubleArray50, doubleArray53);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = line34.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Line line58 = line34.getReverse();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = line23.intersection(line58);
        double double60 = line58.getAngle();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(line58);
        org.junit.Assert.assertNull(vector2D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.141592653589793d + "'", double60 == 3.141592653589793d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(2.220446049250313E-16d);
        double double2 = vector1D1.getX();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.220446049250313E-16d + "'", double2 == 2.220446049250313E-16d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double2 = org.apache.commons.math3.util.FastMath.pow(3.1415926535897927d, 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.006276680299802d + "'", double2 == 31.006276680299802d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        boolean boolean25 = line10.contains(vector2D24);
        line10.setOriginOffset(0.5403023058681338d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = line10.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = line10.wholeHyperplane();
        double double30 = subLine29.getSize();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(line28);
        org.junit.Assert.assertNotNull(subLine29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 97);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math3.util.FastMath.abs(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.8115262724608532d, (double) 10.0f, 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        euclidean1DBSPTree10.setAttribute((java.lang.Object) vector2D13);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree16 = null;
        euclidean1DBSPTree10.insertInTree(euclidean1DBSPTree16, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree19 = euclidean1DBSPTree10.getPlus();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D24, vector1D25);
        double double27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D23, vector1D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = vector1D20.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D29, vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double34 = vector1D33.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D30.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        double double36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D20, vector1D35);
        double double37 = vector1D35.getX();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint39 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D35, true);
        try {
            boolean boolean40 = euclidean1DBSPTree10.insertCut((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree19);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.NEGATIVE_INFINITY + "'", double37 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.Space space4 = vector2D3.getSpace();
        double double5 = vector2D3.getNorm1();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(space4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D2, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double7 = vector1D6.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = vector1D3.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = vector1D3.scalarMultiply((double) (byte) 10);
        double double11 = vector1D10.getX();
        double double12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D1, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D17, vector1D18);
        double double20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D16, vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D13.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D22, vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double27 = vector1D26.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = vector1D23.add(0.5403023058681398d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        double double29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D13, vector1D28);
        double double30 = vector1D10.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet3.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet3.buildNew(euclidean1DBSPTree6);
        double double8 = intervalsSet3.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet14 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) (short) 10);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane15 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion19 = intervalsSet18.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine20 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane15, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree21 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = intervalsSet18.buildNew(euclidean1DBSPTree21);
        double double23 = intervalsSet18.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree25 = intervalsSet18.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree26 = euclidean1DBSPTree25.getMinus();
        boolean boolean27 = intervalsSet14.isEmpty(euclidean1DBSPTree25);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint28 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        try {
            org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree29 = euclidean1DBSPTree10.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-31.0d) + "'", double8 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion19);
        org.junit.Assert.assertNotNull(intervalsSet22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-31.0d) + "'", double23 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree25);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion5 = intervalsSet4.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine6 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane1, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = intervalsSet4.buildNew(euclidean1DBSPTree7);
        double double9 = intervalsSet4.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree11 = intervalsSet4.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = euclidean1DBSPTree11.getMinus();
        euclidean1DBSPTree0.insertInTree(euclidean1DBSPTree12, true);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane15 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion19 = intervalsSet18.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine20 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane15, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree21 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = intervalsSet18.buildNew(euclidean1DBSPTree21);
        double double23 = intervalsSet18.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree25 = intervalsSet18.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = vector2D26.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        euclidean1DBSPTree25.setAttribute((java.lang.Object) vector2D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D31.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double36 = vector3D34.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D35.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Line line42 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D31, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = line42.pointAt((double) (-1.0f));
        euclidean1DBSPTree25.setAttribute((java.lang.Object) line42);
        euclidean1DBSPTree12.insertInTree(euclidean1DBSPTree25, false);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion5);
        org.junit.Assert.assertNotNull(intervalsSet8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-31.0d) + "'", double9 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree11);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion19);
        org.junit.Assert.assertNotNull(intervalsSet22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-31.0d) + "'", double23 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D44);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        double double12 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D3, vector2D7);
        double[] doubleArray14 = vector2D3.toArray();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) (short) 10);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) (short) 10);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet9 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion10 = intervalsSet9.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane6, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet9);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = intervalsSet9.buildNew(euclidean1DBSPTree12);
        double double14 = intervalsSet9.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree16 = intervalsSet9.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree17 = euclidean1DBSPTree16.getMinus();
        boolean boolean18 = intervalsSet5.isEmpty(euclidean1DBSPTree16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D22, vector1D23);
        double double25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D21, vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D31, vector1D32);
        double double34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D30, vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D27.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D21, (double) ' ', vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D39, vector1D40);
        double double42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D38, vector1D40);
        double double43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D21, vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint45 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D40, false);
        org.apache.commons.math3.geometry.partitioning.Side side46 = intervalsSet5.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint45);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D50, vector1D51);
        double double53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D49, vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D59, vector1D60);
        double double62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D58, vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = vector1D55.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D58);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D49, (double) ' ', vector1D58);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double69 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D67, vector1D68);
        double double70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D66, vector1D68);
        double double71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D49, vector1D68);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint73 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D68, false);
        boolean boolean74 = orientedPoint45.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint73);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane75 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet78 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion79 = intervalsSet78.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine80 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane75, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet78);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree81 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet82 = intervalsSet78.buildNew(euclidean1DBSPTree81);
        double double83 = intervalsSet78.getSize();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList84 = intervalsSet78.asList();
        boolean boolean85 = intervalsSet78.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint86 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint45, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet78);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet89 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 100.0f, (double) (-1L));
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector90 = intervalsSet89.getBarycenter();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector91 = intervalsSet89.getBarycenter();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint92 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint45, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet89);
        boolean boolean93 = subOrientedPoint92.isEmpty();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane94 = intervalsSet2.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint92);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane95 = subOrientedPoint92.copySelf();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion10);
        org.junit.Assert.assertNotNull(intervalsSet13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-31.0d) + "'", double14 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree16);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.POSITIVE_INFINITY + "'", double42 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + side46 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side46.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + Double.POSITIVE_INFINITY + "'", double62 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.POSITIVE_INFINITY + "'", double70 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + Double.POSITIVE_INFINITY + "'", double71 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion79);
        org.junit.Assert.assertNotNull(intervalsSet82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + (-31.0d) + "'", double83 == (-31.0d));
        org.junit.Assert.assertNotNull(intervalList84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(euclidean1DVector90);
        org.junit.Assert.assertNotNull(euclidean1DVector91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNull(euclidean1DSubHyperplane94);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane95);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math3.geometry.euclidean.threed.Line line0 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Line line1 = new org.apache.commons.math3.geometry.euclidean.threed.Line(line0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math3.util.FastMath.acos(2.6392665614609125E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948701d + "'", double1 == 1.5707963267948701d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        double[] doubleArray2 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, '4' };
        double double6 = org.apache.commons.math3.util.MathArrays.distance(doubleArray2, doubleArray5);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 0.0d);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray15 = new double[] { 10.0d, '4' };
        double double16 = org.apache.commons.math3.util.MathArrays.distance(doubleArray12, doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(0.0d, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray9, doubleArray15);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray25 = new double[] { 10.0d, '4' };
        double double26 = org.apache.commons.math3.util.MathArrays.distance(doubleArray22, doubleArray25);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray25);
        double double28 = org.apache.commons.math3.util.MathArrays.distance(doubleArray9, doubleArray25);
        try {
            double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1641.5370845643422d + "'", double28 == 1641.5370845643422d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D23.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D27.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        double double31 = vector2D26.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D26, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = vector2D34.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D38.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        double double42 = vector2D37.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Line line44 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D37, 0.0d);
        boolean boolean45 = line33.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line44);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line33);
        boolean boolean47 = line21.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line33);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion6 = intervalsSet5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine7 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree8 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet9 = intervalsSet5.buildNew(euclidean1DBSPTree8);
        double double10 = intervalsSet5.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = intervalsSet5.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D13.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        euclidean1DBSPTree12.setAttribute((java.lang.Object) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D19.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane24 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion28 = intervalsSet27.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree30 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet31 = intervalsSet27.buildNew(euclidean1DBSPTree30);
        double double32 = intervalsSet27.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree34 = intervalsSet27.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D35.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        euclidean1DBSPTree34.setAttribute((java.lang.Object) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D45.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        double double49 = vector2D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D15, 90.0d, vector2D19, (double) (-1.0f), vector2D37, (double) (-100.0f), vector2D48);
        double double51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D37);
        double double52 = vector2D0.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray54 = vector2D53.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = vector2D55.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        double double59 = vector2D53.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        double double60 = vector2D53.getY();
        double double61 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion6);
        org.junit.Assert.assertNotNull(intervalsSet9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-31.0d) + "'", double10 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion28);
        org.junit.Assert.assertNotNull(intervalsSet31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-31.0d) + "'", double32 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.NEGATIVE_INFINITY + "'", double60 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = nonMonotonicSequenceException9.getDirection();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-3.355333228520146d), (java.lang.Number) (-1L), (int) 'a', orderDirection10, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-127), (java.lang.Number) 0.4196070356280701d, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number15 = nonMonotonicSequenceException14.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-127) + "'", number15.equals((-127)));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = nonMonotonicSequenceException9.getDirection();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-3.355333228520146d), (java.lang.Number) (-1L), (int) 'a', orderDirection10, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-127), (java.lang.Number) 0.4196070356280701d, (int) (byte) 0, orderDirection10, false);
        boolean boolean15 = nonMonotonicSequenceException14.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int[] intArray4 = new int[] { 1, (byte) 100, 'a', (-1) };
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4, 0);
        int[] intArray11 = new int[] { 1, (byte) 100, 'a', (-1) };
        int[] intArray13 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11, 0);
        int int14 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray6, intArray11);
        int[] intArray16 = org.apache.commons.math3.util.MathArrays.copyOf(intArray6, (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection0 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray2 = vector2D1.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray2, orderDirection3, false, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = nonMonotonicSequenceException10.getDirection();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection19 = nonMonotonicSequenceException18.getDirection();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException21 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-3.355333228520146d), (java.lang.Number) (-1L), (int) 'a', orderDirection19, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection[] orderDirectionArray22 = new org.apache.commons.math3.util.MathArrays.OrderDirection[] { orderDirection0, orderDirection3, orderDirection11, orderDirection19 };
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection25 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray24, orderDirection25, false, false);
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderDirectionArray22, orderDirection25, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection[] orderDirectionArray31 = new org.apache.commons.math3.util.MathArrays.OrderDirection[] { orderDirection25 };
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray33 = vector2D32.toArray();
        double[] doubleArray34 = new double[] {};
        double[] doubleArray37 = new double[] { 10.0d, '4' };
        double double38 = org.apache.commons.math3.util.MathArrays.distance(doubleArray34, doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray33, doubleArray37);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray37, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray45 = vector2D44.toArray();
        double[] doubleArray46 = new double[] {};
        double[] doubleArray49 = new double[] { 10.0d, '4' };
        double double50 = org.apache.commons.math3.util.MathArrays.distance(doubleArray46, doubleArray49);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray45, doubleArray49);
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray49, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray49);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray37, doubleArray49);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException66 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection67 = nonMonotonicSequenceException66.getDirection();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException69 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-3.355333228520146d), (java.lang.Number) (-1L), (int) 'a', orderDirection67, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException71 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-127), (java.lang.Number) 0.4196070356280701d, (int) (byte) 0, orderDirection67, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray37, orderDirection67, true);
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.isMonotonic(orderDirectionArray31, orderDirection67, true);
        org.junit.Assert.assertTrue("'" + orderDirection0 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection0.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(orderDirectionArray22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(orderDirectionArray31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection67.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D8.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D12.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        double double16 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D7, vector2D11);
        boolean boolean18 = vector2D11.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray20 = vector2D19.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = vector2D21.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        double double25 = vector2D19.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine26 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane29 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet32 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion33 = intervalsSet32.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine34 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane29, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet32);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree35 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet36 = intervalsSet32.buildNew(euclidean1DBSPTree35);
        double double37 = intervalsSet32.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree39 = intervalsSet32.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D40.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        euclidean1DBSPTree39.setAttribute((java.lang.Object) vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = vector2D46.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane51 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet54 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion55 = intervalsSet54.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine56 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane51, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet54);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree57 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet58 = intervalsSet54.buildNew(euclidean1DBSPTree57);
        double double59 = intervalsSet54.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree61 = intervalsSet54.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = vector2D62.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D64);
        euclidean1DBSPTree61.setAttribute((java.lang.Object) vector2D64);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = vector2D68.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = vector2D72.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D74);
        double double76 = vector2D71.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D75);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D42, 90.0d, vector2D46, (double) (-1.0f), vector2D64, (double) (-100.0f), vector2D75);
        double double78 = vector2D42.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine79 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D3, vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = vector2D42.add(1.4210854715202004E-14d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        double double83 = vector2D82.getNorm1();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion33);
        org.junit.Assert.assertNotNull(intervalsSet36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-31.0d) + "'", double37 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion55);
        org.junit.Assert.assertNotNull(intervalsSet58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + (-31.0d) + "'", double59 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertEquals((double) double76, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + Double.POSITIVE_INFINITY + "'", double78 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + Double.POSITIVE_INFINITY + "'", double83 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-127), (java.lang.Number) 2.9982229502979694d, false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        double double3 = vector3D2.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D2.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.scalarMultiply(0.0d);
        double double8 = vector3D7.getX();
        boolean boolean9 = vector3D2.equals((java.lang.Object) vector3D7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        double[] doubleArray2 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, '4' };
        double double6 = org.apache.commons.math3.util.MathArrays.distance(doubleArray2, doubleArray5);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 0.0d);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray15 = new double[] { 10.0d, '4' };
        double double16 = org.apache.commons.math3.util.MathArrays.distance(doubleArray12, doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(0.0d, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray9, doubleArray15);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray24 = new double[] { 10.0d, '4' };
        double double25 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray27 = vector2D26.toArray();
        double[] doubleArray28 = new double[] {};
        double[] doubleArray31 = new double[] { 10.0d, '4' };
        double double32 = org.apache.commons.math3.util.MathArrays.distance(doubleArray28, doubleArray31);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray27, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray31, 0.0d);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray40 = new double[] { 10.0d, '4' };
        double double41 = org.apache.commons.math3.util.MathArrays.distance(doubleArray37, doubleArray40);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray40);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray31, doubleArray40);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray24, doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray15, doubleArray24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray49 = vector2D48.toArray();
        double[] doubleArray50 = org.apache.commons.math3.util.MathArrays.scale(0.0d, doubleArray49);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray24, doubleArray49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray53 = vector2D52.toArray();
        double[] doubleArray54 = new double[] {};
        double[] doubleArray57 = new double[] { 10.0d, '4' };
        double double58 = org.apache.commons.math3.util.MathArrays.distance(doubleArray54, doubleArray57);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray53, doubleArray57);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray57, 0.0d);
        double[] doubleArray63 = new double[] {};
        double[] doubleArray66 = new double[] { 10.0d, '4' };
        double double67 = org.apache.commons.math3.util.MathArrays.distance(doubleArray63, doubleArray66);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray66);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray66);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray57, doubleArray66);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray24, doubleArray66);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        boolean boolean25 = line10.contains(vector2D24);
        line10.setOriginOffset(0.5403023058681338d);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = line10.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = line10.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree31 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((java.lang.Object) vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D30.getZero();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = vector2D33.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = vector2D37.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D40.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        double double46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D36, vector2D40);
        boolean boolean47 = vector2D40.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray49 = vector2D48.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D50.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        double double54 = vector2D48.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine55 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D40, vector2D48);
        boolean boolean56 = vector1D32.equals((java.lang.Object) vector2D40);
        line10.translateToPoint(vector2D40);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(line28);
        org.junit.Assert.assertNotNull(subLine29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D3, vector1D4);
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D2, vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D12, vector1D13);
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D11, vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D8.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D2, (double) ' ', vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D20, vector1D21);
        double double23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D19, vector1D21);
        double double24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D2, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint26 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, false);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane27 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet30 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion31 = intervalsSet30.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine32 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane27, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet30);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion33 = subLine32.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint34 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint26, euclidean1DRegion33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = orientedPoint26.getLocation();
        orientedPoint26.revertSelf();
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion31);
        org.junit.Assert.assertNotNull(euclidean1DRegion33);
        org.junit.Assert.assertNotNull(vector1D35);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.007323524336242976d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8) + "'", int1 == (-8));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D11.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D15.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 0.0d);
        boolean boolean22 = line10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        boolean boolean25 = line10.contains(vector2D24);
        line10.setOriginOffset(0.5403023058681338d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray29 = vector2D28.toArray();
        double[] doubleArray30 = new double[] {};
        double[] doubleArray33 = new double[] { 10.0d, '4' };
        double double34 = org.apache.commons.math3.util.MathArrays.distance(doubleArray30, doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray29, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray33, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane42 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet45 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion46 = intervalsSet45.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine47 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane42, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet45);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree48 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet49 = intervalsSet45.buildNew(euclidean1DBSPTree48);
        double double50 = intervalsSet45.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree52 = intervalsSet45.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = vector2D53.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        euclidean1DBSPTree52.setAttribute((java.lang.Object) vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = vector2D59.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane64 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet67 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion68 = intervalsSet67.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine69 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane64, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet67);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree70 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet71 = intervalsSet67.buildNew(euclidean1DBSPTree70);
        double double72 = intervalsSet67.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree74 = intervalsSet67.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = vector2D75.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D77);
        euclidean1DBSPTree74.setAttribute((java.lang.Object) vector2D77);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = vector2D81.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D83);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = vector2D85.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D87);
        double double89 = vector2D84.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D88);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D55, 90.0d, vector2D59, (double) (-1.0f), vector2D77, (double) (-100.0f), vector2D88);
        double double91 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D40, vector2D77);
        org.apache.commons.math3.geometry.euclidean.twod.Line line92 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D93 = line10.intersection(line92);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet94 = line92.wholeSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion46);
        org.junit.Assert.assertNotNull(intervalsSet49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-31.0d) + "'", double50 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion68);
        org.junit.Assert.assertNotNull(intervalsSet71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + (-31.0d) + "'", double72 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertNotNull(vector2D83);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertNotNull(vector2D85);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertNotNull(vector2D88);
        org.junit.Assert.assertEquals((double) double89, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double91, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D93);
        org.junit.Assert.assertNotNull(polygonsSet94);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double1 = org.apache.commons.math3.util.FastMath.cos((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013388202148675738d + "'", double1 == 0.013388202148675738d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double2 = vector3D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double5 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double8 = vector3D6.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D7.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D4, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Line line15 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine16 = line15.wholeLine();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double19 = vector3D17.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double22 = vector3D20.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double25 = vector3D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D27.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D24.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        double double31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D21, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Line line32 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D17, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine33 = line32.wholeLine();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D37.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D46.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double54 = vector3D52.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D56.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = vector3D53.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        java.lang.Class<?> wildcardClass60 = vector3D53.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D53.scalarMultiply((double) 0.0f);
        double double63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D51, vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.5384395393292852d, vector3D41, (double) 100.0f, vector3D47, (-1.0d), vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line66 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D47, vector3D65);
        boolean boolean67 = line32.isSimilarTo(line66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        double double69 = vector1D68.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = line66.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D68);
        boolean boolean71 = line15.isSimilarTo(line66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double74 = vector3D72.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D76.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D73.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D78);
        double double80 = vector3D78.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = vector3D81.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D92 = vector3D87.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D91);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D93 = vector3D83.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D92);
        double double94 = vector3D92.getY();
        line66.reset(vector3D78, vector3D92);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subLine16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subLine33);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.9999999999999999d + "'", double63 == 0.9999999999999999d);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(vector3D92);
        org.junit.Assert.assertNotNull(vector3D93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + (-4.845955853963567d) + "'", double94 == (-4.845955853963567d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = vector1D1.scalarMultiply((double) (-1L));
        java.text.NumberFormat numberFormat5 = null;
        java.lang.String str6 = vector1D1.toString(numberFormat5);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = orientedPoint8.getLocation();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{(-Infinity)}" + "'", str6.equals("{(-Infinity)}"));
        org.junit.Assert.assertNotNull(vector1D9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double5 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D4.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Line line11 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D10);
        double double12 = vector3D10.getX();
        boolean boolean13 = vector3D10.isNaN();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 10.000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9578497723365d + "'", double1 == 572.9578497723365d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        double[] doubleArray2 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, '4' };
        double double6 = org.apache.commons.math3.util.MathArrays.distance(doubleArray2, doubleArray5);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 0.0d);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray15 = new double[] { 10.0d, '4' };
        double double16 = org.apache.commons.math3.util.MathArrays.distance(doubleArray12, doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(0.0d, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray9, doubleArray15);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray24 = new double[] { 10.0d, '4' };
        double double25 = org.apache.commons.math3.util.MathArrays.distance(doubleArray21, doubleArray24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray27 = vector2D26.toArray();
        double[] doubleArray28 = new double[] {};
        double[] doubleArray31 = new double[] { 10.0d, '4' };
        double double32 = org.apache.commons.math3.util.MathArrays.distance(doubleArray28, doubleArray31);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray27, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray31, 0.0d);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray40 = new double[] { 10.0d, '4' };
        double double41 = org.apache.commons.math3.util.MathArrays.distance(doubleArray37, doubleArray40);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray40);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray31, doubleArray40);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray24, doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray15, doubleArray24);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double2 = org.apache.commons.math3.util.Precision.round(0.9999999958776927d, (-8));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        double double4 = vector3D3.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double10 = vector3D8.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D9.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Line line16 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D5, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D3, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Line line18 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double24 = vector3D22.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D26.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D23.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Line line30 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D19, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Line line31 = line30.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = line18.closestPoint(line31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.Space space36 = vector3D35.getSpace();
        boolean boolean37 = line31.contains(vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = line31.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D39.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double44 = vector3D42.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D46.scalarMultiply(0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D43.add(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Line line50 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D39, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = line31.intersection(line50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = line31.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, 0.7853981633974483d);
        java.lang.String str56 = vector3D55.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D55.negate();
        boolean boolean58 = line31.contains(vector3D55);
        boolean boolean59 = vector3D55.isInfinite();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5384395393292852d + "'", double4 == 0.5384395393292852d);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(line31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(space36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "{0.3820514244; 0.5950098395; 0.7071067812}" + "'", str56.equals("{0.3820514244; 0.5950098395; 0.7071067812}"));
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(1.2005766322266866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0957082787980963d + "'", double1 == 1.0957082787980963d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 10, 2.99822295029797d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D11.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        java.lang.Object[] objArray17 = new java.lang.Object[] { (byte) 1, vector3D11 };
        org.apache.commons.math3.exception.MathInternalError mathInternalError18 = new org.apache.commons.math3.exception.MathInternalError(localizable4, objArray17);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathArithmeticException2, localizable3, objArray17);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray17);
        org.apache.commons.math3.exception.MathInternalError mathInternalError21 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray17);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext22 = mathInternalError21.getContext();
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext22);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.7853981633974483d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) 'a', (int) ' ');
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) dimensionMismatchException3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) (short) 10);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane3 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet6 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion7 = intervalsSet6.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine8 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = intervalsSet6.buildNew(euclidean1DBSPTree9);
        double double11 = intervalsSet6.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree13 = intervalsSet6.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree14 = euclidean1DBSPTree13.getMinus();
        boolean boolean15 = intervalsSet2.isEmpty(euclidean1DBSPTree13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D19, vector1D20);
        double double22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D18, vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D28, vector1D29);
        double double31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D27, vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D24.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D18, (double) ' ', vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D36, vector1D37);
        double double39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D35, vector1D37);
        double double40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D18, vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint42 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D37, false);
        org.apache.commons.math3.geometry.partitioning.Side side43 = intervalsSet2.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D47, vector1D48);
        double double50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D46, vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double58 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D56, vector1D57);
        double double59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D55, vector1D57);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = vector1D52.add(2.220446049250313E-16d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D55);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D46, (double) ' ', vector1D55);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NEGATIVE_INFINITY;
        double double66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D64, vector1D65);
        double double67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D63, vector1D65);
        double double68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D46, vector1D65);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint70 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D65, false);
        boolean boolean71 = orientedPoint42.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint70);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane72 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet75 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion76 = intervalsSet75.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine77 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane72, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet75);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree78 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet79 = intervalsSet75.buildNew(euclidean1DBSPTree78);
        double double80 = intervalsSet75.getSize();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList81 = intervalsSet75.asList();
        boolean boolean82 = intervalsSet75.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint83 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint42, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet75);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet86 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) 100.0f, (double) (-1L));
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector87 = intervalsSet86.getBarycenter();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector88 = intervalsSet86.getBarycenter();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint89 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint42, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet86);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint90 = orientedPoint42.wholeHyperplane();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion7);
        org.junit.Assert.assertNotNull(intervalsSet10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-31.0d) + "'", double11 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree13);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.POSITIVE_INFINITY + "'", double22 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + side43 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side43.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.POSITIVE_INFINITY + "'", double67 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.POSITIVE_INFINITY + "'", double68 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion76);
        org.junit.Assert.assertNotNull(intervalsSet79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + (-31.0d) + "'", double80 == (-31.0d));
        org.junit.Assert.assertNotNull(intervalList81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(euclidean1DVector87);
        org.junit.Assert.assertNotNull(euclidean1DVector88);
        org.junit.Assert.assertNotNull(subOrientedPoint90);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray1 = vector2D0.toArray();
        double[] doubleArray2 = new double[] {};
        double[] doubleArray5 = new double[] { 10.0d, '4' };
        double double6 = org.apache.commons.math3.util.MathArrays.distance(doubleArray2, doubleArray5);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray1, doubleArray5);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 0.0d);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray15 = new double[] { 10.0d, '4' };
        double double16 = org.apache.commons.math3.util.MathArrays.distance(doubleArray12, doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray15);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(0.0d, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray9, doubleArray15);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray25 = new double[] { 10.0d, '4' };
        double double26 = org.apache.commons.math3.util.MathArrays.distance(doubleArray22, doubleArray25);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray25);
        double double28 = org.apache.commons.math3.util.MathArrays.distance(doubleArray9, doubleArray25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        double[] doubleArray30 = vector2D29.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection31 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray30, orderDirection31, false, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection35 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray30, orderDirection35, false);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray25, orderDirection35, true);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1641.5370845643422d + "'", double28 == 1641.5370845643422d);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((-1.0d), 47.423619990161086d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((java.lang.Object) vector1D0);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.getZero();
        boolean boolean3 = vector1D2.isNaN();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 100, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = nonMonotonicSequenceException9.getDirection();
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-3.355333228520146d), (java.lang.Number) (-1L), (int) 'a', orderDirection10, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-127), (java.lang.Number) 0.4196070356280701d, (int) (byte) 0, orderDirection10, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection15 = nonMonotonicSequenceException14.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D0.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D4.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        double double8 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = vector2D3.getNormSq();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet14 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion15 = intervalsSet14.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine16 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree17 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = intervalsSet14.buildNew(euclidean1DBSPTree17);
        double double19 = intervalsSet14.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree21 = intervalsSet14.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D22.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        euclidean1DBSPTree21.setAttribute((java.lang.Object) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D28.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane33 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet36 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) ' ', (double) 1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion37 = intervalsSet36.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine38 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane33, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet36);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree39 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet40 = intervalsSet36.buildNew(euclidean1DBSPTree39);
        double double41 = intervalsSet36.getSize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree43 = intervalsSet36.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = vector2D44.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        euclidean1DBSPTree43.setAttribute((java.lang.Object) vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D50.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = vector2D54.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double58 = vector2D53.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0d, vector2D24, 90.0d, vector2D28, (double) (-1.0f), vector2D46, (double) (-100.0f), vector2D57);
        org.apache.commons.math3.geometry.Space space60 = vector2D46.getSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = vector2D46.scalarMultiply(1.8115262724608532d);
        double double63 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        double[] doubleArray64 = vector2D46.toArray();
        double[] doubleArray66 = new double[] {};
        double[] doubleArray69 = new double[] { 10.0d, '4' };
        double double70 = org.apache.commons.math3.util.MathArrays.distance(doubleArray66, doubleArray69);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((-31.0d), doubleArray69);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray69);
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray64, doubleArray69);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion15);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-31.0d) + "'", double19 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion37);
        org.junit.Assert.assertNotNull(intervalsSet40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-31.0d) + "'", double41 == (-31.0d));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space60);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
    }
}

