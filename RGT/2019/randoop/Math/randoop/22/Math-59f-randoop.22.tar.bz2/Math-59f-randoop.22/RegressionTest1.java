import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.903487555036127d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1469807045859253d + "'", double1 == 3.1469807045859253d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 23, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-7512596943621558861L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn5();
        boolean boolean6 = dfp5.isNaN();
        boolean boolean7 = dfp5.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn5();
        boolean boolean11 = dfp10.isNaN();
        int int12 = dfp10.log10();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField14.setRoundingMode(roundingMode15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField18.setRoundingMode(roundingMode19);
        dfpField14.setRoundingMode(roundingMode19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField14.getSqr3();
        dfpField14.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField14.newDfp((int) (byte) 0);
        boolean boolean28 = dfp10.greaterThan(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = org.apache.commons.math.dfp.DfpField.computeLn(dfp2, dfp5, dfp27);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getLn5();
        boolean boolean36 = dfp35.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getPi();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeExp(dfp32, dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance((double) 0.29876113f);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode46 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField45.setRoundingMode(roundingMode46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode50 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField49.setRoundingMode(roundingMode50);
        dfpField45.setRoundingMode(roundingMode50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField45.getZero();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode56 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField55.setRoundingMode(roundingMode56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode60 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField59.setRoundingMode(roundingMode60);
        dfpField55.setRoundingMode(roundingMode60);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField55.getZero();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getLn5();
        boolean boolean69 = dfp68.isNaN();
        int int70 = dfp68.intValue();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp65.add(dfp68);
        org.apache.commons.math.dfp.Dfp dfp72 = org.apache.commons.math.dfp.DfpField.computeExp(dfp53, dfp65);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp43.newInstance(dfp65);
        java.lang.String str74 = dfp43.toString();
        org.apache.commons.math.dfp.Dfp dfp75 = org.apache.commons.math.dfp.Dfp.copysign(dfp27, dfp43);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + roundingMode46 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode46.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode50 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode50.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + roundingMode56 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode56.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode60 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode60.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2 + "'", int70 == 2);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "0.29876112937925" + "'", str74.equals("0.29876112937925"));
        org.junit.Assert.assertNotNull(dfp75);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance("1.609437912434");
        int int10 = dfp9.log10();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn5();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        dfpField16.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.newInstance(97L);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3333333333333335d + "'", double1 == 1.3333333333333335d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.4005588830367479d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4005588830367479d + "'", double1 == 0.4005588830367479d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits((int) 'a');
        int int4 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        long long1 = org.apache.commons.math.util.FastMath.round((-6.799711455220379d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-7L) + "'", long1 == (-7L));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        int int12 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((long) (short) 100);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getESplit();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.getE();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField24.setRoundingMode(roundingMode25);
        dfpField20.setRoundingMode(roundingMode25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getLn5();
        boolean boolean34 = dfp33.isNaN();
        int int35 = dfp33.intValue();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.add(dfp33);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp38);
        boolean boolean40 = dfp12.lessThan(dfp39);
        int int41 = dfp12.classify();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.tan(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        double double2 = mersenneTwister0.nextGaussian();
//        int int4 = mersenneTwister0.nextInt(10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2855324776669012511L) + "'", long1 == (-2855324776669012511L));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7155433035316402d + "'", double2 == 0.7155433035316402d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1720387314);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.26581528556139d + "'", double1 == 21.26581528556139d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField7.setRoundingMode(roundingMode8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        dfpField7.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn5();
        boolean boolean20 = dfp19.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField22.setRoundingMode(roundingMode23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField26.setRoundingMode(roundingMode27);
        dfpField22.setRoundingMode(roundingMode27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp19.divide(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp16.divide(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getLn5();
        boolean boolean36 = dfp35.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode43 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField42.setRoundingMode(roundingMode43);
        dfpField38.setRoundingMode(roundingMode43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp35.divide(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp32.multiply(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp48.getOne();
        boolean boolean50 = dfp5.unequal(dfp49);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode43 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode43.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(4.406570493076975d);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(0);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn5();
        boolean boolean15 = dfp14.isNaN();
        int int16 = dfp14.intValue();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.add(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.nextAfter(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField26.setRoundingMode(roundingMode27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode31 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField30.setRoundingMode(roundingMode31);
        dfpField26.setRoundingMode(roundingMode31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField26.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField26.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance("0.29876112937925");
        org.apache.commons.math.dfp.Dfp dfp40 = dfp24.subtract(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField41 = dfp39.getField();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp(0);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode31 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode31.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpField41);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.1331484530668263d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7137180947289343d + "'", double1 == 1.7137180947289343d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        dfpField1.setIEEEFlagsBits(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) -1);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getESplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        int int3 = mersenneTwister1.nextInt(1778);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1705 + "'", int3 == 1705);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        byte[] byteArray2 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray2);
        double double4 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.29876114458966163d + "'", double4 == 0.29876114458966163d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 0, (float) (byte) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("0.29876112937925");
        double[] doubleArray15 = dfp12.toSplitDouble();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed((int) (byte) 2);
        mersenneTwister1.setSeed(2L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        int[] intArray11 = new int[] { (short) 10, (short) -1 };
        mersenneTwister8.setSeed(intArray11);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        mersenneTwister1.setSeed(intArray11);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0986122886681098d, 0.4342944819032518d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0986122886681098d + "'", double2 == 1.0986122886681098d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.sinh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        dfpField1.setIEEEFlagsBits(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) -1);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getESplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance(0);
        int int16 = dfp15.log10();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.048147073968205d + "'", double1 == 1.048147073968205d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10000L, (float) 3L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10000.0f + "'", float2 == 10000.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.66827237527655d + "'", double1 == 43.66827237527655d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getOne();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) Double.NEGATIVE_INFINITY, number7, true);
        boolean boolean10 = numberIsTooSmallException9.getBoundIsAllowed();
        java.lang.Number number11 = numberIsTooSmallException9.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + Double.NEGATIVE_INFINITY + "'", number11.equals(Double.NEGATIVE_INFINITY));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn5();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.DfpField.computeExp(dfp2, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((double) 0.29876113f);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField19.setRoundingMode(roundingMode20);
        dfpField15.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField25.setRoundingMode(roundingMode26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField29.setRoundingMode(roundingMode30);
        dfpField25.setRoundingMode(roundingMode30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getLn5();
        boolean boolean39 = dfp38.isNaN();
        int int40 = dfp38.intValue();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp35.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp35);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp13.newInstance(dfp35);
        org.apache.commons.math.dfp.Dfp dfp44 = new org.apache.commons.math.dfp.Dfp(dfp13);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = new org.apache.commons.math.dfp.Dfp(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField52 = dfp51.getField();
        dfpField52.setIEEEFlagsBits(10000);
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField52.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray56 = dfpField52.getLn2Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpField52);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertNotNull(dfpArray56);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn5();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        dfpField16.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = dfp26.getField();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.getOne();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getLn5();
        boolean boolean37 = dfp36.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getPi();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.newInstance(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getPi();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.ceil();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getLn5();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.newInstance(2.718281828459045d);
        boolean boolean51 = dfp45.greaterThan(dfp48);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp45.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp55.floor();
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.DfpField.computeLn(dfp33, dfp40, dfp55);
        boolean boolean58 = dfp26.lessThan(dfp55);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpField27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = new org.apache.commons.math.dfp.Dfp(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField52 = dfp51.getField();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.rint();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpField52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        boolean boolean12 = dfp10.equals((java.lang.Object) (byte) 100);
        int int13 = dfp10.log10K();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn5();
        boolean boolean17 = dfp16.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField19.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField23.setRoundingMode(roundingMode24);
        dfpField19.setRoundingMode(roundingMode24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp16.divide(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance(2.718281828459045d);
        boolean boolean34 = dfp27.unequal(dfp31);
        boolean boolean35 = dfp10.unequal(dfp27);
        org.apache.commons.math.dfp.Dfp dfp38 = null;
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getOne();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getOne();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode47 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField46.setRoundingMode(roundingMode47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp44.add(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.floor();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.multiply(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp27.dotrap((int) (short) 10, "", dfp38, dfp51);
        java.lang.String str54 = dfp27.toString();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + roundingMode47 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode47.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "0." + "'", str54.equals("0."));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn5();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        dfpField16.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = dfp24.getField();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField29.setRoundingMode(roundingMode30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField33.setRoundingMode(roundingMode34);
        dfpField29.setRoundingMode(roundingMode34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getLn5();
        boolean boolean43 = dfp42.isNaN();
        int int44 = dfp42.intValue();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.add(dfp42);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp42.negate();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.negate();
        boolean boolean48 = dfp24.greaterThan(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp50 = dfp46.add(dfp49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpField27);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(1.0077096067805478d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.divide(4);
        double double19 = dfp16.toDouble();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.007709606781d + "'", double19 == 1.007709606781d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn5();
        boolean boolean15 = dfp14.isNaN();
        int int16 = dfp14.intValue();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.add(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.nextAfter(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField26.setRoundingMode(roundingMode27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode31 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField30.setRoundingMode(roundingMode31);
        dfpField26.setRoundingMode(roundingMode31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField26.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField26.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance("0.29876112937925");
        org.apache.commons.math.dfp.Dfp dfp40 = dfp24.subtract(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode31 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode31.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn2();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 10);
        dfpField1.setIEEEFlagsBits((-4));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (-0.28406743513508276d), number7, false);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16, number11, false);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (byte) -1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) (short) -1);
        java.lang.Number number6 = notStrictlyPositiveException5.getMin();
        java.lang.Number number7 = notStrictlyPositiveException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException5.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) Double.NEGATIVE_INFINITY, number10, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (byte) 2, (java.lang.Number) 0.1240944887001123d, false);
        java.lang.Throwable throwable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.exception.MathRuntimeException(throwable17, localizable18, localizable19, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = mathRuntimeException26.getSpecificPattern();
        java.lang.Throwable[] throwableArray28 = mathRuntimeException26.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField32.setRoundingMode(roundingMode33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode37 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField36.setRoundingMode(roundingMode37);
        dfpField32.setRoundingMode(roundingMode37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField32.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField32.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField32.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable8, localizable30, (java.lang.Object[]) dfpArray42);
        java.lang.Throwable throwable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException53 = new org.apache.commons.math.exception.MathRuntimeException(throwable44, localizable45, localizable46, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = mathRuntimeException53.getSpecificPattern();
        java.lang.Throwable[] throwableArray55 = mathRuntimeException53.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable56, (java.lang.Number) (short) -1);
        java.lang.Number number59 = notStrictlyPositiveException58.getMin();
        mathRuntimeException53.addSuppressed((java.lang.Throwable) notStrictlyPositiveException58);
        org.apache.commons.math.exception.util.Localizable localizable61 = notStrictlyPositiveException58.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable62, (java.lang.Number) (short) -1);
        java.lang.Number number65 = notStrictlyPositiveException64.getMin();
        java.lang.Number number66 = notStrictlyPositiveException64.getArgument();
        java.lang.Throwable[] throwableArray67 = notStrictlyPositiveException64.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField71.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray73 = dfpField71.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException64, localizable68, localizable69, (java.lang.Object[]) dfpArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable61, (java.lang.Object[]) dfpArray73);
        java.lang.Object[] objArray76 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable61, objArray76);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException78 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException77);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNull(localizable27);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode37 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode37.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNull(localizable54);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 0 + "'", number59.equals(0));
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 0 + "'", number65.equals(0));
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + (short) -1 + "'", number66.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfpArray73);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int2 = org.apache.commons.math.util.FastMath.max(2147483647, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0000000000000018d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.960464477539059E-8d + "'", double1 == 5.960464477539059E-8d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode54 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField53.setRoundingMode(roundingMode54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode58 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField57.setRoundingMode(roundingMode58);
        dfpField53.setRoundingMode(roundingMode58);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField53.getSqr3();
        boolean boolean64 = dfp62.equals((java.lang.Object) (byte) 100);
        int int65 = dfp62.log10K();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getLn5();
        boolean boolean69 = dfp68.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode72 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField71.setRoundingMode(roundingMode72);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode76 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField75.setRoundingMode(roundingMode76);
        dfpField71.setRoundingMode(roundingMode76);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField71.getZero();
        org.apache.commons.math.dfp.Dfp dfp80 = dfp68.divide(dfp79);
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField82.getLn5();
        org.apache.commons.math.dfp.Dfp dfp85 = dfp83.newInstance(2.718281828459045d);
        boolean boolean86 = dfp79.unequal(dfp83);
        boolean boolean87 = dfp62.unequal(dfp79);
        boolean boolean88 = dfp50.greaterThan(dfp79);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + roundingMode54 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode54.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode58 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode58.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + roundingMode72 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode72.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode76 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode76.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn5();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        dfpField16.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getLn5();
        boolean boolean30 = dfp29.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField32.setRoundingMode(roundingMode33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode37 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField36.setRoundingMode(roundingMode37);
        dfpField32.setRoundingMode(roundingMode37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField32.getZero();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp29.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp26.multiply(dfp41);
        int int43 = dfp42.log10();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode37 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode37.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-4) + "'", int43 == (-4));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        int int12 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp((double) 1.0f);
        dfpField1.setIEEEFlagsBits(3);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.28406743513508276d));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32768, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32768L + "'", long2 == 32768L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(0);
        double[] doubleArray12 = dfp9.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getLn5();
        boolean boolean18 = dfp17.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField24.setRoundingMode(roundingMode25);
        dfpField20.setRoundingMode(roundingMode25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp17.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp28.newInstance((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField33.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getPi();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.ceil();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(2.718281828459045d);
        boolean boolean46 = dfp40.greaterThan(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp36.multiply(dfp43);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp9.dotrap((-241802251), "0.", dfp31, dfp43);
        int int49 = dfp48.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.getZero();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        int int3 = mersenneTwister1.nextInt((int) '4');
        float float4 = mersenneTwister1.nextFloat();
        long long5 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 41 + "'", int3 == 41);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.31474304f + "'", float4 == 0.31474304f);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-8474271314106775063L) + "'", long5 == (-8474271314106775063L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.7713206f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2596511923113866d) + "'", double1 == (-0.2596511923113866d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getSpecificPattern();
        java.lang.Throwable[] throwableArray11 = mathRuntimeException9.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) -1);
        java.lang.Number number15 = notStrictlyPositiveException14.getMin();
        mathRuntimeException9.addSuppressed((java.lang.Throwable) notStrictlyPositiveException14);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) (short) -1);
        java.lang.Number number21 = notStrictlyPositiveException20.getMin();
        java.lang.Number number22 = notStrictlyPositiveException20.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException20.getGeneralPattern();
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray24);
        java.lang.Throwable throwable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.exception.MathRuntimeException(throwable26, localizable27, localizable28, objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable23, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) (short) -1);
        java.lang.Number number40 = notStrictlyPositiveException39.getMin();
        java.lang.Number number41 = notStrictlyPositiveException39.getArgument();
        java.lang.Throwable[] throwableArray42 = notStrictlyPositiveException39.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField46.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException39, localizable43, localizable44, (java.lang.Object[]) dfpArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException39.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode53 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField52.setRoundingMode(roundingMode53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode57 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField56.setRoundingMode(roundingMode57);
        dfpField52.setRoundingMode(roundingMode57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField52.getZero();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField52.getSqr3();
        dfpField52.setIEEEFlags(2);
        java.lang.Object[] objArray64 = new java.lang.Object[] { dfpField52 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException14, localizable17, localizable50, objArray64);
        java.lang.Throwable[] throwableArray66 = notStrictlyPositiveException14.getSuppressed();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0 + "'", number15.equals(0));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) -1 + "'", number22.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0 + "'", number40.equals(0));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (short) -1 + "'", number41.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + roundingMode53 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode53.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode57 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode57.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray66);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5928446161030136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5587224759705249d + "'", double1 == 0.5587224759705249d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn5();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        dfpField16.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = dfp24.getField();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpField27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5533421480573115d + "'", double1 == 1.5533421480573115d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.7155433035316402d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8692135474025396d + "'", double1 == 0.8692135474025396d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = new org.apache.commons.math.dfp.Dfp(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField52 = dfp51.getField();
        dfpField52.setIEEEFlagsBits(10000);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.newDfp(1.0000000000000018d);
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField52.getESplit();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpField52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfpArray57);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((int) (short) 10);
        float float6 = mersenneTwister1.nextFloat();
        long long7 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.7713206f + "'", float6 == 0.7713206f);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 5511170629791907812L + "'", long7 == 5511170629791907812L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) 2147483647);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.ceil(16379.999984737482d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16380.0d + "'", double1 == 16380.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException(throwable5, localizable6, localizable7, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = mathRuntimeException14.getSpecificPattern();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathRuntimeException14);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) (short) -1);
        java.lang.Number number20 = notStrictlyPositiveException19.getMin();
        java.lang.Number number21 = notStrictlyPositiveException19.getArgument();
        java.lang.Throwable[] throwableArray22 = notStrictlyPositiveException19.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException19, localizable23, localizable24, (java.lang.Object[]) dfpArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 0.31474304f);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (short) -1);
        java.lang.Number number36 = notStrictlyPositiveException35.getMin();
        java.lang.Number number37 = notStrictlyPositiveException35.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException35.getGeneralPattern();
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) (-0.28406743513508276d), number40, false);
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 16, number44, false);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) (short) -1);
        java.lang.Number number50 = notStrictlyPositiveException49.getMin();
        java.lang.Number number51 = notStrictlyPositiveException49.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException49.getGeneralPattern();
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) (-0.28406743513508276d), number54, false);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable57, (java.lang.Number) (short) -1);
        java.lang.Number number60 = notStrictlyPositiveException59.getMin();
        java.lang.Number number61 = notStrictlyPositiveException59.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable62 = notStrictlyPositiveException59.getGeneralPattern();
        java.lang.Number number64 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable62, (java.lang.Number) Double.NEGATIVE_INFINITY, number64, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable62, (java.lang.Number) (byte) 2, (java.lang.Number) 0.1240944887001123d, false);
        java.lang.Object[] objArray71 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException72 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException46, localizable52, localizable62, objArray71);
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException75 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable73, (java.lang.Number) (byte) -1);
        java.lang.Object[] objArray76 = notStrictlyPositiveException75.getArguments();
        java.lang.Throwable[] throwableArray77 = notStrictlyPositiveException75.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException78 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException14, localizable30, localizable62, (java.lang.Object[]) throwableArray77);
        java.lang.Class<?> wildcardClass79 = throwableArray77.getClass();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (short) -1 + "'", number21.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0 + "'", number36.equals(0));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (short) -1 + "'", number37.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 0 + "'", number50.equals(0));
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (short) -1 + "'", number51.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 0 + "'", number60.equals(0));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (short) -1 + "'", number61.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(throwableArray77);
        org.junit.Assert.assertNotNull(wildcardClass79);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        int[] intArray4 = new int[] { (short) 10, (short) -1 };
        mersenneTwister1.setSeed(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        double double7 = mersenneTwister6.nextGaussian();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.2527237975288865d + "'", double7 == 1.2527237975288865d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("0.29876112937925");
        boolean boolean15 = dfp12.isInfinite();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getSpecificPattern();
        java.lang.Throwable[] throwableArray11 = mathRuntimeException9.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) -1);
        java.lang.Number number15 = notStrictlyPositiveException14.getMin();
        mathRuntimeException9.addSuppressed((java.lang.Throwable) notStrictlyPositiveException14);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) (short) -1);
        java.lang.Number number21 = notStrictlyPositiveException20.getMin();
        java.lang.Number number22 = notStrictlyPositiveException20.getArgument();
        java.lang.Throwable[] throwableArray23 = notStrictlyPositiveException20.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException20, localizable24, localizable25, (java.lang.Object[]) dfpArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, (java.lang.Object[]) dfpArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathIllegalArgumentException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 1.5707963267948966d);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0 + "'", number15.equals(0));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) -1 + "'", number22.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn5();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.DfpField.computeExp(dfp2, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((double) 0.29876113f);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField19.setRoundingMode(roundingMode20);
        dfpField15.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField25.setRoundingMode(roundingMode26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField29.setRoundingMode(roundingMode30);
        dfpField25.setRoundingMode(roundingMode30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getLn5();
        boolean boolean39 = dfp38.isNaN();
        int int40 = dfp38.intValue();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp35.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp35);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp13.newInstance(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode46 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField45.setRoundingMode(roundingMode46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode50 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField49.setRoundingMode(roundingMode50);
        dfpField45.setRoundingMode(roundingMode50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField45.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp53.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getLn5();
        boolean boolean59 = dfp58.isNaN();
        int int60 = dfp58.intValue();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp55.add(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getPi();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp64.ceil();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp61.nextAfter(dfp65);
        boolean boolean67 = dfp13.lessThan(dfp65);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + roundingMode46 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode46.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode50 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode50.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 2, (byte) 1);
        int int8 = dfp7.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-4) + "'", int8 == (-4));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.getOne();
        int int6 = dfp5.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getTwo();
        int int52 = dfp51.log10K();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.newInstance(1778);
        int int55 = dfp54.log10K();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((int) (byte) 0);
        int int15 = dfpField1.getRadixDigits();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 531683765);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode10);
        dfpField1.setIEEEFlags(0);
        dfpField1.setIEEEFlags((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(0.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.5421166245928095E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        dfpField1.setIEEEFlags((-241802251));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(2);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(2.718281828459045d);
        boolean boolean9 = dfp3.greaterThan(dfp6);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        boolean boolean3 = dfp2.isNaN();
        int int4 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField6.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField10.setRoundingMode(roundingMode11);
        dfpField6.setRoundingMode(roundingMode11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.getSqr3();
        dfpField6.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField6.newDfp((int) (byte) 0);
        boolean boolean20 = dfp2.greaterThan(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp2.negate();
        boolean boolean22 = dfp2.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.4742713141067756E18d) + "'", double1 == (-8.4742713141067756E18d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.divide(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getOne();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.8391469346662815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8391469346662817d + "'", double1 == 0.8391469346662817d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1705);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.134467484278979d + "'", double1 == 8.134467484278979d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField2.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField6.setRoundingMode(roundingMode7);
        dfpField2.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField2.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField2.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn5();
        boolean boolean15 = dfp14.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField17.setRoundingMode(roundingMode18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField21.setRoundingMode(roundingMode22);
        dfpField17.setRoundingMode(roundingMode22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField17.getZero();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp14.divide(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp11.divide(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp29 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp27, dfp28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) 'a');
        int int3 = mersenneTwister1.nextInt(1778);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 90 + "'", int3 == 90);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = new org.apache.commons.math.dfp.Dfp(dfp50);
        int int52 = dfp51.intValue();
        org.apache.commons.math.dfp.Dfp dfp53 = new org.apache.commons.math.dfp.Dfp(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.rint();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = new org.apache.commons.math.dfp.Dfp(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField52 = dfp51.getField();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.floor();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpField52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        dfpField1.setIEEEFlagsBits(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) -1);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getESplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.2159707064193317d, 32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.215970706419332d + "'", double2 == 1.215970706419332d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.3333333333333335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1249387366083d + "'", double1 == 0.1249387366083d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn5();
        boolean boolean12 = dfp11.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getPi();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.nextAfter(dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 16, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int1 = org.apache.commons.math.util.FastMath.abs(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField12.setRoundingMode(roundingMode13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        dfpField12.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField12.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField12.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField12.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField1.newDfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.newInstance((int) (byte) 2);
        java.lang.String str28 = dfp27.toString();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2." + "'", str28.equals("2."));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 16.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.acos(15.999999817128598d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 4542116624592809595L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.65725828108734d + "'", double1 == 18.65725828108734d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((-1));
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("0.015625");
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        dfpField1.setIEEEFlags((-241802251));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((double) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        java.lang.Class<?> wildcardClass14 = dfp13.getClass();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) -1);
        java.lang.Number number7 = notStrictlyPositiveException6.getMin();
        java.lang.Number number8 = notStrictlyPositiveException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray10);
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException(throwable12, localizable13, localizable14, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable9, objArray20);
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException(throwable23, localizable24, localizable25, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathRuntimeException32.getSpecificPattern();
        java.lang.Throwable[] throwableArray34 = mathRuntimeException32.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) (short) -1);
        java.lang.Number number38 = notStrictlyPositiveException37.getMin();
        mathRuntimeException32.addSuppressed((java.lang.Throwable) notStrictlyPositiveException37);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) (short) -1);
        java.lang.Number number44 = notStrictlyPositiveException43.getMin();
        java.lang.Number number45 = notStrictlyPositiveException43.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException43.getGeneralPattern();
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray47);
        java.lang.Throwable throwable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.exception.MathRuntimeException(throwable49, localizable50, localizable51, objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable46, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable60, (java.lang.Number) (short) -1);
        java.lang.Number number63 = notStrictlyPositiveException62.getMin();
        java.lang.Number number64 = notStrictlyPositiveException62.getArgument();
        java.lang.Throwable[] throwableArray65 = notStrictlyPositiveException62.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray71 = dfpField69.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException72 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException62, localizable66, localizable67, (java.lang.Object[]) dfpArray71);
        org.apache.commons.math.exception.util.Localizable localizable73 = notStrictlyPositiveException62.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode76 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField75.setRoundingMode(roundingMode76);
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode80 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField79.setRoundingMode(roundingMode80);
        dfpField75.setRoundingMode(roundingMode80);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField75.getZero();
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField75.getSqr3();
        dfpField75.setIEEEFlags(2);
        java.lang.Object[] objArray87 = new java.lang.Object[] { dfpField75 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException88 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException37, localizable40, localizable73, objArray87);
        org.apache.commons.math.dfp.DfpField dfpField90 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp91 = dfpField90.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray92 = dfpField90.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException93 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable3, localizable73, (java.lang.Object[]) dfpArray92);
        java.lang.Number number94 = notStrictlyPositiveException2.getMin();
        java.lang.Throwable throwable95 = null;
        try {
            notStrictlyPositiveException2.addSuppressed(throwable95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNull(localizable33);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0 + "'", number38.equals(0));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0 + "'", number44.equals(0));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (short) -1 + "'", number45.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 0 + "'", number63.equals(0));
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + (short) -1 + "'", number64.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfpArray71);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + roundingMode76 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode76.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode80 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode80.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfpArray92);
        org.junit.Assert.assertTrue("'" + number94 + "' != '" + 0 + "'", number94.equals(0));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = new org.apache.commons.math.dfp.Dfp(dfp50);
        int int52 = dfp51.intValue();
        org.apache.commons.math.dfp.Dfp dfp53 = new org.apache.commons.math.dfp.Dfp(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getLn5();
        boolean boolean57 = dfp56.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode60 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField59.setRoundingMode(roundingMode60);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode64 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField63.setRoundingMode(roundingMode64);
        dfpField59.setRoundingMode(roundingMode64);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField59.getZero();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp56.divide(dfp67);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getLn5();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.newInstance(2.718281828459045d);
        boolean boolean74 = dfp67.unequal(dfp71);
        java.lang.String str75 = dfp71.toString();
        boolean boolean76 = dfp53.greaterThan(dfp71);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + roundingMode60 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode60.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode64 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode64.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1.609437912434" + "'", str75.equals("1.609437912434"));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, 7012121237219473499L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable6, localizable7, (java.lang.Object[]) dfpArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Class<?> wildcardClass14 = localizable13.getClass();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getSpecificPattern();
        java.lang.Throwable[] throwableArray11 = mathRuntimeException9.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) -1);
        java.lang.Number number15 = notStrictlyPositiveException14.getMin();
        mathRuntimeException9.addSuppressed((java.lang.Throwable) notStrictlyPositiveException14);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) (-8.4742713141067756E18d));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0 + "'", number15.equals(0));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getLn10();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = new org.apache.commons.math.dfp.Dfp(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.getZero();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField13.setRoundingMode(roundingMode14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField17.setRoundingMode(roundingMode18);
        dfpField13.setRoundingMode(roundingMode18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField13.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10K(0);
        double[] doubleArray24 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getLn5();
        boolean boolean30 = dfp29.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField32.setRoundingMode(roundingMode33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode37 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField36.setRoundingMode(roundingMode37);
        dfpField32.setRoundingMode(roundingMode37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField32.getZero();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp29.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.newInstance((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField45.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getPi();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.ceil();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getLn5();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp55.newInstance(2.718281828459045d);
        boolean boolean58 = dfp52.greaterThan(dfp55);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp48.multiply(dfp55);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp21.dotrap((-241802251), "0.", dfp43, dfp55);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField62.getPi();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp60.subtract(dfp63);
        boolean boolean65 = dfp11.greaterThan(dfp63);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode37 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode37.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        mersenneTwister1.setSeed(0L);
        double double4 = mersenneTwister1.nextDouble();
        float float5 = mersenneTwister1.nextFloat();
        float float6 = mersenneTwister1.nextFloat();
        float float7 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.15071724896777527d + "'", double4 == 0.15071724896777527d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.1955427f + "'", float5 == 0.1955427f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.124094486f + "'", float6 == 0.124094486f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.16532528f + "'", float7 == 0.16532528f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp((double) 1.0f);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: -0.284 is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.sqrt();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits((int) 'a');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn5();
        dfpField7.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(41);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
        int int13 = dfp11.classify();
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.util.FastMath.exp(9.903487555036127d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20000.000049999988d + "'", double1 == 20000.000049999988d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (-58.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-58.0d) + "'", double2 == (-58.0d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn5();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        dfpField16.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp24);
        try {
            org.apache.commons.math.dfp.Dfp dfp28 = dfp10.newInstance((-2855324776669012511L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (-0.28406743513508276d), number7, false);
        java.lang.Object[] objArray10 = numberIsTooSmallException9.getArguments();
        java.lang.String str11 = numberIsTooSmallException9.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -0.284 is smaller than, or equal to, the minimum (null): -0.284 is smaller than, or equal to, the minimum (null)" + "'", str11.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -0.284 is smaller than, or equal to, the minimum (null): -0.284 is smaller than, or equal to, the minimum (null)"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double2 = org.apache.commons.math.util.FastMath.max(0.017453292519943295d, (double) 2084377003539008444L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.08437700353900851E18d + "'", double2 == 2.08437700353900851E18d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Object[] objArray6 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number8 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        int int14 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getOne();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.add(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField28.setRoundingMode(roundingMode29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField32.setRoundingMode(roundingMode33);
        dfpField28.setRoundingMode(roundingMode33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField28.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField28.getSqr2();
        java.lang.Object obj40 = null;
        boolean boolean41 = dfp39.equals(obj40);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp24.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.getOne();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField1.newDfp(dfp43);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn5();
        boolean boolean12 = dfp11.isNaN();
        boolean boolean13 = dfp11.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn5();
        boolean boolean17 = dfp16.isNaN();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField24.setRoundingMode(roundingMode25);
        dfpField20.setRoundingMode(roundingMode25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField20.getSqr3();
        dfpField20.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField20.newDfp((int) (byte) 0);
        boolean boolean34 = dfp16.greaterThan(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp8, dfp11, dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp11.floor();
        boolean boolean37 = dfp5.greaterThan(dfp36);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6931471805599453d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6931471805599452d + "'", double2 == 0.6931471805599452d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5514266812416906d + "'", double1 == 0.5514266812416906d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.remainder(dfp11);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8300449887908433d + "'", double1 == 0.8300449887908433d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        long long2 = mersenneTwister1.nextLong();
        double double3 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5406088298409573d + "'", double3 == 0.5406088298409573d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.6888366918779438d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7446188400900611d) + "'", double1 == (-0.7446188400900611d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        long long3 = mersenneTwister1.nextLong();
        boolean boolean4 = mersenneTwister1.nextBoolean();
        boolean boolean5 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        boolean boolean8 = mersenneTwister7.nextBoolean();
        mersenneTwister7.setSeed((int) (byte) 2);
        mersenneTwister7.setSeed(2L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        int[] intArray17 = new int[] { (short) 10, (short) -1 };
        mersenneTwister14.setSeed(intArray17);
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister(intArray17);
        mersenneTwister7.setSeed(intArray17);
        mersenneTwister1.setSeed(intArray17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5511170629791907812L + "'", long3 == 5511170629791907812L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        long long2 = org.apache.commons.math.util.FastMath.min((-7L), (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7L) + "'", long2 == (-7L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-8726104117247366168L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double2 = org.apache.commons.math.util.FastMath.max(20000.000049999988d, 2.5198420997897464d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20000.000049999988d + "'", double2 == 20000.000049999988d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.rint(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn5();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.newInstance(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn5();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(2.718281828459045d);
        boolean boolean23 = dfp17.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp17.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.floor();
        org.apache.commons.math.dfp.Dfp dfp29 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp12, dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp5.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.sqrt();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getESplit();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp(dfp20);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.newInstance();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        boolean boolean3 = dfp2.isNaN();
        int int4 = dfp2.log10();
        boolean boolean5 = dfp2.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr3();
        int int13 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.floor();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.asinh(16.000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4667110378847252d + "'", double1 == 3.4667110378847252d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1412537165573284d + "'", double1 == 2.1412537165573284d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2.0f, (double) 2522350220994807954L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.negate();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField13.setRoundingMode(roundingMode14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField17.setRoundingMode(roundingMode18);
        dfpField13.setRoundingMode(roundingMode18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField13.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn5();
        boolean boolean27 = dfp26.isNaN();
        int int28 = dfp26.intValue();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.add(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getPi();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.ceil();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp29.nextAfter(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp11.newInstance(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getPi();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.ceil();
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp11, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getLn5();
        boolean boolean46 = dfp45.isNaN();
        boolean boolean47 = dfp45.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp45.ceil();
        boolean boolean49 = dfp48.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode53 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField52.setRoundingMode(roundingMode53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode57 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField56.setRoundingMode(roundingMode57);
        dfpField52.setRoundingMode(roundingMode57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField52.getZero();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField64.getLn5();
        boolean boolean66 = dfp65.isNaN();
        int int67 = dfp65.intValue();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp62.add(dfp65);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp65.negate();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp69.newInstance((double) 10);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp38.dotrap(10, "0.", dfp48, dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp38.floor();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + roundingMode53 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode53.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode57 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode57.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField13.setRoundingMode(roundingMode14);
        dfpField9.setRoundingMode(roundingMode14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn5();
        boolean boolean23 = dfp22.isNaN();
        int int24 = dfp22.intValue();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.add(dfp22);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp22.negate();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp7.add(dfp22);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp22.newInstance((byte) 10, (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        mersenneTwister1.setSeed(0L);
        double double4 = mersenneTwister1.nextDouble();
        boolean boolean5 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((int) 'a');
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister((int) 'a');
        int[] intArray15 = new int[] { 10, 1, (-1), (byte) 10, (short) 1 };
        mersenneTwister9.setSeed(intArray15);
        mersenneTwister7.setSeed(intArray15);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray15);
        mersenneTwister1.setSeed(intArray15);
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister(intArray15);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.15071724896777527d + "'", double4 == 0.15071724896777527d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        boolean boolean3 = dfp2.isNaN();
        int int4 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField6.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField10.setRoundingMode(roundingMode11);
        dfpField6.setRoundingMode(roundingMode11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.getSqr3();
        dfpField6.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField6.newDfp((int) (byte) 0);
        boolean boolean20 = dfp2.greaterThan(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp2.negate();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.41549527535753E7d + "'", double1 == 2.41549527535753E7d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.3809734736635041d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3908489436103755d + "'", double1 == 0.3908489436103755d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(0);
        double[] doubleArray12 = dfp9.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.newInstance((byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.divide(64);
        java.lang.String str15 = dfp14.toString();
        boolean boolean16 = dfp14.isInfinite();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.015625" + "'", str15.equals("0.015625"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("0.29876112937925");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp((byte) 100, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn2();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.7336545584598283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0826779851380144d + "'", double1 == 1.0826779851380144d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn5();
        boolean boolean15 = dfp14.isNaN();
        int int16 = dfp14.intValue();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.add(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.negate();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(97);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-1));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Throwable throwable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable1, localizable2, localizable3, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathRuntimeException10.getSpecificPattern();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException10.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (short) -1);
        java.lang.Number number16 = notStrictlyPositiveException15.getMin();
        java.lang.Number number17 = notStrictlyPositiveException15.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable18 = notStrictlyPositiveException15.getGeneralPattern();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) Double.NEGATIVE_INFINITY, number20, true);
        mathRuntimeException10.addSuppressed((java.lang.Throwable) numberIsTooSmallException22);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException22.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) (short) -1);
        java.lang.Number number28 = notStrictlyPositiveException27.getMin();
        java.lang.Number number29 = notStrictlyPositiveException27.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException27.getGeneralPattern();
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (short) -1);
        java.lang.Number number36 = notStrictlyPositiveException35.getMin();
        java.lang.Number number37 = notStrictlyPositiveException35.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException35.getGeneralPattern();
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) (-0.28406743513508276d), number40, false);
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 16, number44, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 8.0f, (java.lang.Number) 1.7763568394002505E-15d, false);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode53 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField52.setRoundingMode(roundingMode53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode57 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField56.setRoundingMode(roundingMode57);
        dfpField52.setRoundingMode(roundingMode57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField52.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField52.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField52.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField52.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable38, (java.lang.Object[]) dfpArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException68 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable66, (java.lang.Number) (short) -1);
        java.lang.Number number69 = notStrictlyPositiveException68.getMin();
        java.lang.Number number70 = notStrictlyPositiveException68.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable71 = notStrictlyPositiveException68.getGeneralPattern();
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) Double.NEGATIVE_INFINITY, number73, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) (byte) 2, (java.lang.Number) 0.1240944887001123d, false);
        java.lang.Throwable throwable80 = null;
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException89 = new org.apache.commons.math.exception.MathRuntimeException(throwable80, localizable81, localizable82, objArray88);
        org.apache.commons.math.exception.util.Localizable localizable90 = mathRuntimeException89.getSpecificPattern();
        java.lang.Throwable[] throwableArray91 = mathRuntimeException89.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable71, (java.lang.Object[]) throwableArray91);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException93 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable24, localizable30, (java.lang.Object[]) throwableArray91);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException97 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 10000L, (java.lang.Number) 10000.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable98 = numberIsTooSmallException97.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0 + "'", number16.equals(0));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) -1 + "'", number17.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0 + "'", number28.equals(0));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (short) -1 + "'", number29.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0 + "'", number36.equals(0));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (short) -1 + "'", number37.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + roundingMode53 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode53.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode57 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode57.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 0 + "'", number69.equals(0));
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + (short) -1 + "'", number70.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNull(localizable90);
        org.junit.Assert.assertNotNull(throwableArray91);
        org.junit.Assert.assertTrue("'" + localizable98 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable98.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        float float2 = mersenneTwister1.nextFloat();
        float float3 = mersenneTwister1.nextFloat();
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.7713206f + "'", float2 == 0.7713206f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.29876113f + "'", float3 == 0.29876113f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.020751834f + "'", float4 == 0.020751834f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable6, localizable7, (java.lang.Object[]) dfpArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 0.31474304f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 0.355060784984864d);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField19.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField23.setRoundingMode(roundingMode24);
        dfpField19.setRoundingMode(roundingMode24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField19.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField19.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField19.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, (java.lang.Object[]) dfpArray32);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn5();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        dfpField16.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = dfp26.getField();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        dfpField27.clearIEEEFlags();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpField27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 2L, (double) 0.020751834f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9999999999999998d + "'", double2 == 1.9999999999999998d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn5();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        dfpField16.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp10.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = dfp24.getField();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField29.setRoundingMode(roundingMode30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField33.setRoundingMode(roundingMode34);
        dfpField29.setRoundingMode(roundingMode34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getLn5();
        boolean boolean43 = dfp42.isNaN();
        int int44 = dfp42.intValue();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.add(dfp42);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp42.negate();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.negate();
        boolean boolean48 = dfp24.greaterThan(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.negate();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpField27);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (short) -1);
        java.lang.Number number11 = notStrictlyPositiveException10.getMin();
        java.lang.Number number12 = notStrictlyPositiveException10.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (-0.28406743513508276d), number15, false);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 16, number19, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 8.0f, (java.lang.Number) 1.7763568394002505E-15d, false);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField27.setRoundingMode(roundingMode28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode32 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField31.setRoundingMode(roundingMode32);
        dfpField27.setRoundingMode(roundingMode32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField27.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField27.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField27.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable13, (java.lang.Object[]) dfpArray39);
        java.lang.String str41 = mathIllegalArgumentException40.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) -1 + "'", number12.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode32 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode32.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: 3.1415 is smaller than, or equal to, the minimum (0.00009265358979323846): 3.1415 is smaller than, or equal to, the minimum (0.00009265358979323846)" + "'", str41.equals("org.apache.commons.math.exception.MathIllegalArgumentException: 3.1415 is smaller than, or equal to, the minimum (0.00009265358979323846): 3.1415 is smaller than, or equal to, the minimum (0.00009265358979323846)"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField4.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.add(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField12.setRoundingMode(roundingMode13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        dfpField12.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField12.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField12.getSqr2();
        java.lang.Object obj24 = null;
        boolean boolean25 = dfp23.equals(obj24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp8.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp8.floor();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getLn5();
        boolean boolean31 = dfp30.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField33.setRoundingMode(roundingMode34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode38 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField37.setRoundingMode(roundingMode38);
        dfpField33.setRoundingMode(roundingMode38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField33.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp30.divide(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp41.newInstance((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp27.subtract(dfp44);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode38 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode38.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField13.setRoundingMode(roundingMode14);
        dfpField9.setRoundingMode(roundingMode14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn5();
        boolean boolean23 = dfp22.isNaN();
        int int24 = dfp22.intValue();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.add(dfp22);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp22.negate();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getTwo();
        boolean boolean28 = dfp7.unequal(dfp26);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField4.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.add(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField12.setRoundingMode(roundingMode13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        dfpField12.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField12.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField12.getSqr2();
        java.lang.Object obj24 = null;
        boolean boolean25 = dfp23.equals(obj24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp8.newInstance(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField28.setRoundingMode(roundingMode29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField32.setRoundingMode(roundingMode33);
        dfpField28.setRoundingMode(roundingMode33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10K(0);
        double[] doubleArray39 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getLn5();
        boolean boolean45 = dfp44.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode48 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField47.setRoundingMode(roundingMode48);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode52 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField51.setRoundingMode(roundingMode52);
        dfpField47.setRoundingMode(roundingMode52);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField47.getZero();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp44.divide(dfp55);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp55.newInstance((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField60.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray62 = dfpField60.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField65.getPi();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp66.ceil();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getLn5();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp70.newInstance(2.718281828459045d);
        boolean boolean73 = dfp67.greaterThan(dfp70);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp63.multiply(dfp70);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp36.dotrap((-241802251), "0.", dfp58, dfp70);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField77.getLn5();
        boolean boolean79 = dfp78.isNaN();
        boolean boolean80 = dfp78.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp70.newInstance(dfp78);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp23.nextAfter(dfp81);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + roundingMode48 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode48.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode52 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode52.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpArray62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getSpecificPattern();
        java.lang.Throwable[] throwableArray11 = mathRuntimeException9.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) -1);
        java.lang.Number number15 = notStrictlyPositiveException14.getMin();
        mathRuntimeException9.addSuppressed((java.lang.Throwable) notStrictlyPositiveException14);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathRuntimeException9.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0 + "'", number15.equals(0));
        org.junit.Assert.assertNull(localizable17);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        boolean boolean3 = dfp2.isNaN();
        int int4 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField6.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField10.setRoundingMode(roundingMode11);
        dfpField6.setRoundingMode(roundingMode11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.getSqr3();
        dfpField6.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField6.newDfp((int) (byte) 0);
        boolean boolean20 = dfp2.greaterThan(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField23.setRoundingMode(roundingMode24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField27.setRoundingMode(roundingMode28);
        dfpField23.setRoundingMode(roundingMode28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField23.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getLn5();
        boolean boolean36 = dfp35.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode43 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField42.setRoundingMode(roundingMode43);
        dfpField38.setRoundingMode(roundingMode43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp35.divide(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp32.divide(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getLn5();
        boolean boolean52 = dfp51.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode55 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField54.setRoundingMode(roundingMode55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode59 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField58.setRoundingMode(roundingMode59);
        dfpField54.setRoundingMode(roundingMode59);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField54.getZero();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp51.divide(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp48.multiply(dfp63);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp48.ceil();
        int int66 = dfp48.classify();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp2.divide(dfp48);
        boolean boolean68 = dfp67.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode43 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode43.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + roundingMode55 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode55.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode59 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode59.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn5();
        boolean boolean6 = dfp5.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.DfpField.computeExp(dfp2, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((double) 0.29876113f);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField19.setRoundingMode(roundingMode20);
        dfpField15.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField25.setRoundingMode(roundingMode26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField29.setRoundingMode(roundingMode30);
        dfpField25.setRoundingMode(roundingMode30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getLn5();
        boolean boolean39 = dfp38.isNaN();
        int int40 = dfp38.intValue();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp35.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp35);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp13.newInstance(dfp35);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp13.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10(32);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5928446161030136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException2.getSuppressed();
        java.lang.Throwable[] throwableArray6 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10000.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.210440366976517d + "'", double1 == 9.210440366976517d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.3699911549825858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0947125472611012d + "'", double1 == 2.0947125472611012d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.12435300177159621d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getLn5();
        boolean boolean13 = dfp12.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((double) 0.29876113f);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp6.divide(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp24 = dfp22.nextAfter(dfp23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int2 = org.apache.commons.math.util.FastMath.min(531683765, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (-0.28406743513508276d), number7, false);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16, number11, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 3.141592653589793d, (java.lang.Number) 4.584967478670572d, true);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1.0f, 2.772588722239781d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.34615191158392206d + "'", double2 == 0.34615191158392206d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1473130782));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getSpecificPattern();
        java.lang.Throwable[] throwableArray11 = mathRuntimeException9.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) -1);
        java.lang.Number number15 = notStrictlyPositiveException14.getMin();
        mathRuntimeException9.addSuppressed((java.lang.Throwable) notStrictlyPositiveException14);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) (short) -1);
        java.lang.Number number21 = notStrictlyPositiveException20.getMin();
        java.lang.Number number22 = notStrictlyPositiveException20.getArgument();
        java.lang.Throwable[] throwableArray23 = notStrictlyPositiveException20.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException20, localizable24, localizable25, (java.lang.Object[]) dfpArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, (java.lang.Object[]) dfpArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathIllegalArgumentException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable34, (java.lang.Number) (short) -1);
        java.lang.Number number37 = notStrictlyPositiveException36.getMin();
        java.lang.Number number38 = notStrictlyPositiveException36.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable39 = notStrictlyPositiveException36.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray40);
        java.lang.Throwable throwable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.exception.MathRuntimeException(throwable42, localizable43, localizable44, objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable39, objArray50);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode55 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField54.setRoundingMode(roundingMode55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode59 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField58.setRoundingMode(roundingMode59);
        dfpField54.setRoundingMode(roundingMode59);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField54.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField54.getLn5();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField54.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField54.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray67 = dfpField54.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable39, (java.lang.Object[]) dfpArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException72 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 10000L, (java.lang.Number) 4.406570493076975d, true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0 + "'", number15.equals(0));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) -1 + "'", number22.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0 + "'", number37.equals(0));
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (short) -1 + "'", number38.equals((short) -1));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + roundingMode55 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode55.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode59 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode59.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfpArray67);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = new org.apache.commons.math.dfp.Dfp(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField52 = dfp51.getField();
        dfpField52.setIEEEFlagsBits(10000);
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField52.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField52.getLn10();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpField52);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance(0.0d);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.sqrt();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5533421480573115d, 1.2182829050172777d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9057034703297316d + "'", double2 == 0.9057034703297316d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.28406743513508276d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27666538981802374d) + "'", double1 == (-0.27666538981802374d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.9999889535683335d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414650163440559d) + "'", double1 == (-0.8414650163440559d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        int int10 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getPi();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-7L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.118819655545162E-4d + "'", double1 == 9.118819655545162E-4d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getOne();
        dfpField5.setIEEEFlagsBits(0);
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((byte) 2, (byte) -1);
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getESplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField5.newDfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField5.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField24.setRoundingMode(roundingMode25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField28.setRoundingMode(roundingMode29);
        dfpField24.setRoundingMode(roundingMode29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField24.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = dfpField24.getRoundingMode();
        dfpField5.setRoundingMode(roundingMode33);
        dfpField1.setRoundingMode(roundingMode33);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance((byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) -1 + "'", number3.equals((short) -1));
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        java.lang.Object obj13 = null;
        boolean boolean14 = dfp12.equals(obj13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField20.setRoundingMode(roundingMode21);
        dfpField16.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField16.getOne();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp12.subtract(dfp27);
        java.lang.Class<?> wildcardClass29 = dfp28.getClass();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField13.setRoundingMode(roundingMode14);
        dfpField9.setRoundingMode(roundingMode14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn5();
        boolean boolean23 = dfp22.isNaN();
        int int24 = dfp22.intValue();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.add(dfp22);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp22.negate();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp7.add(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField29.setRoundingMode(roundingMode30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField33.setRoundingMode(roundingMode34);
        dfpField29.setRoundingMode(roundingMode34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.power10K(0);
        double[] doubleArray40 = dfp37.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getLn5();
        boolean boolean46 = dfp45.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode49 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField48.setRoundingMode(roundingMode49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode53 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField52.setRoundingMode(roundingMode53);
        dfpField48.setRoundingMode(roundingMode53);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField48.getZero();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp45.divide(dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp56.newInstance((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray63 = dfpField61.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getPi();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp67.ceil();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getLn5();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.newInstance(2.718281828459045d);
        boolean boolean74 = dfp68.greaterThan(dfp71);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp64.multiply(dfp71);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp37.dotrap((-241802251), "0.", dfp59, dfp71);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField78.getLn5();
        boolean boolean80 = dfp79.isNaN();
        boolean boolean81 = dfp79.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp82 = dfp71.newInstance(dfp79);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp22.add(dfp71);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + roundingMode49 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode49.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode53 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode53.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfpArray63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10000.0d + "'", double1 == 10000.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance("1.609437912434");
        int int10 = dfp9.intValue();
        org.apache.commons.math.dfp.Dfp dfp11 = null;
        try {
            boolean boolean12 = dfp9.unequal(dfp11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0.0d);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, 0, (-1), (-1L), (short) 10 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getSpecificPattern();
        java.lang.Throwable[] throwableArray11 = mathRuntimeException9.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) -1);
        java.lang.Number number15 = notStrictlyPositiveException14.getMin();
        mathRuntimeException9.addSuppressed((java.lang.Throwable) notStrictlyPositiveException14);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathRuntimeException9.getSpecificPattern();
        java.lang.Throwable[] throwableArray18 = mathRuntimeException9.getSuppressed();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0 + "'", number15.equals(0));
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        dfpField1.setIEEEFlagsBits((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn5();
        boolean boolean15 = dfp14.isNaN();
        int int16 = dfp14.intValue();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.add(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.rint();
        boolean boolean19 = dfp18.isInfinite();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        double double6 = dfp5.toDouble();
        int int7 = dfp5.classify();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode10);
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        java.lang.Object obj13 = null;
        boolean boolean14 = dfp12.equals(obj13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.ceil();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        int int12 = dfpField1.getRadixDigits();
        int int13 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = null;
        dfpField1.setRoundingMode(roundingMode5);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03490658503988659d + "'", double1 == 0.03490658503988659d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.41782887182714457d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2.0f, 1.3699911549825858d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5846898147545105d + "'", double2 == 2.5846898147545105d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(2.718281828459045d);
        boolean boolean9 = dfp3.greaterThan(dfp6);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp3.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp3.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.floor();
        int int15 = dfp14.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(2.718281828459045d);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn5();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.newInstance(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn5();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(2.718281828459045d);
        boolean boolean23 = dfp17.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp17.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.newInstance((long) 2);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.floor();
        org.apache.commons.math.dfp.Dfp dfp29 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp12, dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp5.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField15.setRoundingMode(roundingMode16);
        dfpField11.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn5();
        boolean boolean25 = dfp24.isNaN();
        int int26 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.add(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn5();
        boolean boolean32 = dfp31.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField34.setRoundingMode(roundingMode35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField38.setRoundingMode(roundingMode39);
        dfpField34.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp31.divide(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance(2.718281828459045d);
        boolean boolean49 = dfp42.unequal(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = new org.apache.commons.math.dfp.Dfp(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField52 = dfp51.getField();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getOne();
        dfpField55.setIEEEFlagsBits(0);
        dfpField55.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField55.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode65 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField64.setRoundingMode(roundingMode65);
        dfpField55.setRoundingMode(roundingMode65);
        dfpField52.setRoundingMode(roundingMode65);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpField52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + roundingMode65 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode65.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }
}

