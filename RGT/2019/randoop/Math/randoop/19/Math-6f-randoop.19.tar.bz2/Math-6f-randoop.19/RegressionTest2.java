import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 3.0d);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        try {
            array2DRowRealMatrix0.addToEntry((int) (short) 100, (int) (short) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double5 = brentSolver4.getAbsoluteAccuracy();
        double double6 = brentSolver4.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        double double11 = simpleValueChecker10.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        double double13 = simpleValueChecker10.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector0.mapAddToSelf((double) (short) 10);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector0.mapSubtract((double) 0.032585025f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray17 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        double[] doubleArray20 = pointVectorValuePair19.getSecond();
        boolean boolean22 = pointVectorValuePair19.equals((java.lang.Object) "hi!");
        double[] doubleArray23 = pointVectorValuePair19.getSecond();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, doubleArray23);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.scale(1.0d, doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        try {
            org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getLowerBound();
        java.util.List<java.lang.Double> doubleList24 = cMAESOptimizer22.getStatisticsSigmaHistory();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleList24);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray14, 0.0d, false);
        double[] doubleArray19 = pointValuePair18.getPoint();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(3, (int) (byte) 1);
        double[] doubleArray30 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair32 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray30, doubleArray31);
        double[] doubleArray33 = pointVectorValuePair32.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma34 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray33);
        double[] doubleArray35 = array2DRowRealMatrix20.operate(doubleArray33);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(doubleArray19, doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.0d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) (-9208070452475268559L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean10 = arrayRealVector8.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector11.equals((java.lang.Object) true);
        double double14 = arrayRealVector8.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector7.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean18 = arrayRealVector16.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector15.append(arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector6.add((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean29 = arrayRealVector27.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector27.subtract(realVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean38 = arrayRealVector36.equals((java.lang.Object) true);
        double[] doubleArray39 = arrayRealVector36.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector33.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        try {
            double double41 = arrayRealVector26.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayRealVector40);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getImagEigenvalues();
        boolean boolean6 = eigenDecomposition3.hasComplexEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = eigenDecomposition3.getVT();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition3.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.8813735870195429d, (double) 52L, univariatePointValuePairConvergenceChecker2);
        double double4 = brentOptimizer3.getStartValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        try {
            blockRealMatrix15.multiplyEntry(0, (-186238143), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-186,238,143)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray14 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray21 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray28 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray35 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray36 = new double[][] { doubleArray7, doubleArray14, doubleArray21, doubleArray28, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray38);
        org.apache.commons.math3.exception.MathInternalError mathInternalError40 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "{}", "{}");
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[][] doubleArray5 = array2DRowRealMatrix0.getDataRef();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        try {
            double double15 = arrayRealVector9.getEntry((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray10 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException11 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray9, intArray10);
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        java.lang.Integer[] intArray19 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray20 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable12, intArray19, intArray20);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException22 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray20);
        org.apache.commons.math3.exception.util.Localizable localizable23 = null;
        org.apache.commons.math3.exception.util.Localizable localizable24 = null;
        org.apache.commons.math3.exception.util.Localizable localizable25 = null;
        org.apache.commons.math3.exception.util.Localizable localizable26 = null;
        org.apache.commons.math3.optim.MaxIter maxIter27 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray36 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair38 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray37);
        double[] doubleArray39 = pointVectorValuePair38.getSecond();
        java.lang.Object[] objArray40 = new java.lang.Object[] { maxIter27, 19.085536923187668d, (byte) 100, pointVectorValuePair38 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable26, objArray40);
        org.apache.commons.math3.exception.MathInternalError mathInternalError42 = new org.apache.commons.math3.exception.MathInternalError(localizable25, objArray40);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException43 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable24, objArray40);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray9, localizable23, objArray40);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException45 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 0.8414709848078965d, (java.lang.Object[]) intArray9);
        org.apache.commons.math3.exception.util.Localizable localizable46 = null;
        java.lang.Integer[] intArray53 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray54 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException55 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable46, intArray53, intArray54);
        org.apache.commons.math3.exception.util.Localizable localizable56 = null;
        java.lang.Integer[] intArray63 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray64 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException65 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable56, intArray63, intArray64);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException66 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray53, intArray64);
        org.apache.commons.math3.exception.util.Localizable localizable67 = null;
        org.apache.commons.math3.exception.util.Localizable localizable68 = null;
        org.apache.commons.math3.exception.util.Localizable localizable69 = null;
        org.apache.commons.math3.exception.util.Localizable localizable70 = null;
        org.apache.commons.math3.optim.MaxIter maxIter71 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray80 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray81 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair82 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray80, doubleArray81);
        double[] doubleArray83 = pointVectorValuePair82.getSecond();
        java.lang.Object[] objArray84 = new java.lang.Object[] { maxIter71, 19.085536923187668d, (byte) 100, pointVectorValuePair82 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable70, objArray84);
        org.apache.commons.math3.exception.MathInternalError mathInternalError86 = new org.apache.commons.math3.exception.MathInternalError(localizable69, objArray84);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException87 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable68, objArray84);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray53, localizable67, objArray84);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException89 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray53);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(maxIter27);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(maxIter71);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(objArray84);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        double[] doubleArray10 = blockRealMatrix3.getColumn((int) (short) 1);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(0, (int) (short) 100, 0.10272986741866949d);
        double double4 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.10272986741866949d + "'", double4 == 0.10272986741866949d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = eigenDecomposition3.getD();
        double[] doubleArray7 = eigenDecomposition3.getRealEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, number1, (int) (short) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonicSequenceException5.getArgument();
        int int7 = nonMonotonicSequenceException5.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = nonMonotonicSequenceException5.getDirection();
        java.lang.Number number9 = nonMonotonicSequenceException5.getPrevious();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = nonMonotonicSequenceException5.getDirection();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(orderDirection10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getStartPoint();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList24 = cMAESOptimizer22.getStatisticsMeanHistory();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker25 = cMAESOptimizer22.getConvergenceChecker();
        java.util.List<java.lang.Double> doubleList26 = cMAESOptimizer22.getStatisticsSigmaHistory();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrixList24);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker25);
        org.junit.Assert.assertNotNull(doubleList26);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        long long23 = mersenneTwister11.nextLong();
        double double24 = mersenneTwister11.nextGaussian();
        float float25 = mersenneTwister11.nextFloat();
        long long26 = mersenneTwister11.nextLong();
        mersenneTwister11.setSeed((long) (byte) 10);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1765991400464819176L) + "'", long23 == (-1765991400464819176L));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.5071158626935848d + "'", double24 == 0.5071158626935848d);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.09227538f + "'", float25 == 0.09227538f);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 8556609109677726901L + "'", long26 == 8556609109677726901L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        boolean boolean12 = pointVectorValuePair9.equals((java.lang.Object) "hi!");
        double[] doubleArray13 = pointVectorValuePair9.getPointRef();
        double[] doubleArray14 = pointVectorValuePair9.getValue();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray0, doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        double[][] doubleArray18 = blockRealMatrix15.getData();
        double double19 = blockRealMatrix15.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 14133.824606241582d + "'", double19 == 14133.824606241582d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix1, (int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.math3.optim.MaxIter maxIter0 = org.apache.commons.math3.optim.MaxIter.unlimited();
        int int1 = maxIter0.getMaxIter();
        org.junit.Assert.assertNotNull(maxIter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(14133.824606241582d, (double) 1.0f, 1.0E-14d, (double) 36);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 14133.824606241582d + "'", double4 == 14133.824606241582d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double2 = org.apache.commons.math3.util.FastMath.min(10.0d, (double) (-1765991400464819176L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7659914004648192E18d) + "'", double2 == (-1.7659914004648192E18d));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (short) 1, (-1765991400464819176L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1765991400464819176L) + "'", long2 == (-1765991400464819176L));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = realVectorFormat0.parse("; }");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"; }\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) ' ', (int) (short) 10, (int) (byte) 1, (int) (short) 1);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable6, intArray13, intArray14);
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        java.lang.Integer[] intArray23 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray24 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException25 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable16, intArray23, intArray24);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException26 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray13, intArray24);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException27 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray24);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double double6 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        try {
            arrayRealVector0.setEntry((int) (short) -1, 1.7763568394002505E-15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix15.getRowMatrix(0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        int int10 = arrayRealVector5.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector5.mapAdd((double) 0L);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double16 = sinc14.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector5.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean20 = arrayRealVector18.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector18.subtract(realVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean29 = arrayRealVector27.equals((java.lang.Object) true);
        double[] doubleArray30 = arrayRealVector27.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector24.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        double[] doubleArray38 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray39 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair40 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray39);
        double[] doubleArray41 = pointVectorValuePair40.getSecond();
        double[] doubleArray42 = pointVectorValuePair40.getValue();
        double[] doubleArray43 = pointVectorValuePair40.getValue();
        double[] doubleArray44 = pointVectorValuePair40.getSecond();
        double[] doubleArray45 = pointVectorValuePair40.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, (org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.8414709848078965d + "'", double16 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        double double17 = arrayRealVector7.dotProduct(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector0.ebeDivide(realVector16);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat19 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat20 = realVectorFormat19.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean26 = arrayRealVector24.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, (org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        java.lang.String str28 = realVectorFormat19.format((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        int int29 = arrayRealVector24.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector24.mapAdd((double) 0L);
        org.apache.commons.math3.analysis.function.Sinc sinc33 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double35 = sinc33.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector24.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean41 = arrayRealVector39.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean44 = arrayRealVector42.equals((java.lang.Object) true);
        double double45 = arrayRealVector39.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector24.combine(4.503599627370496E15d, 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        double double47 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.RealVector realVector48 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector46.projection(realVector48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{}" + "'", str28.equals("{}"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.8414709848078965d + "'", double35 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, (-1074790400));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(3, 6, 14133.824606241582d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double17 = sinc15.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction18 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        boolean boolean22 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc15, 0.0922753880002305d, (double) 7.6293945E-6f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction23 = sinc15.derivative();
        boolean boolean26 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc15, 1.2746272669235144d, 1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8414709848078965d + "'", double17 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(univariateFunction23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix15.getColumnMatrix(36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 14133.824606241582d + "'", double18 == 14133.824606241582d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math3.util.FastMath.atan(14133.824606241582d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707255745373732d + "'", double1 == 1.5707255745373732d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double[] doubleArray25 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray32 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray33 = new double[][] { doubleArray25, doubleArray32 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.RealVector realVector36 = blockRealMatrix34.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = blockRealMatrix18.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray44 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray51 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray52 = new double[][] { doubleArray44, doubleArray51 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray52);
        org.apache.commons.math3.linear.RealVector realVector55 = blockRealMatrix53.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = array2DRowRealMatrix56.createMatrix(3, (int) (byte) 1);
        double double60 = array2DRowRealMatrix56.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix56, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix61);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition64 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix56, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor65 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double66 = array2DRowRealMatrix56.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor65);
        double double67 = blockRealMatrix53.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor65);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix18.multiply(blockRealMatrix53);
        org.apache.commons.math3.linear.RealMatrix realMatrix69 = blockRealMatrix68.transpose();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(realMatrix69);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getFirst();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 100, 2147483647, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method -1, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(0, 0, (double) 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarMultiply(0.10272986741866949d);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix17.scalarMultiply((double) 34.999996f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean25 = arrayRealVector23.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapSubtract((double) (-1));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean34 = arrayRealVector32.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector32.subtract(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.append(arrayRealVector39);
        double double43 = arrayRealVector29.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        try {
            blockRealMatrix17.setRowVector((-186238143), (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-186,238,143)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) (-1074790400), 26.5d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition8 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) 4.5035996E15f);
        int int9 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition10 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0);
        try {
            array2DRowRealMatrix0.multiplyEntry((int) '4', 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        int int10 = arrayRealVector5.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector5.mapAdd((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        boolean boolean3 = blockRealMatrix2.isTransposable();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector5.subtract(realVector10);
        boolean boolean12 = arrayRealVector5.isInfinite();
        try {
            blockRealMatrix2.setColumnVector((int) ' ', (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 6x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        int int18 = blockRealMatrix15.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = blockRealMatrix15.walkInOptimizedOrder(realMatrixChangingVisitor19, (int) (byte) 0, 1072693248, 1, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        java.lang.String str7 = arrayRealVector3.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{}" + "'", str7.equals("{}"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 1.1920929E-7f, (double) 2, 9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray4);
        double[] doubleArray6 = target5.getTarget();
        double[] doubleArray7 = target5.getTarget();
        double[] doubleArray8 = target5.getTarget();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence(0.0922753880002305d, 0.4078492487004386d, 98.10395148368781d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.append(arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        boolean boolean14 = array2DRowRealMatrix0.isSquare();
        boolean boolean15 = array2DRowRealMatrix0.isTransposable();
        int int16 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix0.scalarMultiply(97.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        java.text.ParsePosition parsePosition6 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = realVectorFormat3.parse("hi!hi!", parsePosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) 0, 35.0d, (double) 3.8146973E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        double double10 = arrayRealVector0.dotProduct(realVector9);
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector0.getSubVector((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(1, 97);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double double5 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray15 = pointVectorValuePair14.getSecond();
        double[] doubleArray16 = array2DRowRealMatrix0.preMultiply(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray20, 52, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 52 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray8);
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) 100L, false);
        java.lang.Double double15 = pointValuePair14.getSecond();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15.equals(100.0d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner13 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray21 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray21, doubleArray22);
        double[] doubleArray24 = pointVectorValuePair23.getSecond();
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix14.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix27.createMatrix(3, (int) (byte) 1);
        double double31 = array2DRowRealMatrix27.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix27, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix32);
        double[] doubleArray40 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair42 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray40, doubleArray41);
        double[] doubleArray43 = pointVectorValuePair42.getSecond();
        double[] doubleArray44 = pointVectorValuePair42.getValue();
        double[] doubleArray45 = pointVectorValuePair42.getValueRef();
        double[] doubleArray46 = array2DRowRealMatrix32.preMultiply(doubleArray45);
        double[] doubleArray47 = identityPreconditioner13.precondition(doubleArray25, doubleArray45);
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray48);
        org.apache.commons.math3.optim.PointValuePair pointValuePair52 = new org.apache.commons.math3.optim.PointValuePair(doubleArray49, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = array2DRowRealMatrix53.createMatrix(3, (int) (byte) 1);
        double[] doubleArray63 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray64 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray63, doubleArray64);
        double[] doubleArray66 = pointVectorValuePair65.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma67 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray66);
        double[] doubleArray68 = array2DRowRealMatrix53.operate(doubleArray66);
        boolean boolean69 = org.apache.commons.math3.util.MathArrays.equals(doubleArray49, doubleArray66);
        org.apache.commons.math3.optim.InitialGuess initialGuess70 = new org.apache.commons.math3.optim.InitialGuess(doubleArray49);
        double[] doubleArray77 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray78 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair79 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray77, doubleArray78);
        double[] doubleArray80 = pointVectorValuePair79.getSecond();
        double[] doubleArray81 = pointVectorValuePair79.getValue();
        double[] doubleArray82 = pointVectorValuePair79.getValueRef();
        double[] doubleArray83 = identityPreconditioner13.precondition(doubleArray49, doubleArray82);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition84 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray11, doubleArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(100, (int) (byte) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition6 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 3.0d);
        diagonalMatrix4.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = diagonalMatrix4.copy();
        double double14 = diagonalMatrix4.getEntry(9, 0);
        diagonalMatrix4.multiplyEntry((int) (short) 100, 52, 0.5071158626935848d);
        double[][] doubleArray19 = diagonalMatrix4.getData();
        try {
            array2DRowRealMatrix2.setSubMatrix(doubleArray19, (int) (short) 1, 96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (96)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector0.mapAddToSelf((double) (short) 10);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector0.mapSubtract(0.001223444938659668d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double[] doubleArray0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula4 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula5 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] formulaArray6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] { formula4, formula5 };
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray16);
        double[] doubleArray18 = sigma17.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection19 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray26 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray33 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray34 = new double[][] { doubleArray26, doubleArray33 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray18, orderDirection19, doubleArray34);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.isMonotonic(formulaArray6, orderDirection19, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 2979.3805346802806d, (java.lang.Number) 5.298292365610485d, 1, orderDirection19, true);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + formula4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula4.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula5 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula5.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(formulaArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(35.0d, (double) 35L, 4.503599627370496E15d, 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat(", ", "hi!hi!", "hi!hi!");
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        double[] doubleArray17 = pointVectorValuePair15.getValue();
        double[] doubleArray18 = pointVectorValuePair15.getValueRef();
        double[] doubleArray19 = array2DRowRealMatrix5.preMultiply(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(3, (int) (byte) 1);
        double double24 = array2DRowRealMatrix20.getFrobeniusNorm();
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray38 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray39 = new double[][] { doubleArray31, doubleArray38 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = blockRealMatrix40.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix43.createMatrix(3, (int) (byte) 1);
        double double47 = array2DRowRealMatrix43.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix43, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition51 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix43, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor52 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double53 = array2DRowRealMatrix43.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        double double54 = blockRealMatrix40.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        defaultRealMatrixPreservingVisitor52.start((-186238143), 9, (int) (short) 0, 0, 2, (int) (short) 0);
        double double62 = array2DRowRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        try {
            double double67 = array2DRowRealMatrix5.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52, (int) (short) 100, 36, 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getStartPoint();
        int int24 = cMAESOptimizer22.getMaxEvaluations();
        int int25 = cMAESOptimizer22.getIterations();
        int int26 = cMAESOptimizer22.getIterations();
        java.util.List<java.lang.Double> doubleList27 = cMAESOptimizer22.getStatisticsFitnessHistory();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(doubleList27);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getAbsoluteAccuracy();
        double double2 = brentSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-6d + "'", double1 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        double[][] doubleArray2 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix3, (org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        double double8 = array2DRowRealMatrix3.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double[] doubleArray18 = pointVectorValuePair17.getSecond();
        double[] doubleArray19 = array2DRowRealMatrix3.preMultiply(doubleArray18);
        try {
            double[] doubleArray20 = diagonalMatrix1.preMultiply(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double[] doubleArray3 = new double[] { 0.8414709848078965d, (byte) 0, 1.0E-14d };
        double[] doubleArray7 = new double[] { 0.8414709848078965d, (byte) 0, 1.0E-14d };
        double[] doubleArray11 = new double[] { 0.8414709848078965d, (byte) 0, 1.0E-14d };
        double[][] doubleArray12 = new double[][] { doubleArray3, doubleArray7, doubleArray11 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        double[][] doubleArray18 = blockRealMatrix15.getData();
        double[] doubleArray20 = blockRealMatrix15.getColumn((int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        java.lang.String str13 = array2DRowRealMatrix0.toString();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Array2DRowRealMatrix{}" + "'", str13.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix21.createMatrix(3, (int) (byte) 1);
        double[] doubleArray31 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray31, doubleArray32);
        double[] doubleArray34 = pointVectorValuePair33.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix21.operate(doubleArray34);
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray34);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray14, doubleArray34);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex41 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray38, Double.NEGATIVE_INFINITY, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray4);
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister6.nextBytes(byteArray11);
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray17);
        mersenneTwister6.setSeed(0L);
        double double21 = mersenneTwister6.nextGaussian();
        double double22 = mersenneTwister6.nextDouble();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0553194731804223d + "'", double21 == 1.0553194731804223d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.1653253813890907d + "'", double22 == 0.1653253813890907d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(1.424243053035111E44d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 101.66738457347422d + "'", double1 == 101.66738457347422d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian modelFunctionJacobian1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian(multivariateMatrixFunction0);
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction2 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction3 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction4 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction5 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.junit.Assert.assertNull(multivariateMatrixFunction2);
        org.junit.Assert.assertNull(multivariateMatrixFunction3);
        org.junit.Assert.assertNull(multivariateMatrixFunction4);
        org.junit.Assert.assertNull(multivariateMatrixFunction5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) (short) 100, (int) (short) 1);
        double double3 = bracketFinder2.getFMid();
        double double4 = bracketFinder2.getFHi();
        double double5 = bracketFinder2.getFLo();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray8);
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) 100L, false);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) 49);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(100, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2, (int) (byte) 10, (int) (byte) 10, 2147483647, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 34.999996f, 3.0d, (int) (short) 10);
        double double4 = simpleUnivariateValueChecker3.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 34.999996185302734d + "'", double4 == 34.999996185302734d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = blockRealMatrix3.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector4, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.537297501373361d + "'", double1 == 2.537297501373361d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.optim.PointValuePair pointValuePair13 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, (double) '#', true);
        double[] doubleArray14 = pointValuePair13.getFirst();
        java.lang.Double double15 = pointValuePair13.getValue();
        double[] doubleArray16 = pointValuePair13.getPoint();
        boolean boolean17 = blockRealMatrix3.equals((java.lang.Object) doubleArray16);
        org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, 36, (int) (short) 1);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix3.scalarAdd((double) (-127));
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix3.createMatrix(2147483647, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 35.0d + "'", double15.equals(35.0d));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = arrayRealVector0.equals((java.lang.Object) orderDirection3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean14 = arrayRealVector12.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, (org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector12.mapDivideToSelf((double) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector6.combineToSelf((double) 1.1920929E-7f, Double.POSITIVE_INFINITY, realVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.subtract(realVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean31 = arrayRealVector29.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (short) 10);
        double double36 = arrayRealVector26.dotProduct(realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector19.ebeDivide(realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean40 = arrayRealVector38.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector38.subtract(realVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean47 = arrayRealVector45.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean50 = arrayRealVector48.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45, (org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivideToSelf((double) (short) 10);
        double double55 = arrayRealVector45.dotProduct(realVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector38.ebeDivide(realVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean59 = arrayRealVector57.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector60.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector57.subtract(realVector62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean68 = arrayRealVector66.equals((java.lang.Object) true);
        double[] doubleArray69 = arrayRealVector66.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector63.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector38.append((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector37.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = arrayRealVector6.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(arrayRealVector63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(arrayRealVector73);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        boolean boolean3 = arrayRealVector2.isInfinite();
        try {
            arrayRealVector2.setEntry(2, 19986.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (2)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        java.lang.String str4 = realVectorFormat3.getPrefix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = realMatrixFormat0.parse("}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ", " + "'", str1.equals(", "));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        double[][] doubleArray18 = blockRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix15.multiply(realMatrix19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        double double17 = arrayRealVector7.dotProduct(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector0.ebeDivide(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.subtract(realVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean31 = arrayRealVector29.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (short) 10);
        double double36 = arrayRealVector26.dotProduct(realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector19.ebeDivide(realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean40 = arrayRealVector38.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector38.subtract(realVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean49 = arrayRealVector47.equals((java.lang.Object) true);
        double[] doubleArray50 = arrayRealVector47.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector44.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector19.append((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector18.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, arrayRealVector54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(arrayRealVector53);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double7 = diagonalMatrix1.walkInRowOrder(realMatrixChangingVisitor2, (int) 'a', (int) (short) 1, 100, 49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        java.lang.String str4 = realVectorFormat3.getSuffix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector5.subtract(realVector10);
        arrayRealVector11.set(1.0E-15d);
        java.lang.String str14 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        int int15 = arrayRealVector11.getMaxIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!hi!" + "'", str14.equals("hi!hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValueRef();
        double[] doubleArray18 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair20 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray18, doubleArray19);
        double[] doubleArray21 = pointVectorValuePair20.getSecond();
        double[] doubleArray22 = pointVectorValuePair20.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray22);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapAddToSelf((double) 32);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        double[] doubleArray4 = diagonalMatrix3.getDataRef();
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = diagonalMatrix1.subtract(diagonalMatrix3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x97 but expected 35x35");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.append(arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector7.mapAdd(0.17453292519943295d);
        org.apache.commons.math3.linear.RealVector realVector14 = realVector12.mapSubtract(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix36.getRowMatrix((int) (byte) 0);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver39 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double40 = brentSolver39.getStartValue();
        boolean boolean41 = array2DRowRealMatrix36.equals((java.lang.Object) double40);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor42 = null;
        try {
            double double47 = array2DRowRealMatrix36.walkInRowOrder(realMatrixChangingVisitor42, 1072693248, (int) (byte) 10, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowSuffix();
        java.lang.String str4 = realMatrixFormat0.getRowSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "; " + "'", str1.equals("; "));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "; " + "'", str4.equals("; "));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        arrayRealVector6.set(1.0E-15d);
        try {
            double double10 = arrayRealVector6.getEntry((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        long long1 = org.apache.commons.math3.util.FastMath.round(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        boolean boolean12 = pointVectorValuePair9.equals((java.lang.Object) "hi!");
        double[] doubleArray13 = pointVectorValuePair9.getFirst();
        double[] doubleArray14 = pointVectorValuePair9.getValue();
        double[] doubleArray21 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray28 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray29 = new double[][] { doubleArray21, doubleArray28 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray29);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray14, doubleArray29);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException32 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        double[][] doubleArray18 = blockRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = null;
        try {
            blockRealMatrix15.setColumnMatrix((int) (byte) 100, realMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.8414709848078965d, 0.5071158626935848d, (double) (-1765991400464819176L), (double) '4');
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getKey();
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        org.apache.commons.math3.optim.PointValuePair pointValuePair15 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds16 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray12);
        try {
            double double17 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = arrayRealVector0.equals((java.lang.Object) orderDirection3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        int int7 = arrayRealVector0.getDimension();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.append(arrayRealVector7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean14 = arrayRealVector12.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix11, (org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        double double16 = array2DRowRealMatrix11.getFrobeniusNorm();
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector20.subtract(realVector25);
        double double27 = arrayRealVector19.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector28 = array2DRowRealMatrix11.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix29 = arrayRealVector7.outerProduct(realVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getFirst();
        double[] doubleArray6 = pointValuePair4.getFirst();
        java.lang.Double double7 = pointValuePair4.getSecond();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7.equals(35.0d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) 'a', (int) (byte) 100, (int) 'a');
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) 49);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double[] doubleArray17 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        double[] doubleArray20 = pointVectorValuePair19.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray20);
        double[] doubleArray22 = sigma21.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection23 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray30 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray37 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray38 = new double[][] { doubleArray30, doubleArray37 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray38);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray22, orderDirection23, doubleArray38);
        double[] doubleArray47 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray48 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair49 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray47, doubleArray48);
        double[] doubleArray50 = pointVectorValuePair49.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma51 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray50);
        double[] doubleArray52 = sigma51.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection53 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray60 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray67 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray68 = new double[][] { doubleArray60, doubleArray67 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray68);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, orderDirection53, doubleArray68);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, orderDirection23, doubleArray68);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68, false);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException74 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, (java.lang.Object[]) doubleArray68);
        org.apache.commons.math3.exception.ConvergenceException convergenceException75 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) doubleArray68);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68, false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = blockRealMatrix15.getColumnMatrix(0);
        try {
            blockRealMatrix15.multiplyEntry(36, (int) (byte) -1, (double) 4.5035996E15f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-17) + "'", int1 == (-17));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray8);
        java.lang.Class<?> wildcardClass12 = doubleArray1.getClass();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) ' ', (int) (short) 10, (int) (byte) 1, (int) (short) 1);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math3.util.FastMath.floor((-10.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.0d) + "'", double1 == (-10.0d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((-17), (double) (short) 1, (double) 3.8146973E-6f);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 10, 0.0d, (int) '4');
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.7659914004648192E18d), number1, true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.text.NumberFormat numberFormat2 = realMatrixFormat0.getFormat();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "; " + "'", str1.equals("; "));
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(100.0f, (float) 52, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.8813735870195429d, (double) 52L, univariatePointValuePairConvergenceChecker2);
        int int4 = brentOptimizer3.getEvaluations();
        int int5 = brentOptimizer3.getMaxIterations();
        double double6 = brentOptimizer3.getStartValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray9);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException15 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) ' ', 3, (int) (byte) 1);
        org.apache.commons.math3.exception.MathInternalError mathInternalError16 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException15);
        java.lang.Integer[] intArray17 = matrixDimensionMismatchException15.getExpectedDimensions();
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException18 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray17);
        org.apache.commons.math3.exception.util.Localizable localizable19 = null;
        java.lang.Integer[] intArray26 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray27 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException28 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable19, intArray26, intArray27);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException29 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray17, intArray27);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector3.mapDivideToSelf((double) (short) 0);
        int int9 = arrayRealVector3.getMaxIndex();
        int int10 = arrayRealVector3.getDimension();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        double double7 = arrayRealVector1.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.analysis.function.Sinc sinc12 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double14 = sinc12.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector0.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc12);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat19 = new org.apache.commons.math3.linear.RealVectorFormat("; ", "}", "hi!hi!");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector20.subtract(realVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean31 = arrayRealVector29.equals((java.lang.Object) true);
        double[] doubleArray32 = arrayRealVector29.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector26.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double[] doubleArray40 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair42 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray40, doubleArray41);
        double[] doubleArray43 = pointVectorValuePair42.getSecond();
        double[] doubleArray44 = pointVectorValuePair42.getValue();
        double[] doubleArray45 = pointVectorValuePair42.getValue();
        double[] doubleArray46 = pointVectorValuePair42.getSecond();
        double[] doubleArray47 = pointVectorValuePair42.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, doubleArray47);
        java.lang.String str49 = realVectorFormat19.format((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        try {
            org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector0.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.8414709848078965d + "'", double14 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "; }" + "'", str49.equals("; }"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.mapDivideToSelf((double) (short) 10);
        java.lang.Object[] objArray6 = new java.lang.Object[] { (short) 10, 10.0f, (-1.0f) };
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathArithmeticException7.getContext();
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathArithmeticException7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix1, 0, (int) (short) 10);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, 3.0d);
        double[] doubleArray11 = eigenDecomposition10.getImagEigenvalues();
        boolean boolean12 = eigenDecomposition10.hasComplexEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = eigenDecomposition10.getV();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = diagonalMatrix1.multiply(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        try {
            double[] doubleArray19 = blockRealMatrix15.getRow((-23));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-23)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 0, 0.0d, 10);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        double double5 = simpleVectorValueChecker3.getAbsoluteThreshold();
        double double6 = simpleVectorValueChecker3.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        boolean boolean6 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, 0.10272986741866949d);
        try {
            array2DRowRealMatrix0.multiplyEntry((-186238143), 0, (double) 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-186,238,143)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) (-9208070452475268559L), 4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1024.0d) + "'", double2 == (-1024.0d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        boolean boolean14 = array2DRowRealMatrix0.isSquare();
        boolean boolean15 = array2DRowRealMatrix0.isTransposable();
        int int16 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray17 = array2DRowRealMatrix0.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(doubleArray17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.optim.PointValuePair pointValuePair13 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, (double) '#', true);
        double[] doubleArray14 = pointValuePair13.getFirst();
        java.lang.Double double15 = pointValuePair13.getValue();
        double[] doubleArray16 = pointValuePair13.getPoint();
        boolean boolean17 = blockRealMatrix3.equals((java.lang.Object) doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix3.getColumnMatrix(0);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 35.0d + "'", double15.equals(35.0d));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 100.0f, (double) (short) 1, (int) 'a');
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((-23));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        try {
            double[][] doubleArray16 = array2DRowRealMatrix15.getData();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray11 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray18 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector22 = blockRealMatrix20.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix23.createMatrix(3, (int) (byte) 1);
        double double27 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix28);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition31 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix23, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor32 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double33 = array2DRowRealMatrix23.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double double34 = blockRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        defaultRealMatrixPreservingVisitor32.start((-186238143), 9, (int) (short) 0, 0, 2, (int) (short) 0);
        double double42 = array2DRowRealMatrix0.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        defaultRealMatrixPreservingVisitor32.visit((-17), (-1074790400), (double) 35.999996f);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        double[][] doubleArray5 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(5.298292365610485d, 2979.3805346802806d, (double) 7.6293945E-6f, 0.0922753880002305d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getKey();
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray11, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds15 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray11);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (1 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        int int5 = diagonalMatrix1.getColumnDimension();
        double[][] doubleArray6 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix1.copy();
        double[] doubleArray14 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray15);
        double[] doubleArray17 = pointVectorValuePair16.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray17);
        double[] doubleArray19 = sigma18.getSigma();
        try {
            double[] doubleArray20 = diagonalMatrix1.preMultiply(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double double19 = blockRealMatrix18.getNorm();
        double[] doubleArray26 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray33 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray34 = new double[][] { doubleArray26, doubleArray33 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        int int36 = blockRealMatrix35.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.copy();
        java.lang.String str38 = blockRealMatrix35.toString();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix35.scalarAdd(0.41019779969736225d);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix35);
        org.apache.commons.math3.linear.RealVector realVector43 = null;
        try {
            blockRealMatrix35.setColumnVector(9, realVector43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10263.0d + "'", double19 == 10263.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str38.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
        org.junit.Assert.assertNotNull(blockRealMatrix40);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        org.apache.commons.math3.linear.RealVector realVector5 = eigenDecomposition3.getEigenvector((int) '#');
        org.apache.commons.math3.linear.RealVector realVector7 = realVector5.mapSubtract((-4.503599627369091E15d));
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((-10.0d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat1);
        java.lang.String str3 = realMatrixFormat2.getRowSeparator();
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = realMatrixFormat2.parse(", ", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "," + "'", str3.equals(","));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix33, 1);
        blockRealMatrix33.addToEntry((int) (byte) 0, 3, 4.641588833612779d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getFirst();
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray15 = pointVectorValuePair14.getKey();
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray15, doubleArray17);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray5, doubleArray17);
        double[] doubleArray23 = pointVectorValuePair22.getValueRef();
        double[] doubleArray30 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair32 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray30, doubleArray31);
        double[] doubleArray33 = pointVectorValuePair32.getSecond();
        double[] doubleArray34 = pointVectorValuePair32.getValue();
        double[] doubleArray35 = pointVectorValuePair32.getValue();
        double[] doubleArray36 = pointVectorValuePair32.getSecond();
        boolean boolean37 = pointVectorValuePair22.equals((java.lang.Object) pointVectorValuePair32);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix21.createMatrix(3, (int) (byte) 1);
        double[] doubleArray31 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray31, doubleArray32);
        double[] doubleArray34 = pointVectorValuePair33.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix21.operate(doubleArray34);
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray34);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray14, doubleArray34);
        org.apache.commons.math3.linear.RealVector realVector39 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray38);
        org.apache.commons.math3.linear.RealVector realVector41 = realVector39.mapDivide(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(3, (double) (short) -1);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator4 = null;
        try {
            nelderMeadSimplex2.evaluate(multivariateFunction3, pointValuePairComparator4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        float[] floatArray1 = new float[] { 1 };
        float[] floatArray8 = new float[] { 10L, 1, 1, (byte) 10, '4', (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray1, floatArray8);
        float[] floatArray11 = new float[] { 1 };
        float[] floatArray18 = new float[] { 10L, 1, 1, (byte) 10, '4', (short) 1 };
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray11, floatArray18);
        float[] floatArray26 = new float[] { '#', (short) 10, '#', ' ', (short) 0, 'a' };
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(floatArray11, floatArray26);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equals(floatArray8, floatArray11);
        float[] floatArray30 = new float[] { 1 };
        float[] floatArray37 = new float[] { 10L, 1, 1, (byte) 10, '4', (short) 1 };
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray30, floatArray37);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(floatArray11, floatArray30);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        boolean boolean14 = array2DRowRealMatrix0.isSquare();
        boolean boolean15 = array2DRowRealMatrix0.isSquare();
        double double16 = array2DRowRealMatrix0.getNorm();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double2 = org.apache.commons.math3.util.FastMath.min(1.5707255745373732d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707255745373732d + "'", double2 == 1.5707255745373732d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor7 = null;
        try {
            double double8 = arrayRealVector6.walkInOptimizedOrder(realVectorPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        boolean boolean7 = arrayRealVector0.isNaN();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat9 = realVectorFormat8.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean15 = arrayRealVector13.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, (org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        java.lang.String str17 = realVectorFormat8.format((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        int int18 = arrayRealVector13.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector13.mapAdd((double) 0L);
        org.apache.commons.math3.analysis.function.Sinc sinc22 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double24 = sinc22.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector13.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc22);
        double double26 = arrayRealVector0.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.8414709848078965d + "'", double24 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        incrementor1.incrementCount(35);
        incrementor1.incrementCount((-23));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = eigenDecomposition3.getD();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        double double10 = diagonalMatrix1.getEntry(32, (int) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector11.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector11.subtract(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        double[] doubleArray23 = arrayRealVector20.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector17.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        boolean boolean25 = diagonalMatrix1.equals((java.lang.Object) arrayRealVector17);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, 3.0d);
        diagonalMatrix27.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix27.copy();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = diagonalMatrix1.subtract(diagonalMatrix27);
        int int36 = diagonalMatrix1.getRowDimension();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(diagonalMatrix35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 97 + "'", int36 == 97);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getStartPoint();
        java.util.List<java.lang.Double> doubleList24 = cMAESOptimizer22.getStatisticsFitnessHistory();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray25 = null;
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair26 = cMAESOptimizer22.optimize(optimizationDataArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleList24);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getKey();
        double[] doubleArray11 = pointVectorValuePair9.getFirst();
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray8);
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) 100L, false);
        double[] doubleArray15 = pointValuePair14.getFirst();
        double[] doubleArray16 = pointValuePair14.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        int int18 = blockRealMatrix15.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = blockRealMatrix15.walkInOptimizedOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(1.5707255745373732d, 1.0000000000000002d, (int) '4');
        double double4 = simpleUnivariateValueChecker3.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0000000000000002d + "'", double4 == 1.0000000000000002d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getKey();
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray11, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds15 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection19 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean20 = arrayRealVector16.equals((java.lang.Object) orderDirection19);
        double[] doubleArray21 = arrayRealVector16.toArray();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray21);
        double double23 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray11, doubleArray21);
        double[] doubleArray30 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair32 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray30, doubleArray31);
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray21, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double1 = org.apache.commons.math3.util.FastMath.asin(26.5d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("}", ", ", "; }", "hi!hi!", "Array2DRowRealMatrix{}", "");
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        long long23 = mersenneTwister11.nextLong();
        double double24 = mersenneTwister11.nextGaussian();
        double double25 = mersenneTwister11.nextGaussian();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1765991400464819176L) + "'", long23 == (-1765991400464819176L));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.5071158626935848d + "'", double24 == 0.5071158626935848d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.1518043302014853d + "'", double25 == 1.1518043302014853d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray9);
        org.apache.commons.math3.exception.ZeroException zeroException11 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) intArray9);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) zeroException11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        int[] intArray8 = new int[] { (byte) 10 };
        int[] intArray11 = new int[] { 1, (short) 100 };
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray8, intArray11);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister(intArray11);
        byte[] byteArray18 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister13.nextBytes(byteArray18);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker23 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer24 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister13, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker23);
        java.lang.Class<?> wildcardClass25 = simpleValueChecker23.getClass();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(98.10395148368781d, (-10.0d), (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -10 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getTrace();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] formulaArray0 = null;
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix2 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition4 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix2, 3.0d);
        double[] doubleArray5 = eigenDecomposition4.getImagEigenvalues();
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray21 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray21, doubleArray22);
        double[] doubleArray24 = pointVectorValuePair23.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray24);
        double[] doubleArray26 = sigma25.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection27 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray34 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray41 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray42 = new double[][] { doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray42);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray26, orderDirection27, doubleArray42);
        double[] doubleArray51 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray52 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair53 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray51, doubleArray52);
        double[] doubleArray54 = pointVectorValuePair53.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma55 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray54);
        double[] doubleArray56 = sigma55.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection57 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray64 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray71 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray72 = new double[][] { doubleArray64, doubleArray71 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray72);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray56, orderDirection57, doubleArray72);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray13, orderDirection27, doubleArray72);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection27, false);
        try {
            boolean boolean79 = org.apache.commons.math3.util.MathArrays.isMonotonic(formulaArray0, orderDirection27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, true);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver7 = lUDecomposition6.getSolver();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = lUDecomposition6.getSolver();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver9 = lUDecomposition6.getSolver();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = lUDecomposition6.getP();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(decompositionSolver7);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(decompositionSolver9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        double[][] doubleArray2 = diagonalMatrix1.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 96");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean8 = arrayRealVector4.equals((java.lang.Object) orderDirection7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean15 = arrayRealVector13.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.subtract(realVector18);
        arrayRealVector4.setSubVector(0, realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector21.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector4.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean31 = arrayRealVector29.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector29.subtract(realVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean40 = arrayRealVector38.equals((java.lang.Object) true);
        double[] doubleArray41 = arrayRealVector38.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector35.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector21.combine(0.0d, 2.2250738585072014E-308d, (org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor44 = null;
        try {
            double double47 = arrayRealVector38.walkInOptimizedOrder(realVectorChangingVisitor44, (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(arrayRealVector43);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double3 = sinc1.value((double) (byte) -1);
        double double7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 3.4359738367999756E10d, 7.930067261567154E14d, (double) 96);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8414709848078965d + "'", double3 == 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.965205429475417E14d + "'", double7 == 3.965205429475417E14d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix36.getRowMatrix((int) (byte) 0);
        double[] doubleArray45 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray52 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray53 = new double[][] { doubleArray45, doubleArray52 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray53);
        double[] doubleArray56 = blockRealMatrix54.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix54.transpose();
        double[] doubleArray64 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray71 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray72 = new double[][] { doubleArray64, doubleArray71 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray72);
        org.apache.commons.math3.linear.RealVector realVector75 = blockRealMatrix73.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = blockRealMatrix57.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix73);
        double[] doubleArray83 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray90 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray91 = new double[][] { doubleArray83, doubleArray90 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix92 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray91);
        org.apache.commons.math3.linear.RealVector realVector94 = blockRealMatrix92.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix73, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix92);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix38, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x6 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(realVector94);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        double double3 = arrayRealVector2.getMinValue();
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector7.subtract(realVector12);
        double double14 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector2.append((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean18 = arrayRealVector16.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.subtract(realVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean25 = arrayRealVector23.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) (short) 10);
        double double33 = arrayRealVector23.dotProduct(realVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector16.ebeDivide(realVector32);
        double double35 = arrayRealVector13.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 34.999996f);
        double double2 = brentSolver1.getStartValue();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = null;
        try {
            double double6 = brentSolver1.solve((int) '#', univariateFunction4, 0.7853981633974447d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray6 = eigenDecomposition3.getRealEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter((int) (short) 100);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        double double10 = diagonalMatrix1.getEntry(32, (int) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector11.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector11.subtract(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        double[] doubleArray23 = arrayRealVector20.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector17.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        boolean boolean25 = diagonalMatrix1.equals((java.lang.Object) arrayRealVector17);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, 3.0d);
        diagonalMatrix27.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix27.copy();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = diagonalMatrix1.subtract(diagonalMatrix27);
        try {
            diagonalMatrix1.setEntry((-23), 6, 171.88733853924697d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 171.887 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(diagonalMatrix35);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.optim.PointValuePair pointValuePair13 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, (double) '#', true);
        double[] doubleArray14 = pointValuePair13.getFirst();
        java.lang.Double double15 = pointValuePair13.getValue();
        double[] doubleArray16 = pointValuePair13.getPoint();
        boolean boolean17 = blockRealMatrix3.equals((java.lang.Object) doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition21 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix19, 3.0d);
        diagonalMatrix19.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = diagonalMatrix19.copy();
        double double29 = diagonalMatrix19.getEntry(9, 0);
        diagonalMatrix19.multiplyEntry((int) (short) 100, 52, 0.5071158626935848d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x6 but expected 97x97");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 35.0d + "'", double15.equals(35.0d));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapSubtract((double) (-1));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector9.subtract(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector15.append(arrayRealVector16);
        double double20 = arrayRealVector6.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        try {
            arrayRealVector19.addToEntry(32, 0.4078492487004386d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.optim.PointValuePair pointValuePair13 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, (double) '#', true);
        double[] doubleArray14 = pointValuePair13.getFirst();
        java.lang.Double double15 = pointValuePair13.getValue();
        double[] doubleArray16 = pointValuePair13.getPoint();
        boolean boolean17 = blockRealMatrix3.equals((java.lang.Object) doubleArray16);
        org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, 36, (int) (short) 1);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        boolean boolean25 = arrayRealVector24.isInfinite();
        try {
            blockRealMatrix3.setColumnVector(35, (org.apache.commons.math3.linear.RealVector) arrayRealVector24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 35.0d + "'", double15.equals(35.0d));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, (-0.5063656411097588d), 1.11669149749E11d, 14133.824606241582d, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [111,669,149,749, -0.506]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        try {
            org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 127.0f, 0.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        int[] intArray8 = new int[] { (byte) 10 };
        int[] intArray11 = new int[] { 1, (short) 100 };
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray8, intArray11);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister(intArray8);
        int[] intArray15 = new int[] { (byte) 10 };
        int[] intArray18 = new int[] { 1, (short) 100 };
        int int19 = org.apache.commons.math3.util.MathArrays.distance1(intArray15, intArray18);
        int[] intArray21 = new int[] { (byte) 10 };
        int[] intArray24 = new int[] { 1, (short) 100 };
        int int25 = org.apache.commons.math3.util.MathArrays.distance1(intArray21, intArray24);
        int int26 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray15, intArray21);
        int int27 = org.apache.commons.math3.util.MathArrays.distance1(intArray8, intArray15);
        int[] intArray29 = new int[] { (byte) 10 };
        int[] intArray32 = new int[] { 1, (short) 100 };
        int int33 = org.apache.commons.math3.util.MathArrays.distance1(intArray29, intArray32);
        int[] intArray35 = new int[] { (byte) 10 };
        int[] intArray38 = new int[] { 1, (short) 100 };
        int int39 = org.apache.commons.math3.util.MathArrays.distance1(intArray35, intArray38);
        int int40 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray29, intArray35);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix41 = array2DRowRealMatrix0.getSubMatrix(intArray8, intArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        java.lang.Object obj12 = null;
        boolean boolean13 = pointVectorValuePair8.equals(obj12);
        double[] doubleArray14 = pointVectorValuePair8.getKey();
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        double double5 = diagonalMatrix1.getTrace();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) (short) 100, (int) (short) 1);
        double double3 = bracketFinder2.getFMid();
        double double4 = bracketFinder2.getMid();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray9);
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray19 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable11, intArray18, intArray19);
        org.apache.commons.math3.exception.util.Localizable localizable21 = null;
        java.lang.Integer[] intArray28 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray29 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException30 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable21, intArray28, intArray29);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException31 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray18, intArray29);
        org.apache.commons.math3.exception.util.Localizable localizable32 = null;
        org.apache.commons.math3.exception.util.Localizable localizable33 = null;
        org.apache.commons.math3.exception.util.Localizable localizable34 = null;
        org.apache.commons.math3.exception.util.Localizable localizable35 = null;
        org.apache.commons.math3.optim.MaxIter maxIter36 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray45 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray45, doubleArray46);
        double[] doubleArray48 = pointVectorValuePair47.getSecond();
        java.lang.Object[] objArray49 = new java.lang.Object[] { maxIter36, 19.085536923187668d, (byte) 100, pointVectorValuePair47 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable35, objArray49);
        org.apache.commons.math3.exception.MathInternalError mathInternalError51 = new org.apache.commons.math3.exception.MathInternalError(localizable34, objArray49);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException52 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable33, objArray49);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray18, localizable32, objArray49);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException54 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray18);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException55 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) intArray9);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(maxIter36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getPointRef();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getPoint();
        double[] doubleArray15 = pointVectorValuePair8.getValue();
        double[] doubleArray16 = null;
        try {
            double double17 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray15, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (-1074790400), (double) 7.6293945E-6f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double double19 = blockRealMatrix18.getNorm();
        double[] doubleArray26 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray33 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray34 = new double[][] { doubleArray26, doubleArray33 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        int int36 = blockRealMatrix35.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.copy();
        java.lang.String str38 = blockRealMatrix35.toString();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix35.scalarAdd(0.41019779969736225d);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix35);
        java.io.ObjectInputStream objectInputStream43 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) blockRealMatrix18, "hi!", objectInputStream43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10263.0d + "'", double19 == 10263.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str38.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
        org.junit.Assert.assertNotNull(blockRealMatrix40);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = blockRealMatrix15.getColumnMatrix(0);
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector44.subtract(realVector49);
        double double51 = arrayRealVector43.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        try {
            blockRealMatrix15.setRowVector((int) (short) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getPointRef();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getPoint();
        double[] doubleArray15 = pointVectorValuePair8.getKey();
        double[] doubleArray16 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection17 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, number1, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = nonMonotonicSequenceException5.getDirection();
        int int8 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray19);
        double[] doubleArray21 = sigma20.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection22 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray29 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray36 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray37 = new double[][] { doubleArray29, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray21, orderDirection22, doubleArray37);
        double[] doubleArray46 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray47);
        double[] doubleArray49 = pointVectorValuePair48.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma50 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray49);
        double[] doubleArray51 = sigma50.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection52 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray59 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray66 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray67 = new double[][] { doubleArray59, doubleArray66 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray67);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray51, orderDirection52, doubleArray67);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, orderDirection22, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67, false);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException73 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray67);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray67);
        blockRealMatrix74.setEntry((int) (byte) 0, (int) (byte) 1, 0.0d);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition83 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix81, 3.0d);
        org.apache.commons.math3.linear.RealVector realVector85 = eigenDecomposition83.getEigenvector((int) '#');
        try {
            blockRealMatrix74.setColumnVector(10, realVector85);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realVector85);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray20 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray20, doubleArray21);
        double[] doubleArray23 = pointVectorValuePair22.getSecond();
        double[] doubleArray24 = pointVectorValuePair22.getValue();
        double[] doubleArray25 = pointVectorValuePair22.getValue();
        double[] doubleArray26 = pointVectorValuePair22.getSecond();
        double[] doubleArray27 = pointVectorValuePair22.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray27);
        double[] doubleArray35 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray36);
        double[] doubleArray38 = pointVectorValuePair37.getSecond();
        double[] doubleArray39 = pointVectorValuePair37.getValue();
        double[] doubleArray40 = pointVectorValuePair37.getValueRef();
        double[] doubleArray47 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray48 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair49 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray47, doubleArray48);
        double[] doubleArray50 = pointVectorValuePair49.getSecond();
        double[] doubleArray51 = pointVectorValuePair49.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, doubleArray51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector28, doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat1);
        java.text.NumberFormat numberFormat3 = realMatrixFormat2.getFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector3.mapDivideToSelf((double) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean13 = arrayRealVector9.equals((java.lang.Object) orderDirection12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean20 = arrayRealVector18.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, (org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector21.mapDivideToSelf((double) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector15.combineToSelf((double) 1.1920929E-7f, Double.POSITIVE_INFINITY, realVector26);
        double double28 = arrayRealVector3.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 7911606632076355948L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarMultiply(0.10272986741866949d);
        double[] doubleArray27 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray34 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray35 = new double[][] { doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector38 = blockRealMatrix36.getRowVector((int) (byte) 0);
        double[] doubleArray45 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray52 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray53 = new double[][] { doubleArray45, doubleArray52 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray53);
        double[] doubleArray56 = blockRealMatrix54.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix36.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix54);
        try {
            blockRealMatrix17.setRowMatrix(1072693248, blockRealMatrix57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor15 = null;
        try {
            double double18 = arrayRealVector6.walkInDefaultOrder(realVectorChangingVisitor15, 1, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean8 = arrayRealVector4.equals((java.lang.Object) orderDirection7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean15 = arrayRealVector13.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.subtract(realVector18);
        arrayRealVector4.setSubVector(0, realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector21.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector4.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor27 = null;
        try {
            double double30 = arrayRealVector4.walkInOptimizedOrder(realVectorPreservingVisitor27, (int) (byte) 1, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        incrementor1.incrementCount(35);
        incrementor1.resetCount();
        incrementor1.incrementCount();
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        java.lang.String str14 = arrayRealVector13.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean17 = arrayRealVector15.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector15.subtract(realVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean26 = arrayRealVector24.equals((java.lang.Object) true);
        double[] doubleArray27 = arrayRealVector24.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector21.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.analysis.function.Sinc sinc30 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double32 = sinc30.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction33 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector28.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc30);
        boolean boolean37 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc30, 0.0922753880002305d, (double) 7.6293945E-6f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector13.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{}" + "'", str14.equals("{}"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.8414709848078965d + "'", double32 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(arrayRealVector38);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        int int5 = diagonalMatrix1.getColumnDimension();
        double[][] doubleArray6 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', 10.0d);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) (byte) 10, 1.5707963267948966d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker6 = brentOptimizer5.getConvergenceChecker();
        int int7 = brentOptimizer5.getIterations();
        int int8 = brentOptimizer5.getMaxIterations();
        org.junit.Assert.assertNotNull(univariatePointValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 'a', 0.41019779969736225d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        double[] doubleArray22 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray22, doubleArray23);
        double[] doubleArray25 = pointVectorValuePair24.getKey();
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds31 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray25, doubleArray27);
        double double32 = org.apache.commons.math3.util.MathArrays.distance(doubleArray15, doubleArray27);
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x5) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, number1, (int) (short) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonicSequenceException5.getArgument();
        int int7 = nonMonotonicSequenceException5.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = nonMonotonicSequenceException5.getDirection();
        java.lang.Number number9 = nonMonotonicSequenceException5.getPrevious();
        java.lang.Number number10 = nonMonotonicSequenceException5.getArgument();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = nonMonotonicSequenceException5.getDirection();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNull(orderDirection11);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver5 = new org.apache.commons.math3.analysis.solvers.BrentSolver(Double.NaN);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver5);
        double double7 = simpleValueChecker3.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', 10.0d);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) (byte) 10, 1.5707963267948966d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getMax();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double double19 = blockRealMatrix18.getNorm();
        double[] doubleArray26 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray33 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray34 = new double[][] { doubleArray26, doubleArray33 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        int int36 = blockRealMatrix35.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.copy();
        java.lang.String str38 = blockRealMatrix35.toString();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix35.scalarAdd(0.41019779969736225d);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix35);
        double double42 = blockRealMatrix18.getNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10263.0d + "'", double19 == 10263.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str38.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 10263.0d + "'", double42 == 10263.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray15 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException16 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable7, intArray14, intArray15);
        org.apache.commons.math3.exception.util.Localizable localizable17 = null;
        java.lang.Integer[] intArray24 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray25 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException26 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable17, intArray24, intArray25);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException27 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray14, intArray25);
        org.apache.commons.math3.exception.util.Localizable localizable28 = null;
        org.apache.commons.math3.exception.util.Localizable localizable29 = null;
        org.apache.commons.math3.exception.util.Localizable localizable30 = null;
        org.apache.commons.math3.exception.util.Localizable localizable31 = null;
        org.apache.commons.math3.optim.MaxIter maxIter32 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray41 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray41, doubleArray42);
        double[] doubleArray44 = pointVectorValuePair43.getSecond();
        java.lang.Object[] objArray45 = new java.lang.Object[] { maxIter32, 19.085536923187668d, (byte) 100, pointVectorValuePair43 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable31, objArray45);
        org.apache.commons.math3.exception.MathInternalError mathInternalError47 = new org.apache.commons.math3.exception.MathInternalError(localizable30, objArray45);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException48 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable29, objArray45);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray14, localizable28, objArray45);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException50 = new org.apache.commons.math3.exception.NoBracketingException(localizable2, (double) 1.1920929E-7f, 0.0d, 0.8414709848078965d, 2.2250738585072014E-308d, objArray45);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException51 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) Double.POSITIVE_INFINITY, objArray45);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(maxIter32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double double5 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray15 = pointVectorValuePair14.getSecond();
        double[] doubleArray16 = array2DRowRealMatrix0.preMultiply(doubleArray15);
        try {
            array2DRowRealMatrix0.addToEntry(0, 6, (-4.503599627369091E15d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        boolean boolean21 = pointVectorValuePair18.equals((java.lang.Object) "hi!");
        double[] doubleArray22 = pointVectorValuePair18.getSecond();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, doubleArray22);
        double[] doubleArray24 = arrayRealVector23.toArray();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(34.999996f, (double) (-186238143));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.999992f + "'", float2 == 34.999992f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix21.createMatrix(3, (int) (byte) 1);
        double[] doubleArray31 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray31, doubleArray32);
        double[] doubleArray34 = pointVectorValuePair33.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix21.operate(doubleArray34);
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray34);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray14, doubleArray34);
        org.apache.commons.math3.optim.InitialGuess initialGuess39 = new org.apache.commons.math3.optim.InitialGuess(doubleArray34);
        double[] doubleArray40 = initialGuess39.getInitialGuess();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(97);
        int[] intArray3 = new int[] { (byte) 10 };
        int[] intArray6 = new int[] { 1, (short) 100 };
        int int7 = org.apache.commons.math3.util.MathArrays.distance1(intArray3, intArray6);
        int[] intArray8 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        mersenneTwister1.setSeed(intArray3);
        double double11 = mersenneTwister1.nextDouble();
        int[] intArray13 = new int[] { (byte) 10 };
        int[] intArray16 = new int[] { 1, (short) 100 };
        int int17 = org.apache.commons.math3.util.MathArrays.distance1(intArray13, intArray16);
        int[] intArray19 = new int[] { (byte) 10 };
        int[] intArray22 = new int[] { 1, (short) 100 };
        int int23 = org.apache.commons.math3.util.MathArrays.distance1(intArray19, intArray22);
        int int24 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray13, intArray19);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister(intArray19);
        mersenneTwister1.setSeed(intArray19);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5714025949326911d + "'", double11 == 0.5714025949326911d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray9);
        double[] doubleArray11 = sigma10.getSigma();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 34.999996f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5835188324922913d + "'", double1 == 3.5835188324922913d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) 3.43597384E11f, (java.lang.Number) 3.5835188324922913d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 10L, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = array2DRowRealMatrix15.multiply(array2DRowRealMatrix16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 96");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.Integer[] intArray0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) ' ', (int) (short) 10, (int) (byte) 1, (int) (short) 1);
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException5.getWrongDimensions();
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException7 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray9);
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray19 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable11, intArray18, intArray19);
        org.apache.commons.math3.exception.util.Localizable localizable21 = null;
        java.lang.Integer[] intArray28 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray29 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException30 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable21, intArray28, intArray29);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException31 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray18, intArray29);
        org.apache.commons.math3.exception.util.Localizable localizable32 = null;
        org.apache.commons.math3.exception.util.Localizable localizable33 = null;
        org.apache.commons.math3.exception.util.Localizable localizable34 = null;
        org.apache.commons.math3.exception.util.Localizable localizable35 = null;
        org.apache.commons.math3.optim.MaxIter maxIter36 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray45 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray45, doubleArray46);
        double[] doubleArray48 = pointVectorValuePair47.getSecond();
        java.lang.Object[] objArray49 = new java.lang.Object[] { maxIter36, 19.085536923187668d, (byte) 100, pointVectorValuePair47 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable35, objArray49);
        org.apache.commons.math3.exception.MathInternalError mathInternalError51 = new org.apache.commons.math3.exception.MathInternalError(localizable34, objArray49);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException52 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable33, objArray49);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray18, localizable32, objArray49);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException54 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray18);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) intArray9);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(maxIter36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getPointRef();
        double[] doubleArray6 = pointValuePair4.getKey();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        double[] doubleArray43 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray50 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray51 = new double[][] { doubleArray43, doubleArray50 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray51);
        org.apache.commons.math3.linear.RealVector realVector54 = blockRealMatrix52.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = array2DRowRealMatrix55.createMatrix(3, (int) (byte) 1);
        double double59 = array2DRowRealMatrix55.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix55, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix60);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition63 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix55, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor64 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double65 = array2DRowRealMatrix55.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor64);
        double double66 = blockRealMatrix52.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor64);
        defaultRealMatrixPreservingVisitor64.start((-186238143), 9, (int) (short) 0, 0, 2, (int) (short) 0);
        double double74 = blockRealMatrix15.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor64);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double17 = sinc15.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction18 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        boolean boolean22 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc15, 0.0922753880002305d, (double) 7.6293945E-6f);
        double double24 = sinc15.value(2.2163925864078933d);
        try {
            double[] doubleArray28 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc15, 0.0d, (double) 100, (double) 96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8414709848078965d + "'", double17 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.36037891457679466d + "'", double24 == 0.36037891457679466d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        double[] doubleArray22 = new double[] { 343597383680L, 1.0E-6d, 0.5714025949326911d, 0, 1L };
        double[] doubleArray28 = new double[] { 343597383680L, 1.0E-6d, 0.5714025949326911d, 0, 1L };
        double[] doubleArray34 = new double[] { 343597383680L, 1.0E-6d, 0.5714025949326911d, 0, 1L };
        double[][] doubleArray35 = new double[][] { doubleArray22, doubleArray28, doubleArray34 };
        try {
            blockRealMatrix15.setSubMatrix(doubleArray35, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getImagEigenvalues();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = eigenDecomposition3.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (byte) 1, (float) (-9208070452475268559L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction2 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc1);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure3 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure4 = sinc1.value(derivativeStructure3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.addToEntry((int) '#', 0, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.001223444938659668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.706084679233028d) + "'", double1 == (-6.706084679233028d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        int int5 = diagonalMatrix1.getColumnDimension();
        double[][] doubleArray6 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix1.copy();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition11 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix9, 3.0d);
        double[] doubleArray12 = diagonalMatrix9.getDataRef();
        int int13 = diagonalMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = diagonalMatrix1.multiply(diagonalMatrix9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean17 = arrayRealVector15.equals((java.lang.Object) true);
        int int18 = arrayRealVector15.getDimension();
        try {
            org.apache.commons.math3.linear.RealVector realVector19 = diagonalMatrix9.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertNotNull(diagonalMatrix14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double double6 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        try {
            org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector3.getSubVector((int) (short) 10, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.optim.MaxIter maxIter8 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray17 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        double[] doubleArray20 = pointVectorValuePair19.getSecond();
        java.lang.Object[] objArray21 = new java.lang.Object[] { maxIter8, 19.085536923187668d, (byte) 100, pointVectorValuePair19 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable7, objArray21);
        org.apache.commons.math3.exception.MathInternalError mathInternalError23 = new org.apache.commons.math3.exception.MathInternalError(localizable6, objArray21);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException24 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable5, objArray21);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.0d, (double) (byte) 100, (double) 'a', (double) 9, objArray21);
        double double26 = noBracketingException25.getFHi();
        org.junit.Assert.assertNotNull(maxIter8);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 9.0d + "'", double26 == 9.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getPointRef();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getPoint();
        double[] doubleArray15 = pointVectorValuePair8.getValue();
        int[] intArray22 = new int[] { (byte) 10 };
        int[] intArray25 = new int[] { 1, (short) 100 };
        int int26 = org.apache.commons.math3.util.MathArrays.distance1(intArray22, intArray25);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math3.random.MersenneTwister(intArray25);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister27.nextBytes(byteArray32);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker37 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer38 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister27, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker37);
        double[] doubleArray39 = cMAESOptimizer38.getStartPoint();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList40 = cMAESOptimizer38.getStatisticsMeanHistory();
        boolean boolean41 = pointVectorValuePair8.equals((java.lang.Object) cMAESOptimizer38);
        int int42 = cMAESOptimizer38.getMaxEvaluations();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrixList40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix7.createMatrix(3, (int) (byte) 1);
        double double11 = array2DRowRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix12);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition15 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor16 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double17 = array2DRowRealMatrix7.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor16);
        double double18 = defaultRealMatrixPreservingVisitor16.end();
        double double19 = array2DRowRealMatrix0.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor16);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.8813735870195429d, (double) 52L, univariatePointValuePairConvergenceChecker2);
        int int4 = brentOptimizer3.getEvaluations();
        int int5 = brentOptimizer3.getMaxIterations();
        double double6 = brentOptimizer3.getMin();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = brentOptimizer3.getGoalType();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(goalType7);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) ' ', (double) 100.00001f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getPointRef();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix4.createMatrix(3, (int) (byte) 1);
        double double8 = array2DRowRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix4, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix9);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition12 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix4, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor13 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double14 = array2DRowRealMatrix4.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor13);
        double double15 = array2DRowRealMatrix0.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray23 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair25 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray23, doubleArray24);
        double[] doubleArray26 = pointVectorValuePair25.getSecond();
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix16.preMultiply(doubleArray27);
        double[][] doubleArray29 = array2DRowRealMatrix16.getData();
        boolean boolean30 = array2DRowRealMatrix16.isSquare();
        boolean boolean31 = array2DRowRealMatrix16.isTransposable();
        double[] doubleArray38 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray45 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray52 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray59 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray66 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray67 = new double[][] { doubleArray38, doubleArray45, doubleArray52, doubleArray59, doubleArray66 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix68.getRowMatrix((int) (byte) 0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor71 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double72 = array2DRowRealMatrix68.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor71);
        double double73 = array2DRowRealMatrix16.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor71);
        double double74 = array2DRowRealMatrix0.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor71);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray9);
        double[] doubleArray11 = sigma10.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray19 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray26 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray27 = new double[][] { doubleArray19, doubleArray26 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray11, orderDirection12, doubleArray27);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray11);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray39 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray46 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray47 = new double[][] { doubleArray39, doubleArray46 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray47);
        double[] doubleArray50 = blockRealMatrix48.getRow(0);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray50);
        try {
            double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray11, doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getAbsoluteAccuracy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector3.subtract(realVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean14 = arrayRealVector12.equals((java.lang.Object) true);
        double[] doubleArray15 = arrayRealVector12.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector9.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.analysis.function.Sinc sinc18 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double20 = sinc18.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction21 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc18);
        boolean boolean25 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc18, 0.0922753880002305d, (double) 7.6293945E-6f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction26 = sinc18.derivative();
        double double29 = brentSolver0.solve(2, univariateFunction26, (-1.5707963267948966d), 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-6d + "'", double1 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.8414709848078965d + "'", double20 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(univariateFunction26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.3440585709080678E43d + "'", double29 == 1.3440585709080678E43d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval(2.203819919143124d, 0.18399191394796865d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [2.204, 0.184]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray10 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException11 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray9, intArray10);
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        java.lang.Integer[] intArray19 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray20 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable12, intArray19, intArray20);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException22 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray20);
        org.apache.commons.math3.exception.util.Localizable localizable23 = null;
        java.lang.Integer[] intArray30 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray31 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException32 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable23, intArray30, intArray31);
        org.apache.commons.math3.exception.util.Localizable localizable33 = null;
        java.lang.Integer[] intArray40 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray41 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException42 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable33, intArray40, intArray41);
        org.apache.commons.math3.exception.util.Localizable localizable43 = null;
        java.lang.Integer[] intArray50 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray51 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException52 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable43, intArray50, intArray51);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException53 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray40, intArray51);
        org.apache.commons.math3.exception.util.Localizable localizable54 = null;
        org.apache.commons.math3.exception.util.Localizable localizable55 = null;
        org.apache.commons.math3.exception.util.Localizable localizable56 = null;
        org.apache.commons.math3.exception.util.Localizable localizable57 = null;
        org.apache.commons.math3.optim.MaxIter maxIter58 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray67 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray68 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair69 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray67, doubleArray68);
        double[] doubleArray70 = pointVectorValuePair69.getSecond();
        java.lang.Object[] objArray71 = new java.lang.Object[] { maxIter58, 19.085536923187668d, (byte) 100, pointVectorValuePair69 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable57, objArray71);
        org.apache.commons.math3.exception.MathInternalError mathInternalError73 = new org.apache.commons.math3.exception.MathInternalError(localizable56, objArray71);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException74 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable55, objArray71);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray40, localizable54, objArray71);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException76 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray31, intArray40);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException77 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray20, intArray31);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException82 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) ' ', 3, (int) (byte) 1);
        int int83 = matrixDimensionMismatchException82.getWrongRowDimension();
        int int84 = matrixDimensionMismatchException82.getWrongRowDimension();
        java.lang.Integer[] intArray85 = matrixDimensionMismatchException82.getExpectedDimensions();
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException86 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray31, intArray85);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(maxIter58);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 10 + "'", int83 == 10);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 10 + "'", int84 == 10);
        org.junit.Assert.assertNotNull(intArray85);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix36, 32, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(1.0E-15d, (double) 7911606632076355948L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.9116066320763556E18d + "'", double2 == 7.9116066320763556E18d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        long long1 = org.apache.commons.math3.util.FastMath.round(7.6293654275675724E-6d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((-1.7659914004648192E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        try {
            org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix36.getRowMatrix((int) (byte) 0);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver39 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double40 = brentSolver39.getStartValue();
        boolean boolean41 = array2DRowRealMatrix36.equals((java.lang.Object) double40);
        double[] doubleArray48 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray55 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray62 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray69 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray76 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray77 = new double[][] { doubleArray48, doubleArray55, doubleArray62, doubleArray69, doubleArray76 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray77);
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = array2DRowRealMatrix78.getRowMatrix((int) (byte) 0);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = array2DRowRealMatrix36.multiply(array2DRowRealMatrix78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realMatrix80);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        java.lang.Number number10 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection13 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number10, number11, (int) (short) 0, orderDirection13, false);
        java.lang.Number number16 = nonMonotonicSequenceException15.getArgument();
        int int17 = nonMonotonicSequenceException15.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection18 = nonMonotonicSequenceException15.getDirection();
        java.lang.Throwable[] throwableArray19 = nonMonotonicSequenceException15.getSuppressed();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) numberFormat7, localizable9, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat21 = new org.apache.commons.math3.linear.RealMatrixFormat("Array2DRowRealMatrix{}", "", "; }", "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}", "{}", "Array2DRowRealMatrix{}", numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(orderDirection18);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getPointRef();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getPoint();
        double[] doubleArray15 = pointVectorValuePair8.getValue();
        int[] intArray22 = new int[] { (byte) 10 };
        int[] intArray25 = new int[] { 1, (short) 100 };
        int int26 = org.apache.commons.math3.util.MathArrays.distance1(intArray22, intArray25);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math3.random.MersenneTwister(intArray25);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister27.nextBytes(byteArray32);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker37 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer38 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister27, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker37);
        double[] doubleArray39 = cMAESOptimizer38.getStartPoint();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList40 = cMAESOptimizer38.getStatisticsMeanHistory();
        boolean boolean41 = pointVectorValuePair8.equals((java.lang.Object) cMAESOptimizer38);
        double[] doubleArray42 = pointVectorValuePair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrixList40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        int int19 = blockRealMatrix18.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix18.multiply(blockRealMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        incrementor1.incrementCount(35);
        int int4 = incrementor1.getCount();
        int int5 = incrementor1.getMaximalCount();
        incrementor1.incrementCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) ' ', (double) '4');
        double double3 = arrayRealVector2.getLInfNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("; }", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double double6 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector3.mapMultiplyToSelf((double) 1L);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector3.mapMultiplyToSelf(3.2771447329921766d);
        org.apache.commons.math3.linear.RealVector realVector12 = realVector10.mapSubtract(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = blockRealMatrix15.transpose();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getFirst();
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray15 = pointVectorValuePair14.getKey();
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray15, doubleArray17);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray5, doubleArray17);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double double10 = arrayRealVector5.getNorm();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector5.mapSubtractToSelf(1.57625969778098176E17d);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getLowerBound();
        int int24 = cMAESOptimizer22.getIterations();
        double[] doubleArray25 = cMAESOptimizer22.getStartPoint();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(doubleArray25);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        boolean boolean21 = pointVectorValuePair18.equals((java.lang.Object) "hi!");
        double[] doubleArray22 = pointVectorValuePair18.getSecond();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, doubleArray22);
        try {
            double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray9, 1.0E-15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        java.lang.String str18 = blockRealMatrix15.toString();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix15.scalarAdd(0.41019779969736225d);
        java.lang.Class<?> wildcardClass21 = blockRealMatrix20.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str18.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        boolean boolean21 = pointVectorValuePair18.equals((java.lang.Object) "hi!");
        double[] doubleArray22 = pointVectorValuePair18.getSecond();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, doubleArray22);
        double[] doubleArray30 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair32 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray30, doubleArray31);
        double[] doubleArray33 = pointVectorValuePair32.getKey();
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds39 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray33, doubleArray35);
        double[] doubleArray46 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray47);
        double[] doubleArray49 = pointVectorValuePair48.getSecond();
        boolean boolean51 = pointVectorValuePair48.equals((java.lang.Object) "hi!");
        double[] doubleArray52 = pointVectorValuePair48.getFirst();
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray33, doubleArray52);
        org.apache.commons.math3.util.Pair<double[], double[]> doubleArrayPair54 = new org.apache.commons.math3.util.Pair<double[], double[]>(doubleArray9, doubleArray53);
        double[] doubleArray55 = doubleArrayPair54.getKey();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition19 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix17, 3.0d);
        double[] doubleArray20 = eigenDecomposition19.getImagEigenvalues();
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray20);
        org.apache.commons.math3.util.Pair<double[], double[]> doubleArrayPair22 = new org.apache.commons.math3.util.Pair<double[], double[]>(doubleArray14, doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray20 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray20, doubleArray21);
        double[] doubleArray23 = pointVectorValuePair22.getSecond();
        double[] doubleArray24 = pointVectorValuePair22.getValue();
        double[] doubleArray25 = pointVectorValuePair22.getValue();
        double[] doubleArray26 = pointVectorValuePair22.getSecond();
        double[] doubleArray27 = pointVectorValuePair22.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray27);
        double double29 = arrayRealVector9.getL1Norm();
        double[] doubleArray36 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair38 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray37);
        double[] doubleArray39 = pointVectorValuePair38.getKey();
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        org.apache.commons.math3.optim.PointValuePair pointValuePair44 = new org.apache.commons.math3.optim.PointValuePair(doubleArray41, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds45 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray39, doubleArray41);
        double[] doubleArray52 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray53 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair54 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray53);
        double[] doubleArray55 = pointVectorValuePair54.getSecond();
        boolean boolean57 = pointVectorValuePair54.equals((java.lang.Object) "hi!");
        double[] doubleArray58 = pointVectorValuePair54.getFirst();
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray39, doubleArray58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector60);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getFirst();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13, 0.7853981633974447d, (double) 3, (double) (-186238143), 2.203819919143124d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        double double4 = simpleValueChecker3.getRelativeThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray6 = null;
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair7 = nonLinearConjugateGradientOptimizer5.optimize(optimizationDataArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getValue();
        double[] doubleArray15 = pointVectorValuePair8.getSecond();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        boolean boolean3 = blockRealMatrix2.isTransposable();
        int int4 = blockRealMatrix2.getRowDimension();
        try {
            blockRealMatrix2.setEntry((int) (short) 100, (int) (byte) -1, Double.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(35, 1072693248);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        double double4 = simpleValueChecker3.getRelativeThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep(0.0d);
        double double8 = bracketingStep7.getBracketingStep();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray17 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        double[] doubleArray20 = pointVectorValuePair19.getSecond();
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix10.preMultiply(doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix23.createMatrix(3, (int) (byte) 1);
        double double27 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix28);
        double[] doubleArray36 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair38 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray37);
        double[] doubleArray39 = pointVectorValuePair38.getSecond();
        double[] doubleArray40 = pointVectorValuePair38.getValue();
        double[] doubleArray41 = pointVectorValuePair38.getValueRef();
        double[] doubleArray42 = array2DRowRealMatrix28.preMultiply(doubleArray41);
        double[] doubleArray43 = identityPreconditioner9.precondition(doubleArray21, doubleArray41);
        org.apache.commons.math3.optim.InitialGuess initialGuess44 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray45 = new org.apache.commons.math3.optim.OptimizationData[] { bracketingStep7, initialGuess44 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair46 = nonLinearConjugateGradientOptimizer5.optimize(optimizationDataArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(optimizationDataArray45);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getStartPoint();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList24 = cMAESOptimizer22.getStatisticsMeanHistory();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker25 = cMAESOptimizer22.getConvergenceChecker();
        int int26 = cMAESOptimizer22.getEvaluations();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrixList24);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) (-127), 101.66738457347422d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -127 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValueRef();
        double[] doubleArray12 = pointVectorValuePair8.getPointRef();
        double[] doubleArray19 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair21 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray20);
        double[] doubleArray22 = pointVectorValuePair21.getSecond();
        double[] doubleArray23 = pointVectorValuePair21.getValue();
        double[] doubleArray24 = pointVectorValuePair21.getValue();
        double[] doubleArray25 = pointVectorValuePair21.getSecond();
        double[] doubleArray26 = pointVectorValuePair21.getValue();
        double[] doubleArray27 = pointVectorValuePair21.getValue();
        double[] doubleArray28 = pointVectorValuePair21.getPoint();
        boolean boolean29 = pointVectorValuePair8.equals((java.lang.Object) doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValueRef();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = blockRealMatrix15.scalarMultiply(1.5707255745373732d);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition43 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix41, 3.0d);
        double[] doubleArray44 = diagonalMatrix41.getDataRef();
        int int45 = diagonalMatrix41.getColumnDimension();
        double[][] doubleArray46 = diagonalMatrix41.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = diagonalMatrix41.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix48 = blockRealMatrix15.subtract(realMatrix47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 97x97");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 97 + "'", int45 == 97);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix47);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector(obj0, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 10, (double) (byte) 10, (double) 'a');
        double[] doubleArray4 = levenbergMarquardtOptimizer3.getUpperBound();
        int int5 = levenbergMarquardtOptimizer3.getMaxIterations();
        int int6 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        int int7 = levenbergMarquardtOptimizer3.getIterations();
        int int8 = levenbergMarquardtOptimizer3.getMaxIterations();
        int int9 = levenbergMarquardtOptimizer3.getEvaluations();
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, pointVectorValuePairConvergenceChecker1, 0.0d, 100.0d, (double) (byte) 100, (double) (short) -1);
        double[] doubleArray7 = levenbergMarquardtOptimizer6.getStartPoint();
        double double8 = levenbergMarquardtOptimizer6.getChiSquare();
        int int9 = levenbergMarquardtOptimizer6.getMaxEvaluations();
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        int int10 = arrayRealVector5.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector5.mapAdd((double) 0L);
        try {
            arrayRealVector5.setEntry((int) (short) 0, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0, false);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix5, 3.0d);
        double[] doubleArray8 = diagonalMatrix5.getDataRef();
        int int9 = diagonalMatrix5.getColumnDimension();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = diagonalMatrix5.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = diagonalMatrix3.multiply(diagonalMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, pointVectorValuePairConvergenceChecker1, 0.0d, 100.0d, (double) (byte) 100, (double) (short) -1);
        double[] doubleArray7 = levenbergMarquardtOptimizer6.getStartPoint();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker8 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = levenbergMarquardtOptimizer6.getWeightSquareRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = eigenDecomposition3.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = eigenDecomposition3.getVT();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        double double25 = arrayRealVector19.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        try {
            org.apache.commons.math3.linear.RealVector realVector26 = blockRealMatrix15.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 19986.0d + "'", double18 == 19986.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double double7 = arrayRealVector6.getLInfNorm();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(2.2163925864078933d, 19.085536923187668d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray8);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1);
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.createMatrix(3, (int) (byte) 1);
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray19);
        double[] doubleArray21 = array2DRowRealMatrix6.operate(doubleArray19);
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray19);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray19);
        double[] doubleArray24 = sigma23.getSigma();
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.scale(0.0d, doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        long long2 = org.apache.commons.math3.util.FastMath.max(35L, (-1765991400464819176L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 10, (double) (byte) 10, (double) 'a');
        double[] doubleArray4 = levenbergMarquardtOptimizer3.getLowerBound();
        double[] doubleArray5 = levenbergMarquardtOptimizer3.getStartPoint();
        double double6 = levenbergMarquardtOptimizer3.getChiSquare();
        double double7 = levenbergMarquardtOptimizer3.getChiSquare();
        int int8 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(9.999999999996666E-7d, (double) 7911606632076355948L);
        int int3 = brentOptimizer2.getEvaluations();
        int int4 = brentOptimizer2.getEvaluations();
        int int5 = brentOptimizer2.getIterations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double[] doubleArray11 = pointVectorValuePair10.getSecond();
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray13 = array2DRowRealMatrix1.preMultiply(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = array2DRowRealMatrix14.createMatrix(3, (int) (byte) 1);
        double double18 = array2DRowRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix14, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19);
        double[] doubleArray27 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair29 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray28);
        double[] doubleArray30 = pointVectorValuePair29.getSecond();
        double[] doubleArray31 = pointVectorValuePair29.getValue();
        double[] doubleArray32 = pointVectorValuePair29.getValueRef();
        double[] doubleArray33 = array2DRowRealMatrix19.preMultiply(doubleArray32);
        double[] doubleArray34 = identityPreconditioner0.precondition(doubleArray12, doubleArray32);
        org.apache.commons.math3.optim.InitialGuess initialGuess35 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        int int36 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 1.0f, Double.POSITIVE_INFINITY);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 96, 2.537297501373361d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        int int10 = arrayRealVector5.getMaxIndex();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection18 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) orderDirection18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix11, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean26 = arrayRealVector24.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector24.subtract(realVector29);
        arrayRealVector15.setSubVector(0, realVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean34 = arrayRealVector32.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector32.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector38.copy();
        int int40 = arrayRealVector39.getDimension();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor41 = null;
        try {
            double double44 = arrayRealVector39.walkInOptimizedOrder(realVectorPreservingVisitor41, (-1), 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        int int5 = diagonalMatrix1.getColumnDimension();
        double[][] doubleArray6 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.RealVector realVector8 = diagonalMatrix1.getColumnVector((int) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix1.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = diagonalMatrix1.walkInColumnOrder(realMatrixChangingVisitor10, 0, (int) (byte) 100, 52, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 100, 35);
        double double3 = bracketFinder2.getFMid();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = null;
        try {
            bracketFinder2.search(univariateFunction4, goalType5, (double) 97.0f, (-1024.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray3 = array2DRowRealMatrix2.getDataRef();
        try {
            array2DRowRealMatrix2.addToEntry(35, (-23), (-0.5063656411097588d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix7.createMatrix(52, 36);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = blockRealMatrix7.walkInRowOrder(realMatrixChangingVisitor12, 3, (int) (short) 10, 36, (-186238143));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 32, (-186238143));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        int int5 = diagonalMatrix1.getColumnDimension();
        double[][] doubleArray6 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix1.copy();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition11 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix9, 3.0d);
        double[] doubleArray12 = diagonalMatrix9.getDataRef();
        int int13 = diagonalMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = diagonalMatrix1.multiply(diagonalMatrix9);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.blockInverse((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertNotNull(diagonalMatrix14);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray19);
        double[] doubleArray21 = sigma20.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection22 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray29 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray36 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray37 = new double[][] { doubleArray29, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray21, orderDirection22, doubleArray37);
        double[] doubleArray46 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray47);
        double[] doubleArray49 = pointVectorValuePair48.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma50 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray49);
        double[] doubleArray51 = sigma50.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection52 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray59 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray66 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray67 = new double[][] { doubleArray59, doubleArray66 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray67);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray51, orderDirection52, doubleArray67);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, orderDirection22, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67, false);
        org.apache.commons.math3.exception.ZeroException zeroException73 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray67);
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix74);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getFirst();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = null;
        try {
            org.apache.commons.math3.optim.SimpleBounds simpleBounds15 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray13, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(1.0d, (-6.053272382792838d), (-1.5707963267948963d), 26.5d, (double) 100);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        long long23 = mersenneTwister11.nextLong();
        double double24 = mersenneTwister11.nextGaussian();
        double double25 = mersenneTwister11.nextDouble();
        long long26 = mersenneTwister11.nextLong();
        int[] intArray28 = new int[] { (byte) 10 };
        int[] intArray31 = new int[] { 1, (short) 100 };
        int int32 = org.apache.commons.math3.util.MathArrays.distance1(intArray28, intArray31);
        mersenneTwister11.setSeed(intArray31);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1765991400464819176L) + "'", long23 == (-1765991400464819176L));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.5071158626935848d + "'", double24 == 0.5071158626935848d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0922753880002305d + "'", double25 == 0.0922753880002305d);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-9208070452475268559L) + "'", long26 == (-9208070452475268559L));
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        int int5 = diagonalMatrix1.getColumnDimension();
        double[][] doubleArray6 = diagonalMatrix1.getData();
        double[][] doubleArray7 = diagonalMatrix1.getData();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix18.transpose();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10263.0d + "'", double19 == 10263.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double17 = sinc15.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction18 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        boolean boolean22 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc15, 0.0922753880002305d, (double) 7.6293945E-6f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction23 = sinc15.derivative();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction24 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8414709848078965d + "'", double17 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(univariateFunction23);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray8);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException14 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) ' ', 3, (int) (byte) 1);
        org.apache.commons.math3.exception.MathInternalError mathInternalError15 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException14);
        java.lang.Integer[] intArray16 = matrixDimensionMismatchException14.getExpectedDimensions();
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException17 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray8, intArray16);
        try {
            int int19 = multiDimensionMismatchException17.getWrongDimension((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence(1.5707963267948966d, (double) 1072693248, (double) 3.8146973E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,072,693,248, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray10);
        double[] doubleArray12 = sigma11.getSigma();
        org.apache.commons.math3.util.MathArrays.scaleInPlace(97.0d, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) ' ', 3, (int) (byte) 1);
        org.apache.commons.math3.exception.MathInternalError mathInternalError5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException4);
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        int int5 = diagonalMatrix1.getColumnDimension();
        double[][] doubleArray6 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix1.copy();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition11 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix9, 3.0d);
        double[] doubleArray12 = diagonalMatrix9.getDataRef();
        int int13 = diagonalMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = diagonalMatrix1.multiply(diagonalMatrix9);
        double[] doubleArray21 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray28 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray29 = new double[][] { doubleArray21, doubleArray28 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector32 = blockRealMatrix30.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix33.createMatrix(3, (int) (byte) 1);
        double double37 = array2DRowRealMatrix33.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix33, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix38);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition41 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix33, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor42 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double43 = array2DRowRealMatrix33.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        double double44 = blockRealMatrix30.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        defaultRealMatrixPreservingVisitor42.start((-186238143), 9, (int) (short) 0, 0, 2, (int) (short) 0);
        try {
            double double56 = diagonalMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42, (int) (short) -1, (int) ' ', 52, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertNotNull(diagonalMatrix14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 34.999996f);
        double double2 = brentSolver1.getMax();
        double double3 = brentSolver1.getRelativeAccuracy();
        int int4 = brentSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(10.0d, 35, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        double double17 = arrayRealVector7.dotProduct(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector0.ebeDivide(realVector16);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat19 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat20 = realVectorFormat19.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean26 = arrayRealVector24.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, (org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        java.lang.String str28 = realVectorFormat19.format((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        int int29 = arrayRealVector24.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector24.mapAdd((double) 0L);
        org.apache.commons.math3.analysis.function.Sinc sinc33 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double35 = sinc33.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector24.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean41 = arrayRealVector39.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean44 = arrayRealVector42.equals((java.lang.Object) true);
        double double45 = arrayRealVector39.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector24.combine(4.503599627370496E15d, 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        double double47 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector18.copy();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{}" + "'", str28.equals("{}"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.8414709848078965d + "'", double35 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getValue();
        double[] doubleArray15 = pointVectorValuePair8.getPoint();
        double[] doubleArray16 = pointVectorValuePair8.getSecond();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getValue();
        double[] doubleArray15 = pointVectorValuePair8.getPoint();
        double[] doubleArray16 = pointVectorValuePair8.getKey();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction1 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = univariateObjectiveFunction1.getObjectiveFunction();
        org.junit.Assert.assertNotNull(univariateFunction2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        double[][] doubleArray18 = blockRealMatrix15.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix19.scalarAdd((double) 0L);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix19.createMatrix(3, (int) (byte) 1);
        double double23 = array2DRowRealMatrix19.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix24);
        double[] doubleArray32 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray39 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray40 = new double[][] { doubleArray32, doubleArray39 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.RealVector realVector43 = blockRealMatrix41.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix(3, (int) (byte) 1);
        double double48 = array2DRowRealMatrix44.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix44, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix49);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition52 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix44, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor53 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double54 = array2DRowRealMatrix44.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor53);
        double double55 = blockRealMatrix41.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor53);
        defaultRealMatrixPreservingVisitor53.start((-186238143), 9, (int) (short) 0, 0, 2, (int) (short) 0);
        double double63 = array2DRowRealMatrix19.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor53);
        double double64 = blockRealMatrix15.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor53);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 14133.824606241582d + "'", double18 == 14133.824606241582d);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray4);
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister6.nextBytes(byteArray11);
        double double13 = mersenneTwister6.nextGaussian();
        double double14 = mersenneTwister6.nextGaussian();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5170669428427068d + "'", double13 == 1.5170669428427068d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0412659734579794d) + "'", double14 == (-1.0412659734579794d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        boolean boolean38 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix36, 14133.824606241582d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray14 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray21 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray28 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray35 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray36 = new double[][] { doubleArray7, doubleArray14, doubleArray21, doubleArray28, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getDataRef();
        org.apache.commons.math3.exception.MathInternalError mathInternalError39 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        int int2 = incrementor1.getMaximalCount();
        incrementor1.incrementCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = blockRealMatrix15.getColumnMatrix(0);
        int[] intArray41 = new int[] { (byte) 10 };
        int[] intArray44 = new int[] { 1, (short) 100 };
        int int45 = org.apache.commons.math3.util.MathArrays.distance1(intArray41, intArray44);
        int[] intArray47 = new int[] { (byte) 10 };
        int[] intArray50 = new int[] { 1, (short) 100 };
        int int51 = org.apache.commons.math3.util.MathArrays.distance1(intArray47, intArray50);
        int[] intArray53 = new int[] { (byte) 10 };
        int[] intArray56 = new int[] { 1, (short) 100 };
        int int57 = org.apache.commons.math3.util.MathArrays.distance1(intArray53, intArray56);
        int int58 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray47, intArray53);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix15, intArray41, intArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 9 + "'", int45 == 9);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 9 + "'", int51 == 9);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 9 + "'", int57 == 9);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector5);
        double double9 = arrayRealVector0.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector0.mapSubtractToSelf(98.10395148368781d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix1.copy();
        double double11 = diagonalMatrix1.getEntry(9, 0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix13, 3.0d);
        diagonalMatrix13.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = diagonalMatrix1.multiply(diagonalMatrix13);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(diagonalMatrix20);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getFrobeniusNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector20.subtract(realVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean31 = arrayRealVector29.equals((java.lang.Object) true);
        double[] doubleArray32 = arrayRealVector29.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector26.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double double34 = arrayRealVector29.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector29.mapDivide(Double.NEGATIVE_INFINITY);
        try {
            blockRealMatrix15.setColumnVector((-127), realVector36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 14133.824606241582d + "'", double18 == 14133.824606241582d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "; }", "{}", ",", "Array2DRowRealMatrix{}", "");
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 100, (double) 4.5035996E15f, (-0.9251475365964139d), 0.0d);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6, 3.0d);
        double[] doubleArray9 = eigenDecomposition8.getImagEigenvalues();
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray25 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair27 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray26);
        double[] doubleArray28 = pointVectorValuePair27.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray28);
        double[] doubleArray30 = sigma29.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection31 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray38 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray45 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray46 = new double[][] { doubleArray38, doubleArray45 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray30, orderDirection31, doubleArray46);
        double[] doubleArray55 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray56 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair57 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray56);
        double[] doubleArray58 = pointVectorValuePair57.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma59 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray58);
        double[] doubleArray60 = sigma59.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection61 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray68 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray75 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray76 = new double[][] { doubleArray68, doubleArray75 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray76);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray60, orderDirection61, doubleArray76);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray17, orderDirection31, doubleArray76);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray9, orderDirection31, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        try {
            multiDirectionalSimplex4.build(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection61.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector3.subtract(realVector8);
        double double10 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        int int11 = arrayRealVector2.getDimension();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(171.88733853924697d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.839977972566471d + "'", double1 == 5.839977972566471d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getKey();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean15 = arrayRealVector13.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.subtract(realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        double[] doubleArray25 = arrayRealVector22.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector19.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        double[] doubleArray27 = arrayRealVector19.toArray();
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray12, doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat1);
        java.lang.String str3 = realMatrixFormat2.getRowSuffix();
        java.lang.String str4 = realMatrixFormat2.getRowSeparator();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "}" + "'", str3.equals("}"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "," + "'", str4.equals(","));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 52, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5900247258946039d + "'", double2 == 1.5900247258946039d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double[] doubleArray1 = new double[] { 6.283185307179586d };
        double[] doubleArray8 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray15 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray19 = blockRealMatrix17.getRow(0);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        double[] doubleArray27 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair29 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray28);
        double[] doubleArray36 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair38 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray37);
        double[] doubleArray39 = pointVectorValuePair38.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma40 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray39);
        double[] doubleArray41 = sigma40.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection42 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray49 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray56 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray57 = new double[][] { doubleArray49, doubleArray56 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray57);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray41, orderDirection42, doubleArray57);
        double[] doubleArray66 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray67 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair68 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray66, doubleArray67);
        double[] doubleArray69 = pointVectorValuePair68.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma70 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray69);
        double[] doubleArray71 = sigma70.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection72 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray79 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray86 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray87 = new double[][] { doubleArray79, doubleArray86 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix88 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray87);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray71, orderDirection72, doubleArray87);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, orderDirection42, doubleArray87);
        boolean boolean92 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray20, orderDirection42, false);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection42, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection72.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(2.6881171418161356E43d, (double) 4.5035996E15f, 0.0922753880002305d, (double) 0.18399191f, (double) (byte) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.210620335821139E59d + "'", double6 == 1.210620335821139E59d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean8 = arrayRealVector4.equals((java.lang.Object) orderDirection7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean14 = arrayRealVector12.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector12.subtract(realVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, (org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) (short) 10);
        double double29 = arrayRealVector19.dotProduct(realVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector12.ebeDivide(realVector28);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat31 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat32 = realVectorFormat31.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean35 = arrayRealVector33.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean38 = arrayRealVector36.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, (org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        java.lang.String str40 = realVectorFormat31.format((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        int int41 = arrayRealVector36.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector36.mapAdd((double) 0L);
        org.apache.commons.math3.analysis.function.Sinc sinc45 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double47 = sinc45.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector36.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean53 = arrayRealVector51.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean56 = arrayRealVector54.equals((java.lang.Object) true);
        double double57 = arrayRealVector51.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector36.combine(4.503599627370496E15d, 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        double double59 = arrayRealVector30.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(numberFormat32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{}" + "'", str40.equals("{}"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.8414709848078965d + "'", double47 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) ' ', 1.0000000000000002d);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator4 = null;
        try {
            multiDirectionalSimplex2.iterate(multivariateFunction3, pointValuePairComparator4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix2.createMatrix(3, (int) (byte) 1);
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7);
        org.apache.commons.math3.util.Incrementor incrementor11 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        incrementor11.incrementCount(35);
        boolean boolean14 = incrementor11.canIncrement();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer18 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 10, (double) (byte) 10, (double) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, (org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) (short) 10);
        double double29 = arrayRealVector19.dotProduct(realVector28);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean33 = arrayRealVector31.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix30, (org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double35 = array2DRowRealMatrix30.getFrobeniusNorm();
        java.lang.Object[] objArray36 = new java.lang.Object[] { array2DRowRealMatrix2, false, boolean14, 'a', arrayRealVector19, double35 };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException37 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 100L, objArray36);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException38 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (-127), objArray36);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 9993.0d, (java.lang.Number) 32.0d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32.0d + "'", number4.equals(32.0d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getFirst();
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        double[] doubleArray17 = pointVectorValuePair15.getValue();
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.scale((double) 1.0f, doubleArray17);
        boolean boolean19 = pointValuePair4.equals((java.lang.Object) doubleArray17);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException6 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray4);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray4, 0.9999999999999929d, 0.45805495157532494d, 0.0d, 7.999470683622238d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, number1, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.apache.commons.math3.exception.MathInternalError mathInternalError7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) nonMonotonicSequenceException5);
        org.junit.Assert.assertNull(orderDirection6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray4);
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister6.nextBytes(byteArray11);
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray17);
        mersenneTwister6.setSeed(0L);
        mersenneTwister6.setSeed(8556609109677726901L);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(100, (int) (byte) 1);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds12 = org.apache.commons.math3.optim.SimpleBounds.unbounded(1);
        double[] doubleArray13 = simpleBounds12.getLower();
        double[] doubleArray14 = array2DRowRealMatrix10.operate(doubleArray13);
        try {
            double[] doubleArray15 = diagonalMatrix1.operate(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(simpleBounds12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        double[][] doubleArray18 = blockRealMatrix15.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        try {
            double[] doubleArray21 = blockRealMatrix19.getRow(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, number1, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonicSequenceException5.getArgument();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) (-1.0d));
        java.lang.Number number2 = tooManyIterationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-1.0d) + "'", number2.equals((-1.0d)));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double double19 = blockRealMatrix18.getNorm();
        double[] doubleArray26 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray33 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray34 = new double[][] { doubleArray26, doubleArray33 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        int int36 = blockRealMatrix35.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.copy();
        java.lang.String str38 = blockRealMatrix35.toString();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix35.scalarAdd(0.41019779969736225d);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix35);
        double double42 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix18.copy();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10263.0d + "'", double19 == 10263.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str38.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 10263.0d + "'", double42 == 10263.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 96, (long) (-127));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-96L) + "'", long2 == (-96L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector3.subtract(realVector8);
        double double10 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor11 = null;
        try {
            double double14 = arrayRealVector9.walkInOptimizedOrder(realVectorPreservingVisitor11, 0, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        double[][] doubleArray2 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = diagonalMatrix1.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix1.power(0);
        double[][] doubleArray6 = diagonalMatrix1.getData();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean8 = arrayRealVector4.equals((java.lang.Object) orderDirection7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor12 = null;
        try {
            double double17 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor12, (-17), (int) (byte) -1, (int) (byte) 100, 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-17)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix1.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean9 = arrayRealVector5.equals((java.lang.Object) orderDirection8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean16 = arrayRealVector14.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector14.subtract(realVector19);
        arrayRealVector5.setSubVector(0, realVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector22.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector30.subtract(realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean41 = arrayRealVector39.equals((java.lang.Object) true);
        double[] doubleArray42 = arrayRealVector39.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector36.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector22.combine(0.0d, 2.2250738585072014E-308d, (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        java.lang.String str45 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{}" + "'", str45.equals("{}"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double1 = org.apache.commons.math3.util.FastMath.log(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-708.3964185322641d) + "'", double1 == (-708.3964185322641d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(6, 1.0E-15d, (double) (-96L), (-1.0412659734579794d), 26.5d, (double) 2147483647);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 1L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.2676506E30f + "'", float2 == 1.2676506E30f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.36037891457679466d, 0.0d, 19.085536923187668d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix18.createMatrix(3, (int) (byte) 1);
        double double22 = array2DRowRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix18, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double28 = array2DRowRealMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
        double double29 = blockRealMatrix15.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((-1), (int) '4');
        try {
            blockRealMatrix15.copySubMatrix(0, (int) (short) 1, (-127), (int) (byte) 10, doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula3 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula4 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] formulaArray5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] { formula3, formula4 };
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray15 = pointVectorValuePair14.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray15);
        double[] doubleArray17 = sigma16.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection18 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray25 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray32 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray33 = new double[][] { doubleArray25, doubleArray32 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray17, orderDirection18, doubleArray33);
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.isMonotonic(formulaArray5, orderDirection18, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException39 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 1.1920928777442441E-7d, (int) '#', orderDirection18, false);
        org.junit.Assert.assertTrue("'" + formula3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula3.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula4.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(formulaArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray19);
        double[] doubleArray21 = sigma20.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection22 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray29 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray36 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray37 = new double[][] { doubleArray29, doubleArray36 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray21, orderDirection22, doubleArray37);
        double[] doubleArray46 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray47);
        double[] doubleArray49 = pointVectorValuePair48.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma50 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray49);
        double[] doubleArray51 = sigma50.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection52 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray59 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray66 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray67 = new double[][] { doubleArray59, doubleArray66 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray67);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray51, orderDirection52, doubleArray67);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, orderDirection22, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67, false);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
    }
}

