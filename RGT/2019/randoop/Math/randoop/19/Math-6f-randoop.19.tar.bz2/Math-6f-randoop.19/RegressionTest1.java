import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector3.subtract(realVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean14 = arrayRealVector12.equals((java.lang.Object) true);
        double[] doubleArray15 = arrayRealVector12.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector9.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        double[] doubleArray17 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix24.createMatrix(3, (int) (byte) 1);
        double[] doubleArray34 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray34, doubleArray35);
        double[] doubleArray37 = pointVectorValuePair36.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma38 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray37);
        double[] doubleArray39 = array2DRowRealMatrix24.operate(doubleArray37);
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray37);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray17, doubleArray37);
        try {
            double[] doubleArray42 = blockRealMatrix2.operate(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1, (org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        double double6 = array2DRowRealMatrix1.getFrobeniusNorm();
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        double[] doubleArray17 = array2DRowRealMatrix1.preMultiply(doubleArray16);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector5 = null;
        try {
            array2DRowRealMatrix0.setRowVector(2, realVector5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.transpose();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix0.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 97x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector7 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, realVector7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.multiplyEntry((int) (short) -1, 52, (double) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix13.createMatrix(3, (int) (byte) 1);
        double double17 = array2DRowRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix18);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition21 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13, (double) 4.5035996E15f);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix0.add(array2DRowRealMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 171.88733853924697d + "'", double1 == 171.88733853924697d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double double6 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor7 = null;
        try {
            double double8 = arrayRealVector0.walkInOptimizedOrder(realVectorChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, number1, (int) (short) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonicSequenceException5.getArgument();
        int int7 = nonMonotonicSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonicSequenceException5.getArgument();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("hi!hi!", ", ", ", ", numberFormat4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection13 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean14 = arrayRealVector10.equals((java.lang.Object) orderDirection13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix6, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.subtract(realVector24);
        arrayRealVector10.setSubVector(0, realVector24);
        java.lang.StringBuffer stringBuffer27 = null;
        java.text.FieldPosition fieldPosition28 = null;
        try {
            java.lang.StringBuffer stringBuffer29 = realVectorFormat5.format(realVector24, stringBuffer27, fieldPosition28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948963d) + "'", double1 == (-1.5707963267948963d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, pointVectorValuePairConvergenceChecker1, 0.0d, 100.0d, (double) (byte) 100, (double) (short) -1);
        double[] doubleArray7 = levenbergMarquardtOptimizer6.getLowerBound();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = levenbergMarquardtOptimizer6.getWeightSquareRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(doubleArray7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(10.0f, 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.43597384E11f + "'", float2 == 3.43597384E11f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray3 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 1, (-23), (double) (byte) 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver7 = lUDecomposition6.getSolver();
        double double8 = lUDecomposition6.getDeterminant();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(decompositionSolver7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (byte) 100, 0.35349068386023774d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0.353)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        double[] doubleArray17 = pointVectorValuePair15.getValue();
        double[] doubleArray18 = pointVectorValuePair15.getValueRef();
        double[] doubleArray19 = array2DRowRealMatrix5.preMultiply(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray27 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair29 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray28);
        double[] doubleArray30 = pointVectorValuePair29.getSecond();
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30);
        double[] doubleArray32 = array2DRowRealMatrix20.preMultiply(doubleArray31);
        double[][] doubleArray33 = array2DRowRealMatrix20.getData();
        try {
            array2DRowRealMatrix5.setSubMatrix(doubleArray33, 0, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 1 columns are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getRealEigenvalues();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = eigenDecomposition3.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45805495157532494d + "'", double2 == 0.45805495157532494d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 9.999999999996666E-7d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval(1.0E-6d, 1.1920928777442441E-7d, (double) 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 1.1920928777442441E-7d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) (short) 10, 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.5403023058681398d, (double) (-1L), 1.1920928777442441E-7d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray9);
        double[] doubleArray11 = sigma10.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray19 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray26 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray27 = new double[][] { doubleArray19, doubleArray26 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray11, orderDirection12, doubleArray27);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = weight30.getWeight();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix31);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray10 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray17 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray18 = new double[][] { doubleArray10, doubleArray17 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        int int20 = blockRealMatrix19.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix19.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x97 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(1.7763568394002505E-15d, (double) 4.5035996E15f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.503599627370496E15d + "'", double2 == 4.503599627370496E15d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[][] doubleArray4 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) 'a');
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(97, 32, doubleArray4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValueRef();
        try {
            double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray11, 1.1920928777442441E-7d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(100, (int) (byte) 1);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor3, 1, (int) (byte) 1, (int) (byte) -1, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.5403023058681398d, 2.718281828459045d, 0.18399191394796865d, (double) (byte) -1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(9.999999999996666E-7d, (double) ' ', 1.11669149749E11d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.getSubMatrix((int) (byte) 100, 0, (int) 'a', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, number1, (int) (short) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonicSequenceException5.getArgument();
        int int7 = nonMonotonicSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonicSequenceException5.getPrevious();
        int int9 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        boolean boolean4 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray15 = pointVectorValuePair14.getSecond();
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        double[] doubleArray17 = array2DRowRealMatrix5.preMultiply(doubleArray16);
        double[][] doubleArray18 = array2DRowRealMatrix5.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix0.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(5.298292365610485d, 2.6881171418161356E43d, 0.0d, (double) 52L, 4.503599627370496E15d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.424243053035111E44d + "'", double6 == 1.424243053035111E44d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        incrementor1.incrementCount(0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        double double7 = arrayRealVector1.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        java.lang.Object obj9 = null;
        boolean boolean10 = arrayRealVector8.equals(obj9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 32, (float) 3, (float) 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(9);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getFrobeniusNorm();
        try {
            double double19 = blockRealMatrix15.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 14133.824606241582d + "'", double18 == 14133.824606241582d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 1.0f, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 100, Double.NEGATIVE_INFINITY);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.5071158626935848d, (double) '#', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver8 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 34.999996f);
        double double9 = brentSolver8.getMax();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver8);
        double[] doubleArray11 = nonLinearConjugateGradientOptimizer10.getUpperBound();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(doubleArray11);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 1.0f, Double.POSITIVE_INFINITY);
        double double3 = simpleUnivariateValueChecker2.getRelativeThreshold();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 32, (-1.5707963267948966d));
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 32, (-1.5707963267948966d));
        boolean boolean11 = simpleUnivariateValueChecker2.converged(97, univariatePointValuePair7, univariatePointValuePair10);
        double double12 = simpleUnivariateValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.45805495157532494d, (java.lang.Number) 5.298292365610485d, false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((-127), 14133.824606241582d, 6.283185307179586d);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100.0f, 4.641588833612779d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarMultiply(0.10272986741866949d);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix17.scalarMultiply((double) 34.999996f);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray29 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair31 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray29, doubleArray30);
        double[] doubleArray32 = pointVectorValuePair31.getSecond();
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector34 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray22);
        try {
            double[] doubleArray35 = blockRealMatrix17.preMultiply(doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(realVector34);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        try {
            org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(35.0d, 0.0d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 10);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator3 = null;
        try {
            multiDirectionalSimplex1.iterate(multivariateFunction2, pointValuePairComparator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double3 = sinc1.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction4 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc1);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 0.0922753880002305d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0.092, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8414709848078965d + "'", double3 == 0.8414709848078965d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 52, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray41 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray42 = new double[][] { doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[][] doubleArray44 = array2DRowRealMatrix43.getDataRef();
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray44, 32, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 32 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        double[] doubleArray17 = pointVectorValuePair15.getValue();
        double[] doubleArray18 = pointVectorValuePair15.getValueRef();
        double[] doubleArray19 = array2DRowRealMatrix5.preMultiply(doubleArray18);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix5.copy();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-1.5707963267948963d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) -1, (int) 'a', (-10.0d));
        org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) nonSymmetricMatrixException3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(",", ",", "", "", "", "", numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat1);
        java.lang.String str3 = realMatrixFormat2.getRowSeparator();
        java.lang.String str4 = realMatrixFormat2.getRowSuffix();
        java.lang.String str5 = realMatrixFormat2.getSuffix();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "," + "'", str3.equals(","));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "}" + "'", str4.equals("}"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "}" + "'", str5.equals("}"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarMultiply(0.10272986741866949d);
        try {
            double double20 = blockRealMatrix17.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getImagEigenvalues();
        try {
            org.apache.commons.math3.linear.RealVector realVector7 = eigenDecomposition3.getEigenvector((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(171.88733853924697d, 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 171.88733853924697d + "'", double2 == 171.88733853924697d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, (-0.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarMultiply(0.10272986741866949d);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix17.scalarMultiply((double) 34.999996f);
        try {
            org.apache.commons.math3.linear.RealVector realVector23 = blockRealMatrix17.getRowVector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector5.subtract(realVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean16 = arrayRealVector14.equals((java.lang.Object) true);
        double[] doubleArray17 = arrayRealVector14.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector11.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, (org.apache.commons.math3.linear.RealVector) arrayRealVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double17 = sinc15.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction18 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        try {
            double[] doubleArray23 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc15, (double) 10, (double) (short) -1, 0.5071158626935848d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, 0.507]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8414709848078965d + "'", double17 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double double6 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8, 3.0d);
        org.apache.commons.math3.linear.RealVector realVector12 = eigenDecomposition10.getEigenvector((int) '#');
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector0.ebeDivide(realVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        double double17 = arrayRealVector7.dotProduct(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector0.ebeDivide(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.subtract(realVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean30 = arrayRealVector28.equals((java.lang.Object) true);
        double[] doubleArray31 = arrayRealVector28.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector28.mapMultiplyToSelf((double) 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector35);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix15.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix42 = blockRealMatrix37.getSubMatrix((int) (byte) -1, 100, 0, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker6 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 100, Double.NEGATIVE_INFINITY);
        double double7 = simpleValueChecker6.getRelativeThreshold();
        double double8 = simpleValueChecker6.getAbsoluteThreshold();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, (double) 'a', 4.584967478670572d, (double) 7.6293945E-6f, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition8 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) 4.5035996E15f);
        try {
            double double11 = array2DRowRealMatrix0.getEntry(35, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1.7763568394002505E-15d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 3, (double) 10L);
        int int3 = powellOptimizer2.getEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double6 = diagonalMatrix1.walkInRowOrder(realMatrixPreservingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) ' ', 3, (int) (byte) 1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = matrixDimensionMismatchException4.getContext();
        int int6 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        int int10 = arrayRealVector5.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector5.mapAdd((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean15 = arrayRealVector13.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean18 = arrayRealVector16.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, (org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector13.append(19.085536923187668d);
        double double22 = realVector21.getMinValue();
        try {
            double double23 = arrayRealVector5.cosine(realVector21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 19.085536923187668d + "'", double22 == 19.085536923187668d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray4);
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister6.nextBytes(byteArray11);
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray17);
        float float19 = mersenneTwister6.nextFloat();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.18399191f + "'", float19 == 0.18399191f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math3.util.FastMath.atan(0.35349068386023774d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3397811690374588d + "'", double1 == 0.3397811690374588d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray3 = array2DRowRealMatrix2.getDataRef();
        double[] doubleArray10 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray17 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray24 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray31 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray38 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray39 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix40.getRowMatrix((int) (byte) 0);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix42);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (byte) 0, numberFormat2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getMax();
        double double2 = brentSolver0.getStartValue();
        org.apache.commons.math3.analysis.function.Sinc sinc5 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double7 = sinc5.value((double) (byte) -1);
        try {
            double double9 = brentSolver0.solve((int) (byte) 1, (org.apache.commons.math3.analysis.UnivariateFunction) sinc5, 97.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (1) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8414709848078965d + "'", double7 == 0.8414709848078965d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector10.subtract(realVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector16.append(arrayRealVector17);
        java.lang.String str21 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        java.text.ParsePosition parsePosition23 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = realVectorFormat0.parse("hi!", parsePosition23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{}" + "'", str21.equals("{}"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2);
        org.apache.commons.math3.optim.PointValuePair pointValuePair6 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) '#', true);
        double[] doubleArray7 = pointValuePair6.getFirst();
        double[] doubleArray14 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray15);
        double[] doubleArray17 = pointVectorValuePair16.getKey();
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds23 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray17, doubleArray19);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray19);
        try {
            double[] doubleArray25 = diagonalMatrix1.operate(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getStartPoint();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList24 = cMAESOptimizer22.getStatisticsMeanHistory();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray25 = null;
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair26 = cMAESOptimizer22.optimize(optimizationDataArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrixList24);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 3.43597384E11f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(6, 9993.0d);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator4 = null;
        try {
            multiDirectionalSimplex2.evaluate(multivariateFunction3, pointValuePairComparator4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean8 = arrayRealVector4.equals((java.lang.Object) orderDirection7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = array2DRowRealMatrix0.getRowVector((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(10263.0d, (-23));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.001223444938659668d + "'", double2 == 0.001223444938659668d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.append(arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector7.mapAdd(0.17453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean15 = arrayRealVector13.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.subtract(realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean25 = arrayRealVector23.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapDivideToSelf((double) (short) 10);
        double double30 = arrayRealVector20.dotProduct(realVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector13.ebeDivide(realVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean34 = arrayRealVector32.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector32.subtract(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean41 = arrayRealVector39.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean44 = arrayRealVector42.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, (org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector46.mapDivideToSelf((double) (short) 10);
        double double49 = arrayRealVector39.dotProduct(realVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector32.ebeDivide(realVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean53 = arrayRealVector51.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector54.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector51.subtract(realVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean62 = arrayRealVector60.equals((java.lang.Object) true);
        double[] doubleArray63 = arrayRealVector60.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = arrayRealVector57.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.RealVector realVector65 = arrayRealVector32.append((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = arrayRealVector31.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        java.lang.String str67 = arrayRealVector32.toString();
        try {
            org.apache.commons.math3.linear.RealVector realVector68 = realVector12.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(arrayRealVector64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(arrayRealVector66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "{}" + "'", str67.equals("{}"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        int int8 = arrayRealVector7.getDimension();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        double[][] doubleArray11 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) 'a');
        try {
            blockRealMatrix7.setSubMatrix(doubleArray11, 6, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        boolean boolean21 = pointVectorValuePair18.equals((java.lang.Object) "hi!");
        double[] doubleArray22 = pointVectorValuePair18.getSecond();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, doubleArray22);
        double double24 = arrayRealVector23.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getRealEigenvalues();
        org.apache.commons.math3.linear.RealVector realVector7 = eigenDecomposition3.getEigenvector((int) (byte) 0);
        int int8 = realVector7.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 96 + "'", int8 == 96);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix4.createMatrix(3, (int) (byte) 1);
        double[] doubleArray14 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray15);
        double[] doubleArray17 = pointVectorValuePair16.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray17);
        double[] doubleArray19 = array2DRowRealMatrix4.operate(doubleArray17);
        double[] doubleArray26 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair28 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray27);
        double[] doubleArray29 = pointVectorValuePair28.getKey();
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30);
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray31, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds35 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray29, doubleArray31);
        double double36 = org.apache.commons.math3.util.MathArrays.distance(doubleArray19, doubleArray31);
        try {
            blockRealMatrix2.setRow((int) '4', doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        float float2 = org.apache.commons.math3.util.FastMath.max(7.6293945E-6f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.6293945E-6f + "'", float2 == 7.6293945E-6f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.41019779969736225d, (double) (short) 10, 10.0d, (double) (short) 1, 0.17453292519943295d, (double) (-23), 0.17453292519943295d, 97.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 27.01741446173166d + "'", double8 == 27.01741446173166d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = eigenDecomposition3.getD();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = eigenDecomposition3.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getLowerBound();
        java.util.List<java.lang.Double> doubleList24 = cMAESOptimizer22.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList25 = cMAESOptimizer22.getStatisticsFitnessHistory();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleList24);
        org.junit.Assert.assertNotNull(doubleList25);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) ' ', 3, (int) (byte) 1);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        double[] doubleArray22 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray22, doubleArray23);
        double[] doubleArray25 = pointVectorValuePair24.getKey();
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds31 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray25, doubleArray27);
        double double32 = org.apache.commons.math3.util.MathArrays.distance(doubleArray15, doubleArray27);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray15, 1.7763568394002505E-15d, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 110 is larger than the maximum (6)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, number1, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = nonMonotonicSequenceException5.getDirection();
        java.lang.Number number8 = nonMonotonicSequenceException5.getPrevious();
        java.lang.Number number9 = nonMonotonicSequenceException5.getArgument();
        boolean boolean10 = nonMonotonicSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix20, 3.0d);
        double[][] doubleArray23 = diagonalMatrix20.getData();
        try {
            blockRealMatrix17.setColumnMatrix((int) (byte) 10, (org.apache.commons.math3.linear.RealMatrix) diagonalMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double double10 = arrayRealVector5.getNorm();
        int int11 = arrayRealVector5.getMinIndex();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double[] doubleArray11 = pointVectorValuePair10.getSecond();
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray13 = array2DRowRealMatrix1.preMultiply(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = array2DRowRealMatrix14.createMatrix(3, (int) (byte) 1);
        double double18 = array2DRowRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix14, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19);
        double[] doubleArray27 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair29 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray28);
        double[] doubleArray30 = pointVectorValuePair29.getSecond();
        double[] doubleArray31 = pointVectorValuePair29.getValue();
        double[] doubleArray32 = pointVectorValuePair29.getValueRef();
        double[] doubleArray33 = array2DRowRealMatrix19.preMultiply(doubleArray32);
        double[] doubleArray34 = identityPreconditioner0.precondition(doubleArray12, doubleArray32);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray35);
        org.apache.commons.math3.optim.PointValuePair pointValuePair39 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) '#', true);
        double[] doubleArray40 = pointValuePair39.getFirst();
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        double[] doubleArray11 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair13 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray11, doubleArray12);
        double[] doubleArray14 = pointVectorValuePair13.getSecond();
        double[] doubleArray21 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray21, doubleArray22);
        double[] doubleArray24 = pointVectorValuePair23.getSecond();
        boolean boolean26 = pointVectorValuePair23.equals((java.lang.Object) "hi!");
        double[] doubleArray27 = pointVectorValuePair23.getSecond();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, doubleArray27);
        try {
            org.apache.commons.math3.linear.RealVector realVector29 = diagonalMatrix1.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix20, (org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double double25 = array2DRowRealMatrix20.getFrobeniusNorm();
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean31 = arrayRealVector29.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector29.subtract(realVector34);
        double double36 = arrayRealVector28.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.RealVector realVector37 = array2DRowRealMatrix20.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        try {
            blockRealMatrix15.setColumnMatrix((int) (short) -1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 19986.0d + "'", double18 == 19986.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        int int19 = blockRealMatrix18.getColumnDimension();
        try {
            double[] doubleArray21 = blockRealMatrix18.getColumn((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        int int10 = arrayRealVector5.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector11 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, realVector11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 4.641588833612779d, (java.lang.Number) 10263.0d, (java.lang.Number) (byte) 10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getValueRef();
        double[] doubleArray13 = pointVectorValuePair8.getPoint();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double2 = org.apache.commons.math3.util.FastMath.min(Double.POSITIVE_INFINITY, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 35, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray4);
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister6.nextBytes(byteArray11);
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray17);
        mersenneTwister6.setSeed(0L);
        mersenneTwister6.setSeed((long) 32);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getValueRef();
        double[] doubleArray19 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair21 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray20);
        double[] doubleArray22 = pointVectorValuePair21.getSecond();
        double[] doubleArray23 = pointVectorValuePair21.getValue();
        double[] doubleArray24 = pointVectorValuePair21.getValue();
        double[] doubleArray25 = pointVectorValuePair21.getValueRef();
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray25);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 3, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 35L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(97.0f, 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray21 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray21, doubleArray22);
        double[] doubleArray24 = pointVectorValuePair23.getSecond();
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix14.preMultiply(doubleArray25);
        double[][] doubleArray27 = array2DRowRealMatrix14.getData();
        boolean boolean28 = array2DRowRealMatrix14.isSquare();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix0.add(array2DRowRealMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector1.subtract(realVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        double[] doubleArray13 = arrayRealVector10.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector7.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        double[] doubleArray15 = arrayRealVector7.toArray();
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = array2DRowRealMatrix22.createMatrix(3, (int) (byte) 1);
        double[] doubleArray32 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair34 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray32, doubleArray33);
        double[] doubleArray35 = pointVectorValuePair34.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma36 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray35);
        double[] doubleArray37 = array2DRowRealMatrix22.operate(doubleArray35);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray35);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray15, doubleArray35);
        org.apache.commons.math3.optim.InitialGuess initialGuess40 = new org.apache.commons.math3.optim.InitialGuess(doubleArray35);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.scale((double) 100.0f, doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor38 = null;
        try {
            double double39 = array2DRowRealMatrix36.walkInColumnOrder(realMatrixChangingVisitor38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        java.lang.String str18 = blockRealMatrix15.toString();
        int[] intArray20 = new int[] { (byte) 10 };
        int[] intArray23 = new int[] { 1, (short) 100 };
        int int24 = org.apache.commons.math3.util.MathArrays.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] { (byte) 10 };
        int[] intArray29 = new int[] { 1, (short) 100 };
        int int30 = org.apache.commons.math3.util.MathArrays.distance1(intArray26, intArray29);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math3.random.MersenneTwister(intArray29);
        org.apache.commons.math3.exception.util.Localizable localizable32 = null;
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) 'a');
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable32, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) doubleArray36);
        try {
            blockRealMatrix15.copySubMatrix(intArray20, intArray29, doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str18.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix21.createMatrix(3, (int) (byte) 1);
        double[] doubleArray31 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray31, doubleArray32);
        double[] doubleArray34 = pointVectorValuePair33.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix21.operate(doubleArray34);
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray34);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray14, doubleArray34);
        org.apache.commons.math3.optim.InitialGuess initialGuess39 = new org.apache.commons.math3.optim.InitialGuess(doubleArray34);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix40 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector6.mapMultiplyToSelf((double) 100L);
        double[] doubleArray17 = null;
        try {
            arrayRealVector6.setSubVector(2, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        try {
            arrayRealVector2.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("hi!hi!", ", ", ", ", numberFormat4);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat4);
        java.lang.String str7 = realVectorFormat6.getSuffix();
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "}" + "'", str7.equals("}"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        boolean boolean22 = blockRealMatrix21.isTransposable();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.add(blockRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 6x97");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 19986.0d + "'", double18 == 19986.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 0.032585025f, (double) 96, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver7 = lUDecomposition6.getSolver();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = lUDecomposition6.getU();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(decompositionSolver7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        double[] doubleArray14 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray15);
        double double17 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray14);
        java.lang.Class<?> wildcardClass18 = doubleArray7.getClass();
        try {
            array2DRowRealMatrix0.setColumn(2147483647, doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) (-1.0f));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, pointVectorValuePairConvergenceChecker1, 0.0d, 100.0d, (double) (byte) 100, (double) (short) -1);
        double[] doubleArray7 = levenbergMarquardtOptimizer6.getStartPoint();
        int int8 = levenbergMarquardtOptimizer6.getIterations();
        double[] doubleArray9 = levenbergMarquardtOptimizer6.getStartPoint();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray10 = new org.apache.commons.math3.optim.OptimizationData[] {};
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair11 = levenbergMarquardtOptimizer6.optimize(optimizationDataArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(doubleArray9);
        org.junit.Assert.assertNotNull(optimizationDataArray10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) '#');
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (-1), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getPointRef();
        java.lang.Double double6 = pointValuePair4.getValue();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6.equals(35.0d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 2147483647, 0.0d, (double) 1.1920929E-7f, 98.10395148368781d, (double) '4', 27.01741446173166d, 4.503599627370496E15d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-4.503599627369091E15d) + "'", double8 == (-4.503599627369091E15d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat5 = realVectorFormat4.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat("hi!hi!", ", ", ", ", numberFormat5);
        java.lang.StringBuffer stringBuffer7 = null;
        java.text.FieldPosition fieldPosition8 = null;
        try {
            java.lang.StringBuffer stringBuffer9 = org.apache.commons.math3.util.CompositeFormat.formatDouble(27.01741446173166d, numberFormat5, stringBuffer7, fieldPosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(98.10395148368781d, Double.NEGATIVE_INFINITY);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds4 = org.apache.commons.math3.optim.SimpleBounds.unbounded(1);
        org.apache.commons.math3.optim.MaxIter maxIter5 = org.apache.commons.math3.optim.MaxIter.unlimited();
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction6 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction7 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction6);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(35, (double) (byte) 10);
        org.apache.commons.math3.optim.MaxIter maxIter11 = org.apache.commons.math3.optim.MaxIter.unlimited();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner12 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray20 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray20, doubleArray21);
        double[] doubleArray23 = pointVectorValuePair22.getSecond();
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix13.preMultiply(doubleArray24);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix26.createMatrix(3, (int) (byte) 1);
        double double30 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31);
        double[] doubleArray39 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair41 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray39, doubleArray40);
        double[] doubleArray42 = pointVectorValuePair41.getSecond();
        double[] doubleArray43 = pointVectorValuePair41.getValue();
        double[] doubleArray44 = pointVectorValuePair41.getValueRef();
        double[] doubleArray45 = array2DRowRealMatrix31.preMultiply(doubleArray44);
        double[] doubleArray46 = identityPreconditioner12.precondition(doubleArray24, doubleArray44);
        org.apache.commons.math3.optim.InitialGuess initialGuess47 = new org.apache.commons.math3.optim.InitialGuess(doubleArray44);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray48 = new org.apache.commons.math3.optim.OptimizationData[] { simpleBounds4, maxIter5, modelFunction7, nelderMeadSimplex10, maxIter11, initialGuess47 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair49 = simplexOptimizer2.optimize(optimizationDataArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(simpleBounds4);
        org.junit.Assert.assertNotNull(maxIter5);
        org.junit.Assert.assertNotNull(maxIter11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(optimizationDataArray48);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean16 = arrayRealVector14.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector14.subtract(realVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean27 = arrayRealVector25.equals((java.lang.Object) true);
        double double28 = arrayRealVector22.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector21.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector30.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean37 = arrayRealVector35.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector29.append(arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector20.add((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        try {
            org.apache.commons.math3.linear.RealVector realVector41 = array2DRowRealMatrix0.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(arrayRealVector40);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction0);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = objectiveFunction1.getObjectiveFunction();
        org.junit.Assert.assertNull(multivariateFunction2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("hi!hi!", ", ", ", ", numberFormat4);
        java.lang.String str6 = realVectorFormat5.getPrefix();
        java.text.ParsePosition parsePosition8 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = realVectorFormat5.parse("{}", parsePosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!hi!" + "'", str6.equals("hi!hi!"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        try {
            blockRealMatrix18.setEntry(6, 32, 14133.824606241582d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 1.0f, Double.POSITIVE_INFINITY);
        double double3 = simpleUnivariateValueChecker2.getRelativeThreshold();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 32, (-1.5707963267948966d));
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 32, (-1.5707963267948966d));
        boolean boolean11 = simpleUnivariateValueChecker2.converged(97, univariatePointValuePair7, univariatePointValuePair10);
        double double12 = univariatePointValuePair10.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32.0d + "'", double12 == 32.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix2.createMatrix(3, (int) (byte) 1);
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7);
        org.apache.commons.math3.util.Incrementor incrementor11 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        incrementor11.incrementCount(35);
        boolean boolean14 = incrementor11.canIncrement();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer18 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 10, (double) (byte) 10, (double) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, (org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) (short) 10);
        double double29 = arrayRealVector19.dotProduct(realVector28);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean33 = arrayRealVector31.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix30, (org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double35 = array2DRowRealMatrix30.getFrobeniusNorm();
        java.lang.Object[] objArray36 = new java.lang.Object[] { array2DRowRealMatrix2, false, boolean14, 'a', arrayRealVector19, double35 };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException37 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 100L, objArray36);
        org.apache.commons.math3.exception.ConvergenceException convergenceException38 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, objArray36);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        int int19 = blockRealMatrix18.getColumnDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector21.subtract(realVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) true);
        double[] doubleArray33 = arrayRealVector30.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector27.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double[] doubleArray35 = arrayRealVector27.toArray();
        try {
            blockRealMatrix18.setRow((-1074790400), doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor5, 6, (-1), (int) (byte) 0, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray9);
        org.apache.commons.math3.optim.InitialGuess initialGuess11 = new org.apache.commons.math3.optim.InitialGuess(doubleArray9);
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        int int10 = arrayRealVector5.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector5.mapAdd((double) 0L);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double16 = sinc14.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector5.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc14, 2.718281828459045d, (double) (short) 100);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure21 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure22 = sinc14.value(derivativeStructure21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.8414709848078965d + "'", double16 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector17);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math3.util.FastMath.asin(1.0E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 2147483647, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray3 = array2DRowRealMatrix2.getDataRef();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix2.power(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (3x35) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection13 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean14 = arrayRealVector10.equals((java.lang.Object) orderDirection13);
        try {
            blockRealMatrix7.setColumnVector((int) ' ', (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean10 = arrayRealVector8.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector11.equals((java.lang.Object) true);
        double double14 = arrayRealVector8.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector7.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean18 = arrayRealVector16.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector15.append(arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector6.add((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double[] doubleArray33 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray40 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray41 = new double[][] { doubleArray33, doubleArray40 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector44 = blockRealMatrix42.getRowVector((int) (byte) 0);
        try {
            double double45 = arrayRealVector6.getL1Distance(realVector44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(3, (-6.053272382792838d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) 10, 1.0E-14d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getPointRef();
        int int13 = org.apache.commons.math3.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-186238143) + "'", int13 == (-186238143));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(1, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray35, 0.5071158626935848d, 0.3397811690374588d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        try {
            diagonalMatrix1.addToEntry((int) (short) 100, (int) ' ', 1.0E-6d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 0 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray5 = array2DRowRealMatrix4.getDataRef();
        java.lang.StringBuffer stringBuffer6 = null;
        java.text.FieldPosition fieldPosition7 = null;
        try {
            java.lang.StringBuffer stringBuffer8 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix4, stringBuffer6, fieldPosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ", " + "'", str1.equals(", "));
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-4.503599627369091E15d), (java.lang.Number) (short) 0, (java.lang.Number) (byte) 10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getFirst();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 2147483647, (float) 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        int int10 = arrayRealVector5.getMaxIndex();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection18 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean19 = arrayRealVector15.equals((java.lang.Object) orderDirection18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix11, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean26 = arrayRealVector24.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector24.subtract(realVector29);
        arrayRealVector15.setSubVector(0, realVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean34 = arrayRealVector32.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector32.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection42 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean43 = arrayRealVector39.equals((java.lang.Object) orderDirection42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean50 = arrayRealVector48.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean53 = arrayRealVector51.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, (org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector51.mapDivideToSelf((double) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector45.combineToSelf((double) 1.1920929E-7f, Double.POSITIVE_INFINITY, realVector56);
        try {
            org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector5.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(arrayRealVector57);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 32.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray3 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = array2DRowRealMatrix4.walkInColumnOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        long[] longArray3 = new long[] { 36, (-1L), 1 };
        long[] longArray7 = new long[] { 36, (-1L), 1 };
        long[] longArray11 = new long[] { 36, (-1L), 1 };
        long[][] longArray12 = new long[][] { longArray3, longArray7, longArray11 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray12);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray12);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double[] doubleArray25 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray32 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray33 = new double[][] { doubleArray25, doubleArray32 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.RealVector realVector36 = blockRealMatrix34.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = blockRealMatrix18.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean40 = arrayRealVector38.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean43 = arrayRealVector41.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector38, (org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector41.mapDivideToSelf((double) (short) 0);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix18, realVector46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(realVector46);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        long[] longArray5 = new long[] { 10, (short) 10, 35, 'a', 0L };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray5);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] { (byte) 10 };
        int[] intArray10 = new int[] { 1, (short) 100 };
        int int11 = org.apache.commons.math3.util.MathArrays.distance1(intArray7, intArray10);
        int int12 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray7);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math3.random.MersenneTwister(intArray7);
        int int15 = mersenneTwister13.nextInt((int) (byte) 1);
        float float16 = mersenneTwister13.nextFloat();
        long long17 = mersenneTwister13.nextLong();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.032585025f + "'", float16 == 0.032585025f);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 7911606632076355948L + "'", long17 == 7911606632076355948L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        double[] doubleArray22 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray22, doubleArray23);
        double[] doubleArray25 = pointVectorValuePair24.getKey();
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds31 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray25, doubleArray27);
        double double32 = org.apache.commons.math3.util.MathArrays.distance(doubleArray15, doubleArray27);
        try {
            double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray27, 0.3397811690374588d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(19.085536923187668d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math3.util.FastMath.floor(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((-1.0f), (float) (byte) -1, (float) 7911606632076355948L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(0.35349068386023774d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3397811690374588d + "'", double2 == 0.3397811690374588d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat(", ", "hi!hi!", "hi!hi!");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval(100);
        int int2 = maxEval1.getMaxEval();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        double[] doubleArray20 = diagonalMatrix19.getDataRef();
        try {
            double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray17, doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getKey();
        double[] doubleArray10 = pointVectorValuePair8.getFirst();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) -1, (int) 'a', (-10.0d));
        int int4 = nonSymmetricMatrixException3.getRow();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        boolean boolean7 = arrayRealVector0.isNaN();
        boolean boolean8 = arrayRealVector0.isInfinite();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor18 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double23 = blockRealMatrix15.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor18, 100, (int) '#', (int) '4', 96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, 171.88733853924697d, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        boolean boolean14 = array2DRowRealMatrix0.isSquare();
        boolean boolean15 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        double[] doubleArray17 = pointVectorValuePair15.getValue();
        double[] doubleArray18 = pointVectorValuePair15.getValueRef();
        double[] doubleArray19 = array2DRowRealMatrix5.preMultiply(doubleArray18);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double21 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4', 35.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 0, (float) 35L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(1.1920928777442441E-7d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getPoint();
        double[] doubleArray6 = pointValuePair4.getKey();
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        double[] doubleArray14 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray15);
        double[] doubleArray23 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair25 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray23, doubleArray24);
        double[] doubleArray26 = pointVectorValuePair25.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray26);
        double[] doubleArray28 = sigma27.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection29 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray36 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray43 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray44 = new double[][] { doubleArray36, doubleArray43 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, orderDirection29, doubleArray44);
        double[] doubleArray53 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray54 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair55 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray53, doubleArray54);
        double[] doubleArray56 = pointVectorValuePair55.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma57 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray56);
        double[] doubleArray58 = sigma57.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection59 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray66 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray73 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray74 = new double[][] { doubleArray66, doubleArray73 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray74);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray58, orderDirection59, doubleArray74);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray15, orderDirection29, doubleArray74);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74, false);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException80 = new org.apache.commons.math3.exception.MathArithmeticException(localizable7, (java.lang.Object[]) doubleArray74);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, doubleArray74);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight82 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection59.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 1L, (double) 35, (int) (byte) 100);
        double double4 = simpleVectorValueChecker3.getAbsoluteThreshold();
        double double5 = simpleVectorValueChecker3.getAbsoluteThreshold();
        double double6 = simpleVectorValueChecker3.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 0, 0.0d, 10);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        int int5 = levenbergMarquardtOptimizer4.getMaxIterations();
        int int6 = levenbergMarquardtOptimizer4.getEvaluations();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        double double37 = blockRealMatrix15.getNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 19986.0d + "'", double37 == 19986.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) ' ', 3, (int) (byte) 1);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int7 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        double[] doubleArray24 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray24, doubleArray25);
        double[] doubleArray27 = pointVectorValuePair26.getKey();
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        org.apache.commons.math3.optim.PointValuePair pointValuePair32 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds33 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray27, doubleArray29);
        try {
            blockRealMatrix15.setRow((-1074790400), doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 35, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition8 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) 4.5035996E15f);
        int int9 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray17 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray25 = new double[][] { doubleArray17, doubleArray24 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray25);
        int int27 = blockRealMatrix26.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix26.copy();
        java.lang.String str29 = blockRealMatrix26.toString();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix26.scalarAdd(0.41019779969736225d);
        try {
            array2DRowRealMatrix0.setRowMatrix(0, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str29.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
        org.junit.Assert.assertNotNull(blockRealMatrix31);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) (byte) 100);
        double double2 = brentSolver1.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        java.lang.Class<?> wildcardClass23 = simpleValueChecker21.getClass();
        double double24 = simpleValueChecker21.getRelativeThreshold();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        double double7 = lUDecomposition6.getDeterminant();
        double double8 = lUDecomposition6.getDeterminant();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        boolean boolean7 = array2DRowRealMatrix5.isTransposable();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        double[] doubleArray43 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray50 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray51 = new double[][] { doubleArray43, doubleArray50 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray51);
        int int53 = blockRealMatrix52.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix52.copy();
        java.lang.String str55 = blockRealMatrix52.toString();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix36, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix52);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition60 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix58, 3.0d);
        double[][] doubleArray61 = diagonalMatrix58.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix36.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 97x97");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str55.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence((double) (short) 100, 0.0d, 2.2250738585072014E-308d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula3 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula4 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] formulaArray5 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] { formula3, formula4 };
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray15 = pointVectorValuePair14.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray15);
        double[] doubleArray17 = sigma16.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection18 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray25 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray32 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray33 = new double[][] { doubleArray25, doubleArray32 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray17, orderDirection18, doubleArray33);
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.isMonotonic(formulaArray5, orderDirection18, true);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException39 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 2979.3805346802806d, (java.lang.Number) 5.298292365610485d, 1, orderDirection18, true);
        int int40 = nonMonotonicSequenceException39.getIndex();
        org.junit.Assert.assertTrue("'" + formula3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula3.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula4.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(formulaArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) (short) 100, (int) (short) 1);
        double double3 = bracketFinder2.getHi();
        int int4 = bracketFinder2.getEvaluations();
        int int5 = bracketFinder2.getEvaluations();
        double double6 = bracketFinder2.getFLo();
        double double7 = bracketFinder2.getFMid();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, (double) 10L, (double) 4.5035996E15f, (double) 36, 96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [4,503,599,627,370,496, 10]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 1.0f, Double.POSITIVE_INFINITY);
        double double3 = simpleUnivariateValueChecker2.getAbsoluteThreshold();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 32, (-1.5707963267948966d));
        double double8 = univariatePointValuePair7.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair11 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 4.5035996E15f, 1.0d);
        double double12 = univariatePointValuePair11.getValue();
        boolean boolean13 = simpleUnivariateValueChecker2.converged(3, univariatePointValuePair7, univariatePointValuePair11);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.5707963267948966d) + "'", double8 == (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        double[][] doubleArray2 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        double double10 = arrayRealVector4.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector3.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        try {
            org.apache.commons.math3.linear.RealVector realVector12 = diagonalMatrix1.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector11);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 0.032585025f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray0, 0.10272986741866949d, 14133.824606241582d, 98.10395148368781d, 1.7763568394002505E-15d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, Double.NaN);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.analysis.function.Sinc sinc7 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(arrayRealVector8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        double[] doubleArray16 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray23 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray24 = new double[][] { doubleArray16, doubleArray23 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray24);
        org.apache.commons.math3.linear.RealVector realVector27 = blockRealMatrix25.getRowVector((int) (byte) 0);
        try {
            blockRealMatrix7.setRowMatrix(3, blockRealMatrix25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 1x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf((double) (short) 10);
        java.lang.Object[] objArray9 = new java.lang.Object[] { (short) 10, 10.0f, (-1.0f) };
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math3.exception.MathArithmeticException(localizable3, objArray9);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, objArray9);
        org.apache.commons.math3.exception.MathInternalError mathInternalError12 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray9);
        org.apache.commons.math3.exception.ZeroException zeroException13 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray9);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        int int19 = blockRealMatrix18.getColumnDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(3, (int) (byte) 1);
        double double24 = array2DRowRealMatrix20.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix25);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition28 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix20, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor29 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double30 = array2DRowRealMatrix20.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor29);
        try {
            double double35 = blockRealMatrix18.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor29, (int) (byte) 10, (int) (short) -1, (-186238143), 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix39.createMatrix(3, (int) (byte) 1);
        double double43 = array2DRowRealMatrix39.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix39, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix44);
        double[] doubleArray52 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray53 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair54 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray53);
        double[] doubleArray55 = pointVectorValuePair54.getSecond();
        double[] doubleArray56 = pointVectorValuePair54.getValue();
        double[] doubleArray57 = pointVectorValuePair54.getValueRef();
        double[] doubleArray58 = array2DRowRealMatrix44.preMultiply(doubleArray57);
        try {
            blockRealMatrix15.setColumn((int) (byte) 10, doubleArray57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix36.getRowMatrix((int) (byte) 0);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition40 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix36, 2.203819919143124d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (5x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1);
        double[] doubleArray9 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair11 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray9, doubleArray10);
        double double12 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray9);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(1.11669149749E11d, doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix15.copy();
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition39 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat1);
        java.lang.String str3 = realMatrixFormat2.getSuffix();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "}" + "'", str3.equals("}"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        try {
            double[] doubleArray38 = blockRealMatrix33.getRow((-186238143));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-186,238,143)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        int int18 = blockRealMatrix15.getRowDimension();
        java.lang.String str19 = blockRealMatrix15.toString();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str19.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((-4.503599627369091E15d), (double) 0, (double) 34.999996f, (double) 4.5035996E15f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.57625969778098176E17d + "'", double4 == 1.57625969778098176E17d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector21.subtract(realVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) true);
        double[] doubleArray33 = arrayRealVector30.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector27.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double[] doubleArray35 = arrayRealVector27.toArray();
        org.apache.commons.math3.linear.RealVector realVector36 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        org.apache.commons.math3.optim.PointValuePair pointValuePair41 = new org.apache.commons.math3.optim.PointValuePair(doubleArray38, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix42.createMatrix(3, (int) (byte) 1);
        double[] doubleArray52 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray53 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair54 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray53);
        double[] doubleArray55 = pointVectorValuePair54.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma56 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray55);
        double[] doubleArray57 = array2DRowRealMatrix42.operate(doubleArray55);
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equals(doubleArray38, doubleArray55);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray35, doubleArray55);
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.scale((double) (byte) 1, doubleArray59);
        try {
            blockRealMatrix15.setRow((int) (short) 1, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 19986.0d + "'", double18 == 19986.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathUnsupportedOperationException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(100, (int) (byte) 1);
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3);
        double[] doubleArray11 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair13 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray11, doubleArray12);
        double double14 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray4, doubleArray11);
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray4, (double) 100L, false);
        try {
            double[] doubleArray18 = array2DRowRealMatrix2.preMultiply(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (byte) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(Double.POSITIVE_INFINITY, 9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) '#', (double) 1.0f);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = powellOptimizer2.getGoalType();
        int int4 = powellOptimizer2.getIterations();
        org.junit.Assert.assertNull(goalType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-1), (java.lang.Number) (byte) -1, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) -1 + "'", number6.equals((byte) -1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = blockRealMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.17453292519943295d, 10263.0d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 0.09227538f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        double double17 = arrayRealVector7.dotProduct(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector0.ebeDivide(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.subtract(realVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean30 = arrayRealVector28.equals((java.lang.Object) true);
        double[] doubleArray31 = arrayRealVector28.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean37 = arrayRealVector35.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean40 = arrayRealVector38.equals((java.lang.Object) true);
        double double41 = arrayRealVector35.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector34.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean45 = arrayRealVector43.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector43.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean50 = arrayRealVector48.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector43, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector42.append(arrayRealVector48);
        double double53 = arrayRealVector0.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor54 = null;
        try {
            double double55 = arrayRealVector42.walkInDefaultOrder(realVectorChangingVisitor54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 3.43597384E11f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 343597383680L + "'", long1 == 343597383680L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector0.append(19.085536923187668d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        int int12 = arrayRealVector9.getDimension();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector9.mapDivideToSelf(4.9E-324d);
        try {
            org.apache.commons.math3.linear.RealVector realVector15 = realVector8.projection(realVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        boolean boolean14 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double16 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 0.09227538f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09214448658937861d + "'", double1 == 0.09214448658937861d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x2) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) -1, (int) 'a', (-10.0d));
        int int4 = nonSymmetricMatrixException3.getColumn();
        double double5 = nonSymmetricMatrixException3.getThreshold();
        java.lang.Throwable[] throwableArray6 = nonSymmetricMatrixException3.getSuppressed();
        double double7 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-10.0d) + "'", double5 == (-10.0d));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-10.0d) + "'", double7 == (-10.0d));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = blockRealMatrix2.transpose();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getStartPoint();
        int int24 = cMAESOptimizer22.getMaxEvaluations();
        int int25 = cMAESOptimizer22.getIterations();
        java.util.List<java.lang.Double> doubleList26 = cMAESOptimizer22.getStatisticsFitnessHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType27 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction28 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction29 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction28);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction30 = objectiveFunction29.getObjectiveFunction();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction31 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction32 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction31);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction33 = objectiveFunction32.getObjectiveFunction();
        org.apache.commons.math3.optim.MaxEval maxEval35 = new org.apache.commons.math3.optim.MaxEval((int) ' ');
        org.apache.commons.math3.optim.MaxEval maxEval37 = new org.apache.commons.math3.optim.MaxEval((int) ' ');
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray38 = new org.apache.commons.math3.optim.OptimizationData[] { goalType27, objectiveFunction29, objectiveFunction32, maxEval35, maxEval37 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair39 = cMAESOptimizer22.optimize(optimizationDataArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(doubleList26);
        org.junit.Assert.assertTrue("'" + goalType27 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType27.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNull(multivariateFunction30);
        org.junit.Assert.assertNull(multivariateFunction33);
        org.junit.Assert.assertNotNull(optimizationDataArray38);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        long long23 = mersenneTwister11.nextLong();
        double double24 = mersenneTwister11.nextGaussian();
        float float25 = mersenneTwister11.nextFloat();
        int int27 = mersenneTwister11.nextInt(97);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1765991400464819176L) + "'", long23 == (-1765991400464819176L));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.5071158626935848d + "'", double24 == 0.5071158626935848d);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.09227538f + "'", float25 == 0.09227538f);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 49 + "'", int27 == 49);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(98.10395148368781d, Double.NEGATIVE_INFINITY);
        double[] doubleArray9 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair11 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray9, doubleArray10);
        double[] doubleArray12 = pointVectorValuePair11.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray12);
        double[] doubleArray14 = sigma13.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection15 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray22 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray29 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray30 = new double[][] { doubleArray22, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray14, orderDirection15, doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction34 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction35 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction34);
        double[] doubleArray42 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair44 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray42, doubleArray43);
        double[] doubleArray45 = pointVectorValuePair44.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma46 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray45);
        double[] doubleArray47 = sigma46.getSigma();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray48 = new org.apache.commons.math3.optim.OptimizationData[] { weight33, modelFunction35, sigma46 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair49 = simplexOptimizer2.optimize(optimizationDataArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(optimizationDataArray48);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray0, 1.5574077246549023d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) ' ', 3, (int) (byte) 1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = matrixDimensionMismatchException4.getContext();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(2.227615833318806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.692752580359079d + "'", double1 == 4.692752580359079d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double[] doubleArray11 = pointVectorValuePair10.getSecond();
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray13 = array2DRowRealMatrix1.preMultiply(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = array2DRowRealMatrix14.createMatrix(3, (int) (byte) 1);
        double double18 = array2DRowRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix14, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19);
        double[] doubleArray27 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair29 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray28);
        double[] doubleArray30 = pointVectorValuePair29.getSecond();
        double[] doubleArray31 = pointVectorValuePair29.getValue();
        double[] doubleArray32 = pointVectorValuePair29.getValueRef();
        double[] doubleArray33 = array2DRowRealMatrix19.preMultiply(doubleArray32);
        double[] doubleArray34 = identityPreconditioner0.precondition(doubleArray12, doubleArray32);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray32, 0.0922753880002305d, 4.584967478670572d, 2.203819919143124d, 4.9E-324d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double5 = brentSolver4.getAbsoluteAccuracy();
        double double6 = brentSolver4.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        double double11 = simpleValueChecker10.getRelativeThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver13 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 34.999996f);
        double double14 = brentSolver13.getMax();
        double double15 = brentSolver13.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner16 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray24 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray24, doubleArray25);
        double[] doubleArray27 = pointVectorValuePair26.getSecond();
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray29 = array2DRowRealMatrix17.preMultiply(doubleArray28);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix30.createMatrix(3, (int) (byte) 1);
        double double34 = array2DRowRealMatrix30.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix30, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix35);
        double[] doubleArray43 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray44 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray43, doubleArray44);
        double[] doubleArray46 = pointVectorValuePair45.getSecond();
        double[] doubleArray47 = pointVectorValuePair45.getValue();
        double[] doubleArray48 = pointVectorValuePair45.getValueRef();
        double[] doubleArray49 = array2DRowRealMatrix35.preMultiply(doubleArray48);
        double[] doubleArray50 = identityPreconditioner16.precondition(doubleArray28, doubleArray48);
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray51);
        org.apache.commons.math3.optim.PointValuePair pointValuePair55 = new org.apache.commons.math3.optim.PointValuePair(doubleArray52, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = array2DRowRealMatrix56.createMatrix(3, (int) (byte) 1);
        double[] doubleArray66 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray67 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair68 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray66, doubleArray67);
        double[] doubleArray69 = pointVectorValuePair68.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma70 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray69);
        double[] doubleArray71 = array2DRowRealMatrix56.operate(doubleArray69);
        boolean boolean72 = org.apache.commons.math3.util.MathArrays.equals(doubleArray52, doubleArray69);
        org.apache.commons.math3.optim.InitialGuess initialGuess73 = new org.apache.commons.math3.optim.InitialGuess(doubleArray52);
        double[] doubleArray80 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray81 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair82 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray80, doubleArray81);
        double[] doubleArray83 = pointVectorValuePair82.getSecond();
        double[] doubleArray84 = pointVectorValuePair82.getValue();
        double[] doubleArray85 = pointVectorValuePair82.getValueRef();
        double[] doubleArray86 = identityPreconditioner16.precondition(doubleArray52, doubleArray85);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer87 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver13, (org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner) identityPreconditioner16);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer88 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-14d + "'", double15 == 1.0E-14d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray9);
        double[] doubleArray11 = sigma10.getSigma();
        int int12 = org.apache.commons.math3.util.MathUtils.hash(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector9.set((double) 100.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean18 = arrayRealVector16.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.subtract(realVector21);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector16.mapAddToSelf((double) (short) 10);
        double double25 = arrayRealVector9.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector26.subtract(realVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean37 = arrayRealVector35.equals((java.lang.Object) true);
        double[] doubleArray38 = arrayRealVector35.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector32.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = arrayRealVector32.toArray();
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42);
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = array2DRowRealMatrix47.createMatrix(3, (int) (byte) 1);
        double[] doubleArray57 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray58 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray57, doubleArray58);
        double[] doubleArray60 = pointVectorValuePair59.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma61 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray60);
        double[] doubleArray62 = array2DRowRealMatrix47.operate(doubleArray60);
        boolean boolean63 = org.apache.commons.math3.util.MathArrays.equals(doubleArray43, doubleArray60);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray60);
        double[] doubleArray65 = new double[] {};
        double[] doubleArray72 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray73 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair74 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray72, doubleArray73);
        double[] doubleArray75 = pointVectorValuePair74.getSecond();
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray65, doubleArray75);
        double double77 = org.apache.commons.math3.util.MathArrays.distance(doubleArray64, doubleArray75);
        org.apache.commons.math3.linear.RealVector realVector78 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        org.apache.commons.math3.linear.RealVector realVector80 = realVector78.mapMultiply((double) (-1));
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix81 = arrayRealVector9.outerProduct(realVector78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(realVector80);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.apache.commons.math3.util.FastMath.min(96, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded(100);
        org.junit.Assert.assertNotNull(simpleBounds1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 32);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix2 = null;
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = diagonalMatrix1.multiply(diagonalMatrix2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray9);
        org.apache.commons.math3.optim.InitialGuess initialGuess11 = new org.apache.commons.math3.optim.InitialGuess(doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray19 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair21 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray20);
        double[] doubleArray22 = pointVectorValuePair21.getSecond();
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        double[] doubleArray24 = array2DRowRealMatrix12.preMultiply(doubleArray23);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray9, doubleArray24, true);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray9);
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray19 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable11, intArray18, intArray19);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray8, intArray19);
        org.apache.commons.math3.exception.util.Localizable localizable22 = null;
        org.apache.commons.math3.exception.util.Localizable localizable23 = null;
        org.apache.commons.math3.exception.util.Localizable localizable24 = null;
        org.apache.commons.math3.exception.util.Localizable localizable25 = null;
        org.apache.commons.math3.optim.MaxIter maxIter26 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray35 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray36);
        double[] doubleArray38 = pointVectorValuePair37.getSecond();
        java.lang.Object[] objArray39 = new java.lang.Object[] { maxIter26, 19.085536923187668d, (byte) 100, pointVectorValuePair37 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable25, objArray39);
        org.apache.commons.math3.exception.MathInternalError mathInternalError41 = new org.apache.commons.math3.exception.MathInternalError(localizable24, objArray39);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException42 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable23, objArray39);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray8, localizable22, objArray39);
        org.apache.commons.math3.exception.ConvergenceException convergenceException44 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, objArray39);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(maxIter26);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 1.0f, Double.POSITIVE_INFINITY);
        double double3 = simpleUnivariateValueChecker2.getRelativeThreshold();
        double double4 = simpleUnivariateValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.6293654275675724E-6d + "'", double1 == 7.6293654275675724E-6d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        int[] intArray2 = new int[] { (byte) 10 };
        int[] intArray5 = new int[] { 1, (short) 100 };
        int int6 = org.apache.commons.math3.util.MathArrays.distance1(intArray2, intArray5);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        int[] intArray9 = new int[] { (byte) 10 };
        int[] intArray12 = new int[] { 1, (short) 100 };
        int int13 = org.apache.commons.math3.util.MathArrays.distance1(intArray9, intArray12);
        int[] intArray15 = new int[] { (byte) 10 };
        int[] intArray18 = new int[] { 1, (short) 100 };
        int int19 = org.apache.commons.math3.util.MathArrays.distance1(intArray15, intArray18);
        int int20 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray9, intArray15);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, intArray5, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 0, 0.0d, 10);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        double[] doubleArray5 = levenbergMarquardtOptimizer4.getStartPoint();
        int int6 = levenbergMarquardtOptimizer4.getIterations();
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        int int18 = blockRealMatrix15.getRowDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix19.createMatrix(3, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix15.multiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean25 = arrayRealVector23.equals((java.lang.Object) true);
        double double26 = arrayRealVector20.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector19.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        org.apache.commons.math3.analysis.function.Sinc sinc31 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double33 = sinc31.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector19.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc31);
        try {
            blockRealMatrix15.setColumnVector(10, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.8414709848078965d + "'", double33 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector34);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(35, (double) (byte) 10);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator4 = null;
        try {
            nelderMeadSimplex2.iterate(multivariateFunction3, pointValuePairComparator4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat10 = realVectorFormat9.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat11 = new org.apache.commons.math3.linear.RealVectorFormat("hi!hi!", ", ", ", ", numberFormat10);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat12 = new org.apache.commons.math3.linear.RealMatrixFormat("; ", "{}", "hi!", ",", "", "hi!", numberFormat10);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, (double) 343597383680L, (double) 2, (double) 7.6293945E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [343,597,383,680, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((-23), (double) 35L, 97.0d, (double) 0.09227538f, 98.10395148368781d);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        java.lang.String str3 = arrayRealVector0.toString();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{}" + "'", str3.equals("{}"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector(obj0, ",", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition8 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor9 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double10 = array2DRowRealMatrix0.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor9);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner12 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray20 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray20, doubleArray21);
        double[] doubleArray23 = pointVectorValuePair22.getSecond();
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix13.preMultiply(doubleArray24);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix26.createMatrix(3, (int) (byte) 1);
        double double30 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31);
        double[] doubleArray39 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair41 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray39, doubleArray40);
        double[] doubleArray42 = pointVectorValuePair41.getSecond();
        double[] doubleArray43 = pointVectorValuePair41.getValue();
        double[] doubleArray44 = pointVectorValuePair41.getValueRef();
        double[] doubleArray45 = array2DRowRealMatrix31.preMultiply(doubleArray44);
        double[] doubleArray46 = identityPreconditioner12.precondition(doubleArray24, doubleArray44);
        try {
            array2DRowRealMatrix0.setRow(96, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (96)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 1.0f, Double.POSITIVE_INFINITY);
        double double3 = simpleUnivariateValueChecker2.getRelativeThreshold();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 32, (-1.5707963267948966d));
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 32, (-1.5707963267948966d));
        boolean boolean11 = simpleUnivariateValueChecker2.converged(97, univariatePointValuePair7, univariatePointValuePair10);
        double double12 = univariatePointValuePair7.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32.0d + "'", double12 == 32.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = arrayRealVector0.equals((java.lang.Object) orderDirection3);
        double[] doubleArray5 = arrayRealVector0.toArray();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor6 = null;
        try {
            double double9 = arrayRealVector0.walkInDefaultOrder(realVectorPreservingVisitor6, 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}", "hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix1.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix1.getSubMatrix(2147483647, (int) (short) 10, 97, (-23));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor13 = null;
        try {
            double double14 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(3.0d, 0.10272986741866949d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', 10.0d);
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) (byte) 10, 1.5707963267948966d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getStartValue();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        int[] intArray14 = new int[] { (byte) 10 };
        int[] intArray17 = new int[] { 1, (short) 100 };
        int int18 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray17);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math3.random.MersenneTwister(intArray17);
        byte[] byteArray24 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister19.nextBytes(byteArray24);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker29 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer30 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister19, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker29);
        java.lang.Class<?> wildcardClass31 = simpleValueChecker29.getClass();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) (byte) 100, 1.0E-6d, false, (int) 'a', 2147483647, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker29);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList33 = cMAESOptimizer32.getStatisticsDHistory();
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(realMatrixList33);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        double[] doubleArray17 = pointVectorValuePair15.getValue();
        double[] doubleArray18 = pointVectorValuePair15.getValueRef();
        double[] doubleArray19 = array2DRowRealMatrix5.preMultiply(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector20.subtract(realVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean29 = arrayRealVector27.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.mapDivideToSelf((double) (short) 10);
        double double37 = arrayRealVector27.dotProduct(realVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector20.ebeDivide(realVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean41 = arrayRealVector39.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector39.subtract(realVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean50 = arrayRealVector48.equals((java.lang.Object) true);
        double[] doubleArray51 = arrayRealVector48.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector45.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector20.append((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, arrayRealVector20);
        boolean boolean56 = arrayRealVector54.equals((java.lang.Object) 14133.824606241582d);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math3.util.FastMath.log(26.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2771447329921766d + "'", double1 == 3.2771447329921766d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        long[] longArray5 = new long[] { '#', 32, 0, 10, 36 };
        long[] longArray11 = new long[] { '#', 32, 0, 10, 36 };
        long[][] longArray12 = new long[][] { longArray5, longArray11 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray12);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray12);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}", "hi!hi!");
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix21.createMatrix(3, (int) (byte) 1);
        double[] doubleArray31 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray31, doubleArray32);
        double[] doubleArray34 = pointVectorValuePair33.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix21.operate(doubleArray34);
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray34);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray14, doubleArray34);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray46 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray47);
        double[] doubleArray49 = pointVectorValuePair48.getSecond();
        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray49);
        double double51 = org.apache.commons.math3.util.MathArrays.distance(doubleArray38, doubleArray49);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection52 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        try {
            boolean boolean54 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray49, orderDirection52, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean7 = arrayRealVector3.equals((java.lang.Object) orderDirection6);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 4.584967478670572d, 36, orderDirection6, true);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition8 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) 4.5035996E15f);
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        double[][] doubleArray13 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) 'a');
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable9, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) doubleArray13);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray13, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 32 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        long long2 = org.apache.commons.math3.util.FastMath.min(0L, 8556609109677726901L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("{}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = blockRealMatrix15.getColumnMatrix(0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition43 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix41, 3.0d);
        double[][] doubleArray44 = diagonalMatrix41.getData();
        try {
            blockRealMatrix15.setSubMatrix(doubleArray44, (int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double5 = brentSolver4.getAbsoluteAccuracy();
        double double6 = brentSolver4.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        double double8 = brentSolver4.getMax();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 36, 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.999996f + "'", float2 == 35.999996f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat("; ", "{}", ", ", "", "}", ",", numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix1.copy();
        double double11 = diagonalMatrix1.getEntry(9, 0);
        try {
            double double14 = diagonalMatrix1.getEntry(100, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964139d) + "'", double1 == (-0.9251475365964139d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        double double13 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray12);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, (-186238143), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 7.6293945E-6f, (double) 10.0f, 26.5d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        boolean boolean6 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, 0.10272986741866949d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean10 = arrayRealVector8.equals((java.lang.Object) true);
        try {
            array2DRowRealMatrix0.setColumnVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math3.util.FastMath.atan(3.2771447329921766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2746272669235144d + "'", double1 == 1.2746272669235144d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        double double7 = arrayRealVector1.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        boolean boolean11 = arrayRealVector10.isInfinite();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        double[] doubleArray17 = pointVectorValuePair15.getValue();
        double[] doubleArray18 = pointVectorValuePair15.getValueRef();
        double[] doubleArray19 = array2DRowRealMatrix5.preMultiply(doubleArray18);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix5.getSubMatrix(0, 0, (int) (short) -1, (-1074790400));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getValue();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, 10, (-127));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix1.copy();
        double double11 = diagonalMatrix1.getEntry(9, 0);
        diagonalMatrix1.multiplyEntry((int) (short) 100, 52, 0.5071158626935848d);
        double[] doubleArray22 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray22, doubleArray23);
        double[] doubleArray25 = pointVectorValuePair24.getKey();
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) '#', true);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds31 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray25, doubleArray27);
        try {
            double[] doubleArray32 = diagonalMatrix1.operate(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        incrementor1.incrementCount(35);
        int int4 = incrementor1.getCount();
        int int5 = incrementor1.getMaximalCount();
        boolean boolean6 = incrementor1.canIncrement();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix5.getDataRef();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(doubleArray7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double3 = sinc1.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction4 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc1);
        double double7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 1.5707963267948966d, 4.692752580359079d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8414709848078965d + "'", double3 == 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.1415927783384228d + "'", double7 == 3.1415927783384228d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double double6 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector0.mapAddToSelf(10263.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 1.1920929E-7f);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.1920929E-7f + "'", number2.equals(1.1920929E-7f));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.424243053035111E44d, (java.lang.Number) (-4.503599627369091E15d), false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double5 = brentSolver4.getAbsoluteAccuracy();
        double double6 = brentSolver4.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker10 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        double double11 = simpleValueChecker10.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker10);
        int int13 = nonLinearConjugateGradientOptimizer12.getIterations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getRealEigenvalues();
        org.apache.commons.math3.linear.RealVector realVector7 = eigenDecomposition3.getEigenvector((int) (byte) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition3.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.09227538f, (float) (short) -1, 34.999996f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.8813735870195429d, (double) 52L, univariatePointValuePairConvergenceChecker2);
        int int4 = brentOptimizer3.getEvaluations();
        int int5 = brentOptimizer3.getMaxIterations();
        int int6 = brentOptimizer3.getEvaluations();
        int int7 = brentOptimizer3.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math3.util.MathArrays.distance(intArray0, intArray1);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 32.0d, 4.503599627370496E15d, 3.0d, 1.0000000000000002d, 1.424243053035111E44d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 132 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        int int5 = diagonalMatrix1.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        double double10 = diagonalMatrix1.getEntry(32, (int) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector11.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector11.subtract(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        double[] doubleArray23 = arrayRealVector20.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector17.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        boolean boolean25 = diagonalMatrix1.equals((java.lang.Object) arrayRealVector17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor26 = null;
        try {
            double double31 = diagonalMatrix1.walkInColumnOrder(realMatrixChangingVisitor26, (-23), 32, 3, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-23)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        double[] doubleArray11 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray18 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        int int21 = blockRealMatrix20.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.copy();
        int int23 = blockRealMatrix20.getRowDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = diagonalMatrix1.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) ' ');
        int int2 = maxEval1.getMaxEval();
        int int3 = maxEval1.getMaxEval();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval(10);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        double[] doubleArray12 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray19 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray20 = new double[][] { doubleArray12, doubleArray19 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray23 = blockRealMatrix21.getRow(0);
        double[][] doubleArray24 = blockRealMatrix21.getData();
        try {
            array2DRowRealMatrix0.setColumnMatrix(2, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(96, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector21.subtract(realVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) true);
        double[] doubleArray33 = arrayRealVector30.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector27.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double[] doubleArray35 = arrayRealVector27.toArray();
        org.apache.commons.math3.linear.RealVector realVector36 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        org.apache.commons.math3.optim.PointValuePair pointValuePair41 = new org.apache.commons.math3.optim.PointValuePair(doubleArray38, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix42.createMatrix(3, (int) (byte) 1);
        double[] doubleArray52 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray53 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair54 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray53);
        double[] doubleArray55 = pointVectorValuePair54.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma56 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray55);
        double[] doubleArray57 = array2DRowRealMatrix42.operate(doubleArray55);
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equals(doubleArray38, doubleArray55);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray35, doubleArray55);
        org.apache.commons.math3.optim.InitialGuess initialGuess60 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        try {
            blockRealMatrix18.setRow(0, doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x2");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10263.0d + "'", double19 == 10263.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        float[] floatArray6 = new float[] { 10L, 10, 32, 7911606632076355948L, 1, (short) 100 };
        float[] floatArray7 = null;
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray6, floatArray7);
        float[] floatArray9 = null;
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray7, floatArray9);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getFirst();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker4 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(2979.3805346802806d, (double) (short) 1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 171.88733853924697d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999929d + "'", double1 == 0.9999999999999929d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(1.11669149749E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.11669149749E11d + "'", double1 == 1.11669149749E11d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, (double) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getDataRef();
        try {
            double double40 = array2DRowRealMatrix36.getEntry(97, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean20 = arrayRealVector18.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix17, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 35, 3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        incrementor1.incrementCount(35);
        incrementor1.resetCount();
        int int5 = incrementor1.getMaximalCount();
        boolean boolean6 = incrementor1.canIncrement();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat("hi!hi!", ", ", ", ", numberFormat7);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat7);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat10 = new org.apache.commons.math3.linear.RealVectorFormat("}", "", ",", numberFormat7);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat11 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 9, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.999999999999998d + "'", double2 == 8.999999999999998d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double double5 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix7, 3.0d);
        double[] doubleArray10 = diagonalMatrix7.getDataRef();
        try {
            double[] doubleArray11 = array2DRowRealMatrix0.operate(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray5 = array2DRowRealMatrix4.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(0, (-23), doubleArray5, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math3.util.FastMath.log(2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.999470683622238d + "'", double1 == 7.999470683622238d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = arrayRealVector0.equals((java.lang.Object) orderDirection3);
        int int5 = arrayRealVector0.getDimension();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getRealEigenvalues();
        double double7 = eigenDecomposition3.getRealEigenvalue(6);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix(obj0, "}", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = arrayRealVector0.equals((java.lang.Object) orderDirection3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean14 = arrayRealVector12.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, (org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector12.mapDivideToSelf((double) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector6.combineToSelf((double) 1.1920929E-7f, Double.POSITIVE_INFINITY, realVector17);
        int int19 = arrayRealVector6.getMaxIndex();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray6 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray7 = eigenDecomposition3.getImagEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix15.copy();
        try {
            org.apache.commons.math3.linear.RealVector realVector39 = blockRealMatrix15.getColumnVector((-1074790400));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        double[] doubleArray3 = arrayRealVector0.toArray();
        int int4 = arrayRealVector0.getMaxIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean8 = arrayRealVector6.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector6.subtract(realVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean17 = arrayRealVector15.equals((java.lang.Object) true);
        double[] doubleArray18 = arrayRealVector15.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector12.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = arrayRealVector5.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(1.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math3.util.FastMath.log10(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        double double7 = arrayRealVector1.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.analysis.function.Sinc sinc12 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double14 = sinc12.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector0.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc12);
        double[] doubleArray16 = arrayRealVector15.getDataRef();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.8414709848078965d + "'", double14 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        double double7 = arrayRealVector1.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        double double11 = arrayRealVector10.getLInfNorm();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getColumnVector(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, 171.88733853924697d, 0.41019779969736225d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(2979.3805346802806d, (double) (-1.0f));
        double double3 = brentSolver2.getMin();
        double double4 = brentSolver2.getStartValue();
        double double5 = brentSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double17 = sinc15.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction18 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        try {
            double[] doubleArray24 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc15, (double) 6, (double) (-1.0f), 1.0E-15d, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [6, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8414709848078965d + "'", double17 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 100.0f, (double) (short) 1, (int) 'a');
        double double4 = simpleVectorValueChecker3.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 100, 35);
        double double3 = bracketFinder2.getFMid();
        double double4 = bracketFinder2.getHi();
        int int5 = bracketFinder2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        int int5 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (int) 'a', 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        double double7 = arrayRealVector1.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector0.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector9.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean16 = arrayRealVector14.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector8.append(arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.subtract(realVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.append(arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector26.mapAdd(0.17453292519943295d);
        try {
            org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector14.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector31);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double[] doubleArray18 = pointVectorValuePair17.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray18);
        double[] doubleArray20 = sigma19.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray28 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray35 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray36 = new double[][] { doubleArray28, doubleArray35 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray20, orderDirection21, doubleArray36);
        double[] doubleArray45 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray45, doubleArray46);
        double[] doubleArray48 = pointVectorValuePair47.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma49 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray48);
        double[] doubleArray50 = sigma49.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray58 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray65 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray66 = new double[][] { doubleArray58, doubleArray65 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray50, orderDirection51, doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, orderDirection21, doubleArray66);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        try {
            array2DRowRealMatrix71.addToEntry((int) (byte) -1, 1072693248, 4.584967478670572d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector10.subtract(realVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector16.append(arrayRealVector17);
        java.lang.String str21 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector22.subtract(realVector27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector22.mapAddToSelf((double) (short) 10);
        java.lang.StringBuffer stringBuffer31 = null;
        java.text.FieldPosition fieldPosition32 = null;
        try {
            java.lang.StringBuffer stringBuffer33 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector22, stringBuffer31, fieldPosition32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{}" + "'", str21.equals("{}"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math3.util.FastMath.tan((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        double[] doubleArray43 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray50 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray51 = new double[][] { doubleArray43, doubleArray50 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray51);
        int int53 = blockRealMatrix52.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix52.copy();
        java.lang.String str55 = blockRealMatrix52.toString();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix36, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix52);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor57 = null;
        try {
            double double58 = blockRealMatrix52.walkInOptimizedOrder(realMatrixPreservingVisitor57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str55.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = arrayRealVector0.equals((java.lang.Object) orderDirection3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector5.subtract(realVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.append(arrayRealVector12);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector12.mapAdd(0.17453292519943295d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.8813735870195429d, (double) (short) -1, (double) (-1765991400464819176L), 4.9E-324d, 19986.0d, 0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3487.3336694488476d + "'", double6 == 3487.3336694488476d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.optim.MaxIter maxIter7 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        java.lang.Object[] objArray20 = new java.lang.Object[] { maxIter7, 19.085536923187668d, (byte) 100, pointVectorValuePair18 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable6, objArray20);
        org.apache.commons.math3.exception.MathInternalError mathInternalError22 = new org.apache.commons.math3.exception.MathInternalError(localizable5, objArray20);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException23 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable4, objArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable3, objArray20);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException25 = new org.apache.commons.math3.exception.MathArithmeticException(localizable2, objArray20);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 2.1474836470000021E9d, objArray20);
        org.junit.Assert.assertNotNull(maxIter7);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) (-23));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix7);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = blockRealMatrix7.walkInOptimizedOrder(realMatrixChangingVisitor9, (int) (short) 10, (-127), 97, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        double[] doubleArray24 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray32 = new double[][] { doubleArray24, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = blockRealMatrix33.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix33.transpose();
        double[] doubleArray43 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray50 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray51 = new double[][] { doubleArray43, doubleArray50 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray51);
        org.apache.commons.math3.linear.RealVector realVector54 = blockRealMatrix52.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = blockRealMatrix36.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix15.add(blockRealMatrix36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 6x2");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realMatrix55);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = diagonalMatrix1.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix1.transpose();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition5 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix3, 3.0d);
        diagonalMatrix3.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = diagonalMatrix3.copy();
        double double13 = diagonalMatrix3.getEntry(9, 0);
        double[] doubleArray14 = diagonalMatrix3.getDataRef();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 97, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method -1, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 100, Double.NEGATIVE_INFINITY);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.5071158626935848d, (double) '#', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver8 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 34.999996f);
        double double9 = brentSolver8.getMax();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver8);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray11 = new org.apache.commons.math3.optim.OptimizationData[] {};
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair12 = nonLinearConjugateGradientOptimizer10.optimize(optimizationDataArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(optimizationDataArray11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getNorm();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix20, 3.0d);
        diagonalMatrix20.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = diagonalMatrix20.copy();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix15.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 97x97");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 19986.0d + "'", double18 == 19986.0d);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        double[] doubleArray5 = eigenDecomposition3.getImagEigenvalues();
        boolean boolean6 = eigenDecomposition3.hasComplexEigenvalues();
        double double7 = eigenDecomposition3.getDeterminant();
        double double9 = eigenDecomposition3.getRealEigenvalue((int) (byte) 0);
        double double10 = eigenDecomposition3.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray23 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair25 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray23, doubleArray24);
        double[] doubleArray26 = pointVectorValuePair25.getSecond();
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix16.preMultiply(doubleArray27);
        double[][] doubleArray29 = array2DRowRealMatrix16.getData();
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray29, (int) (short) 1, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 1 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getMax();
        double double2 = brentSolver0.getStartValue();
        double double3 = brentSolver0.getMax();
        double double4 = brentSolver0.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-6d + "'", double4 == 1.0E-6d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray10 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException11 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray9, intArray10);
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        java.lang.Integer[] intArray19 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray20 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable12, intArray19, intArray20);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException22 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray20);
        org.apache.commons.math3.exception.util.Localizable localizable23 = null;
        java.lang.Integer[] intArray30 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray31 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException32 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable23, intArray30, intArray31);
        org.apache.commons.math3.exception.util.Localizable localizable33 = null;
        java.lang.Integer[] intArray40 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray41 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException42 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable33, intArray40, intArray41);
        org.apache.commons.math3.exception.util.Localizable localizable43 = null;
        java.lang.Integer[] intArray50 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray51 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException52 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable43, intArray50, intArray51);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException53 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray40, intArray51);
        org.apache.commons.math3.exception.util.Localizable localizable54 = null;
        org.apache.commons.math3.exception.util.Localizable localizable55 = null;
        org.apache.commons.math3.exception.util.Localizable localizable56 = null;
        org.apache.commons.math3.exception.util.Localizable localizable57 = null;
        org.apache.commons.math3.optim.MaxIter maxIter58 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray67 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray68 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair69 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray67, doubleArray68);
        double[] doubleArray70 = pointVectorValuePair69.getSecond();
        java.lang.Object[] objArray71 = new java.lang.Object[] { maxIter58, 19.085536923187668d, (byte) 100, pointVectorValuePair69 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable57, objArray71);
        org.apache.commons.math3.exception.MathInternalError mathInternalError73 = new org.apache.commons.math3.exception.MathInternalError(localizable56, objArray71);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException74 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable55, objArray71);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray40, localizable54, objArray71);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException76 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray31, intArray40);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException77 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray20, intArray31);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException78 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) intArray20);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(maxIter58);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(objArray71);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        int int19 = blockRealMatrix18.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix18.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x2) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getKey();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix10.createMatrix(3, (int) (byte) 1);
        double[] doubleArray20 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray20, doubleArray21);
        double[] doubleArray23 = pointVectorValuePair22.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma24 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix10.operate(doubleArray23);
        try {
            double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray9, doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.optim.MaxIter maxIter5 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray14 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray15);
        double[] doubleArray17 = pointVectorValuePair16.getSecond();
        java.lang.Object[] objArray18 = new java.lang.Object[] { maxIter5, 19.085536923187668d, (byte) 100, pointVectorValuePair16 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable4, objArray18);
        org.apache.commons.math3.exception.MathInternalError mathInternalError20 = new org.apache.commons.math3.exception.MathInternalError(localizable3, objArray18);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException21 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable2, objArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray18);
        java.lang.Class<?> wildcardClass23 = objArray18.getClass();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException24 = new org.apache.commons.math3.exception.NotFiniteNumberException(number0, objArray18);
        org.junit.Assert.assertNotNull(maxIter5);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(171.88733853924697d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getPoint();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        int int10 = arrayRealVector5.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector5.mapAdd((double) 0L);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double16 = sinc14.value((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector5.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean25 = arrayRealVector23.equals((java.lang.Object) true);
        double double26 = arrayRealVector20.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector5.combine(4.503599627370496E15d, 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector20.mapAddToSelf(0.0922753880002305d);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.8414709848078965d + "'", double16 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(100, (int) (byte) 1);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds4 = org.apache.commons.math3.optim.SimpleBounds.unbounded(1);
        double[] doubleArray5 = simpleBounds4.getLower();
        double[] doubleArray6 = array2DRowRealMatrix2.operate(doubleArray5);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double double18 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray15);
        try {
            double[] doubleArray19 = array2DRowRealMatrix2.preMultiply(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(simpleBounds4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver5 = new org.apache.commons.math3.analysis.solvers.BrentSolver(Double.NaN);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver5);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType7 = nonLinearConjugateGradientOptimizer6.getGoalType();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNull(goalType7);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, pointVectorValuePairConvergenceChecker1, 0.0d, 100.0d, (double) (byte) 100, (double) (short) -1);
        double[] doubleArray7 = levenbergMarquardtOptimizer6.getLowerBound();
        int int8 = levenbergMarquardtOptimizer6.getEvaluations();
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) 2.227615833318806d, "hi!hi!", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowSuffix();
        java.lang.String str4 = realMatrixFormat0.getRowPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "; " + "'", str1.equals("; "));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        int[] intArray5 = new int[] { (byte) 10 };
        int[] intArray8 = new int[] { 1, (short) 100 };
        int int9 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray8);
        int[] intArray10 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        int[] intArray12 = new int[] { (byte) 10 };
        int[] intArray15 = new int[] { 1, (short) 100 };
        int int16 = org.apache.commons.math3.util.MathArrays.distance1(intArray12, intArray15);
        int[] intArray17 = org.apache.commons.math3.util.MathArrays.copyOf(intArray12);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math3.random.MersenneTwister(intArray12);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, intArray10, intArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix15.getSubMatrix(10, (int) (byte) 10, 96, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        double double17 = arrayRealVector7.dotProduct(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector0.ebeDivide(realVector16);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.mapMultiply((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(97.0d, (double) 9, 1.11669149749E11d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.append(arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector7.mapAdd(0.17453292519943295d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector7.append(1.1920928777442441E-7d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector5);
        org.apache.commons.math3.linear.RealVector realVector9 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector0.subtract(realVector9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((double) 8556609109677726901L, (double) 34.999996f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        try {
            org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (-1074790400), (double) (-9208070452475268559L), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.append(arrayRealVector7);
        java.lang.String str11 = arrayRealVector7.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{}" + "'", str11.equals("{}"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[] doubleArray4 = eigenDecomposition3.getImagEigenvalues();
        boolean boolean5 = eigenDecomposition3.hasComplexEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = eigenDecomposition3.getVT();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        boolean boolean6 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, 0.10272986741866949d);
        int int7 = array2DRowRealMatrix0.getRowDimension();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math3.util.FastMath.atan(0.9999999999999929d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974447d + "'", double1 == 0.7853981633974447d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix1, 0, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean10 = arrayRealVector8.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean13 = arrayRealVector11.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, (org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) (-1));
        try {
            diagonalMatrix1.setRowVector(1072693248, (org.apache.commons.math3.linear.RealVector) arrayRealVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,072,693,248)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        boolean boolean14 = array2DRowRealMatrix0.isSquare();
        boolean boolean15 = array2DRowRealMatrix0.isTransposable();
        org.apache.commons.math3.linear.AnyMatrix anyMatrix16 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, anyMatrix16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (short) 10, (double) 0.0f, (int) 'a');
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        double[] doubleArray11 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray18 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray19 = new double[][] { doubleArray11, doubleArray18 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector22 = blockRealMatrix20.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix23.createMatrix(3, (int) (byte) 1);
        double double27 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix28);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition31 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix23, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor32 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double33 = array2DRowRealMatrix23.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double double34 = blockRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        try {
            double double39 = diagonalMatrix1.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32, (int) '4', 2147483647, 2, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition18 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, 3.0d);
        double[] doubleArray19 = eigenDecomposition18.getImagEigenvalues();
        double[] doubleArray26 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair28 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray27);
        double[] doubleArray35 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray36);
        double[] doubleArray38 = pointVectorValuePair37.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray38);
        double[] doubleArray40 = sigma39.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection41 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray48 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray55 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray56 = new double[][] { doubleArray48, doubleArray55 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray56);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray40, orderDirection41, doubleArray56);
        double[] doubleArray65 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair67 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray66);
        double[] doubleArray68 = pointVectorValuePair67.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma69 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray68);
        double[] doubleArray70 = sigma69.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection71 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray78 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray85 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray86 = new double[][] { doubleArray78, doubleArray85 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix87 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray86);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray70, orderDirection71, doubleArray86);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray27, orderDirection41, doubleArray86);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray19, orderDirection41, false);
        try {
            boolean boolean94 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray14, orderDirection41, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection71.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 100, Double.NEGATIVE_INFINITY);
        double double3 = simpleValueChecker2.getRelativeThreshold();
        double double4 = simpleValueChecker2.getAbsoluteThreshold();
        double double5 = simpleValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, pointVectorValuePairConvergenceChecker1, 0.0d, 100.0d, (double) (byte) 100, (double) (short) -1);
        double[] doubleArray7 = levenbergMarquardtOptimizer6.getStartPoint();
        int int8 = levenbergMarquardtOptimizer6.getIterations();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker9 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        double[] doubleArray13 = pointVectorValuePair8.getPoint();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.7853981633974447d, 0.0d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        int int7 = realVector5.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean10 = arrayRealVector8.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector8.subtract(realVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean18 = arrayRealVector16.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        double double22 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector15.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean26 = arrayRealVector24.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector24.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean31 = arrayRealVector29.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24, arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector23.append(arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector14.add((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        try {
            org.apache.commons.math3.linear.RealVector realVector35 = realVector5.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray7);
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray18 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair20 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray18, doubleArray19);
        double[] doubleArray21 = pointVectorValuePair20.getSecond();
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        double[] doubleArray23 = array2DRowRealMatrix11.preMultiply(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix11.getData();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException25 = new org.apache.commons.math3.exception.MathArithmeticException(localizable10, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        double double13 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray12);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition17 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix15, 3.0d);
        double[] doubleArray18 = diagonalMatrix15.getDataRef();
        int int19 = diagonalMatrix15.getColumnDimension();
        double[][] doubleArray20 = diagonalMatrix15.getData();
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray12, doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, pointVectorValuePairConvergenceChecker1, 0.0d, 100.0d, (double) (byte) 100, (double) (short) -1);
        double[] doubleArray7 = levenbergMarquardtOptimizer6.getStartPoint();
        try {
            double double8 = levenbergMarquardtOptimizer6.getRMS();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(doubleArray7);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.mapDivideToSelf((double) (short) 10);
        java.lang.Object[] objArray6 = new java.lang.Object[] { (short) 10, 10.0f, (-1.0f) };
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathArithmeticException7.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathArithmeticException7.getContext();
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(exceptionContext10);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.createMatrix(3, (int) (byte) 1);
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double[] doubleArray18 = pointVectorValuePair17.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray18);
        double[] doubleArray20 = array2DRowRealMatrix5.operate(doubleArray18);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray18);
        try {
            double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.9999999999999929d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4359738367999756E10d + "'", double2 == 3.4359738367999756E10d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 1.0f, (double) (byte) 0);
        double double3 = brentSolver2.getMin();
        org.apache.commons.math3.analysis.function.Sinc sinc6 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double double9 = brentSolver2.solve(1, (org.apache.commons.math3.analysis.UnivariateFunction) sinc6, 3487.3336694488476d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [3,487.334, 1,743.667]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        try {
            double[] doubleArray19 = blockRealMatrix15.getColumn(35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = diagonalMatrix1.getRowMatrix((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector5 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector6 = array2DRowRealMatrix0.operateTranspose(realVector5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double[] doubleArray17 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        double[] doubleArray20 = pointVectorValuePair19.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray20);
        double[] doubleArray22 = sigma21.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection23 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray30 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray37 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray38 = new double[][] { doubleArray30, doubleArray37 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray38);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray22, orderDirection23, doubleArray38);
        double[] doubleArray47 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray48 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair49 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray47, doubleArray48);
        double[] doubleArray50 = pointVectorValuePair49.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma51 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray50);
        double[] doubleArray52 = sigma51.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection53 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray60 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray67 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray68 = new double[][] { doubleArray60, doubleArray67 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray68);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, orderDirection53, doubleArray68);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, orderDirection23, doubleArray68);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix(100, (int) (byte) 100, doubleArray68, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 2,704");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.analysis.function.Sinc sinc15 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double17 = sinc15.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction18 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector13.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc15);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor20 = null;
        try {
            double double23 = arrayRealVector19.walkInOptimizedOrder(realVectorPreservingVisitor20, (-1074790400), 96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8414709848078965d + "'", double17 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2163925864078933d + "'", double1 == 2.2163925864078933d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double[] doubleArray25 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray32 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray33 = new double[][] { doubleArray25, doubleArray32 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.RealVector realVector36 = blockRealMatrix34.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = blockRealMatrix18.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[][] doubleArray40 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 32);
        try {
            blockRealMatrix34.setSubMatrix(doubleArray40, (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 32, (-1.5707963267948966d));
        double double3 = univariatePointValuePair2.getValue();
        double double4 = univariatePointValuePair2.getValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.5707963267948966d) + "'", double3 == (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.5707963267948966d) + "'", double4 == (-1.5707963267948966d));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        boolean boolean14 = array2DRowRealMatrix0.isSquare();
        boolean boolean15 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition19 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix17, 3.0d);
        diagonalMatrix17.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = diagonalMatrix17.copy();
        double double27 = diagonalMatrix17.getEntry(9, 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix0.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        boolean boolean11 = pointVectorValuePair8.equals((java.lang.Object) "hi!");
        double[] doubleArray12 = pointVectorValuePair8.getPointRef();
        double[] doubleArray13 = pointVectorValuePair8.getValue();
        double[] doubleArray14 = pointVectorValuePair8.getPoint();
        double[] doubleArray15 = pointVectorValuePair8.getKey();
        double[] doubleArray16 = pointVectorValuePair8.getSecond();
        double[] doubleArray17 = pointVectorValuePair8.getFirst();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix0.preMultiply(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix0.getData();
        boolean boolean14 = array2DRowRealMatrix0.isSquare();
        boolean boolean15 = array2DRowRealMatrix0.isTransposable();
        double[] doubleArray22 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray29 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray36 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray43 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray50 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray51 = new double[][] { doubleArray22, doubleArray29, doubleArray36, doubleArray43, doubleArray50 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix52.getRowMatrix((int) (byte) 0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor55 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double56 = array2DRowRealMatrix52.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor55);
        double double57 = array2DRowRealMatrix0.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor55);
        double[] doubleArray64 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray71 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray72 = new double[][] { doubleArray64, doubleArray71 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray72);
        org.apache.commons.math3.linear.RealVector realVector75 = blockRealMatrix73.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix79 = array2DRowRealMatrix76.createMatrix(3, (int) (byte) 1);
        double double80 = array2DRowRealMatrix76.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix76, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix81);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition84 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix76, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor85 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double86 = array2DRowRealMatrix76.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor85);
        double double87 = blockRealMatrix73.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor85);
        defaultRealMatrixPreservingVisitor85.start((-186238143), 9, (int) (short) 0, 0, 2, (int) (short) 0);
        try {
            double double99 = array2DRowRealMatrix0.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor85, 100, (int) (short) 100, 2, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(realMatrix79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) 9, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.5d + "'", double2 == 4.5d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getPoint();
        double[] doubleArray6 = pointValuePair4.getKey();
        java.lang.Double double7 = pointValuePair4.getSecond();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7.equals(35.0d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 4.692752580359079d, (double) 7.6293945E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [4.693, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double[] doubleArray11 = pointVectorValuePair10.getSecond();
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray13 = array2DRowRealMatrix1.preMultiply(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = array2DRowRealMatrix14.createMatrix(3, (int) (byte) 1);
        double double18 = array2DRowRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix14, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19);
        double[] doubleArray27 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair29 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray28);
        double[] doubleArray30 = pointVectorValuePair29.getSecond();
        double[] doubleArray31 = pointVectorValuePair29.getValue();
        double[] doubleArray32 = pointVectorValuePair29.getValueRef();
        double[] doubleArray33 = array2DRowRealMatrix19.preMultiply(doubleArray32);
        double[] doubleArray34 = identityPreconditioner0.precondition(doubleArray12, doubleArray32);
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray34, 0.0d);
        java.lang.Double double37 = pointValuePair36.getValue();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37.equals(0.0d));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("hi!hi!", ", ", ", ", numberFormat4);
        java.lang.String str6 = realVectorFormat5.getSeparator();
        java.lang.String str7 = realVectorFormat5.getSeparator();
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ", " + "'", str6.equals(", "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + ", " + "'", str7.equals(", "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 'a', 343597383680L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 343597383680L + "'", long2 == 343597383680L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        double[][] doubleArray2 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = diagonalMatrix1.copy();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = null;
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = diagonalMatrix1.multiply(diagonalMatrix4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        double double17 = arrayRealVector7.dotProduct(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector0.ebeDivide(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector19.subtract(realVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean31 = arrayRealVector29.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapDivideToSelf((double) (short) 10);
        double double36 = arrayRealVector26.dotProduct(realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector19.ebeDivide(realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean40 = arrayRealVector38.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector38.subtract(realVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean49 = arrayRealVector47.equals((java.lang.Object) true);
        double[] doubleArray50 = arrayRealVector47.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector44.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector19.append((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector18.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        try {
            arrayRealVector53.setEntry((-23), 0.35349068386023774d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-23)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(arrayRealVector53);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        int int19 = blockRealMatrix18.getColumnDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(3, (int) (byte) 1);
        double double24 = array2DRowRealMatrix20.getFrobeniusNorm();
        double[] doubleArray31 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray38 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray39 = new double[][] { doubleArray31, doubleArray38 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector42 = blockRealMatrix40.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix43.createMatrix(3, (int) (byte) 1);
        double double47 = array2DRowRealMatrix43.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix43, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition51 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix43, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor52 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double53 = array2DRowRealMatrix43.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        double double54 = blockRealMatrix40.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        defaultRealMatrixPreservingVisitor52.start((-186238143), 9, (int) (short) 0, 0, 2, (int) (short) 0);
        double double62 = array2DRowRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        try {
            double double67 = blockRealMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52, 35, 0, 100, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((-10.0d), (-1.5707963267948963d), (double) 35.999996f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        double[] doubleArray22 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray22, doubleArray23);
        double[] doubleArray25 = pointVectorValuePair24.getSecond();
        double[] doubleArray26 = pointVectorValuePair24.getValue();
        double[] doubleArray27 = pointVectorValuePair24.getValue();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray13, doubleArray27, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.transpose();
        double double19 = blockRealMatrix18.getNorm();
        double[] doubleArray26 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray33 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray34 = new double[][] { doubleArray26, doubleArray33 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        int int36 = blockRealMatrix35.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.copy();
        java.lang.String str38 = blockRealMatrix35.toString();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix35.scalarAdd(0.41019779969736225d);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix35);
        double[] doubleArray48 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray49 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair50 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray48, doubleArray49);
        double[] doubleArray51 = pointVectorValuePair50.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray51);
        org.apache.commons.math3.optim.InitialGuess initialGuess53 = new org.apache.commons.math3.optim.InitialGuess(doubleArray51);
        try {
            double[] doubleArray54 = blockRealMatrix35.preMultiply(doubleArray51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10263.0d + "'", double19 == 10263.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}" + "'", str38.equals("BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}"));
        org.junit.Assert.assertNotNull(blockRealMatrix40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix1.copy();
        double double11 = diagonalMatrix1.getEntry(9, 0);
        diagonalMatrix1.multiplyEntry((int) (short) 100, 52, 0.5071158626935848d);
        double[][] doubleArray16 = diagonalMatrix1.getData();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat17 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat18 = realVectorFormat17.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, (org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        java.lang.String str26 = realVectorFormat17.format((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        int int27 = arrayRealVector22.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector22.mapAdd((double) 0L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector30.mapMultiply(4.503599627370496E15d);
        try {
            org.apache.commons.math3.linear.RealVector realVector34 = diagonalMatrix1.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(numberFormat18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{}" + "'", str26.equals("{}"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 4.641588833612779d, (java.lang.Number) (-1.0f), false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(Double.POSITIVE_INFINITY, (double) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector4.subtract(realVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean15 = arrayRealVector13.equals((java.lang.Object) true);
        double[] doubleArray16 = arrayRealVector13.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector10.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.analysis.function.Sinc sinc19 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double21 = sinc19.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction22 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector17.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc19);
        boolean boolean26 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc19, 0.0922753880002305d, (double) 7.6293945E-6f);
        try {
            double double30 = brentSolver2.solve((int) (byte) 0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc19, 171.88733853924697d, 0.5403023058681398d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [171.887, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.8414709848078965d + "'", double21 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.8813735870195429d, (double) 52L, univariatePointValuePairConvergenceChecker2);
        int int4 = brentOptimizer3.getEvaluations();
        int int5 = brentOptimizer3.getMaxIterations();
        int int6 = brentOptimizer3.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat("", "", "BlockRealMatrix{{100.0,35.0,9993.0,35.0,0.0,100.0},{100.0,35.0,9993.0,35.0,0.0,100.0}}", "}", ",", "hi!hi!", numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 1.0f, (double) (byte) 0);
        double double3 = brentSolver2.getMin();
        double double4 = brentSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray16 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray17);
        double[] doubleArray19 = pointVectorValuePair18.getSecond();
        boolean boolean21 = pointVectorValuePair18.equals((java.lang.Object) "hi!");
        double[] doubleArray22 = pointVectorValuePair18.getSecond();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, doubleArray22);
        double[] doubleArray30 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair32 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray30, doubleArray31);
        double[] doubleArray39 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair41 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray39, doubleArray40);
        double[] doubleArray42 = pointVectorValuePair41.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma43 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray42);
        double[] doubleArray44 = sigma43.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection45 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray52 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray59 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray60 = new double[][] { doubleArray52, doubleArray59 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray60);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray44, orderDirection45, doubleArray60);
        double[] doubleArray69 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray70 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair71 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray69, doubleArray70);
        double[] doubleArray72 = pointVectorValuePair71.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma73 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray72);
        double[] doubleArray74 = sigma73.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection75 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray82 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray89 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray90 = new double[][] { doubleArray82, doubleArray89 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix91 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray90);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray74, orderDirection75, doubleArray90);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray31, orderDirection45, doubleArray90);
        try {
            boolean boolean95 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray22, orderDirection45, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection75.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
    }
}

