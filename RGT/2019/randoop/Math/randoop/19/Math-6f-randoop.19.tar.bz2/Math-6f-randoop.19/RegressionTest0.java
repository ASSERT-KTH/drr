import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.text.NumberFormat numberFormat0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (short) 10, (double) (byte) -1, 100.0d, 0.0d, 100.0d, (double) (byte) 100, (double) 3, 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9993.0d + "'", double8 == 9993.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.optim.MaxEval maxEval0 = org.apache.commons.math3.optim.MaxEval.unlimited();
        org.junit.Assert.assertNotNull(maxEval0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.085536923187668d + "'", double1 == 19.085536923187668d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        int[] intArray5 = new int[] { (byte) 10, 0, '#', (byte) -1 };
        int[] intArray12 = new int[] { (byte) 100, (short) 1, (short) -1, 3, (short) -1, 3 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix0.getSubMatrix(intArray5, intArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.setColumnMatrix((int) (short) 100, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 19.085536923187668d, 0.0d, (-1.0d), 19.085536923187668d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, (int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition1 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray11 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair13 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray11, doubleArray12);
        double[] doubleArray14 = pointVectorValuePair13.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray14);
        try {
            array2DRowRealMatrix0.setColumn((int) '4', doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix4.createMatrix(3, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 3x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1, (int) '#', 100, 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (byte) -1, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 3, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        int[] intArray9 = new int[] { 0, 1, '4', (short) 10, (short) 0 };
        int[] intArray12 = new int[] { (byte) -1, (short) 10 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix0.getSubMatrix(intArray9, intArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(10.0d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-10.0d) + "'", double2 == (-10.0d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition5 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { 100.0d, (short) 0, 1L, (short) 0, 100, 9993.0d };
        double[] doubleArray14 = new double[] { 100.0d, (short) 0, 1L, (short) 0, 100, 9993.0d };
        double[] doubleArray21 = new double[] { 100.0d, (short) 0, 1L, (short) 0, 100, 9993.0d };
        double[][] doubleArray22 = new double[][] { doubleArray7, doubleArray14, doubleArray21 };
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray22, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 1 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker4 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10L, 0.0d, (double) (-1), (double) (short) 10, pointValuePairConvergenceChecker4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException(number0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = new double[][] {};
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray4, (int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 100 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.setColumnMatrix((int) (short) 100, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector4.subtract(realVector9);
        try {
            org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix0.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        float float3 = org.apache.commons.math3.util.Precision.round((float) 100, (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor7 = null;
        try {
            double double10 = arrayRealVector0.walkInDefaultOrder(realVectorChangingVisitor7, (int) ' ', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "", "", "", "hi!", ", ", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.mapDivideToSelf((double) (short) 10);
        java.lang.Object[] objArray6 = new java.lang.Object[] { (short) 10, 10.0f, (-1.0f) };
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray6);
        java.io.ObjectInputStream objectInputStream9 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) localizable0, ", ", objectInputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray9);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = null;
        try {
            boolean boolean14 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray9, orderDirection11, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix4.createMatrix(3, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix3, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        double[] doubleArray3 = arrayRealVector0.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean6 = arrayRealVector4.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector4.subtract(realVector9);
        try {
            double double11 = arrayRealVector0.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 10, (double) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            org.apache.commons.math3.linear.RealVector realVector1 = arrayRealVector0.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        java.io.ObjectOutputStream objectOutputStream4 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, objectOutputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(10.0d, (double) ' ', (double) (-1L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        try {
            array2DRowRealMatrix0.multiplyEntry((int) '4', (int) (short) -1, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (-1L), numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double double4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve(univariateFunction0, 0.0d, 0.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            arrayRealVector0.addToEntry((int) (byte) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat3);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat4.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 3, (double) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((-10.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.0d) + "'", double1 == (-10.0d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.optim.MaxIter maxIter3 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray15 = pointVectorValuePair14.getSecond();
        java.lang.Object[] objArray16 = new java.lang.Object[] { maxIter3, 19.085536923187668d, (byte) 100, pointVectorValuePair14 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray16);
        org.apache.commons.math3.exception.MathInternalError mathInternalError18 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray16);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException19 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, objArray16);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext20 = mathUnsupportedOperationException19.getContext();
        org.junit.Assert.assertNotNull(maxIter3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(exceptionContext20);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int[] intArray0 = null;
        try {
            int[] intArray1 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double[] doubleArray0 = null;
        org.apache.commons.math3.optim.PointValuePair pointValuePair3 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 0.0d, false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math3.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math3.linear.SingularMatrixException();
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 10, (int) ' ', 3, (int) (byte) 1);
        try {
            int int6 = matrixDimensionMismatchException4.getExpectedDimension((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.createMatrix(3, (int) (byte) 1);
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double[] doubleArray18 = pointVectorValuePair17.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray18);
        double[] doubleArray20 = array2DRowRealMatrix5.operate(doubleArray18);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray18);
        try {
            double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray1, (double) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence((double) 32, 0.0d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [32, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction1 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction(univariateFunction0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int1 = org.apache.commons.math3.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        long[] longArray6 = new long[] { (short) 100, (short) 10, (short) 1, 10L, (short) -1, 100L };
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double21 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor16, (int) (short) 1, (int) '4', (int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        try {
            array2DRowRealMatrix0.setEntry(1, 3, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '4', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix1.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray5 = array2DRowRealMatrix1.getDataRef();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, (double) 1.1920929E-7f, (double) 52, (double) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "", "", "; ", "; ", "", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        try {
            double[] doubleArray6 = array2DRowRealMatrix0.getRow((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.scalarMultiply((double) 1.1920929E-7f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 10, (double) 1);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator4 = null;
        try {
            nelderMeadSimplex2.evaluate(multivariateFunction3, pointValuePairComparator4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.getColumnMatrix((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math3.exception.ConvergenceException convergenceException0 = new org.apache.commons.math3.exception.ConvergenceException();
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 3, (int) (short) 100, (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) '#', (double) 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.999996f + "'", float2 == 34.999996f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0d, (-10.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.5035996E15f + "'", float2 == 4.5035996E15f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        try {
            array2DRowRealMatrix0.addToEntry(1, (-1), (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double[] doubleArray1 = new double[] { 3.0d };
        double[] doubleArray3 = new double[] { 3.0d };
        double[] doubleArray5 = new double[] { 3.0d };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1);
        try {
            double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 1, 9993.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair9 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray8);
        double[] doubleArray10 = pointVectorValuePair9.getSecond();
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray10);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray10, (double) (byte) 1, (-10.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1, (org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        double double6 = array2DRowRealMatrix1.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix0.multiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray9 = array2DRowRealMatrix5.getDataRef();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = array2DRowRealMatrix0.add(array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNull(doubleArray9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double double5 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[][] doubleArray12 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) 'a');
        try {
            array2DRowRealMatrix0.copySubMatrix(9, (int) (byte) 1, 0, 0, doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (9)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 10, (double) (byte) 10, (double) 'a');
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction5 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction4);
        org.apache.commons.math3.optim.MaxEval maxEval7 = new org.apache.commons.math3.optim.MaxEval((int) ' ');
        org.apache.commons.math3.optim.MaxEval maxEval9 = new org.apache.commons.math3.optim.MaxEval((int) ' ');
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep11 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep(0.0d);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray12 = new org.apache.commons.math3.optim.OptimizationData[] { objectiveFunction5, maxEval7, maxEval9, bracketingStep11 };
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair13 = levenbergMarquardtOptimizer3.optimize(optimizationDataArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(optimizationDataArray12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix16.createMatrix(3, (int) (byte) 1);
        double[] doubleArray26 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair28 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray27);
        double[] doubleArray29 = pointVectorValuePair28.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma30 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray29);
        double[] doubleArray31 = array2DRowRealMatrix16.operate(doubleArray29);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 100.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double double4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve(univariateFunction0, (double) 34.999996f, 0.0d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.append(arrayRealVector7);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor11 = null;
        try {
            double double12 = arrayRealVector6.walkInDefaultOrder(realVectorPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 10, (double) (byte) 10, (double) 'a');
        double[] doubleArray4 = levenbergMarquardtOptimizer3.getUpperBound();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker5 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.subtract(realMatrix5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round(1.0f, (int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 100, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double double5 = array2DRowRealMatrix0.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealVector realVector7 = array2DRowRealMatrix0.getRowVector(35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        int[] intArray12 = new int[] { (byte) 10 };
        int[] intArray15 = new int[] { 1, (short) 100 };
        int int16 = org.apache.commons.math3.util.MathArrays.distance1(intArray12, intArray15);
        double[] doubleArray22 = new double[] { 'a', 32, (short) 0, 35.0d, Double.NEGATIVE_INFINITY };
        double[] doubleArray28 = new double[] { 'a', 32, (short) 0, 35.0d, Double.NEGATIVE_INFINITY };
        double[] doubleArray34 = new double[] { 'a', 32, (short) 0, 35.0d, Double.NEGATIVE_INFINITY };
        double[] doubleArray40 = new double[] { 'a', 32, (short) 0, 35.0d, Double.NEGATIVE_INFINITY };
        double[] doubleArray46 = new double[] { 'a', 32, (short) 0, 35.0d, Double.NEGATIVE_INFINITY };
        double[] doubleArray52 = new double[] { 'a', 32, (short) 0, 35.0d, Double.NEGATIVE_INFINITY };
        double[][] doubleArray53 = new double[][] { doubleArray22, doubleArray28, doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        try {
            array2DRowRealMatrix0.copySubMatrix(intArray9, intArray15, doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(0.0d, (double) ' ', (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 10.0f, (double) (short) 1, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 6, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 10L, (float) 100L, (float) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, (int) (byte) 1, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (byte) 0, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber(", ", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        boolean boolean4 = array2DRowRealMatrix0.isSquare();
        int[] intArray7 = new int[] { (byte) -1, 10 };
        int[] intArray9 = new int[] { (byte) 10 };
        int[] intArray12 = new int[] { 1, (short) 100 };
        int int13 = org.apache.commons.math3.util.MathArrays.distance1(intArray9, intArray12);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, intArray7, intArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0, (double) 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("hi!", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        try {
            realVector5.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor5, 35, (int) (short) 10, 32, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) ' ', 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 52, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat3);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat4.parse("; ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double7 = diagonalMatrix1.walkInRowOrder(realMatrixPreservingVisitor2, 1, (int) (byte) 100, (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(0, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.addToEntry((int) (byte) 0, (int) (byte) 1, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean19 = arrayRealVector17.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) true);
        double double23 = arrayRealVector17.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        try {
            array2DRowRealMatrix0.setRowVector(3, (org.apache.commons.math3.linear.RealVector) arrayRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType0.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) '4', (double) 2147483647, (double) 3, (double) '#', (double) 0.0f, 35.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.11669149749E11d + "'", double6 == 1.11669149749E11d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, (int) '#', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double2 = org.apache.commons.math3.util.FastMath.min((-1.0d), (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) (short) 100, (int) (short) 1);
        int int3 = bracketFinder2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor14 = null;
        try {
            double double17 = arrayRealVector9.walkInOptimizedOrder(realVectorChangingVisitor14, (int) (short) 0, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean8 = arrayRealVector6.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double double12 = arrayRealVector6.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        try {
            array2DRowRealMatrix0.setColumnVector((int) (short) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) ' ', 0.0d, (double) 52L);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector5);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor9 = null;
        try {
            double double12 = arrayRealVector0.walkInOptimizedOrder(realVectorPreservingVisitor9, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray7 = new double[] { Double.POSITIVE_INFINITY, 3 };
        double[] doubleArray10 = new double[] { Double.POSITIVE_INFINITY, 3 };
        double[] doubleArray13 = new double[] { Double.POSITIVE_INFINITY, 3 };
        double[] doubleArray16 = new double[] { Double.POSITIVE_INFINITY, 3 };
        double[] doubleArray19 = new double[] { Double.POSITIVE_INFINITY, 3 };
        double[] doubleArray22 = new double[] { Double.POSITIVE_INFINITY, 3 };
        double[][] doubleArray23 = new double[][] { doubleArray7, doubleArray10, doubleArray13, doubleArray16, doubleArray19, doubleArray22 };
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray23, (int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 32 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray29 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray30 = new double[][] { doubleArray22, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix15.multiply(blockRealMatrix31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        double double17 = arrayRealVector7.dotProduct(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector0.ebeDivide(realVector16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(3, (int) (byte) 1);
        double[] doubleArray30 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair32 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray30, doubleArray31);
        double[] doubleArray33 = pointVectorValuePair32.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma34 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray33);
        double[] doubleArray35 = array2DRowRealMatrix20.operate(doubleArray33);
        try {
            arrayRealVector0.setSubVector((int) (short) 100, doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.optim.MaxIter maxIter4 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        java.lang.Object[] objArray17 = new java.lang.Object[] { maxIter4, 19.085536923187668d, (byte) 100, pointVectorValuePair15 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable3, objArray17);
        org.apache.commons.math3.exception.MathInternalError mathInternalError19 = new org.apache.commons.math3.exception.MathInternalError(localizable2, objArray17);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable0, localizable1, objArray17);
        org.junit.Assert.assertNotNull(maxIter4);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        long[][] longArray0 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix0.getSubMatrix(32, 6, (int) (short) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        try {
            org.apache.commons.math3.linear.RealVector realVector8 = array2DRowRealMatrix0.getColumnVector((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor7 = null;
        try {
            double double10 = arrayRealVector6.walkInOptimizedOrder(realVectorPreservingVisitor7, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) 'a');
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable16, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) doubleArray20);
        try {
            blockRealMatrix15.setSubMatrix(doubleArray20, (int) '#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.scalarAdd(19.085536923187668d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector9.append(arrayRealVector14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector2.subtract(realVector7);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector2.mapAddToSelf((double) (short) 10);
        try {
            org.apache.commons.math3.linear.RealVector realVector11 = diagonalMatrix1.preMultiply(realVector10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) 'a');
        try {
            blockRealMatrix15.setSubMatrix(doubleArray18, 6, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        boolean boolean4 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition5 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        try {
            array2DRowRealMatrix36.setEntry((int) (short) 1, (int) '#', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor7 = null;
        try {
            double double10 = arrayRealVector6.walkInOptimizedOrder(realVectorPreservingVisitor7, (int) (short) 1, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean18 = arrayRealVector16.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector21);
        try {
            org.apache.commons.math3.linear.RealVector realVector25 = array2DRowRealMatrix0.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        float float2 = org.apache.commons.math3.util.Precision.round((-1.0f), (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.0f) + "'", float2 == (-0.0f));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '4', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = lUDecomposition6.getP();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double17 = blockRealMatrix15.walkInOptimizedOrder(realMatrixPreservingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = null;
        try {
            blockRealMatrix15.setRowMatrix((int) (byte) 0, realMatrix19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.getColumnMatrix(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean19 = arrayRealVector17.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector17.subtract(realVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean26 = arrayRealVector24.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean29 = arrayRealVector27.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) (short) 10);
        double double34 = arrayRealVector24.dotProduct(realVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector17.ebeDivide(realVector33);
        try {
            blockRealMatrix15.setColumnVector((int) (byte) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector5);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor9 = null;
        try {
            double double10 = arrayRealVector5.walkInOptimizedOrder(realVectorChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 1, 0.0d, 2.2250738585072014E-308d, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) ' ', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix39 = array2DRowRealMatrix36.createMatrix((int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.createMatrix(3, (int) (byte) 1);
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double[] doubleArray18 = pointVectorValuePair17.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray18);
        double[] doubleArray20 = array2DRowRealMatrix5.operate(doubleArray18);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray18);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection22 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getMin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(2.2250738585072014E-308d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 9, false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(100, (int) (short) 0, (int) (byte) -1, 100);
        try {
            int int6 = matrixDimensionMismatchException4.getExpectedDimension((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight5 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 1.0f, (double) (byte) 0);
        int int3 = brentSolver2.getEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        double[] doubleArray24 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray24, doubleArray25);
        double[] doubleArray27 = pointVectorValuePair26.getSecond();
        double[] doubleArray28 = pointVectorValuePair26.getValue();
        double[] doubleArray29 = pointVectorValuePair26.getValue();
        try {
            double double30 = org.apache.commons.math3.util.MathArrays.distance(doubleArray17, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 100, (-1.0d), (double) (short) 100, (double) (byte) 10, (double) (byte) 1, (-10.0d));
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction7 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator8 = null;
        try {
            nelderMeadSimplex6.evaluate(multivariateFunction7, pointValuePairComparator8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 35, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double21 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor16, 6, (int) (byte) 1, 6, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) 'a');
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable16, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) doubleArray20);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray20, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 100 columns are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = array2DRowRealMatrix0.add(array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.3805346802806d + "'", double1 == 2979.3805346802806d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(0.17453292519943295d, (double) 1L, (double) (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        try {
            incrementor1.incrementCount(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (100) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) 0, (float) (byte) 1, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math3.util.FastMath.cos(2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4078492487004386d + "'", double1 == 0.4078492487004386d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector5);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor9 = null;
        try {
            double double10 = arrayRealVector8.walkInOptimizedOrder(realVectorChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 10L, 0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        int[] intArray6 = null;
        try {
            int int7 = org.apache.commons.math3.util.MathArrays.distance1(intArray4, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("; ", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (short) 0, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix18, (org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double double23 = array2DRowRealMatrix18.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix15.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x6 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, (double) (short) 100, (double) 10, (double) 1.1920929E-7f, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int[] intArray10 = new int[] { (byte) 10 };
        int[] intArray13 = new int[] { 1, (short) 100 };
        int int14 = org.apache.commons.math3.util.MathArrays.distance1(intArray10, intArray13);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math3.random.MersenneTwister(intArray13);
        byte[] byteArray20 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister15.nextBytes(byteArray20);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker25 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister15, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker25);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, 6.283185307179586d, (-1.0d), (double) (-1), (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertNotNull(byteArray20);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        int[] intArray12 = new int[] { (byte) 10 };
        int[] intArray15 = new int[] { 1, (short) 100 };
        int int16 = org.apache.commons.math3.util.MathArrays.distance1(intArray12, intArray15);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, intArray6, intArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.append(arrayRealVector7);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor11 = null;
        try {
            double double14 = arrayRealVector10.walkInOptimizedOrder(realVectorPreservingVisitor11, 3, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 32, 1.1920929E-7f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix0.getSubMatrix((int) (byte) 100, (int) (byte) 1, (int) ' ', 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse(", ");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \", \" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector5);
        try {
            arrayRealVector8.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector3.subtract(realVector8);
        double double10 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor11 = null;
        try {
            double double12 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        try {
            org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector(6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        try {
            arrayRealVector9.setEntry((int) (short) -1, 1.11669149749E11d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 100, 35);
        double double3 = bracketFinder2.getFHi();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter(", ", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        long long23 = mersenneTwister11.nextLong();
        try {
            long long25 = mersenneTwister11.nextLong((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1765991400464819176L) + "'", long23 == (-1765991400464819176L));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = eigenDecomposition3.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        try {
            double[] doubleArray17 = blockRealMatrix15.getRow((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] { (byte) 10 };
        int[] intArray10 = new int[] { 1, (short) 100 };
        int int11 = org.apache.commons.math3.util.MathArrays.distance1(intArray7, intArray10);
        int[] intArray13 = new int[] { (byte) 10 };
        int[] intArray16 = new int[] { 1, (short) 100 };
        int int17 = org.apache.commons.math3.util.MathArrays.distance1(intArray13, intArray16);
        int int18 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray7, intArray13);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math3.random.MersenneTwister(intArray13);
        try {
            int int20 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray4, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        int[] intArray8 = new int[] { (byte) 10 };
        int[] intArray11 = new int[] { 1, (short) 100 };
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] { (byte) 10 };
        int[] intArray17 = new int[] { 1, (short) 100 };
        int int18 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray17);
        int int19 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray8, intArray14);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math3.random.MersenneTwister(intArray14);
        int[] intArray22 = new int[] { (byte) 10 };
        int[] intArray25 = new int[] { 1, (short) 100 };
        int int26 = org.apache.commons.math3.util.MathArrays.distance1(intArray22, intArray25);
        int[] intArray28 = new int[] { (byte) 10 };
        int[] intArray31 = new int[] { 1, (short) 100 };
        int int32 = org.apache.commons.math3.util.MathArrays.distance1(intArray28, intArray31);
        int int33 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray22, intArray28);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix34 = array2DRowRealMatrix5.getSubMatrix(intArray14, intArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector3.mapMultiply((double) 1L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray41 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray42 = new double[][] { doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        try {
            array2DRowRealMatrix5.setSubMatrix(doubleArray42, 2147483647, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 2,147,483,647 rows are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) '#', 6.283185307179586d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10L, pointVectorValuePairConvergenceChecker1, 0.0d, 100.0d, (double) (byte) 100, (double) (short) -1);
        try {
            double double7 = levenbergMarquardtOptimizer6.getRMS();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix0.getColumnMatrix((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getKey();
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        try {
            double double12 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray9, doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray22, doubleArray23);
        double[] doubleArray25 = pointVectorValuePair24.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray25);
        try {
            double[] doubleArray27 = blockRealMatrix15.operate(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double double5 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double double6 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor7 = null;
        try {
            double double10 = arrayRealVector3.walkInDefaultOrder(realVectorChangingVisitor7, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 52, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("{}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"{}\" unparseable (from position 1) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) (short) 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(2.718281828459045d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.text.ParsePosition parsePosition3 = null;
        try {
            java.lang.Number number4 = org.apache.commons.math3.util.CompositeFormat.parseNumber("; ", numberFormat2, parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray11, (double) '#', true);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray9, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double[] doubleArray18 = pointVectorValuePair17.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray18);
        double[] doubleArray20 = sigma19.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray28 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray35 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray36 = new double[][] { doubleArray28, doubleArray35 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray20, orderDirection21, doubleArray36);
        double[] doubleArray45 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray45, doubleArray46);
        double[] doubleArray48 = pointVectorValuePair47.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma49 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray48);
        double[] doubleArray50 = sigma49.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray58 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray65 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray66 = new double[][] { doubleArray58, doubleArray65 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray50, orderDirection51, doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, orderDirection21, doubleArray66);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex74 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray66, 0.0d, 19.085536923187668d, 0.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker6 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        double double7 = simpleValueChecker6.getRelativeThreshold();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, 0.0d, 9993.0d, (double) 1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) ' ');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 34.999996f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        try {
            double double7 = brentSolver1.solve((int) (byte) -1, univariateFunction3, 0.0d, 2979.3805346802806d, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 32, (-1.5707963267948966d));
        double double3 = univariatePointValuePair2.getValue();
        double double4 = univariatePointValuePair2.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.5707963267948966d) + "'", double3 == (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray11 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray18 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray25 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray32 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray39 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray40 = new double[][] { doubleArray11, doubleArray18, doubleArray25, doubleArray32, doubleArray39 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = array2DRowRealMatrix41.getRowMatrix((int) (byte) 0);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix43);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("{}", 52);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double[] doubleArray18 = pointVectorValuePair17.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray18);
        double[] doubleArray20 = sigma19.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray28 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray35 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray36 = new double[][] { doubleArray28, doubleArray35 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray20, orderDirection21, doubleArray36);
        double[] doubleArray45 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray45, doubleArray46);
        double[] doubleArray48 = pointVectorValuePair47.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma49 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray48);
        double[] doubleArray50 = sigma49.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray58 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray65 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray66 = new double[][] { doubleArray58, doubleArray65 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray50, orderDirection51, doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, orderDirection21, doubleArray66);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex70 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix2 = null;
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = diagonalMatrix1.subtract(diagonalMatrix2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        float[] floatArray4 = new float[] { 100L, 0.0f, 97, (-1L) };
        float[] floatArray6 = new float[] { 1 };
        float[] floatArray13 = new float[] { 10L, 1, 1, (byte) 10, '4', (short) 1 };
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray6, floatArray13);
        float[] floatArray21 = new float[] { '#', (short) 10, '#', ' ', (short) 0, 'a' };
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray21);
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray4, floatArray21);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x97 but expected 97x97");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("; ", ", ", "{}", "; ", "", ", ");
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((-1), 35, 0, (int) '#');
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        double[] doubleArray3 = arrayRealVector0.toArray();
        java.io.ObjectOutputStream objectOutputStream4 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, objectOutputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = blockRealMatrix15.getRow(0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix15.getColumnMatrix((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 2979.3805346802806d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException(number0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        try {
            org.apache.commons.math3.linear.RealVector realVector19 = blockRealMatrix15.getRowVector(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) 10, (float) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 34.999996f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        try {
            double double6 = brentSolver1.solve((int) (short) 1, univariateFunction3, (double) 2147483647, 2979.3805346802806d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        try {
            double double18 = blockRealMatrix15.getEntry((int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        double[] doubleArray2 = diagonalMatrix1.getDataRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = diagonalMatrix1.add(diagonalMatrix4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x35 but expected 97x97");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray9);
        double[] doubleArray11 = sigma10.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray19 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray26 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray27 = new double[][] { doubleArray19, doubleArray26 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray11, orderDirection12, doubleArray27);
        try {
            double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray11, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) (byte) 0, 9993.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9993.0d + "'", double2 == 9993.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat3);
        java.text.ParsePosition parsePosition6 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = realVectorFormat4.parse("hi!hi!", parsePosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        long[] longArray5 = new long[] { (short) -1, 100L, 1L, (short) 100, ' ' };
        long[] longArray11 = new long[] { (short) -1, 100L, 1L, (short) 100, ' ' };
        long[] longArray17 = new long[] { (short) -1, 100L, 1L, (short) 100, ' ' };
        long[] longArray23 = new long[] { (short) -1, 100L, 1L, (short) 100, ' ' };
        long[] longArray29 = new long[] { (short) -1, 100L, 1L, (short) 100, ' ' };
        long[] longArray35 = new long[] { (short) -1, 100L, 1L, (short) 100, ' ' };
        long[][] longArray36 = new long[][] { longArray5, longArray11, longArray17, longArray23, longArray29, longArray35 };
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertNotNull(longArray36);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getMax();
        double double2 = brentSolver0.getStartValue();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = null;
        try {
            double double6 = brentSolver0.solve(10, univariateFunction4, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            org.apache.commons.math3.linear.RealVector realVector18 = blockRealMatrix15.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(1.11669149749E11d, (double) 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor5, 1, 0, (int) (byte) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray10 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException11 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray9, intArray10);
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        java.lang.Integer[] intArray19 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray20 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable12, intArray19, intArray20);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException22 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray20);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, number1, (java.lang.Object[]) intArray20);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.35349068386023774d + "'", double0 == 0.35349068386023774d);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) 10, (int) '4');
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int1 = brentSolver0.getEvaluations();
        double double2 = brentSolver0.getAbsoluteAccuracy();
        double double3 = brentSolver0.getMax();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double[] doubleArray6 = arrayRealVector3.toArray();
        int int7 = arrayRealVector3.getMaxIndex();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        double[] doubleArray2 = diagonalMatrix1.getDataRef();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean10 = arrayRealVector8.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, (org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        java.lang.String str12 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double double13 = arrayRealVector8.getNorm();
        try {
            org.apache.commons.math3.linear.RealVector realVector14 = diagonalMatrix1.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{}" + "'", str12.equals("{}"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, (double) 1, 1.11669149749E11d, (double) 35, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double[] doubleArray8 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray15 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray16 = new double[][] { doubleArray8, doubleArray15 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray19 = blockRealMatrix17.getRow(0);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        try {
            arrayRealVector0.setSubVector((int) (byte) 1, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(realVector4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 10, 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = arrayRealVector0.equals((java.lang.Object) orderDirection3);
        double[] doubleArray5 = arrayRealVector0.toArray();
        int int6 = org.apache.commons.math3.util.MathUtils.hash(doubleArray5);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        double[] doubleArray8 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray9);
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray8);
        java.lang.Class<?> wildcardClass12 = doubleArray1.getClass();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(2147483647, (-1), (int) 'a', (int) (byte) 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(2.718281828459045d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction1 = null;
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver2 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution6 = null;
        try {
            double double7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide((int) (byte) 0, univariateFunction1, univariateFunctionBracketedUnivariateSolver2, 0.0d, (double) 3, 4.584967478670572d, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep(0.0d);
        double double2 = bracketingStep1.getBracketingStep();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        java.text.ParsePosition parsePosition3 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = realMatrixFormat0.parse("hi!hi!", parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ", " + "'", str1.equals(", "));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.text.ParsePosition parsePosition3 = null;
        try {
            java.lang.Number number4 = org.apache.commons.math3.util.CompositeFormat.parseNumber("hi!", numberFormat2, parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 1, (double) 10.0f);
        int int3 = nelderMeadSimplex2.getDimension();
        double[] doubleArray4 = null;
        try {
            nelderMeadSimplex2.build(doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, (double) 1.0f, (double) 9, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getPointRef();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", ", ", "; ");
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean9 = arrayRealVector7.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) (short) 10);
        double double17 = arrayRealVector7.dotProduct(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector0.ebeDivide(realVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean21 = arrayRealVector19.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean24 = arrayRealVector22.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, (org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        try {
            org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector18.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!hi!", "hi!hi!", "hi!hi!");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence(0.0d, 2.2250738585072014E-308d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(4.9E-324d, 10.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double[] doubleArray17 = null;
        try {
            blockRealMatrix15.setRow((int) (byte) 0, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{}", "hi!hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double3 = org.apache.commons.math3.util.Precision.round(100.0d, (-1), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (-1), numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.optim.MaxIter maxIter3 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray12 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair14 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray13);
        double[] doubleArray15 = pointVectorValuePair14.getSecond();
        java.lang.Object[] objArray16 = new java.lang.Object[] { maxIter3, 19.085536923187668d, (byte) 100, pointVectorValuePair14 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, objArray16);
        org.apache.commons.math3.exception.MathInternalError mathInternalError18 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray16);
        org.apache.commons.math3.exception.MathInternalError mathInternalError19 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray16);
        org.junit.Assert.assertNotNull(maxIter3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-23) + "'", int1 == (-23));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula12 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula13 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] formulaArray14 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] { formula12, formula13 };
        double[] doubleArray21 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray21, doubleArray22);
        double[] doubleArray24 = pointVectorValuePair23.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray24);
        double[] doubleArray26 = sigma25.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection27 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray34 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray41 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray42 = new double[][] { doubleArray34, doubleArray41 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray42);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray26, orderDirection27, doubleArray42);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.isMonotonic(formulaArray14, orderDirection27, true);
        try {
            boolean boolean48 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray11, orderDirection27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + formula12 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula12.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula13 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula13.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(formulaArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = arrayRealVector0.equals((java.lang.Object) orderDirection3);
        double[] doubleArray5 = arrayRealVector0.toArray();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor6 = null;
        try {
            double double7 = arrayRealVector0.walkInOptimizedOrder(realVectorChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        try {
            double[] doubleArray6 = array2DRowRealMatrix0.getRow(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor7, 9, 97, (int) (byte) 0, (-23));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (9)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, arrayRealVector5);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor9 = null;
        try {
            double double10 = arrayRealVector8.walkInOptimizedOrder(realVectorPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix15, 9, (int) (byte) 100, 32, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (9)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        double[] doubleArray14 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray15);
        double[] doubleArray17 = pointVectorValuePair16.getSecond();
        boolean boolean19 = pointVectorValuePair16.equals((java.lang.Object) "hi!");
        double[] doubleArray20 = pointVectorValuePair16.getPointRef();
        try {
            double[] doubleArray21 = diagonalMatrix1.preMultiply(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(10.0d, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.10272986741866949d + "'", double2 == 0.10272986741866949d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure2 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure3 = sinc1.value(derivativeStructure2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("; ", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean7 = arrayRealVector3.equals((java.lang.Object) orderDirection6);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.createMatrix(10, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean19 = arrayRealVector17.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector17.subtract(realVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) true);
        double[] doubleArray29 = arrayRealVector26.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector23.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray37 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray38 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray38);
        double[] doubleArray40 = pointVectorValuePair39.getSecond();
        double[] doubleArray41 = pointVectorValuePair39.getValue();
        double[] doubleArray42 = pointVectorValuePair39.getValue();
        double[] doubleArray43 = pointVectorValuePair39.getSecond();
        double[] doubleArray44 = pointVectorValuePair39.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray44);
        try {
            org.apache.commons.math3.linear.RealVector realVector46 = blockRealMatrix15.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getSecond();
        double[] doubleArray10 = pointVectorValuePair8.getValue();
        double[] doubleArray11 = pointVectorValuePair8.getValue();
        double[] doubleArray12 = pointVectorValuePair8.getSecond();
        org.apache.commons.math3.util.Pair<double[], double[]> doubleArrayPair13 = new org.apache.commons.math3.util.Pair<double[], double[]>((org.apache.commons.math3.util.Pair<double[], double[]>) pointVectorValuePair8);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean4 = arrayRealVector2.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean7 = arrayRealVector5.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        java.lang.StringBuffer stringBuffer11 = null;
        java.text.FieldPosition fieldPosition12 = null;
        try {
            java.lang.StringBuffer stringBuffer13 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector10, stringBuffer11, fieldPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double double6 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector3.mapMultiplyToSelf((double) 1L);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        double[] doubleArray12 = diagonalMatrix11.getDataRef();
        try {
            arrayRealVector3.setSubVector(32, doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double double5 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double11 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor6, (int) (byte) 0, (int) (short) 0, 52, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(pointVectorValuePairConvergenceChecker0);
        double double2 = levenbergMarquardtOptimizer1.getChiSquare();
        double[] doubleArray4 = new double[] { (-1.5707963267948966d) };
        try {
            double[][] doubleArray6 = levenbergMarquardtOptimizer1.computeCovariances(doubleArray4, 1.7763568394002505E-15d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("");
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector9.subtract(realVector14);
        double double16 = arrayRealVector8.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        java.lang.String str17 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean20 = arrayRealVector18.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, (org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector18.append(19.085536923187668d);
        java.lang.StringBuffer stringBuffer27 = null;
        java.text.FieldPosition fieldPosition28 = null;
        try {
            java.lang.StringBuffer stringBuffer29 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector18, stringBuffer27, fieldPosition28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!hi!" + "'", str17.equals("hi!hi!"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '4', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray0, (double) 2147483647, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor18 = null;
        try {
            double double23 = blockRealMatrix15.walkInRowOrder(realMatrixChangingVisitor18, (-23), (int) (byte) -1, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-23)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix36.getRowMatrix((int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor39 = null;
        try {
            double double40 = array2DRowRealMatrix36.walkInColumnOrder(realMatrixChangingVisitor39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        org.apache.commons.math3.linear.RealVector realVector5 = eigenDecomposition3.getEigenvector((int) '#');
        try {
            org.apache.commons.math3.linear.RealVector realVector7 = eigenDecomposition3.getEigenvector((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        try {
            blockRealMatrix2.setEntry(35, 0, 4.641588833612779d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (short) 100);
        double[] doubleArray2 = simpleBounds1.getUpper();
        org.junit.Assert.assertNotNull(simpleBounds1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(pointVectorValuePairConvergenceChecker0);
        double double2 = levenbergMarquardtOptimizer1.getChiSquare();
        try {
            int int3 = levenbergMarquardtOptimizer1.getTargetSize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(2979.3805346802806d, (double) 10L, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        try {
            array2DRowRealMatrix0.setEntry((int) '#', (int) (byte) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector3.mapDivideToSelf((double) (short) 0);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor9 = null;
        try {
            double double12 = arrayRealVector3.walkInOptimizedOrder(realVectorPreservingVisitor9, (int) (short) 100, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.scalarMultiply((double) 34.999996f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((-127), (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getFirst();
        java.lang.Double double6 = pointValuePair4.getSecond();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6.equals(35.0d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 100, 35);
        double double3 = bracketFinder2.getFMid();
        double double4 = bracketFinder2.getMid();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getMax();
        org.apache.commons.math3.analysis.function.Sinc sinc4 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double double7 = brentSolver0.solve((int) (short) 0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc4, 0.5071158626935848d, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix17.scalarMultiply(0.10272986741866949d);
        int[] intArray21 = new int[] { (byte) 10 };
        int[] intArray24 = new int[] { 1, (short) 100 };
        int int25 = org.apache.commons.math3.util.MathArrays.distance1(intArray21, intArray24);
        int[] intArray27 = new int[] { (byte) 10 };
        int[] intArray30 = new int[] { 1, (short) 100 };
        int int31 = org.apache.commons.math3.util.MathArrays.distance1(intArray27, intArray30);
        int int32 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray21, intArray27);
        int[] intArray38 = new int[] { ' ', 35, (byte) 1, (-1), (byte) 100 };
        double[][] doubleArray41 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 32);
        try {
            blockRealMatrix17.copySubMatrix(intArray27, intArray38, doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 9 + "'", int31 == 9);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
        incrementor1.incrementCount(35);
        boolean boolean4 = incrementor1.canIncrement();
        int int5 = incrementor1.getMaximalCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector0.append(19.085536923187668d);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor9 = null;
        try {
            double double10 = arrayRealVector0.walkInDefaultOrder(realVectorChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 32);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray2, 1.0000000000000002d, (double) 9, 1.7763568394002505E-15d, (double) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: simplex must contain at least one point");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.transpose();
        try {
            blockRealMatrix3.setRowMatrix(1, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x6 but expected 1x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) '#', (double) 1.0f);
        int int3 = powellOptimizer2.getEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(2979.3805346802806d, (double) (-1.0f));
        double double3 = brentSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double17 = blockRealMatrix15.walkInOptimizedOrder(realMatrixChangingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) '#', (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math3.util.FastMath.exp(9993.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        double[] doubleArray3 = arrayRealVector0.toArray();
        int int4 = arrayRealVector0.getMaxIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        try {
            org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector0.getSubVector((int) (byte) 10, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) (byte) 1, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 26.5d + "'", double2 == 26.5d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 2979.3805346802806d, (double) 100.0f, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [2,979.381, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        double[] doubleArray2 = diagonalMatrix1.getDataRef();
        double[] doubleArray9 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray16 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray17 = new double[][] { doubleArray9, doubleArray16 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray17);
        double[] doubleArray20 = blockRealMatrix18.getRow(0);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        try {
            double[] doubleArray22 = diagonalMatrix1.operate(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix1.copy();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        double[] doubleArray11 = diagonalMatrix10.getDataRef();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix1.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 'a', 6);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, number1, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = nonMonotonicSequenceException5.getDirection();
        boolean boolean8 = nonMonotonicSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonicSequenceException5.getPrevious();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double[] doubleArray10 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair12 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray11);
        double[] doubleArray13 = pointVectorValuePair12.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) (-23), (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = arrayRealVector0.equals((java.lang.Object) orderDirection3);
        double[] doubleArray5 = arrayRealVector0.toArray();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector0.mapDivide((double) 'a');
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor8 = null;
        try {
            double double9 = arrayRealVector0.walkInDefaultOrder(realVectorChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("hi!", (-127));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int[] intArray6 = new int[] { (byte) 10 };
        int[] intArray9 = new int[] { 1, (short) 100 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray9);
        byte[] byteArray16 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray16);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker21 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 100, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(0, (double) (short) 100, false, (int) ' ', (int) (byte) -1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker21);
        double[] doubleArray23 = cMAESOptimizer22.getStartPoint();
        int int24 = cMAESOptimizer22.getMaxEvaluations();
        int int25 = cMAESOptimizer22.getIterations();
        java.util.List<java.lang.Double> doubleList26 = cMAESOptimizer22.getStatisticsSigmaHistory();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(doubleList26);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray10 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray17 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray18 = new double[][] { doubleArray10, doubleArray17 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = blockRealMatrix19.getRowVector((int) (byte) 0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix2.subtract(blockRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x97 but expected 2x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        org.apache.commons.math3.linear.RealVector realVector5 = eigenDecomposition3.getEigenvector((int) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) orderDirection9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean17 = arrayRealVector15.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean20 = arrayRealVector18.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector18.mapDivideToSelf((double) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector12.combineToSelf((double) 1.1920929E-7f, Double.POSITIVE_INFINITY, realVector23);
        try {
            org.apache.commons.math3.linear.RealVector realVector25 = realVector5.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) true);
        double[] doubleArray12 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector6.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = arrayRealVector6.toArray();
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray17, (double) '#', true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix21.createMatrix(3, (int) (byte) 1);
        double[] doubleArray31 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray31, doubleArray32);
        double[] doubleArray34 = pointVectorValuePair33.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix21.operate(doubleArray34);
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray34);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray14, doubleArray34);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        diagonalMatrix1.multiplyEntry(35, 1, (double) 4.5035996E15f);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix1.copy();
        double double11 = diagonalMatrix1.getEntry(9, 0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = diagonalMatrix1.subtract(diagonalMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x97 but expected 35x35");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray4);
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister6.nextBytes(byteArray11);
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray17);
        double double19 = mersenneTwister6.nextGaussian();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.5071158626935848d + "'", double19 == 0.5071158626935848d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double3 = sinc1.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction4 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc1);
        boolean boolean7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 1.11669149749E11d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8414709848078965d + "'", double3 == 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded(1);
        double[] doubleArray2 = simpleBounds1.getUpper();
        double[] doubleArray3 = simpleBounds1.getUpper();
        org.junit.Assert.assertNotNull(simpleBounds1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker6 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 100, Double.NEGATIVE_INFINITY);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, (double) (byte) 1, (double) (-127), (double) 3, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.optim.MaxIter maxIter5 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray14 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray15);
        double[] doubleArray17 = pointVectorValuePair16.getSecond();
        java.lang.Object[] objArray18 = new java.lang.Object[] { maxIter5, 19.085536923187668d, (byte) 100, pointVectorValuePair16 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable4, objArray18);
        org.apache.commons.math3.exception.MathInternalError mathInternalError20 = new org.apache.commons.math3.exception.MathInternalError(localizable3, objArray18);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException21 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable2, objArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray18);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException23 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray18);
        org.junit.Assert.assertNotNull(maxIter5);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.ZeroException zeroException2 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = zeroException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) -1, (int) 'a', (-10.0d));
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = nonSymmetricMatrixException3.getContext();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor5, (-127), 100, 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        double[][] doubleArray4 = diagonalMatrix1.getData();
        double[] doubleArray11 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair13 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray11, doubleArray12);
        double[] doubleArray14 = pointVectorValuePair13.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray14);
        try {
            double[] doubleArray16 = diagonalMatrix1.operate(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(4.9E-324d, (double) 1, (double) 4.5035996E15f, Double.NEGATIVE_INFINITY, (double) (-1765991400464819176L));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int[] intArray1 = new int[] { (byte) 10 };
        int[] intArray4 = new int[] { 1, (short) 100 };
        int int5 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray4);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray4);
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) 1, (byte) 0, (byte) 100 };
        mersenneTwister6.nextBytes(byteArray11);
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) -1 };
        mersenneTwister6.nextBytes(byteArray17);
        double double19 = mersenneTwister6.nextDouble();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.18399191394796865d + "'", double19 == 0.18399191394796865d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double[] doubleArray18 = pointVectorValuePair17.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray18);
        double[] doubleArray20 = sigma19.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray28 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray35 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray36 = new double[][] { doubleArray28, doubleArray35 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray20, orderDirection21, doubleArray36);
        double[] doubleArray45 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray45, doubleArray46);
        double[] doubleArray48 = pointVectorValuePair47.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma49 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray48);
        double[] doubleArray50 = sigma49.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray58 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray65 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray66 = new double[][] { doubleArray58, doubleArray65 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray50, orderDirection51, doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, orderDirection21, doubleArray66);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix70 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getColumnSeparator();
        java.text.ParsePosition parsePosition4 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = realMatrixFormat0.parse("; ", parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "; " + "'", str1.equals("; "));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ", " + "'", str2.equals(", "));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double double5 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        double double7 = lUDecomposition6.getDeterminant();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = lUDecomposition6.getP();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.8414709848078965d, (double) (short) 0, (double) 6, 0.18399191394796865d, (double) (byte) 1, 0.0d, (double) 97, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 98.10395148368781d + "'", double8 == 98.10395148368781d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (-1765991400464819176L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        double[] doubleArray13 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray14);
        double[] doubleArray16 = pointVectorValuePair15.getSecond();
        double[] doubleArray17 = pointVectorValuePair15.getValue();
        double[] doubleArray18 = pointVectorValuePair15.getValueRef();
        double[] doubleArray19 = array2DRowRealMatrix5.preMultiply(doubleArray18);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) 'a');
        try {
            array2DRowRealMatrix5.setSubMatrix(doubleArray22, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException; message: first 52 columns are not initialized yet");
        } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        double double6 = arrayRealVector0.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(6, (int) 'a');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = blockRealMatrix3.walkInOptimizedOrder(realMatrixPreservingVisitor4, (int) (byte) 10, 10, (int) (byte) 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector0.append(19.085536923187668d);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor9 = null;
        try {
            double double12 = arrayRealVector0.walkInDefaultOrder(realVectorPreservingVisitor9, (-23), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-23)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) (short) 100, (int) (short) 1);
        double double3 = bracketFinder2.getHi();
        int int4 = bracketFinder2.getEvaluations();
        int int5 = bracketFinder2.getEvaluations();
        double double6 = bracketFinder2.getLo();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) -1, (int) 'a', (-10.0d));
        int int4 = nonSymmetricMatrixException3.getColumn();
        double double5 = nonSymmetricMatrixException3.getThreshold();
        double double6 = nonSymmetricMatrixException3.getThreshold();
        double double7 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-10.0d) + "'", double5 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-10.0d) + "'", double6 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-10.0d) + "'", double7 == (-10.0d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) '4', 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair4 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) '#', true);
        double[] doubleArray5 = pointValuePair4.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        double[] doubleArray14 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray15);
        double[] doubleArray17 = pointVectorValuePair16.getSecond();
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray17, 1.0E-15d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 1.0f, 0.0d, 2147483647);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 32, 10, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method -1, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) 'a');
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix1, 3.0d);
        org.apache.commons.math3.linear.RealVector realVector5 = eigenDecomposition3.getEigenvector((int) '#');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean10 = arrayRealVector6.equals((java.lang.Object) orderDirection9);
        double[] doubleArray11 = arrayRealVector6.toArray();
        try {
            double double12 = realVector5.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.append(arrayRealVector7);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor11 = null;
        try {
            double double12 = arrayRealVector10.walkInDefaultOrder(realVectorChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.8813735870195429d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8813735870195429d + "'", double2 == 0.8813735870195429d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(0.5071158626935848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41019779969736225d + "'", double1 == 0.41019779969736225d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 1, (double) 10.0f);
        int int3 = nelderMeadSimplex2.getDimension();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator5 = null;
        try {
            nelderMeadSimplex2.iterate(multivariateFunction4, pointValuePairComparator5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (-127));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 127.0f + "'", float1 == 127.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 3);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) (-10.0d));
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException5 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) -1, (int) 'a', (-10.0d));
        int int6 = nonSymmetricMatrixException5.getColumn();
        double double7 = nonSymmetricMatrixException5.getThreshold();
        tooManyIterationsException1.addSuppressed((java.lang.Throwable) nonSymmetricMatrixException5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-10.0d) + "'", double7 == (-10.0d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 4.5035996E15f, 1.0d);
        double double3 = univariatePointValuePair2.getValue();
        double double4 = univariatePointValuePair2.getValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 0, (-1), (-127), 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.227615833318806d + "'", double1 == 2.227615833318806d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) -1, (float) '4', 100.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.optim.MaxIter maxIter8 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray17 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray18);
        double[] doubleArray20 = pointVectorValuePair19.getSecond();
        java.lang.Object[] objArray21 = new java.lang.Object[] { maxIter8, 19.085536923187668d, (byte) 100, pointVectorValuePair19 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable7, objArray21);
        org.apache.commons.math3.exception.MathInternalError mathInternalError23 = new org.apache.commons.math3.exception.MathInternalError(localizable6, objArray21);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException24 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable5, objArray21);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.0d, (double) (byte) 100, (double) 'a', (double) 9, objArray21);
        double double26 = noBracketingException25.getLo();
        double double27 = noBracketingException25.getLo();
        double double28 = noBracketingException25.getFLo();
        org.junit.Assert.assertNotNull(maxIter8);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 97.0d + "'", double28 == 97.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(1, 0.18399191394796865d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(3, (int) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean8 = arrayRealVector4.equals((java.lang.Object) orderDirection7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, true);
        org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double13 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray13 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable5, intArray12, intArray13);
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray23 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException24 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable15, intArray22, intArray23);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException25 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray12, intArray23);
        org.apache.commons.math3.exception.util.Localizable localizable26 = null;
        org.apache.commons.math3.exception.util.Localizable localizable27 = null;
        org.apache.commons.math3.exception.util.Localizable localizable28 = null;
        org.apache.commons.math3.exception.util.Localizable localizable29 = null;
        org.apache.commons.math3.optim.MaxIter maxIter30 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray39 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair41 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray39, doubleArray40);
        double[] doubleArray42 = pointVectorValuePair41.getSecond();
        java.lang.Object[] objArray43 = new java.lang.Object[] { maxIter30, 19.085536923187668d, (byte) 100, pointVectorValuePair41 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable29, objArray43);
        org.apache.commons.math3.exception.MathInternalError mathInternalError45 = new org.apache.commons.math3.exception.MathInternalError(localizable28, objArray43);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException46 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable27, objArray43);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray12, localizable26, objArray43);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException48 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 1.1920929E-7f, 0.0d, 0.8414709848078965d, 2.2250738585072014E-308d, objArray43);
        double double49 = noBracketingException48.getFLo();
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(maxIter30);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.8414709848078965d + "'", double49 == 0.8414709848078965d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(35);
        double[] doubleArray2 = diagonalMatrix1.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(3, (int) '#');
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix1.multiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 6.283185307179586d, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray0, 2.227615833318806d, 0.10272986741866949d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (-23));
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector3.append(0.0922753880002305d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(0.41019779969736225d, 0.5071158626935848d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector1.subtract(realVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean12 = arrayRealVector10.equals((java.lang.Object) true);
        double[] doubleArray13 = arrayRealVector10.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector7.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        double double15 = arrayRealVector10.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector10.mapDivide(Double.NEGATIVE_INFINITY);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0, arrayRealVector10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat("hi!hi!", ", ", ", ", numberFormat7);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat("", ",", ",", numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray9);
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { 0, 3, 100, 10, 1, 3 };
        java.lang.Integer[] intArray19 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable11, intArray18, intArray19);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray8, intArray19);
        org.apache.commons.math3.exception.util.Localizable localizable22 = null;
        org.apache.commons.math3.exception.util.Localizable localizable23 = null;
        org.apache.commons.math3.exception.util.Localizable localizable24 = null;
        org.apache.commons.math3.exception.util.Localizable localizable25 = null;
        org.apache.commons.math3.optim.MaxIter maxIter26 = org.apache.commons.math3.optim.MaxIter.unlimited();
        double[] doubleArray35 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray36);
        double[] doubleArray38 = pointVectorValuePair37.getSecond();
        java.lang.Object[] objArray39 = new java.lang.Object[] { maxIter26, 19.085536923187668d, (byte) 100, pointVectorValuePair37 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable25, objArray39);
        org.apache.commons.math3.exception.MathInternalError mathInternalError41 = new org.apache.commons.math3.exception.MathInternalError(localizable24, objArray39);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException42 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable23, objArray39);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray8, localizable22, objArray39);
        org.apache.commons.math3.exception.ZeroException zeroException44 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray39);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError45 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) zeroException44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(maxIter26);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((-127), (int) (byte) -1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector0.subtract(realVector5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector0.mapAddToSelf((double) (short) 10);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor9 = null;
        try {
            double double12 = arrayRealVector0.walkInDefaultOrder(realVectorChangingVisitor9, 100, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        int int16 = blockRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean20 = arrayRealVector18.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector18.subtract(realVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean29 = arrayRealVector27.equals((java.lang.Object) true);
        double[] doubleArray30 = arrayRealVector27.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector24.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        double[] doubleArray38 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray39 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair40 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray39);
        double[] doubleArray41 = pointVectorValuePair40.getSecond();
        double[] doubleArray42 = pointVectorValuePair40.getValue();
        double[] doubleArray43 = pointVectorValuePair40.getValue();
        double[] doubleArray44 = pointVectorValuePair40.getSecond();
        double[] doubleArray45 = pointVectorValuePair40.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray45);
        try {
            blockRealMatrix15.setRow((-127), doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(pointVectorValuePairConvergenceChecker0);
        double double2 = levenbergMarquardtOptimizer1.getChiSquare();
        try {
            double double3 = levenbergMarquardtOptimizer1.getRMS();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector3.subtract(realVector8);
        double double10 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        boolean boolean11 = arrayRealVector9.isNaN();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double[] doubleArray6 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray13 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getRowVector((int) (byte) 0);
        double double18 = blockRealMatrix15.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealVector realVector20 = blockRealMatrix15.getRowVector(35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 14133.824606241582d + "'", double18 == 14133.824606241582d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 1.1920929E-7f, (double) 1L, 1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1920928777442441E-7d + "'", double3 == 1.1920928777442441E-7d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean2 = arrayRealVector0.equals((java.lang.Object) true);
        double[] doubleArray3 = arrayRealVector0.toArray();
        int int4 = arrayRealVector0.getMaxIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor6 = null;
        try {
            double double9 = arrayRealVector0.walkInDefaultOrder(realVectorPreservingVisitor6, (int) (short) -1, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.203819919143124d + "'", double1 == 2.203819919143124d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(14133.824606241582d, 1.1920928777442441E-7d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean3 = arrayRealVector1.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) (short) 0);
        double double7 = lUDecomposition6.getDeterminant();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = lUDecomposition6.getL();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(Double.POSITIVE_INFINITY, (double) (byte) 1);
        org.apache.commons.math3.analysis.function.Sinc sinc5 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double7 = sinc5.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction8 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc5);
        try {
            double double12 = brentSolver2.solve((int) (short) 0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc5, 32.0d, 2.2250738585072014E-308d, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [32, 1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8414709848078965d + "'", double7 == 0.8414709848078965d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) (short) 100, (int) (short) 1);
        double double3 = bracketFinder2.getFMid();
        int int4 = bracketFinder2.getEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0922753880002305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) -1, (double) 34.999996f, (double) (-0.0f), (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 2147483647, 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1474836470000021E9d + "'", double2 == 2.1474836470000021E9d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) -1, (int) 'a', (-10.0d));
        int int4 = nonSymmetricMatrixException3.getColumn();
        double double5 = nonSymmetricMatrixException3.getThreshold();
        java.lang.Throwable throwable6 = null;
        try {
            nonSymmetricMatrixException3.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-10.0d) + "'", double5 == (-10.0d));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction0);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction2 = modelFunction1.getModelFunction();
        org.junit.Assert.assertNull(multivariateVectorFunction2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) (short) 100, (int) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean5 = arrayRealVector3.equals((java.lang.Object) true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector3.subtract(realVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        boolean boolean14 = arrayRealVector12.equals((java.lang.Object) true);
        double[] doubleArray15 = arrayRealVector12.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector9.combine((double) 100L, (double) 32, (org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.analysis.function.Sinc sinc18 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double20 = sinc18.value((double) (byte) -1);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction21 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector16.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc18);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType23 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        try {
            bracketFinder2.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc18, goalType23, (double) (-1), (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (1) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.8414709848078965d + "'", double20 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertTrue("'" + goalType23 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType23.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math3.util.FastMath.atan(1.0E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.999999999996666E-7d + "'", double1 == 9.999999999996666E-7d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat1);
        java.lang.String str3 = realMatrixFormat2.getRowSeparator();
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = realMatrixFormat2.parse(",", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "," + "'", str3.equals(","));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (short) 100);
        double[] doubleArray2 = simpleBounds1.getLower();
        org.junit.Assert.assertNotNull(simpleBounds1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(100);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 0.032585025f, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        int[] intArray2 = new int[] { (short) 10, 32 };
        int[] intArray4 = new int[] { (byte) 10 };
        int[] intArray7 = new int[] { 1, (short) 100 };
        int int8 = org.apache.commons.math3.util.MathArrays.distance1(intArray4, intArray7);
        int[] intArray10 = new int[] { (byte) 10 };
        int[] intArray13 = new int[] { 1, (short) 100 };
        int int14 = org.apache.commons.math3.util.MathArrays.distance1(intArray10, intArray13);
        int int15 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray4, intArray10);
        try {
            int int16 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray2, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double[] doubleArray6 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray15 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray16);
        double[] doubleArray18 = pointVectorValuePair17.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray18);
        double[] doubleArray20 = sigma19.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray28 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray35 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray36 = new double[][] { doubleArray28, doubleArray35 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray20, orderDirection21, doubleArray36);
        double[] doubleArray45 = new double[] { (-1), 1L, 0, 1.0d, (-1), (byte) 0 };
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray45, doubleArray46);
        double[] doubleArray48 = pointVectorValuePair47.getSecond();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma49 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray48);
        double[] doubleArray50 = sigma49.getSigma();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection51 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray58 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[] doubleArray65 = new double[] { 100, '#', 9993.0d, '#', 0.0f, 100.0d };
        double[][] doubleArray66 = new double[][] { doubleArray58, doubleArray65 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray50, orderDirection51, doubleArray66);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, orderDirection21, doubleArray66);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition72 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) -1, (double) (-1L), 32.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 0L, 10.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 34.999996f, Double.NEGATIVE_INFINITY, 0.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 2147483647);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double[] doubleArray6 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray13 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray20 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray27 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[] doubleArray34 = new double[] { 34.999996f, 32, 10.0f, 34.999996f, (-1L), 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor37 = null;
        try {
            double double42 = array2DRowRealMatrix36.walkInColumnOrder(realMatrixPreservingVisitor37, (int) ' ', (int) 'a', 0, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }
}

