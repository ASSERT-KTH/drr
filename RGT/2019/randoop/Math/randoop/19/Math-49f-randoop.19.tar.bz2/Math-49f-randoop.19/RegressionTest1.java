import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 10L, (-1) };
        double[] doubleArray6 = new double[] { 10L, (-1) };
        double[] doubleArray9 = new double[] { 10L, (-1) };
        double[] doubleArray12 = new double[] { 10L, (-1) };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.scalarAdd((double) 0);
        try {
            double double22 = array2DRowRealMatrix17.getEntry(32, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(4.641588833612779d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double[][] doubleArray15 = array2DRowRealMatrix5.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        try {
            org.apache.commons.math.linear.RealVector realVector18 = array2DRowRealMatrix16.getRowVector(35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 10L, (-1) };
        double[] doubleArray6 = new double[] { 10L, (-1) };
        double[] doubleArray9 = new double[] { 10L, (-1) };
        double[] doubleArray12 = new double[] { 10L, (-1) };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, true);
        double[][] doubleArray18 = array2DRowRealMatrix17.getDataRef();
        double double19 = array2DRowRealMatrix17.getNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix17.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (4x2) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 40.0d + "'", double19 == 40.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix((int) (short) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = array2DRowRealMatrix19.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix22.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        int int32 = array2DRowRealMatrix22.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix39 = array2DRowRealMatrix35.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix38);
        double[][] doubleArray40 = array2DRowRealMatrix35.getData();
        array2DRowRealMatrix22.setSubMatrix(doubleArray40, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix22.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = array2DRowRealMatrix47.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix50);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix54.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix50.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        double double62 = array2DRowRealMatrix57.getEntry((int) (byte) 1, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix63 = array2DRowRealMatrix22.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = array2DRowRealMatrix5.multiply(array2DRowRealMatrix57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix63);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (short) 1, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 1 + "'", number4.equals((short) 1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector2.mapMultiply(0.0d);
        double[] doubleArray25 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        try {
            double double27 = openMapRealVector2.dotProduct(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        double double14 = openMapRealVector12.getLInfNorm();
        double double15 = openMapRealVector12.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        int int20 = openMapRealVector2.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector2.mapAdd(4.64158883361278d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(openMapRealVector22);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector2.append(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray28 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector24.add(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector19.combineToSelf(0.0d, 0.7615941559557649d, doubleArray28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector35.combineToSelf(0.0d, (double) (-127), (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray51 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector47.add(doubleArray51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector47.subtract(openMapRealVector57);
        org.apache.commons.math.linear.RealVector realVector59 = openMapRealVector42.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray71 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector67.add(doubleArray71);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector67.subtract(openMapRealVector77);
        org.apache.commons.math.linear.RealVector realVector79 = openMapRealVector62.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector78);
        org.apache.commons.math.linear.RealVector realVector80 = openMapRealVector42.projection((org.apache.commons.math.linear.RealVector) openMapRealVector62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector82 = openMapRealVector42.append(openMapRealVector81);
        org.apache.commons.math.linear.RealVector realVector83 = openMapRealVector38.projection((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = openMapRealVector38.mapAdd(1.9459101490553132d);
        try {
            org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector19.combine(2.220446049250313E-16d, 4.605170185988092d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(openMapRealVector58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(openMapRealVector82);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertNotNull(openMapRealVector85);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix10.subtract(openMapRealMatrix13);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix7.add(openMapRealMatrix13);
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealMatrix15.getRowVector((int) (short) 1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector20.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray44 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector40.add(doubleArray44);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector40.subtract(openMapRealVector50);
        double[] doubleArray52 = openMapRealVector40.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector20.ebeDivide(doubleArray52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray52, (-0.41032129904824216d));
        try {
            double[] doubleArray56 = openMapRealMatrix15.preMultiply(doubleArray52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(openMapRealVector53);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray26 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector22.add(doubleArray26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector22.subtract(openMapRealVector32);
        double[] doubleArray34 = openMapRealVector22.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector2.ebeDivide(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector43.add(doubleArray47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector43.subtract(openMapRealVector53);
        org.apache.commons.math.linear.RealVector realVector55 = openMapRealVector38.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector54);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix56 = openMapRealVector35.outerProduct((org.apache.commons.math.linear.RealVector) openMapRealVector38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(realVector55);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        try {
            openMapRealMatrix5.setEntry((int) (short) -1, 0, 4.605170185988092d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector18.add(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector18.subtract(openMapRealVector28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector28.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector12.add(openMapRealVector28);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector28.mapSubtract((double) 32);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(realVector34);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        int int50 = array2DRowRealMatrix46.getRowDimension();
        double[][] doubleArray51 = array2DRowRealMatrix46.getData();
        int int52 = array2DRowRealMatrix46.getRowDimension();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector33.add(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector33.subtract(openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray51 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector47.add(doubleArray51);
        double double55 = openMapRealVector33.dotProduct(openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector33);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray70 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.RealVector realVector73 = openMapRealVector66.add(doubleArray70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = openMapRealVector66.subtract(openMapRealVector76);
        org.apache.commons.math.linear.RealVector realVector78 = openMapRealVector61.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray85 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math.linear.RealVector realVector88 = openMapRealVector81.add(doubleArray85);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector91 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector92 = openMapRealVector81.subtract(openMapRealVector91);
        double[] doubleArray93 = openMapRealVector81.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector94 = openMapRealVector61.ebeDivide(doubleArray93);
        org.apache.commons.math.linear.RealVector realVector95 = openMapRealVector33.combineToSelf((double) 100.0f, (double) (-1), doubleArray93);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector96 = openMapRealVector30.subtract(openMapRealVector33);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction97 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector98 = openMapRealVector30.map(univariateRealFunction97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertNotNull(openMapRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(realVector88);
        org.junit.Assert.assertNotNull(openMapRealVector92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(openMapRealVector94);
        org.junit.Assert.assertNotNull(realVector95);
        org.junit.Assert.assertNotNull(openMapRealVector96);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        java.lang.Object obj15 = null;
        boolean boolean16 = array2DRowRealMatrix5.equals(obj15);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector20.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector36);
        try {
            array2DRowRealMatrix5.setColumnVector(127, realVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector20.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray49 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector45.add(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector45.subtract(openMapRealVector55);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector40.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector20.projection((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        double double59 = openMapRealVector5.getDistance(openMapRealVector40);
        double[] doubleArray64 = new double[] { 1.9459101490553132d, (short) 10 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray64, (double) (-1.0f));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector66);
        try {
            org.apache.commons.math.linear.RealVector realVector68 = openMapRealVector5.combineToSelf(0.41078129050290885d, 2.993222846126381d, (org.apache.commons.math.linear.RealVector) openMapRealVector67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, 100.00001f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        boolean boolean6 = array2DRowRealMatrix4.equals((java.lang.Object) (-0.9974947163822921d));
        double[][] doubleArray7 = array2DRowRealMatrix4.getData();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) '4', (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -127 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[][] doubleArray23 = array2DRowRealMatrix18.getData();
        array2DRowRealMatrix5.setSubMatrix(doubleArray23, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix5.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = array2DRowRealMatrix30.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix37.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        org.apache.commons.math.linear.RealMatrix realMatrix42 = array2DRowRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        double double45 = array2DRowRealMatrix40.getEntry((int) (byte) 1, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector50.add(doubleArray54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector50.subtract(openMapRealVector60);
        double[] doubleArray65 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray65);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector50.append(doubleArray65);
        try {
            array2DRowRealMatrix40.setRowVector(35, (org.apache.commons.math.linear.RealVector) openMapRealVector67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(openMapRealVector67);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[][] doubleArray23 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector2.append(openMapRealVector41);
        double[] doubleArray43 = openMapRealVector2.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        boolean boolean6 = array2DRowRealMatrix4.equals((java.lang.Object) (-0.9974947163822921d));
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix4.walkInRowOrder(realMatrixPreservingVisitor7, 97, (int) (short) 100, (-127), 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor23 = null;
        try {
            double double28 = array2DRowRealMatrix22.walkInColumnOrder(realMatrixChangingVisitor23, 35, 0, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = array2DRowRealMatrix10.walkInColumnOrder(realMatrixChangingVisitor11, 10, 1, (int) (short) 1, 127);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double[][] doubleArray15 = array2DRowRealMatrix5.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix18 = array2DRowRealMatrix16.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 35L, 0.1754034190044697d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5657848424924816d + "'", double2 == 1.5657848424924816d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix2.scalarAdd(0.7615941559557649d);
        double[] doubleArray11 = array2DRowRealMatrix2.getRow(0);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap37 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap38 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap37);
        boolean boolean39 = openMapRealVector25.equals((java.lang.Object) openIntToDoubleHashMap38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray46 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector42.add(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector42.subtract(openMapRealVector52);
        double[] doubleArray54 = openMapRealVector42.getData();
        double double55 = openMapRealVector25.getDistance(openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray62 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector58.add(doubleArray62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = openMapRealVector58.subtract(openMapRealVector68);
        org.apache.commons.math.linear.RealVector realVector71 = openMapRealVector68.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray83 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray83);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray83);
        org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector79.add(doubleArray83);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector89 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector90 = openMapRealVector79.subtract(openMapRealVector89);
        org.apache.commons.math.linear.RealVector realVector91 = openMapRealVector74.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector90);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector92 = openMapRealVector68.add(openMapRealVector90);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector93 = openMapRealVector25.subtract(openMapRealVector68);
        boolean boolean94 = openMapRealVector25.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(openMapRealVector69);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(openMapRealVector90);
        org.junit.Assert.assertNotNull(realVector91);
        org.junit.Assert.assertNotNull(openMapRealVector92);
        org.junit.Assert.assertNotNull(openMapRealVector93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1624473515096265d + "'", double1 == 1.1624473515096265d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector2);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector2.mapAdd((double) (short) 0);
        boolean boolean28 = openMapRealVector2.isInfinite();
        double[] doubleArray29 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.subtract(doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap3 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap2);
        boolean boolean5 = openIntToDoubleHashMap3.containsKey((int) (byte) 1);
        double double7 = openIntToDoubleHashMap3.remove(0);
        boolean boolean9 = openIntToDoubleHashMap3.containsKey((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, 0);
        int int3 = dimensionMismatchException2.getDimension();
        int int4 = dimensionMismatchException2.getDimension();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = dimensionMismatchException2.getContext();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector(10, 100, (double) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray15 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector11.add(doubleArray15);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector11.subtract(openMapRealVector21);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector6.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray35 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.RealVector realVector38 = openMapRealVector31.add(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector31.subtract(openMapRealVector41);
        org.apache.commons.math.linear.RealVector realVector43 = openMapRealVector26.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector6.projection((org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector6.append(openMapRealVector45);
        double[] doubleArray47 = openMapRealVector6.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector3.append(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(openMapRealVector46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, true);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix10.walkInOptimizedOrder(realMatrixPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[][] doubleArray23 = array2DRowRealMatrix18.getData();
        array2DRowRealMatrix5.setSubMatrix(doubleArray23, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix5.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = array2DRowRealMatrix30.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix37.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        org.apache.commons.math.linear.RealMatrix realMatrix42 = array2DRowRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        double double45 = array2DRowRealMatrix40.getEntry((int) (byte) 1, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray53 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        org.apache.commons.math.linear.RealVector realVector56 = openMapRealVector49.add(doubleArray53);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix40.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 10x100 but expected 3x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realVector56);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix(0);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((-0.41032129904824216d), 0.09008991760634888d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.040128288983502236d + "'", double2 == 0.040128288983502236d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix10.subtract(openMapRealMatrix13);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix7.add(openMapRealMatrix13);
        try {
            double double18 = openMapRealMatrix15.getEntry(0, 127);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix10.subtract(openMapRealMatrix13);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix7.add(openMapRealMatrix13);
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealMatrix15.getRowVector((int) (short) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor18 = null;
        try {
            double double19 = openMapRealMatrix15.walkInRowOrder(realMatrixPreservingVisitor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix9);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double12 = openMapRealMatrix9.walkInColumnOrder(realMatrixPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector2.append(openMapRealVector41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray49 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector45.add(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector45.subtract(openMapRealVector55);
        openMapRealVector56.set(100.0d);
        double double59 = openMapRealVector2.getL1Distance(openMapRealVector56);
        org.apache.commons.math.linear.RealVector realVector61 = openMapRealVector56.mapMultiply((double) 52);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(realVector61);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        long long1 = org.apache.commons.math.util.FastMath.round((-4.503599627370496E15d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-4503599627370496L) + "'", long1 == (-4503599627370496L));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray42 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector38.add(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector38.subtract(openMapRealVector48);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector33.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray62 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector58.add(doubleArray62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = openMapRealVector58.subtract(openMapRealVector68);
        org.apache.commons.math.linear.RealVector realVector70 = openMapRealVector53.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector69);
        org.apache.commons.math.linear.RealVector realVector71 = openMapRealVector33.projection((org.apache.commons.math.linear.RealVector) openMapRealVector53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = openMapRealVector33.append(openMapRealVector72);
        double[] doubleArray74 = openMapRealVector33.getData();
        double double75 = openMapRealVector30.getLInfDistance(doubleArray74);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 10, (int) '4', 100.0d);
        try {
            double double80 = openMapRealVector30.cosine((org.apache.commons.math.linear.RealVector) openMapRealVector79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(openMapRealVector69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(openMapRealVector73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) ' ', (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.09951163E12f + "'", float2 == 1.09951163E12f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 97);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, 4.641588833612779d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0);
        org.apache.commons.math.linear.RealVector realVector4 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = openMapRealVector3.ebeMultiply(realVector4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor24 = null;
        try {
            double double29 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor24, (int) (byte) 0, 6, (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((-0.42193247391194444d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[] doubleArray9 = new double[] { 1.9459101490553132d, (short) 10 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray9, (double) (-1.0f));
        try {
            double[] doubleArray12 = array2DRowRealMatrix2.preMultiply(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix10.subtract(openMapRealMatrix13);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix7.add(openMapRealMatrix13);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix17 = openMapRealMatrix7.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (10x97) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray3 = new double[] { 'a', 1.0000001192092896d, 1.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray3);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray3, (-9.999666653335238E-5d));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray18 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector14.add(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector14.subtract(openMapRealVector24);
        org.apache.commons.math.linear.RealVector realVector26 = openMapRealVector9.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector29.add(doubleArray33);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector29.subtract(openMapRealVector39);
        double[] doubleArray41 = openMapRealVector29.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector9.ebeDivide(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector9.mapAdd(1.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector6.append(openMapRealVector44);
        double double46 = openMapRealVector44.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.503599627370496E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix(0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double2 = org.apache.commons.math.util.FastMath.copySign(4.64158883361278d, (-0.42193247391194444d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.64158883361278d) + "'", double2 == (-4.64158883361278d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor18 = openMapRealVector12.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray25 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealVector21.add(doubleArray25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector21.subtract(openMapRealVector31);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector21.append(doubleArray36);
        try {
            double double39 = openMapRealVector12.getDistance(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(entryItor18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(openMapRealVector38);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2265357086400241d + "'", double1 == 1.2265357086400241d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        openMapRealVector13.set(100.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray27 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector23.add(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = openMapRealVector23.subtract(openMapRealVector33);
        org.apache.commons.math.linear.RealVector realVector35 = openMapRealVector18.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector43.add(doubleArray47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector43.subtract(openMapRealVector53);
        org.apache.commons.math.linear.RealVector realVector55 = openMapRealVector38.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector54);
        org.apache.commons.math.linear.RealVector realVector56 = openMapRealVector18.projection((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector13.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(openMapRealVector34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(openMapRealVector57);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 10L, (-1) };
        double[] doubleArray6 = new double[] { 10L, (-1) };
        double[] doubleArray9 = new double[] { 10L, (-1) };
        double[] doubleArray12 = new double[] { 10L, (-1) };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.scalarAdd((double) 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double21 = array2DRowRealMatrix17.walkInOptimizedOrder(realMatrixChangingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.mapAddToSelf(4.9E-324d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector12.copy();
        double[] doubleArray19 = openMapRealVector18.getData();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 10L, (-1) };
        double[] doubleArray6 = new double[] { 10L, (-1) };
        double[] doubleArray9 = new double[] { 10L, (-1) };
        double[] doubleArray12 = new double[] { 10L, (-1) };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor18 = null;
        try {
            double double23 = array2DRowRealMatrix17.walkInRowOrder(realMatrixChangingVisitor18, 97, 0, (int) (byte) 100, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap3 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap2);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap3.iterator();
        boolean boolean5 = iterator4.hasNext();
        try {
            double double6 = iterator4.value();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.combineToSelf(0.0d, (double) (-127), (org.apache.commons.math.linear.RealVector) openMapRealVector3);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector7.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector7.append(openMapRealVector46);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector3.projection((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector3.mapAdd(1.9459101490553132d);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector3.mapDivide(3.1622776601683795d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(realVector52);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        double double5 = array2DRowRealMatrix4.getNorm();
        int int6 = array2DRowRealMatrix4.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3440585709080678E43d + "'", double5 == 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix10.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix17.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix13.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
        boolean boolean23 = openMapRealMatrix5.equals((java.lang.Object) array2DRowRealMatrix20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix26.copy();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix28 = openMapRealMatrix5.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 97 != 52");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap37 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap38 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap37);
        boolean boolean39 = openMapRealVector25.equals((java.lang.Object) openIntToDoubleHashMap38);
        boolean boolean41 = openIntToDoubleHashMap38.containsKey(10);
        double double44 = openIntToDoubleHashMap38.put(0, 0.0d);
        double double46 = openIntToDoubleHashMap38.get((int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-1.0d) + "'", double44 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix9);
        double[][] doubleArray11 = openMapRealMatrix9.getData();
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector20.combineToSelf(0.0d, (double) (-127), (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray56 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math.linear.RealVector realVector59 = openMapRealVector52.add(doubleArray56);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector52.subtract(openMapRealVector62);
        org.apache.commons.math.linear.RealVector realVector64 = openMapRealVector47.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector63);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector27.projection((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector27.append(openMapRealVector66);
        org.apache.commons.math.linear.RealVector realVector68 = openMapRealVector23.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = openMapRealVector23.mapAdd(1.9459101490553132d);
        org.apache.commons.math.linear.RealVector realVector71 = openMapRealVector5.combine((double) (-1L), 0.9999999958776927d, (org.apache.commons.math.linear.RealVector) openMapRealVector70);
        double double72 = openMapRealVector5.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(openMapRealVector67);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(openMapRealVector70);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, 4.641588833612779d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector10.add(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector10.subtract(openMapRealVector20);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector5.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector21);
        int int23 = openMapRealVector5.getMinIndex();
        boolean boolean24 = openMapRealVector5.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector5.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray48 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector44.add(doubleArray48);
        try {
            double double52 = openMapRealVector40.cosine(doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        double double25 = openMapRealVector16.getL1Norm();
        openMapRealVector16.set((double) 52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix35 = array2DRowRealMatrix31.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix34);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix42 = array2DRowRealMatrix38.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix41);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix45.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix48);
        org.apache.commons.math.linear.RealMatrix realMatrix50 = array2DRowRealMatrix41.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = array2DRowRealMatrix31.subtract(array2DRowRealMatrix48);
        boolean boolean52 = openMapRealVector28.equals((java.lang.Object) array2DRowRealMatrix31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray66 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray66);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray66);
        org.apache.commons.math.linear.RealVector realVector69 = openMapRealVector62.add(doubleArray66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = openMapRealVector62.subtract(openMapRealVector72);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector57.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector73);
        org.apache.commons.math.linear.RealVector realVector76 = openMapRealVector57.mapMultiply(0.0d);
        double double77 = openMapRealVector57.getSparsity();
        org.apache.commons.math.linear.RealVector realVector78 = openMapRealVector28.combine((double) 6, 0.0d, (org.apache.commons.math.linear.RealVector) openMapRealVector57);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(openMapRealVector73);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector78);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) -1, 0, (double) (-127));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, 4.641588833612779d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, (double) 32);
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        boolean boolean8 = openMapRealMatrix7.isSquare();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix(1, (int) (short) 1);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = openMapRealMatrix7.multiply((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 97 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray26 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector22.add(doubleArray26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector22.subtract(openMapRealVector32);
        double[] doubleArray34 = openMapRealVector22.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector2.ebeDivide(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34, (-0.41032129904824216d));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor39 = openMapRealVector38.sparseIterator();
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(entryItor39);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray2 = new double[] { 10L, (-1) };
        double[] doubleArray5 = new double[] { 10L, (-1) };
        double[] doubleArray8 = new double[] { 10L, (-1) };
        double[] doubleArray11 = new double[] { 10L, (-1) };
        double[][] doubleArray12 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        boolean boolean14 = array2DRowRealMatrix13.isSquare();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double[] doubleArray3 = new double[] { 'a', 1.0000001192092896d, 1.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray3);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray3, (-9.999666653335238E-5d));
        int int7 = openMapRealVector6.getDimension();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) (byte) 100);
        try {
            array2DRowRealMatrix5.addToEntry((int) (short) 10, 0, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        openMapRealVector13.set(100.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector18.add(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector18.subtract(openMapRealVector28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        double double40 = openMapRealVector18.dotProduct(openMapRealVector32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector43.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector18.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray58 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58);
        org.apache.commons.math.linear.RealVector realVector61 = openMapRealVector54.add(doubleArray58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = openMapRealVector54.subtract(openMapRealVector64);
        org.apache.commons.math.linear.RealVector realVector66 = openMapRealVector49.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector65);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray78 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.RealVector realVector81 = openMapRealVector74.add(doubleArray78);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = openMapRealVector74.subtract(openMapRealVector84);
        org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector69.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector85);
        org.apache.commons.math.linear.RealVector realVector87 = openMapRealVector49.projection((org.apache.commons.math.linear.RealVector) openMapRealVector69);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector88 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector89 = openMapRealVector49.append(openMapRealVector88);
        double[] doubleArray90 = openMapRealVector49.getData();
        double double91 = openMapRealVector46.getLInfDistance(doubleArray90);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector92 = openMapRealVector13.projection(doubleArray90);
        double[] doubleArray93 = openMapRealVector92.getData();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector46);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertNotNull(openMapRealVector65);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(openMapRealVector85);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(realVector87);
        org.junit.Assert.assertNotNull(openMapRealVector89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector92);
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix10.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix17.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix24.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix27);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix20.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix27);
        int int31 = array2DRowRealMatrix10.getColumnDimension();
        boolean boolean32 = array2DRowRealMatrix10.isSquare();
        double[] doubleArray34 = array2DRowRealMatrix10.getColumn(6);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix35 = openMapRealMatrix5.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray27 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector23.add(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = openMapRealVector23.subtract(openMapRealVector33);
        org.apache.commons.math.linear.RealVector realVector35 = openMapRealVector18.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector12.add(openMapRealVector34);
        boolean boolean37 = openMapRealVector34.isNaN();
        double[] doubleArray40 = new double[] { 1.9459101490553132d, (short) 10 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray40, (double) (-1.0f));
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix43 = openMapRealVector34.outerProduct(doubleArray40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(openMapRealVector34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        boolean boolean3 = openMapRealVector2.isInfinite();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3862943611198906d + "'", double1 == 1.3862943611198906d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector7.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector7.append(openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector2.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector48.mapDivideToSelf(0.0d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.combineToSelf(0.0d, (double) (-127), (org.apache.commons.math.linear.RealVector) openMapRealVector3);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector7.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector7.append(openMapRealVector46);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector3.projection((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector7.mapDivideToSelf((-0.4747043615871866d));
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray26 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector22.add(doubleArray26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector22.subtract(openMapRealVector32);
        double[] doubleArray34 = openMapRealVector22.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector2.ebeDivide(doubleArray34);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor36 = openMapRealVector35.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray43 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector39.add(doubleArray43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector39.subtract(openMapRealVector49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray57 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector53.add(doubleArray57);
        double double61 = openMapRealVector39.dotProduct(openMapRealVector53);
        double double62 = openMapRealVector53.getL1Norm();
        openMapRealVector53.set((double) 52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = openMapRealVector35.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(entryItor36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector65);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(realVector19);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor21 = openMapRealVector20.sparseIterator();
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(entryItor21);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, 4.641588833612779d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector10.add(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector10.subtract(openMapRealVector20);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector5.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector21);
        int int23 = openMapRealVector5.getMinIndex();
        boolean boolean24 = openMapRealVector5.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector5.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector51.add(doubleArray55);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = openMapRealVector51.subtract(openMapRealVector61);
        org.apache.commons.math.linear.RealVector realVector63 = openMapRealVector46.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(realVector63);
        org.apache.commons.math.linear.RealVector realVector66 = openMapRealVector64.mapDivide(Double.NaN);
        org.apache.commons.math.linear.RealVector realVector67 = openMapRealVector40.combine((double) '#', 0.6483608274590866d, (org.apache.commons.math.linear.RealVector) openMapRealVector64);
        double[] doubleArray71 = new double[] { 'a', 1.0000001192092896d, 1.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray71);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray71, (-9.999666653335238E-5d));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = openMapRealVector64.append(doubleArray71);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor76 = openMapRealVector75.sparseIterator();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(openMapRealVector62);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(openMapRealVector75);
        org.junit.Assert.assertNotNull(entryItor76);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 127);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.688117141816136E43d + "'", double1 == 2.688117141816136E43d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, 0, 0);
        int int4 = dimensionMismatchException3.getDimension();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = dimensionMismatchException3.getContext();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        boolean boolean6 = array2DRowRealMatrix4.equals((java.lang.Object) (-0.9974947163822921d));
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix4.walkInRowOrder(realMatrixChangingVisitor7, 32, 0, (int) (byte) 1, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        boolean boolean24 = array2DRowRealMatrix2.isSquare();
        double[] doubleArray26 = array2DRowRealMatrix2.getColumn(6);
        try {
            array2DRowRealMatrix2.setEntry((int) (short) 10, (int) (short) 1, (double) 127.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector9.add(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector9.subtract(openMapRealVector19);
        double[] doubleArray24 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector9.append(doubleArray24);
        try {
            double[] doubleArray27 = openMapRealMatrix6.preMultiply(doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(openMapRealVector26);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix25.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix21.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix11.subtract(array2DRowRealMatrix28);
        double[] doubleArray33 = array2DRowRealMatrix31.getColumn(1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = array2DRowRealMatrix8.subtract(array2DRowRealMatrix31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int36 = array2DRowRealMatrix35.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix31.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        java.lang.Object obj15 = null;
        boolean boolean16 = array2DRowRealMatrix5.equals(obj15);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor17 = null;
        try {
            double double22 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixPreservingVisitor17, 32, (-1), 127, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.9974947163822921d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5424087315476646d + "'", double1 == 0.5424087315476646d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        int int45 = openMapRealVector27.getMinIndex();
        double double46 = openMapRealVector16.getL1Distance(openMapRealVector27);
        double[] doubleArray47 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix48 = openMapRealVector16.outerProduct(doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        int int25 = openMapRealVector16.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector20.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray49 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector45.add(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector45.subtract(openMapRealVector55);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector40.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector20.projection((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        double double59 = openMapRealVector5.getDistance(openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector40.mapAddToSelf((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray68 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray68);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray68);
        org.apache.commons.math.linear.RealVector realVector71 = openMapRealVector64.add(doubleArray68);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = openMapRealVector64.subtract(openMapRealVector74);
        double[] doubleArray79 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray79);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = openMapRealVector64.append(doubleArray79);
        try {
            double double82 = openMapRealVector40.getLInfDistance(doubleArray79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(openMapRealVector75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(openMapRealVector81);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        openMapRealVector13.set(100.0d);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix25.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix21.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
        double[][] doubleArray31 = array2DRowRealMatrix21.getData();
        double[] doubleArray33 = array2DRowRealMatrix21.getRow((int) (byte) 0);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector13.add(doubleArray33);
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector13.mapSubtractToSelf(0.09008991760634888d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector13.mapAdd(2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(openMapRealVector38);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        array2DRowRealMatrix22.addToEntry(0, 32, Double.NaN);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = openMapRealMatrix29.subtract(openMapRealMatrix32);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix34 = openMapRealMatrix32.copy();
        boolean boolean35 = openMapRealMatrix34.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix22.multiply((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix33);
        org.junit.Assert.assertNotNull(openMapRealMatrix34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix9);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = openMapRealMatrix13.subtract(openMapRealMatrix16);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = openMapRealMatrix16.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix25 = openMapRealMatrix21.subtract(openMapRealMatrix24);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix18.add(openMapRealMatrix24);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix10.add(openMapRealMatrix18);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix17);
        org.junit.Assert.assertNotNull(openMapRealMatrix18);
        org.junit.Assert.assertNotNull(openMapRealMatrix25);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        boolean boolean18 = openMapRealVector2.isInfinite();
        double[] doubleArray19 = openMapRealVector2.getData();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.175201377593356d + "'", double1 == 1.175201377593356d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        boolean boolean8 = openMapRealMatrix7.isSquare();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        openMapRealMatrix14.addToEntry(0, 6, (-1.5707963267948966d));
        int int20 = openMapRealMatrix14.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix7.add(openMapRealMatrix14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix24.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix35 = array2DRowRealMatrix31.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix34);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix27.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix34);
        double[][] doubleArray37 = array2DRowRealMatrix27.getData();
        double[] doubleArray39 = array2DRowRealMatrix27.getRow((int) (byte) 0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix40 = openMapRealMatrix21.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 10x97 but expected 10x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        java.lang.String str7 = array2DRowRealMatrix5.toString();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.copy();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str7.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector2.mapDivide(3.141592653589793d);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray16, 4.641588833612779d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray30 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector26.add(doubleArray30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector26.subtract(openMapRealVector36);
        org.apache.commons.math.linear.RealVector realVector38 = openMapRealVector21.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector37);
        int int39 = openMapRealVector21.getMinIndex();
        boolean boolean40 = openMapRealVector21.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector43.add(doubleArray47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector43.subtract(openMapRealVector53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector21.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector18.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray71 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector67.add(doubleArray71);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector67.subtract(openMapRealVector77);
        org.apache.commons.math.linear.RealVector realVector79 = openMapRealVector62.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector78);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector80 = new org.apache.commons.math.linear.OpenMapRealVector(realVector79);
        org.apache.commons.math.linear.RealVector realVector82 = openMapRealVector80.mapDivide(Double.NaN);
        org.apache.commons.math.linear.RealVector realVector83 = openMapRealVector56.combine((double) '#', 0.6483608274590866d, (org.apache.commons.math.linear.RealVector) openMapRealVector80);
        org.apache.commons.math.linear.RealVector realVector84 = openMapRealVector2.add((org.apache.commons.math.linear.RealVector) openMapRealVector56);
        int int85 = openMapRealVector56.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertNotNull(realVector82);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertNotNull(realVector84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0f + "'", float1 == 6.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.1624473515096265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.39709459624648213d + "'", double1 == 0.39709459624648213d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap37 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap38 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap37);
        boolean boolean39 = openMapRealVector25.equals((java.lang.Object) openIntToDoubleHashMap38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray46 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector42.add(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector42.subtract(openMapRealVector52);
        double[] doubleArray54 = openMapRealVector42.getData();
        double double55 = openMapRealVector25.getDistance(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector56 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector25.add(realVector56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 1.0f);
        double double4 = openIntToDoubleHashMap1.put((int) (byte) 0, (double) (byte) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator5 = openIntToDoubleHashMap1.iterator();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(iterator5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 1L, 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.99999994f + "'", float2 == 0.99999994f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[] doubleArray24 = array2DRowRealMatrix22.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix22.scalarAdd(1.1102230246251565E-16d);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix22.walkInOptimizedOrder(realMatrixChangingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double[][] doubleArray15 = array2DRowRealMatrix5.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor17 = null;
        try {
            double double22 = array2DRowRealMatrix16.walkInColumnOrder(realMatrixChangingVisitor17, 10, 1, 6, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(0, 127);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix25.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix21.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix11.subtract(array2DRowRealMatrix28);
        double[] doubleArray33 = array2DRowRealMatrix31.getColumn(1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = array2DRowRealMatrix8.subtract(array2DRowRealMatrix31);
        try {
            array2DRowRealMatrix8.addToEntry((int) 'a', 127, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix34);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[] doubleArray24 = array2DRowRealMatrix22.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix22.scalarAdd(1.1102230246251565E-16d);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix22.transpose();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, 4.641588833612779d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, (double) 100L);
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710663101885897d + "'", double1 == 3.2710663101885897d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = mathArithmeticException0.getContext();
        java.lang.Throwable[] throwableArray3 = mathArithmeticException0.getSuppressed();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix2.copy();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor4, (-127), 0, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 3.1622776601683795d, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException7 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, 0);
        outOfRangeException3.addSuppressed((java.lang.Throwable) dimensionMismatchException7);
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector20.combineToSelf(0.0d, (double) (-127), (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray56 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math.linear.RealVector realVector59 = openMapRealVector52.add(doubleArray56);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector52.subtract(openMapRealVector62);
        org.apache.commons.math.linear.RealVector realVector64 = openMapRealVector47.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector63);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector27.projection((org.apache.commons.math.linear.RealVector) openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector27.append(openMapRealVector66);
        org.apache.commons.math.linear.RealVector realVector68 = openMapRealVector23.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = openMapRealVector23.mapAdd(1.9459101490553132d);
        org.apache.commons.math.linear.RealVector realVector71 = openMapRealVector5.combine((double) (-1L), 0.9999999958776927d, (org.apache.commons.math.linear.RealVector) openMapRealVector70);
        int int72 = openMapRealVector70.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(openMapRealVector67);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(openMapRealVector70);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray26 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector22.add(doubleArray26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector22.subtract(openMapRealVector32);
        double[] doubleArray34 = openMapRealVector22.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector2.ebeDivide(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray34, (-0.41032129904824216d));
        double[] doubleArray38 = openMapRealVector37.toArray();
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        double[] doubleArray10 = new double[] { 10L, (-1) };
        double[] doubleArray13 = new double[] { 10L, (-1) };
        double[] doubleArray16 = new double[] { 10L, (-1) };
        double[] doubleArray19 = new double[] { 10L, (-1) };
        double[][] doubleArray20 = new double[][] { doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) doubleArray20);
        boolean boolean23 = array2DRowRealMatrix5.equals((java.lang.Object) localizable7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        array2DRowRealMatrix46.addToEntry(0, 32, Double.NaN);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix60 = array2DRowRealMatrix56.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix59);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix67 = array2DRowRealMatrix63.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix66);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix74 = array2DRowRealMatrix70.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix73);
        org.apache.commons.math.linear.RealMatrix realMatrix75 = array2DRowRealMatrix66.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix73);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = array2DRowRealMatrix56.subtract(array2DRowRealMatrix73);
        org.apache.commons.math.linear.RealMatrix realMatrix77 = array2DRowRealMatrix53.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix56);
        org.apache.commons.math.linear.RealMatrix realMatrix78 = array2DRowRealMatrix46.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix53);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = array2DRowRealMatrix5.multiply(array2DRowRealMatrix53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix76);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        java.lang.String str7 = array2DRowRealMatrix5.toString();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str7.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix10.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix17.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix13.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
        boolean boolean23 = openMapRealMatrix5.equals((java.lang.Object) array2DRowRealMatrix20);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double29 = array2DRowRealMatrix20.walkInRowOrder(realMatrixChangingVisitor24, 0, (int) (short) 1, (-1), 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        double double10 = openMapRealVector2.getSparsity();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.4747043615871866d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6220689367557651d + "'", double1 == 0.6220689367557651d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        java.lang.String str23 = array2DRowRealMatrix19.toString();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str23.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector2.mapAddToSelf(10.04987562112089d);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector32.mapDivide((double) (-1L));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(realVector34);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double[] doubleArray2 = new double[] { 1.9459101490553132d, (short) 10 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray2, (double) (-1.0f));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = openMapRealVector4.unitVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector9.add(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector9.subtract(openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray27 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector23.add(doubleArray27);
        double double31 = openMapRealVector9.dotProduct(openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = openMapRealVector9.mapAdd((double) (short) 0);
        try {
            openMapRealVector4.setSubVector(97, (org.apache.commons.math.linear.RealVector) openMapRealVector9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(openMapRealVector5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector34);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 10, (java.lang.Number) 100, (java.lang.Number) 35);
        java.lang.String str4 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [100, 35] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [100, 35] range"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) -1, 0, 0.040128288983502236d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        array2DRowRealMatrix19.multiplyEntry(1, (int) 'a', 6.0d);
        java.lang.String str27 = array2DRowRealMatrix19.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix34.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix41.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix52 = array2DRowRealMatrix48.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix51);
        org.apache.commons.math.linear.RealMatrix realMatrix53 = array2DRowRealMatrix44.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = array2DRowRealMatrix34.subtract(array2DRowRealMatrix51);
        double[][] doubleArray55 = array2DRowRealMatrix34.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, true);
        try {
            array2DRowRealMatrix19.copySubMatrix((int) (short) 1, (int) '4', (int) '4', (int) (byte) -1, doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str27.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix17);
        boolean boolean20 = array2DRowRealMatrix17.equals((java.lang.Object) (byte) 100);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        double[] doubleArray24 = new double[] { 10L, (-1) };
        double[] doubleArray27 = new double[] { 10L, (-1) };
        double[] doubleArray30 = new double[] { 10L, (-1) };
        double[] doubleArray33 = new double[] { 10L, (-1) };
        double[][] doubleArray34 = new double[][] { doubleArray24, doubleArray27, doubleArray30, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, (java.lang.Object[]) doubleArray34);
        array2DRowRealMatrix17.setSubMatrix(doubleArray34, (int) (short) 0, (int) ' ');
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, (java.lang.Object[]) doubleArray34);
        try {
            openMapRealMatrix5.copySubMatrix(6, (int) 'a', 97, 52, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix10.subtract(openMapRealMatrix13);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix7.add(openMapRealMatrix13);
        double[] doubleArray17 = openMapRealMatrix13.getColumn((int) ' ');
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7221586788190554d + "'", double1 == 0.7221586788190554d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector2);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector2.mapAdd((double) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray34 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector30.add(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector30.subtract(openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray48 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector44.add(doubleArray48);
        double double52 = openMapRealVector30.dotProduct(openMapRealVector44);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector55.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector30.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector30.mapAddToSelf(10.04987562112089d);
        org.apache.commons.math.linear.RealVector realVector62 = openMapRealVector30.mapMultiply(3.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector2.add(openMapRealVector30);
        double[] doubleArray67 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray67, 0.0d);
        try {
            double double72 = openMapRealVector63.cosine(doubleArray67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(openMapRealVector58);
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double[][] doubleArray15 = array2DRowRealMatrix5.getData();
        org.apache.commons.math.linear.RealVector realVector17 = array2DRowRealMatrix5.getColumnVector((int) (short) 0);
        int[] intArray19 = new int[] { 35 };
        int[] intArray22 = new int[] { (short) 100, 'a' };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        double[][] doubleArray26 = array2DRowRealMatrix25.getData();
        try {
            array2DRowRealMatrix5.copySubMatrix(intArray19, intArray22, doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector7.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector7.append(openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector2.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        boolean boolean49 = openMapRealVector2.isInfinite();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.RealVector realVector7 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector8 = openMapRealVector2.combineToSelf(4.641588833612779d, (-0.009999666686665238d), realVector7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector9.add(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector9.subtract(openMapRealVector19);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector4.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector29.add(doubleArray33);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector29.subtract(openMapRealVector39);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector24.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector40);
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector4.projection((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector4.append(openMapRealVector43);
        double[] doubleArray45 = openMapRealVector4.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45);
        double[] doubleArray47 = array2DRowRealMatrix0.preMultiply(doubleArray45);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        array2DRowRealMatrix22.addToEntry(0, 32, Double.NaN);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix32.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix35);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix43 = array2DRowRealMatrix39.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix50 = array2DRowRealMatrix46.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix49);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = array2DRowRealMatrix42.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix49);
        org.apache.commons.math.linear.RealMatrix realMatrix53 = array2DRowRealMatrix29.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix32);
        org.apache.commons.math.linear.RealMatrix realMatrix54 = array2DRowRealMatrix22.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix61 = array2DRowRealMatrix57.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix60);
        double[][] doubleArray62 = array2DRowRealMatrix57.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix70 = array2DRowRealMatrix66.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix69);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix77 = array2DRowRealMatrix73.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix76);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix84 = array2DRowRealMatrix80.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix83);
        org.apache.commons.math.linear.RealMatrix realMatrix85 = array2DRowRealMatrix76.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix83);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = array2DRowRealMatrix66.subtract(array2DRowRealMatrix83);
        double[] doubleArray88 = array2DRowRealMatrix86.getColumn(1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix63.subtract(array2DRowRealMatrix86);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix90 = array2DRowRealMatrix22.multiply(array2DRowRealMatrix63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertNotNull(realMatrix84);
        org.junit.Assert.assertNotNull(realMatrix85);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        double double5 = array2DRowRealMatrix4.getNorm();
        try {
            array2DRowRealMatrix4.addToEntry(0, 97, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3440585709080678E43d + "'", double5 == 1.3440585709080678E43d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix((int) (short) 0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor17 = null;
        try {
            double double22 = array2DRowRealMatrix5.walkInRowOrder(realMatrixPreservingVisitor17, 35, (int) (short) -1, (int) (byte) 10, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor31 = openMapRealVector27.iterator();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(entryItor31);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        openMapRealMatrix5.addToEntry(0, 6, (-1.5707963267948966d));
        int int11 = openMapRealMatrix5.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix15.subtract(openMapRealMatrix18);
        openMapRealMatrix18.addToEntry(0, 6, (-1.5707963267948966d));
        int int24 = openMapRealMatrix18.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix25 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix18);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix26 = openMapRealMatrix12.multiply((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 97 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 97 + "'", int24 == 97);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix(52, 97);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector37.add(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector37.subtract(openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector51.add(doubleArray55);
        double double59 = openMapRealVector37.dotProduct(openMapRealVector51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray71 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector67.add(doubleArray71);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector67.subtract(openMapRealVector77);
        org.apache.commons.math.linear.RealVector realVector79 = openMapRealVector62.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector78);
        int int80 = openMapRealVector62.getMinIndex();
        double double81 = openMapRealVector51.getL1Distance(openMapRealVector62);
        org.apache.commons.math.linear.RealVector realVector83 = openMapRealVector51.mapSubtractToSelf(3.1622776601683795d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = openMapRealVector25.add(openMapRealVector51);
        double[] doubleArray89 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix90 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray89);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix91 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray89);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector93 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray89, 0.0d);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix94 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray89);
        try {
            openMapRealVector25.setSubVector(52, doubleArray89);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertNotNull(openMapRealVector84);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, 5, 97);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector2.mapMultiply(4.64158883361278d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray18 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector14.add(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector14.subtract(openMapRealVector24);
        org.apache.commons.math.linear.RealVector realVector26 = openMapRealVector9.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector25);
        int int27 = openMapRealVector9.getMinIndex();
        boolean boolean28 = openMapRealVector9.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray35 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.RealVector realVector38 = openMapRealVector31.add(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector31.subtract(openMapRealVector41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector9.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector2.add((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        double[] doubleArray45 = openMapRealVector41.toArray();
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector41.mapMultiplyToSelf(1.9459101490553132d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector47);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        int int1 = org.apache.commons.math.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        boolean boolean8 = openMapRealMatrix7.isSquare();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix16 = openMapRealMatrix14.copy();
        boolean boolean17 = openMapRealMatrix16.isSquare();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix20.subtract(openMapRealMatrix23);
        openMapRealMatrix23.addToEntry(0, 6, (-1.5707963267948966d));
        int int29 = openMapRealMatrix23.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = openMapRealMatrix16.add(openMapRealMatrix23);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix31 = openMapRealMatrix7.add(openMapRealMatrix30);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertNotNull(openMapRealMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix30);
        org.junit.Assert.assertNotNull(openMapRealMatrix31);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray18 = openMapRealVector5.toArray();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray4 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean7 = array2DRowRealMatrix5.equals((java.lang.Object) (-0.9974947163822921d));
        java.lang.String str8 = array2DRowRealMatrix5.toString();
        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}" + "'", str8.equals("Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615942060206032d + "'", double1 == 0.7615942060206032d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector20.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray49 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector45.add(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector45.subtract(openMapRealVector55);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector40.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector20.projection((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        double double59 = openMapRealVector5.getDistance(openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector40.mapAddToSelf((double) (short) -1);
        int int62 = openMapRealVector40.getMaxIndex();
        double[] doubleArray66 = new double[] { 'a', 1.0000001192092896d, 1.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray66, (-9.999666653335238E-5d));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray66, 10.0d);
        double double72 = openMapRealVector40.getL1Distance(openMapRealVector71);
        java.lang.Class<?> wildcardClass73 = openMapRealVector40.getClass();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 97.0d + "'", double72 == 97.0d);
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(127, 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        boolean boolean8 = openMapRealMatrix7.isSquare();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        openMapRealMatrix14.addToEntry(0, 6, (-1.5707963267948966d));
        int int20 = openMapRealMatrix14.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix7.add(openMapRealMatrix14);
        try {
            double double24 = openMapRealMatrix21.getEntry((int) (byte) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        double double15 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        double double16 = openMapRealVector2.getLInfNorm();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[][] doubleArray23 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) '#');
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix26.scalarMultiply(Double.POSITIVE_INFINITY);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix2.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6220689367557651d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector(35, (-1), (-0.009999666686665238d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        array2DRowRealMatrix2.multiplyEntry(0, (int) 'a', (double) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor8, 35, 6, 32, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 1.0f);
        double double3 = openIntToDoubleHashMap1.get((int) ' ');
        double double5 = openIntToDoubleHashMap1.remove(0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double2 = org.apache.commons.math.util.FastMath.max(6.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 127);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        openMapRealMatrix5.addToEntry(0, 6, (-1.5707963267948966d));
        int int11 = openMapRealMatrix5.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix5);
        boolean boolean14 = openMapRealMatrix5.equals((java.lang.Object) 99.99999999999999d);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector18.add(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector18.subtract(openMapRealVector28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector28.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector12.add(openMapRealVector28);
        try {
            openMapRealVector12.setEntry((-1), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(openMapRealVector32);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector2.append(openMapRealVector41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray49 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector45.add(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector45.subtract(openMapRealVector55);
        openMapRealVector56.set(100.0d);
        double double59 = openMapRealVector2.getL1Distance(openMapRealVector56);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray66 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray66);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray66);
        org.apache.commons.math.linear.RealVector realVector69 = openMapRealVector62.add(doubleArray66);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = openMapRealVector62.subtract(openMapRealVector72);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray80 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray80);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix82 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray80);
        org.apache.commons.math.linear.RealVector realVector83 = openMapRealVector76.add(doubleArray80);
        double double84 = openMapRealVector62.dotProduct(openMapRealVector76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector87 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector89 = openMapRealVector87.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector90 = openMapRealVector62.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector87);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector92 = openMapRealVector62.mapAddToSelf(10.04987562112089d);
        org.apache.commons.math.linear.RealVector realVector94 = openMapRealVector62.mapMultiply(3.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector95 = openMapRealVector2.append((org.apache.commons.math.linear.RealVector) openMapRealVector62);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector96 = openMapRealVector62.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(openMapRealVector73);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(realVector89);
        org.junit.Assert.assertNotNull(openMapRealVector90);
        org.junit.Assert.assertNotNull(openMapRealVector92);
        org.junit.Assert.assertNotNull(realVector94);
        org.junit.Assert.assertNotNull(openMapRealVector95);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[][] doubleArray23 = array2DRowRealMatrix18.getData();
        array2DRowRealMatrix5.setSubMatrix(doubleArray23, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix5.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = array2DRowRealMatrix30.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix37.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        org.apache.commons.math.linear.RealMatrix realMatrix42 = array2DRowRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        double double45 = array2DRowRealMatrix40.getEntry((int) (byte) 1, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        double double47 = array2DRowRealMatrix40.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(32, 1.0d);
        double double3 = openMapRealVector2.getL1Norm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(6, (int) (short) 1);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = openMapRealVector2.add(openMapRealVector6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 6");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[][] doubleArray23 = array2DRowRealMatrix18.getData();
        array2DRowRealMatrix5.setSubMatrix(doubleArray23, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix5.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = array2DRowRealMatrix30.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix37.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        org.apache.commons.math.linear.RealMatrix realMatrix42 = array2DRowRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        double double45 = array2DRowRealMatrix40.getEntry((int) (byte) 1, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        double[] doubleArray50 = new double[] { 'a', 1.0000001192092896d, 1.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50, (-9.999666653335238E-5d));
        try {
            double[] doubleArray54 = array2DRowRealMatrix40.preMultiply(doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 1.0f);
        double double3 = openIntToDoubleHashMap1.get((int) ' ');
        double double5 = openIntToDoubleHashMap1.remove(3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) (byte) 100, (java.lang.Number) 4.9E-324d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.9E-324d + "'", number4.equals(4.9E-324d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector33.add(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector30.add(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray48 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector44.add(doubleArray48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector44.subtract(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray62 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector58.add(doubleArray62);
        double double66 = openMapRealVector44.dotProduct(openMapRealVector58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray78 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.RealVector realVector81 = openMapRealVector74.add(doubleArray78);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = openMapRealVector74.subtract(openMapRealVector84);
        org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector69.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector85);
        int int87 = openMapRealVector69.getMinIndex();
        double double88 = openMapRealVector58.getL1Distance(openMapRealVector69);
        org.apache.commons.math.linear.RealVector realVector90 = openMapRealVector58.mapSubtractToSelf(3.1622776601683795d);
        double double91 = openMapRealVector30.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector58);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction92 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector93 = openMapRealVector30.map(univariateRealFunction92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(openMapRealVector85);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.combineToSelf(0.0d, (double) (-127), (org.apache.commons.math.linear.RealVector) openMapRealVector3);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector7.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector7.append(openMapRealVector46);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector3.projection((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector3.mapAdd(1.9459101490553132d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray57 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector53.add(doubleArray57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector53.subtract(openMapRealVector63);
        double[] doubleArray65 = openMapRealVector53.getData();
        org.apache.commons.math.linear.RealVector realVector66 = openMapRealVector50.add((org.apache.commons.math.linear.RealVector) openMapRealVector53);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector66);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        array2DRowRealMatrix19.multiplyEntry(1, (int) 'a', 6.0d);
        java.lang.String str27 = array2DRowRealMatrix19.toString();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor28 = null;
        try {
            double double29 = array2DRowRealMatrix19.walkInColumnOrder(realMatrixPreservingVisitor28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str27.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector2.append(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray28 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector24.add(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector19.combineToSelf(0.0d, 0.7615941559557649d, doubleArray28);
        double[] doubleArray37 = new double[] { 'a', 1.0000001192092896d, 1.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray37, (-9.999666653335238E-5d));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray52 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52);
        org.apache.commons.math.linear.RealVector realVector55 = openMapRealVector48.add(doubleArray52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = openMapRealVector48.subtract(openMapRealVector58);
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector43.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector59);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray67 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math.linear.RealVector realVector70 = openMapRealVector63.add(doubleArray67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = openMapRealVector63.subtract(openMapRealVector73);
        double[] doubleArray75 = openMapRealVector63.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = openMapRealVector43.ebeDivide(doubleArray75);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector43.mapAdd(1.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = openMapRealVector40.append(openMapRealVector78);
        openMapRealVector19.setSubVector(0, (org.apache.commons.math.linear.RealVector) openMapRealVector79);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(openMapRealVector59);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(openMapRealVector74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(openMapRealVector76);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(openMapRealVector79);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.mapAddToSelf(4.9E-324d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector12.copy();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector18.copy();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray46 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector42.add(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector42.subtract(openMapRealVector52);
        double[] doubleArray54 = openMapRealVector42.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector22.ebeDivide(doubleArray54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = openMapRealVector22.mapAdd(1.0d);
        double double58 = openMapRealVector18.dotProduct(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(openMapRealVector57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix12.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = array2DRowRealMatrix19.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix15.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix22);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            array2DRowRealMatrix5.multiplyEntry((int) '#', (int) (short) 1, (-0.5872139151569291d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.1102230246251565E-16d, 127.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.741913579725642E-19d + "'", double2 == 8.741913579725642E-19d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        boolean boolean35 = openMapRealVector25.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector38.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector38.mapDivideToSelf((double) 35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector25.append(openMapRealVector38);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(openMapRealVector43);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double2 = org.apache.commons.math.util.FastMath.min(0.34414365766927546d, 6.228504600082091E-21d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.228504600082091E-21d + "'", double2 == 6.228504600082091E-21d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        int int20 = openMapRealVector12.getMaxIndex();
        try {
            array2DRowRealMatrix5.setColumnVector((int) (byte) 1, (org.apache.commons.math.linear.RealVector) openMapRealVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 10x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix9 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix9);
        int int11 = openMapRealMatrix9.getRowDimension();
        try {
            double double14 = openMapRealMatrix9.getEntry((int) (short) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        int int10 = array2DRowRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix13.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix27.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix30);
        org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix23.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix30);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix30);
        double[][] doubleArray34 = array2DRowRealMatrix13.getDataRef();
        try {
            array2DRowRealMatrix8.setSubMatrix(doubleArray34, 0, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (104)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix33);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, true);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector13.add(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector13.subtract(openMapRealVector23);
        org.apache.commons.math.linear.RealVector realVector26 = openMapRealVector23.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector34.add(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector34.subtract(openMapRealVector44);
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector29.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector23.add(openMapRealVector45);
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector45.mapSubtract((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector45.mapSubtract(100.0d);
        double[] doubleArray52 = openMapRealVector45.toArray();
        try {
            double[] doubleArray53 = array2DRowRealMatrix10.operate(doubleArray52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        double[] doubleArray14 = openMapRealVector2.getData();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor15 = openMapRealVector2.sparseIterator();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(entryItor15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix10.subtract(openMapRealMatrix13);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix7.add(openMapRealMatrix13);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double17 = openMapRealMatrix7.walkInOptimizedOrder(realMatrixPreservingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap0 = null;
        try {
            org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(10, 0.5424087315476646d);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) 10);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        boolean boolean8 = openMapRealMatrix7.isSquare();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix11.subtract(openMapRealMatrix14);
        openMapRealMatrix14.addToEntry(0, 6, (-1.5707963267948966d));
        int int20 = openMapRealMatrix14.getColumnDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix7.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix24.subtract(openMapRealMatrix27);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix31 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = openMapRealMatrix27.add(openMapRealMatrix31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix43 = array2DRowRealMatrix39.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix50 = array2DRowRealMatrix46.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix49);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = array2DRowRealMatrix42.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix49);
        double[][] doubleArray52 = array2DRowRealMatrix42.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52);
        openMapRealMatrix27.copySubMatrix(0, 6, 0, (int) (short) 10, doubleArray52);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix55 = openMapRealMatrix14.add(openMapRealMatrix27);
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix21);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(openMapRealMatrix32);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(openMapRealMatrix55);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.2710663101885897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4844415983612418d + "'", double1 == 1.4844415983612418d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        double[][] doubleArray4 = array2DRowRealMatrix3.getData();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException5 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double[] doubleArray2 = new double[] { 1.9459101490553132d, (short) 10 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray2, (double) (-1.0f));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector4);
        double[] doubleArray8 = new double[] { 1.9459101490553132d, (short) 10 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray8, (double) (-1.0f));
        org.apache.commons.math.linear.RealMatrix realMatrix11 = openMapRealVector4.outerProduct(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        long long1 = org.apache.commons.math.util.FastMath.round(1.3862943611198906d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix((int) (short) 0);
        double[][] doubleArray17 = array2DRowRealMatrix5.getData();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix12.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = array2DRowRealMatrix19.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix15.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix22);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray27 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector23.add(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = openMapRealVector23.subtract(openMapRealVector33);
        org.apache.commons.math.linear.RealVector realVector35 = openMapRealVector18.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector12.add(openMapRealVector34);
        boolean boolean37 = openMapRealVector34.isNaN();
        int int38 = openMapRealVector34.getDimension();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(openMapRealVector34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }
}

