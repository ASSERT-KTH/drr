import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 1L, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.04987562112089d + "'", double2 == 10.04987562112089d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 0.0f, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0L, (java.lang.Number) (byte) 1, (java.lang.Number) (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 100L, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9459101490553132d + "'", double1 == 1.9459101490553132d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(1.0f, (double) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, 0);
        int int3 = dimensionMismatchException2.getDimension();
        java.lang.Number number4 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1 + "'", number4.equals(1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix5.walkInRowOrder(realMatrixChangingVisitor7, (int) '#', 0, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double[][] doubleArray14 = array2DRowRealMatrix9.getData();
        try {
            array2DRowRealMatrix2.setSubMatrix(doubleArray14, 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41032129904824216d) + "'", double1 == (-0.41032129904824216d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.abs(10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.04987562112089d + "'", double1 == 10.04987562112089d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            array2DRowRealMatrix2.setEntry((int) (short) 1, (int) (byte) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor15 = null;
        try {
            double double20 = array2DRowRealMatrix12.walkInOptimizedOrder(realMatrixPreservingVisitor15, (int) (short) 1, (int) '#', (int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix4.walkInRowOrder(realMatrixChangingVisitor5, (int) (short) -1, (int) (byte) 10, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.getSubMatrix((int) (short) -1, (int) '#', (int) '#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.power((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: p must be >= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.linear.RealVector realVector0 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(realVector0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double16 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        int[] intArray4 = new int[] { (short) -1 };
        int[] intArray6 = new int[] { (byte) -1 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.getSubMatrix(intArray4, intArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) "");
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double[][] doubleArray14 = array2DRowRealMatrix9.getData();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 52");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            double double9 = openMapRealVector2.getL1Distance(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor7, (int) (short) -1, 10, 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[] doubleArray10 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        try {
            double[] doubleArray13 = array2DRowRealMatrix5.operate(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix2.createMatrix(0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix10);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix4.multiply(realMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        try {
            openMapRealVector2.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray7 = new double[] { (-1.0d), 1.0000001f, 10L, 2.220446049250313E-16d };
        try {
            double double8 = openMapRealVector2.dotProduct(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = new double[][] {};
        try {
            array2DRowRealMatrix5.setSubMatrix(doubleArray7, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9974947163822921d) + "'", double1 == (-0.9974947163822921d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray4 = new double[] { 10L };
        try {
            double double5 = openMapRealVector2.cosine(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 1.0f);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) (short) -1);
        double[] doubleArray8 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = openMapRealVector2.ebeMultiply(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        try {
            double double24 = openMapRealVector12.getDistance(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) "");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        double[][] doubleArray17 = array2DRowRealMatrix12.getData();
        try {
            array2DRowRealMatrix5.setRowMatrix(6, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 10x100 but expected 1x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray21 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector17.add(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector17.subtract(openMapRealVector27);
        try {
            openMapRealVector12.setSubVector((int) (byte) 100, (org.apache.commons.math.linear.RealVector) openMapRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(openMapRealVector28);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double2 = org.apache.commons.math.util.FastMath.min(3.1622776601683795d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1622776601683795d + "'", double2 == 3.1622776601683795d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 100, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix((int) (short) 0);
        double[] doubleArray18 = null;
        try {
            array2DRowRealMatrix5.setRow((int) (byte) 0, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double0 = org.apache.commons.math.linear.OpenMapRealVector.DEFAULT_ZERO_TOLERANCE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-12d + "'", double0 == 1.0E-12d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.7615941559557649d, 1.0E-12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.351336525445773E-13d) + "'", double2 == (-2.351336525445773E-13d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray30 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector26.add(doubleArray30);
        try {
            array2DRowRealMatrix19.setRowVector((int) (byte) 1, (org.apache.commons.math.linear.RealVector) openMapRealVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) '#');
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor3, (int) (byte) 0, (int) (short) 1, (int) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int1 = org.apache.commons.math.util.FastMath.abs(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector2.ebeDivide(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray45 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector41.add(doubleArray45);
        double double49 = openMapRealVector27.dotProduct(openMapRealVector41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector52.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray61 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray61);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray61);
        org.apache.commons.math.linear.RealVector realVector64 = openMapRealVector57.add(doubleArray61);
        double double65 = openMapRealVector52.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector57);
        double double66 = openMapRealVector41.getL1Distance(openMapRealVector57);
        try {
            double double67 = openMapRealVector2.cosine((org.apache.commons.math.linear.RealVector) openMapRealVector57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1L, (java.lang.Number) (-1.0d), (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        double double15 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction16 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector7.map(univariateRealFunction16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray15 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector11.add(doubleArray15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        try {
            double[] doubleArray20 = array2DRowRealMatrix5.preMultiply(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) "");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray15 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector11.add(doubleArray15);
        try {
            double[] doubleArray19 = array2DRowRealMatrix5.preMultiply(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix8.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix15.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix18);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix11.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix18);
        int int21 = array2DRowRealMatrix11.getRowDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix5.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector13.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector18.add(doubleArray22);
        double double26 = openMapRealVector13.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector18);
        try {
            openMapRealVector2.setSubVector((int) (byte) 10, (org.apache.commons.math.linear.RealVector) openMapRealVector13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        try {
            openMapRealVector2.setEntry(0, 10.04987562112089d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) "");
        try {
            org.apache.commons.math.linear.RealVector realVector10 = array2DRowRealMatrix5.getColumnVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) "");
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor9, (-1), 10, (int) (short) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector2.projection(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor23 = null;
        try {
            double double24 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[] doubleArray10 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        try {
            double[] doubleArray12 = array2DRowRealMatrix2.operate(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix27.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix30);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix34.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix41.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix44);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix37.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix27.subtract(array2DRowRealMatrix44);
        double[] doubleArray49 = array2DRowRealMatrix47.getColumn(1);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix50 = openMapRealVector16.outerProduct(doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) (byte) 100);
        try {
            array2DRowRealMatrix5.multiplyEntry(0, (int) (byte) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) "");
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 1L, (short) 100, 0.0d, 3.141592653589793d };
        try {
            double[] doubleArray15 = array2DRowRealMatrix5.operate(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) (byte) 100);
        try {
            double double9 = array2DRowRealMatrix5.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        boolean boolean15 = array2DRowRealMatrix12.equals((java.lang.Object) (byte) 100);
        try {
            array2DRowRealMatrix5.setColumnMatrix((int) 'a', (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.preMultiply(realMatrix11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor8, (int) (short) -1, (int) '4', (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1754034190044697d + "'", double1 == 0.1754034190044697d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        int int20 = openMapRealVector2.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray27 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector23.add(doubleArray27);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix31 = openMapRealVector2.outerProduct(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix((int) (short) 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor17 = null;
        try {
            double double18 = array2DRowRealMatrix5.walkInRowOrder(realMatrixChangingVisitor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix25.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix32.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix35);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix28.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix35);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix22.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double[][] doubleArray14 = array2DRowRealMatrix9.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix9.scalarAdd(0.7615941559557649d);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix5.preMultiply(realMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.40872429885248984d + "'", double0 == 0.40872429885248984d);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix8.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix15.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix18);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix11.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix18);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = array2DRowRealMatrix5.add(array2DRowRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 10x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, 0);
        int int3 = dimensionMismatchException2.getDimension();
        java.lang.Throwable throwable4 = null;
        try {
            dimensionMismatchException2.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double[] doubleArray2 = new double[] { 10L, (-1) };
        double[] doubleArray5 = new double[] { 10L, (-1) };
        double[] doubleArray8 = new double[] { 10L, (-1) };
        double[] doubleArray11 = new double[] { 10L, (-1) };
        double[][] doubleArray12 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix17.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix24.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix27);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix20.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix27);
        try {
            array2DRowRealMatrix13.setRowMatrix((int) (short) 1, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 10x100 but expected 1x2");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.cosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix5.walkInRowOrder(realMatrixPreservingVisitor7, (int) 'a', 0, (int) (short) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor3, (int) (short) 0, (int) (byte) 10, (int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        double double15 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction16 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector2.map(univariateRealFunction16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray24 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector20.add(doubleArray24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector20.subtract(openMapRealVector30);
        double[] doubleArray35 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector20.append(doubleArray35);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector5.subtract(doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor7, (int) '4', (int) (byte) 1, (int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, 0);
        int int3 = dimensionMismatchException2.getDimension();
        java.lang.String str4 = dimensionMismatchException2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.DimensionMismatchException: 1 != 0" + "'", str4.equals("org.apache.commons.math.exception.DimensionMismatchException: 1 != 0"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            org.apache.commons.math.linear.RealVector realVector8 = array2DRowRealMatrix5.getRowVector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix5.getSubMatrix(6, 10, (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        double double40 = openMapRealVector27.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double double41 = openMapRealVector16.getL1Distance(openMapRealVector32);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix48 = array2DRowRealMatrix44.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix55 = array2DRowRealMatrix51.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix58.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix61);
        org.apache.commons.math.linear.RealMatrix realMatrix63 = array2DRowRealMatrix54.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix61);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = array2DRowRealMatrix44.subtract(array2DRowRealMatrix61);
        double[] doubleArray66 = array2DRowRealMatrix64.getColumn(1);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector32.ebeMultiply(doubleArray66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix64);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray7 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.RealVector realVector10 = openMapRealVector3.add(doubleArray7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector3.subtract(openMapRealVector13);
        double[] doubleArray18 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector3.append(doubleArray18);
        try {
            double double21 = openMapRealVector0.cosine(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector2.projection(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector2.mapAddToSelf(10.04987562112089d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray39 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector35.add(doubleArray39);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector2.projection(doubleArray39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-1.0f), (java.lang.Number) (-1.0d), (java.lang.Number) 10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.64158883361278d + "'", double1 == 4.64158883361278d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[] doubleArray24 = array2DRowRealMatrix22.getColumn(1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor25 = null;
        try {
            double double30 = array2DRowRealMatrix22.walkInColumnOrder(realMatrixPreservingVisitor25, (int) '#', 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) '#');
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix4.walkInColumnOrder(realMatrixPreservingVisitor5, (int) '#', (int) 'a', 10, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 10L, (-1) };
        double[] doubleArray6 = new double[] { 10L, (-1) };
        double[] doubleArray9 = new double[] { 10L, (-1) };
        double[] doubleArray12 = new double[] { 10L, (-1) };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        try {
            java.lang.String str16 = mathIllegalArgumentException15.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix10.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
        double[][] doubleArray15 = array2DRowRealMatrix10.getData();
        try {
            array2DRowRealMatrix2.setSubMatrix(doubleArray15, 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.009999666686665238d) + "'", double2 == (-0.009999666686665238d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) 10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix25 = array2DRowRealMatrix21.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix24);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix17.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = array2DRowRealMatrix7.subtract(array2DRowRealMatrix24);
        double[] doubleArray29 = array2DRowRealMatrix27.getColumn(1);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.projection(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.41032129904824216d), (java.lang.Number) (-0.41032129904824216d), (java.lang.Number) 0.7615941559557649d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.atanh(100.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        int[] intArray7 = new int[] {};
        int[] intArray8 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.getSubMatrix(intArray7, intArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        int int20 = openMapRealVector18.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.power((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (52x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor9, 6, (int) (short) -1, (-127), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector3 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector4 = array2DRowRealMatrix2.preMultiply(realVector3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double17 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixPreservingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix((int) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector20.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray49 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector45.add(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector45.subtract(openMapRealVector55);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector40.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector20.projection((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector20.append(openMapRealVector59);
        double[] doubleArray61 = openMapRealVector20.getData();
        try {
            array2DRowRealMatrix5.setRow(0, doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        int[] intArray9 = new int[] { 6, 100 };
        int[] intArray13 = new int[] { 'a', '#', 10 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix2.getSubMatrix(intArray9, intArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 0, (double) 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        try {
            double double25 = array2DRowRealMatrix19.getEntry((-1), 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[] doubleArray24 = array2DRowRealMatrix22.getColumn(1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor25 = null;
        try {
            double double26 = array2DRowRealMatrix22.walkInOptimizedOrder(realMatrixChangingVisitor25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double[] doubleArray2 = new double[] { 10L, (-1) };
        double[] doubleArray5 = new double[] { 10L, (-1) };
        double[] doubleArray8 = new double[] { 10L, (-1) };
        double[] doubleArray11 = new double[] { 10L, (-1) };
        double[][] doubleArray12 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix23.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix26);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix19.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix26);
        int int29 = array2DRowRealMatrix19.getRowDimension();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 4x2 but expected 10x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) (byte) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        openMapRealVector13.set(100.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector18.add(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector18.subtract(openMapRealVector28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector18.mapDivide(3.141592653589793d);
        try {
            double double32 = openMapRealVector13.cosine((org.apache.commons.math.linear.RealVector) openMapRealVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(realVector31);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) '#');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
        double[][] doubleArray10 = array2DRowRealMatrix5.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        try {
            array2DRowRealMatrix2.setSubMatrix(doubleArray10, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector9.add(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector9.subtract(openMapRealVector19);
        double[] doubleArray21 = openMapRealVector9.getData();
        try {
            double[] doubleArray22 = array2DRowRealMatrix2.operate(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[] doubleArray24 = array2DRowRealMatrix22.getColumn(1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix22.subtract(array2DRowRealMatrix25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector2);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector33.add(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector33.subtract(openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector28.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector44);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray57 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector53.add(doubleArray57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector53.subtract(openMapRealVector63);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector48.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector64);
        org.apache.commons.math.linear.RealVector realVector66 = openMapRealVector28.projection((org.apache.commons.math.linear.RealVector) openMapRealVector48);
        double double67 = openMapRealVector25.dotProduct(openMapRealVector48);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        int int45 = openMapRealVector27.getMinIndex();
        double double46 = openMapRealVector16.getL1Distance(openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector50.add(doubleArray54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector50.subtract(openMapRealVector60);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray68 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray68);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray68);
        org.apache.commons.math.linear.RealVector realVector71 = openMapRealVector64.add(doubleArray68);
        double double72 = openMapRealVector50.dotProduct(openMapRealVector64);
        try {
            openMapRealVector16.setSubVector((-127), (org.apache.commons.math.linear.RealVector) openMapRealVector50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        try {
            array2DRowRealMatrix2.copySubMatrix((int) (byte) -1, (-1), 35, 0, doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix60 = array2DRowRealMatrix56.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix59);
        double[][] doubleArray61 = array2DRowRealMatrix56.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray61);
        try {
            array2DRowRealMatrix46.copySubMatrix((int) (byte) 0, 6, (int) (byte) -1, (int) 'a', doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector11 = openMapRealVector2.mapSubtract((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray18 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector14.add(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector14.subtract(openMapRealVector24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray32 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32);
        org.apache.commons.math.linear.RealVector realVector35 = openMapRealVector28.add(doubleArray32);
        double double36 = openMapRealVector14.dotProduct(openMapRealVector28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector39.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector14.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector14.mapAddToSelf(10.04987562112089d);
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector14.mapMultiply(3.0d);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix47 = openMapRealVector2.outerProduct((org.apache.commons.math.linear.RealVector) openMapRealVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(realVector46);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double double17 = array2DRowRealMatrix12.getEntry((int) (byte) 1, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor18 = null;
        try {
            double double19 = array2DRowRealMatrix12.walkInColumnOrder(realMatrixChangingVisitor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        double[] doubleArray20 = new double[] { 1.9459101490553132d, (short) 10 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray20, (double) (-1.0f));
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix23 = openMapRealVector2.outerProduct(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix((int) (short) 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor17 = null;
        try {
            double double22 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor17, 0, (int) (byte) 1, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor7, 6, (int) (byte) 0, (int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: initial row 6 after final row 0");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix2.scalarAdd(0.7615941559557649d);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray54, 0.0d);
        try {
            array2DRowRealMatrix2.setColumnVector(0, (org.apache.commons.math.linear.RealVector) openMapRealVector58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 10x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector2.mapAddToSelf(10.04987562112089d);
        double[] doubleArray35 = new double[] { '#', (byte) 10 };
        try {
            double double36 = openMapRealVector2.dotProduct(doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) (byte) 100);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix5.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        double double40 = openMapRealVector27.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double double41 = openMapRealVector16.getL1Distance(openMapRealVector32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray48 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector44.add(doubleArray48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector44.subtract(openMapRealVector54);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector54.mapMultiplyToSelf((double) 0L);
        double double58 = openMapRealVector32.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector54);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        double[] doubleArray7 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        try {
            double[] doubleArray9 = array2DRowRealMatrix2.preMultiply(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector37.add(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector37.subtract(openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector51.add(doubleArray55);
        double double59 = openMapRealVector37.dotProduct(openMapRealVector51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray71 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector67.add(doubleArray71);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector67.subtract(openMapRealVector77);
        org.apache.commons.math.linear.RealVector realVector79 = openMapRealVector62.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector78);
        int int80 = openMapRealVector62.getMinIndex();
        double double81 = openMapRealVector51.getL1Distance(openMapRealVector62);
        org.apache.commons.math.linear.RealVector realVector83 = openMapRealVector51.mapSubtractToSelf(3.1622776601683795d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = openMapRealVector25.add(openMapRealVector51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector87 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray91 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix92 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray91);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix93 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray91);
        org.apache.commons.math.linear.RealVector realVector94 = openMapRealVector87.add(doubleArray91);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix95 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray91);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector96 = openMapRealVector84.subtract(doubleArray91);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertNotNull(openMapRealVector84);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(realVector94);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap3 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap2);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap3.iterator();
        try {
            iterator4.advance();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 1, 1.0E-12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(100, 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.power(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (3x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        boolean boolean24 = array2DRowRealMatrix2.isSquare();
        int[] intArray25 = new int[] {};
        int[] intArray29 = new int[] { 1, (short) 0, 10 };
        double[][] doubleArray30 = null;
        try {
            array2DRowRealMatrix2.copySubMatrix(intArray25, intArray29, doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NoDataException; message: empty selected row index array");
        } catch (org.apache.commons.math.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector43.add(doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector2.subtract(doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector7.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector7.append(openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector2.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.RealVector realVector49 = null;
        try {
            double double50 = openMapRealVector2.dotProduct(realVector49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix56 = array2DRowRealMatrix52.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        double[][] doubleArray57 = array2DRowRealMatrix52.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        try {
            array2DRowRealMatrix2.setSubMatrix(doubleArray57, (int) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.1754034190044697d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector25 = array2DRowRealMatrix2.getRowVector((int) (byte) 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor26 = null;
        try {
            double double27 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector2.mapDivide(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector16 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector2.append(realVector16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor50 = null;
        try {
            double double51 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.220446049250313E-16d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41078129050290885d + "'", double1 == 0.41078129050290885d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            array2DRowRealMatrix5.addToEntry(10, (int) (byte) 100, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) "");
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor9, (int) (byte) -1, (int) ' ', 6, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        boolean boolean24 = array2DRowRealMatrix2.isSquare();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor25 = null;
        try {
            double double30 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor25, (-127), 100, (int) (byte) -1, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector37.add(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector37.subtract(openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector51.add(doubleArray55);
        double double59 = openMapRealVector37.dotProduct(openMapRealVector51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray71 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector67.add(doubleArray71);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector67.subtract(openMapRealVector77);
        org.apache.commons.math.linear.RealVector realVector79 = openMapRealVector62.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector78);
        int int80 = openMapRealVector62.getMinIndex();
        double double81 = openMapRealVector51.getL1Distance(openMapRealVector62);
        org.apache.commons.math.linear.RealVector realVector83 = openMapRealVector51.mapSubtractToSelf(3.1622776601683795d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = openMapRealVector25.add(openMapRealVector51);
        double[] doubleArray86 = new double[] { (-0.41032129904824216d) };
        try {
            double double87 = openMapRealVector25.getDistance(doubleArray86);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertNotNull(openMapRealVector84);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        int int20 = openMapRealVector2.getMinIndex();
        boolean boolean21 = openMapRealVector2.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray28 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector24.add(doubleArray28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector24.subtract(openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector2.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray44 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector40.add(doubleArray44);
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector40.mapSubtract((double) (-1));
        try {
            openMapRealVector36.setSubVector((int) (short) 0, (org.apache.commons.math.linear.RealVector) openMapRealVector40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(realVector49);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            double double9 = array2DRowRealMatrix2.getEntry((int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (int) (byte) 1, (int) ' ');
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector2);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray34 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector30.add(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector30.subtract(openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray48 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector44.add(doubleArray48);
        double double52 = openMapRealVector30.dotProduct(openMapRealVector44);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray67 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math.linear.RealVector realVector70 = openMapRealVector63.add(doubleArray67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = openMapRealVector63.subtract(openMapRealVector73);
        org.apache.commons.math.linear.RealVector realVector75 = openMapRealVector58.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector74);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray82 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math.linear.RealVector realVector85 = openMapRealVector78.add(doubleArray82);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector88 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector89 = openMapRealVector78.subtract(openMapRealVector88);
        double[] doubleArray90 = openMapRealVector78.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector91 = openMapRealVector58.ebeDivide(doubleArray90);
        org.apache.commons.math.linear.RealVector realVector92 = openMapRealVector30.combineToSelf((double) 100.0f, (double) (-1), doubleArray90);
        org.apache.commons.math.linear.RealVector realVector93 = openMapRealVector25.combineToSelf(0.1754034190044697d, (double) (-1L), realVector92);
        org.apache.commons.math.linear.RealVector realVector96 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector97 = openMapRealVector25.combine((double) 100.0f, 0.9999999958776927d, realVector96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(openMapRealVector74);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(openMapRealVector89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(openMapRealVector91);
        org.junit.Assert.assertNotNull(realVector92);
        org.junit.Assert.assertNotNull(realVector93);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor23 = null;
        try {
            double double24 = array2DRowRealMatrix19.walkInOptimizedOrder(realMatrixChangingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector37.add(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector37.subtract(openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector51.add(doubleArray55);
        double double59 = openMapRealVector37.dotProduct(openMapRealVector51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray71 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector67.add(doubleArray71);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector67.subtract(openMapRealVector77);
        org.apache.commons.math.linear.RealVector realVector79 = openMapRealVector62.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector78);
        int int80 = openMapRealVector62.getMinIndex();
        double double81 = openMapRealVector51.getL1Distance(openMapRealVector62);
        org.apache.commons.math.linear.RealVector realVector83 = openMapRealVector51.mapSubtractToSelf(3.1622776601683795d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = openMapRealVector25.add(openMapRealVector51);
        try {
            double double86 = openMapRealVector25.getEntry((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertNotNull(openMapRealVector84);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        array2DRowRealMatrix19.multiplyEntry(1, (int) 'a', 6.0d);
        try {
            double double27 = array2DRowRealMatrix19.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, 0);
        int int5 = dimensionMismatchException4.getDimension();
        int int6 = dimensionMismatchException4.getDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix23.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix26);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix19.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix9.subtract(array2DRowRealMatrix26);
        int int30 = array2DRowRealMatrix9.getColumnDimension();
        boolean boolean31 = array2DRowRealMatrix9.isSquare();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray43 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector39.add(doubleArray43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector39.subtract(openMapRealVector49);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector34.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray63 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math.linear.RealVector realVector66 = openMapRealVector59.add(doubleArray63);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = openMapRealVector59.subtract(openMapRealVector69);
        org.apache.commons.math.linear.RealVector realVector71 = openMapRealVector54.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector70);
        org.apache.commons.math.linear.RealVector realVector72 = openMapRealVector34.projection((org.apache.commons.math.linear.RealVector) openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = openMapRealVector34.append(openMapRealVector73);
        double[] doubleArray75 = openMapRealVector34.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray82 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math.linear.RealVector realVector85 = openMapRealVector78.add(doubleArray82);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector88 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector89 = openMapRealVector78.subtract(openMapRealVector88);
        org.apache.commons.math.linear.RealVector realVector91 = openMapRealVector88.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector93 = openMapRealVector88.append((double) 0);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor94 = openMapRealVector88.sparseIterator();
        java.lang.Object[] objArray95 = new java.lang.Object[] { dimensionMismatchException4, array2DRowRealMatrix9, doubleArray75, openMapRealVector88 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException96 = new org.apache.commons.math.exception.MathArithmeticException(localizable1, objArray95);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException97 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray95);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(openMapRealVector70);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(realVector72);
        org.junit.Assert.assertNotNull(openMapRealVector74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(openMapRealVector89);
        org.junit.Assert.assertNotNull(realVector91);
        org.junit.Assert.assertNotNull(openMapRealVector93);
        org.junit.Assert.assertNotNull(entryItor94);
        org.junit.Assert.assertNotNull(objArray95);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(100, (int) (short) 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap3 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap2);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap3.iterator();
        try {
            double double5 = iterator4.value();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector43.add(doubleArray47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector2.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        double[] doubleArray56 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray56, 0.0d);
        try {
            openMapRealVector51.setSubVector((int) (byte) 0, doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix15.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix18);
        double[][] doubleArray20 = array2DRowRealMatrix15.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        double[][] doubleArray22 = array2DRowRealMatrix21.getDataRef();
        try {
            array2DRowRealMatrix5.copySubMatrix((int) (short) 100, 35, 0, (int) (byte) 100, doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.64158883361278d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray21 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector17.add(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector17.subtract(openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray35 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.RealVector realVector38 = openMapRealVector31.add(doubleArray35);
        double double39 = openMapRealVector17.dotProduct(openMapRealVector31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector42.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector17.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray57 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector53.add(doubleArray57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector53.subtract(openMapRealVector63);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector48.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector64);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray77 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray77);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray77);
        org.apache.commons.math.linear.RealVector realVector80 = openMapRealVector73.add(doubleArray77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = openMapRealVector73.subtract(openMapRealVector83);
        org.apache.commons.math.linear.RealVector realVector85 = openMapRealVector68.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector84);
        org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector48.projection((org.apache.commons.math.linear.RealVector) openMapRealVector68);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector87 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector88 = openMapRealVector48.append(openMapRealVector87);
        double[] doubleArray89 = openMapRealVector48.getData();
        double double90 = openMapRealVector45.getLInfDistance(doubleArray89);
        try {
            double[] doubleArray91 = array2DRowRealMatrix12.operate(doubleArray89);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(openMapRealVector28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(openMapRealVector84);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(openMapRealVector88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, (long) (-127));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-127L) + "'", long2 == (-127L));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector7.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector7.append(openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector2.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector53 = openMapRealVector51.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray60 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math.linear.RealVector realVector63 = openMapRealVector56.add(doubleArray60);
        double double64 = openMapRealVector51.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.RealVector realVector66 = openMapRealVector51.mapMultiplyToSelf(3.141592653589793d);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix67 = openMapRealVector48.outerProduct((org.apache.commons.math.linear.RealVector) openMapRealVector51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(realVector66);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, 4.641588833612779d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector10.add(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector10.subtract(openMapRealVector20);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector5.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector21);
        int int23 = openMapRealVector5.getMinIndex();
        boolean boolean24 = openMapRealVector5.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector5.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray48 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector44.add(doubleArray48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector44.subtract(openMapRealVector54);
        double[] doubleArray59 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector44.append(doubleArray59);
        try {
            openMapRealVector40.setSubVector(100, (org.apache.commons.math.linear.RealVector) openMapRealVector61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(openMapRealVector61);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) -1, 1.9459101490553132d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4747043615871866d) + "'", double2 == (-0.4747043615871866d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-127));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 127.0f + "'", float1 == 127.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector2.append(openMapRealVector41);
        double[] doubleArray43 = openMapRealVector2.getData();
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray47, 0.0d);
        try {
            double double52 = openMapRealVector2.getDistance(doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray15 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector11.add(doubleArray15);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector11.subtract(openMapRealVector21);
        double[] doubleArray26 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector11.append(doubleArray26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector33.add(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector28.combineToSelf(0.0d, 0.7615941559557649d, doubleArray37);
        try {
            double[] doubleArray42 = array2DRowRealMatrix5.operate(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(openMapRealVector28);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) "");
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor9, (int) '#', 0, (int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        double double14 = openMapRealVector12.getLInfNorm();
        int int15 = openMapRealVector12.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 1.0f);
        double double3 = openIntToDoubleHashMap1.get((int) ' ');
        boolean boolean5 = openIntToDoubleHashMap1.containsKey(52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap37 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap38 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap37);
        boolean boolean39 = openMapRealVector25.equals((java.lang.Object) openIntToDoubleHashMap38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray46 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector42.add(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector42.subtract(openMapRealVector52);
        double[] doubleArray54 = openMapRealVector42.getData();
        double double55 = openMapRealVector25.getDistance(openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray62 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector58.add(doubleArray62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = openMapRealVector58.subtract(openMapRealVector68);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray76 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math.linear.RealVector realVector79 = openMapRealVector72.add(doubleArray76);
        double double80 = openMapRealVector58.dotProduct(openMapRealVector72);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector85 = openMapRealVector83.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector86 = openMapRealVector58.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector83);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector89 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray93 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix94 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray93);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix95 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray93);
        org.apache.commons.math.linear.RealVector realVector96 = openMapRealVector89.add(doubleArray93);
        org.apache.commons.math.linear.RealVector realVector97 = openMapRealVector86.add(doubleArray93);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector98 = openMapRealVector42.append(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(openMapRealVector69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(openMapRealVector86);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(realVector96);
        org.junit.Assert.assertNotNull(realVector97);
        org.junit.Assert.assertNotNull(openMapRealVector98);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix((int) (short) 0);
        java.lang.Class<?> wildcardClass17 = realMatrix16.getClass();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 6, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int2 = org.apache.commons.math.util.FastMath.max(100, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double[][] doubleArray15 = array2DRowRealMatrix5.getData();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double17 = array2DRowRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.40872429885248984d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4087242988524898d + "'", double2 == 0.4087242988524898d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 6, (java.lang.Number) (short) 1, (java.lang.Number) 1.3440585709080678E43d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector10.add(doubleArray14);
        try {
            array2DRowRealMatrix5.setColumn(0, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 3x1 but expected 10x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector33.add(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector33.subtract(openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray51 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector47.add(doubleArray51);
        double double55 = openMapRealVector33.dotProduct(openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector33);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray70 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.RealVector realVector73 = openMapRealVector66.add(doubleArray70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = openMapRealVector66.subtract(openMapRealVector76);
        org.apache.commons.math.linear.RealVector realVector78 = openMapRealVector61.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray85 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math.linear.RealVector realVector88 = openMapRealVector81.add(doubleArray85);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector91 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector92 = openMapRealVector81.subtract(openMapRealVector91);
        double[] doubleArray93 = openMapRealVector81.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector94 = openMapRealVector61.ebeDivide(doubleArray93);
        org.apache.commons.math.linear.RealVector realVector95 = openMapRealVector33.combineToSelf((double) 100.0f, (double) (-1), doubleArray93);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector96 = openMapRealVector30.subtract(openMapRealVector33);
        org.apache.commons.math.linear.RealVector realVector98 = openMapRealVector33.mapSubtract((double) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertNotNull(openMapRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(realVector88);
        org.junit.Assert.assertNotNull(openMapRealVector92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(openMapRealVector94);
        org.junit.Assert.assertNotNull(realVector95);
        org.junit.Assert.assertNotNull(openMapRealVector96);
        org.junit.Assert.assertNotNull(realVector98);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-127), (java.lang.Number) (-2.351336525445773E-13d), number3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        boolean boolean8 = array2DRowRealMatrix5.equals((java.lang.Object) (byte) 100);
        int int9 = array2DRowRealMatrix5.getColumnDimension();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        try {
            double[] doubleArray17 = array2DRowRealMatrix10.operate(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix8.walkInOptimizedOrder(realMatrixChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 35L, 0.40872429885248984d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.getSubMatrix((int) (byte) 100, (int) 'a', (-1), 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 100L, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) (byte) 100, (java.lang.Number) 4.9E-324d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) 1.0f, (java.lang.Number) 0.0d);
        java.lang.String str8 = outOfRangeException7.toString();
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range" + "'", str8.equals("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double2 = org.apache.commons.math.util.FastMath.hypot(4.641588833612779d, 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.06997501805306d + "'", double2 == 11.06997501805306d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray43 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector39.add(doubleArray43);
        double double47 = openMapRealVector25.dotProduct(openMapRealVector39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector50.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector25.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray60 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math.linear.RealVector realVector63 = openMapRealVector56.add(doubleArray60);
        org.apache.commons.math.linear.RealVector realVector64 = openMapRealVector53.add(doubleArray60);
        try {
            double[] doubleArray65 = array2DRowRealMatrix2.preMultiply(doubleArray60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertNotNull(realVector64);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix2.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix6.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix13.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = array2DRowRealMatrix9.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix2.add(array2DRowRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 52x1 but expected 10x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int2 = org.apache.commons.math.util.FastMath.min((-127), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-127) + "'", int2 == (-127));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix5.multiply(array2DRowRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 10L, (-1) };
        double[] doubleArray6 = new double[] { 10L, (-1) };
        double[] doubleArray9 = new double[] { 10L, (-1) };
        double[] doubleArray12 = new double[] { 10L, (-1) };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, true);
        double[][] doubleArray18 = array2DRowRealMatrix17.getDataRef();
        int[] intArray21 = new int[] { (byte) 10, (byte) -1 };
        int[] intArray25 = new int[] { '#', (-127), (byte) 1 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix17.getSubMatrix(intArray21, intArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector9.add(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector9.subtract(openMapRealVector19);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector4.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector29.add(doubleArray33);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = openMapRealVector29.subtract(openMapRealVector39);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector24.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector40);
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector4.projection((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector4.append(openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector44.mapDivideToSelf((double) (byte) 10);
        try {
            org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector1.projection((org.apache.commons.math.linear.RealVector) openMapRealVector44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(openMapRealVector40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(realVector46);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        try {
            openMapRealVector12.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix5.getRowMatrix((int) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector20.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray44 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector40.add(doubleArray44);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector40.subtract(openMapRealVector50);
        double[] doubleArray52 = openMapRealVector40.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector20.ebeDivide(doubleArray52);
        try {
            array2DRowRealMatrix5.setColumn(6, doubleArray52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 10x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(openMapRealVector53);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        double[] doubleArray18 = new double[] { (-1.0f), (-1.0f), 1.0E-12d, 6 };
        try {
            double double19 = openMapRealVector13.getDistance(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        try {
            double double10 = array2DRowRealMatrix8.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-127L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 0L);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        try {
            iterator2.advance();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, (int) (byte) 100);
        int int3 = openMapRealVector2.getMinIndex();
        double double4 = openMapRealVector2.getMaxValue();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        double[] doubleArray19 = openMapRealVector7.getData();
        try {
            double double20 = openMapRealVector2.cosine(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap3 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap2);
        double double5 = openIntToDoubleHashMap3.remove((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap3 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap2);
        double double6 = openIntToDoubleHashMap3.put((-1), (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix12.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix8.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        java.lang.Object obj18 = null;
        boolean boolean19 = array2DRowRealMatrix8.equals(obj18);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix8.scalarAdd((double) 0L);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix2.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 52");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.009999666686665238d), (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.999666653335238E-5d) + "'", double2 == (-9.999666653335238E-5d));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 1.0000001f, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000001192092896d + "'", double2 == 1.0000001192092896d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.combineToSelf(0.0d, (double) (-127), (org.apache.commons.math.linear.RealVector) openMapRealVector3);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector7.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector7.append(openMapRealVector46);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector3.projection((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix55 = array2DRowRealMatrix51.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix58.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix61);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix69 = array2DRowRealMatrix65.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix68);
        org.apache.commons.math.linear.RealMatrix realMatrix70 = array2DRowRealMatrix61.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix68);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = array2DRowRealMatrix51.subtract(array2DRowRealMatrix68);
        double[] doubleArray73 = array2DRowRealMatrix71.getColumn(1);
        try {
            double double74 = openMapRealVector3.cosine(doubleArray73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix71);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 10L, (-1) };
        double[] doubleArray6 = new double[] { 10L, (-1) };
        double[] doubleArray9 = new double[] { 10L, (-1) };
        double[] doubleArray12 = new double[] { 10L, (-1) };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.scalarAdd((double) 0);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix23.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix26);
        double[][] doubleArray28 = array2DRowRealMatrix23.getData();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, (java.lang.Object[]) doubleArray28);
        try {
            array2DRowRealMatrix17.setSubMatrix(doubleArray28, 52, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, (int) (byte) 100);
        double[] doubleArray3 = null;
        try {
            double double4 = openMapRealVector2.cosine(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        int int20 = openMapRealVector2.getMinIndex();
        boolean boolean21 = openMapRealVector2.isInfinite();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor22 = openMapRealVector2.iterator();
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(entryItor22);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray24 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector20.add(doubleArray24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector20.subtract(openMapRealVector30);
        double[] doubleArray35 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector20.append(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray46 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector42.add(doubleArray46);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector37.combineToSelf(0.0d, 0.7615941559557649d, doubleArray46);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector17.add(openMapRealVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(entryItor35);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        array2DRowRealMatrix19.multiplyEntry(1, (int) 'a', 6.0d);
        double[][] doubleArray27 = array2DRowRealMatrix19.getData();
        double[] doubleArray28 = null;
        try {
            double[] doubleArray29 = array2DRowRealMatrix19.operate(doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) '#');
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.scalarMultiply(Double.POSITIVE_INFINITY);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        try {
            double[] doubleArray16 = array2DRowRealMatrix2.preMultiply(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        try {
            double double25 = array2DRowRealMatrix22.getEntry(35, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(realVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(realVector19);
        double[] doubleArray22 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector21.append(doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector2);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray39 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector35.add(doubleArray39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector35.subtract(openMapRealVector45);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector30.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector50.add(doubleArray54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector50.subtract(openMapRealVector60);
        double[] doubleArray62 = openMapRealVector50.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector30.ebeDivide(doubleArray62);
        org.apache.commons.math.linear.RealVector realVector64 = openMapRealVector2.combineToSelf((double) 100.0f, (double) (-1), doubleArray62);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction65 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector66 = openMapRealVector2.map(univariateRealFunction65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(openMapRealVector46);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(realVector64);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        array2DRowRealMatrix2.multiplyEntry(0, (int) 'a', (double) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor8, 10, (int) (byte) 1, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector20.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray49 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector45.add(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector45.subtract(openMapRealVector55);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector40.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector20.projection((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        double double59 = openMapRealVector5.getDistance(openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray66 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray66);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray66);
        org.apache.commons.math.linear.RealVector realVector69 = openMapRealVector62.add(doubleArray66);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray66);
        try {
            double double71 = openMapRealVector40.dotProduct(doubleArray66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realVector69);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        boolean boolean6 = array2DRowRealMatrix4.equals((java.lang.Object) (-0.9974947163822921d));
        java.lang.String str7 = array2DRowRealMatrix4.toString();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix4.walkInRowOrder(realMatrixChangingVisitor8, 0, (int) '4', (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}" + "'", str7.equals("Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector2.append(openMapRealVector41);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix45.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix56 = array2DRowRealMatrix52.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix55);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix63 = array2DRowRealMatrix59.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = array2DRowRealMatrix55.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix45.subtract(array2DRowRealMatrix62);
        int int66 = array2DRowRealMatrix45.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector68 = array2DRowRealMatrix45.getRowVector((int) (byte) 1);
        try {
            double double69 = openMapRealVector41.getL1Distance(realVector68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
        org.junit.Assert.assertNotNull(realVector68);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap37 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap38 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap37);
        boolean boolean39 = openMapRealVector25.equals((java.lang.Object) openIntToDoubleHashMap38);
        boolean boolean41 = openIntToDoubleHashMap38.containsKey(10);
        double double43 = openIntToDoubleHashMap38.get((int) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap3 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap2);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap3.iterator();
        double double6 = openIntToDoubleHashMap3.remove((-127));
        org.junit.Assert.assertNotNull(iterator4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        openMapRealVector13.set(100.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector18.add(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector18.subtract(openMapRealVector28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        double double40 = openMapRealVector18.dotProduct(openMapRealVector32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector43.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector18.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray58 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58);
        org.apache.commons.math.linear.RealVector realVector61 = openMapRealVector54.add(doubleArray58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = openMapRealVector54.subtract(openMapRealVector64);
        org.apache.commons.math.linear.RealVector realVector66 = openMapRealVector49.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector65);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray78 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.RealVector realVector81 = openMapRealVector74.add(doubleArray78);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = openMapRealVector74.subtract(openMapRealVector84);
        org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector69.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector85);
        org.apache.commons.math.linear.RealVector realVector87 = openMapRealVector49.projection((org.apache.commons.math.linear.RealVector) openMapRealVector69);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector88 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector89 = openMapRealVector49.append(openMapRealVector88);
        double[] doubleArray90 = openMapRealVector49.getData();
        double double91 = openMapRealVector46.getLInfDistance(doubleArray90);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector92 = openMapRealVector13.projection(doubleArray90);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector94 = openMapRealVector13.append(35.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector46);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertNotNull(openMapRealVector65);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(openMapRealVector85);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(realVector87);
        org.junit.Assert.assertNotNull(openMapRealVector89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector92);
        org.junit.Assert.assertNotNull(openMapRealVector94);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 0.40872429885248984d, 1.3440585709080678E43d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray2, (double) 0.0f);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (byte) 10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.scalarMultiply(6.0d);
        double[] doubleArray14 = null;
        try {
            array2DRowRealMatrix10.setRow(10, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.4087242988524898d, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.228504600082091E-21d + "'", double2 == 6.228504600082091E-21d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            org.apache.commons.math.linear.RealVector realVector8 = array2DRowRealMatrix2.getRowVector((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0000001192092896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 52, (double) 0L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double[] doubleArray2 = new double[] { 1.9459101490553132d, (short) 10 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray2, (double) (-1.0f));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector4);
        org.apache.commons.math.linear.RealVector realVector6 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector4.add(realVector6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[][] doubleArray23 = array2DRowRealMatrix18.getData();
        array2DRowRealMatrix5.setSubMatrix(doubleArray23, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix5.transpose();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor28 = null;
        try {
            double double33 = array2DRowRealMatrix5.walkInRowOrder(realMatrixChangingVisitor28, 1, (int) (short) 100, (int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector33.add(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector30.add(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray48 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector44.add(doubleArray48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector44.subtract(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray62 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector58.add(doubleArray62);
        double double66 = openMapRealVector44.dotProduct(openMapRealVector58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray78 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.RealVector realVector81 = openMapRealVector74.add(doubleArray78);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = openMapRealVector74.subtract(openMapRealVector84);
        org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector69.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector85);
        int int87 = openMapRealVector69.getMinIndex();
        double double88 = openMapRealVector58.getL1Distance(openMapRealVector69);
        org.apache.commons.math.linear.RealVector realVector90 = openMapRealVector58.mapSubtractToSelf(3.1622776601683795d);
        double double91 = openMapRealVector30.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector58);
        try {
            double double93 = openMapRealVector30.getEntry(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(openMapRealVector85);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 10L, (-1) };
        double[] doubleArray6 = new double[] { 10L, (-1) };
        double[] doubleArray9 = new double[] { 10L, (-1) };
        double[] doubleArray12 = new double[] { 10L, (-1) };
        double[][] doubleArray13 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray24 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector20.add(doubleArray24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector20.subtract(openMapRealVector30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector34.add(doubleArray38);
        double double42 = openMapRealVector20.dotProduct(openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector45.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector50.add(doubleArray54);
        double double58 = openMapRealVector45.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector50);
        double double59 = openMapRealVector34.getL1Distance(openMapRealVector50);
        try {
            org.apache.commons.math.linear.RealVector realVector60 = array2DRowRealMatrix17.preMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.scalarMultiply(6.0d);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix10.getColumnMatrix((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        double[] doubleArray10 = new double[] { 10L, (-1) };
        double[] doubleArray13 = new double[] { 10L, (-1) };
        double[] doubleArray16 = new double[] { 10L, (-1) };
        double[] doubleArray19 = new double[] { 10L, (-1) };
        double[][] doubleArray20 = new double[][] { doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) doubleArray20);
        boolean boolean23 = array2DRowRealMatrix5.equals((java.lang.Object) localizable7);
        try {
            double[] doubleArray25 = array2DRowRealMatrix5.getRow((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction18 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.map(univariateRealFunction18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        try {
            double double42 = openMapRealVector2.getEntry(35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix10.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix6.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
        int int16 = array2DRowRealMatrix6.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = array2DRowRealMatrix19.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        double[][] doubleArray24 = array2DRowRealMatrix19.getData();
        array2DRowRealMatrix6.setSubMatrix(doubleArray24, 0, (int) (byte) 0);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) 10, (double) 1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator3 = openIntToDoubleHashMap2.iterator();
        org.junit.Assert.assertNotNull(iterator3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 100.0f, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.0000001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector33.add(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector33.subtract(openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray51 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector47.add(doubleArray51);
        double double55 = openMapRealVector33.dotProduct(openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector33);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray70 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.RealVector realVector73 = openMapRealVector66.add(doubleArray70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = openMapRealVector66.subtract(openMapRealVector76);
        org.apache.commons.math.linear.RealVector realVector78 = openMapRealVector61.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray85 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math.linear.RealVector realVector88 = openMapRealVector81.add(doubleArray85);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector91 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector92 = openMapRealVector81.subtract(openMapRealVector91);
        double[] doubleArray93 = openMapRealVector81.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector94 = openMapRealVector61.ebeDivide(doubleArray93);
        org.apache.commons.math.linear.RealVector realVector95 = openMapRealVector33.combineToSelf((double) 100.0f, (double) (-1), doubleArray93);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector96 = openMapRealVector30.subtract(openMapRealVector33);
        org.apache.commons.math.linear.RealVector realVector98 = openMapRealVector96.mapSubtractToSelf((double) 127.0f);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertNotNull(openMapRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(realVector88);
        org.junit.Assert.assertNotNull(openMapRealVector92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(openMapRealVector94);
        org.junit.Assert.assertNotNull(realVector95);
        org.junit.Assert.assertNotNull(openMapRealVector96);
        org.junit.Assert.assertNotNull(realVector98);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.mapAddToSelf(4.9E-324d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction18 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.mapToSelf(univariateRealFunction18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((-127), 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -127 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.acos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.asin(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap37 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap38 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap37);
        boolean boolean39 = openMapRealVector25.equals((java.lang.Object) openIntToDoubleHashMap38);
        boolean boolean41 = openIntToDoubleHashMap38.containsKey(10);
        boolean boolean43 = openIntToDoubleHashMap38.containsKey((int) (short) -1);
        int int44 = openIntToDoubleHashMap38.size();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        int int50 = array2DRowRealMatrix46.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix53.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix56);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = array2DRowRealMatrix60.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix63);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix71 = array2DRowRealMatrix67.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix70);
        org.apache.commons.math.linear.RealMatrix realMatrix72 = array2DRowRealMatrix63.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix70);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = array2DRowRealMatrix53.subtract(array2DRowRealMatrix70);
        double[][] doubleArray74 = array2DRowRealMatrix53.getDataRef();
        try {
            array2DRowRealMatrix46.setSubMatrix(doubleArray74, (int) ' ', (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(realMatrix72);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix73);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix25.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix32.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix35);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix28.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix35);
        double[][] doubleArray38 = array2DRowRealMatrix28.getData();
        double double39 = array2DRowRealMatrix28.getNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix40 = array2DRowRealMatrix2.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[][] doubleArray23 = array2DRowRealMatrix18.getData();
        array2DRowRealMatrix5.setSubMatrix(doubleArray23, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double32 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixPreservingVisitor27, (int) (short) 0, (int) (short) 0, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: initial column 6 after final column 0");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        double double50 = array2DRowRealMatrix46.getFrobeniusNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix60 = array2DRowRealMatrix56.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix59);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix67 = array2DRowRealMatrix63.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix66);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix74 = array2DRowRealMatrix70.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix73);
        org.apache.commons.math.linear.RealMatrix realMatrix75 = array2DRowRealMatrix66.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix73);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = array2DRowRealMatrix56.subtract(array2DRowRealMatrix73);
        org.apache.commons.math.linear.RealMatrix realMatrix77 = array2DRowRealMatrix53.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix56);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix46.multiply(array2DRowRealMatrix53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix76);
        org.junit.Assert.assertNotNull(realMatrix77);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix12.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = array2DRowRealMatrix19.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix15.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix22);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        try {
            double double29 = array2DRowRealMatrix5.getEntry((int) (byte) 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        org.apache.commons.math.linear.RealVector realVector12 = array2DRowRealMatrix8.getRowVector(1);
        try {
            double[] doubleArray14 = array2DRowRealMatrix8.getRow((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix4.walkInColumnOrder(realMatrixChangingVisitor5, 100, 0, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double20 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor15, 100, 100, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        java.lang.Double[] doubleArray24 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray24, 4.641588833612779d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector34.add(doubleArray38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector34.subtract(openMapRealVector44);
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector29.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector45);
        int int47 = openMapRealVector29.getMinIndex();
        boolean boolean48 = openMapRealVector29.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector51.add(doubleArray55);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = openMapRealVector51.subtract(openMapRealVector61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector29.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector26.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector64);
        try {
            array2DRowRealMatrix22.setColumnVector(52, (org.apache.commons.math.linear.RealVector) openMapRealVector65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 10x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(openMapRealVector62);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(openMapRealVector64);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        double double40 = openMapRealVector27.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double double41 = openMapRealVector16.getL1Distance(openMapRealVector32);
        try {
            double double43 = openMapRealVector32.getEntry((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector33.add(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector33.subtract(openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray51 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector47.add(doubleArray51);
        double double55 = openMapRealVector33.dotProduct(openMapRealVector47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector33);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray70 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.RealVector realVector73 = openMapRealVector66.add(doubleArray70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = openMapRealVector66.subtract(openMapRealVector76);
        org.apache.commons.math.linear.RealVector realVector78 = openMapRealVector61.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray85 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math.linear.RealVector realVector88 = openMapRealVector81.add(doubleArray85);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector91 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector92 = openMapRealVector81.subtract(openMapRealVector91);
        double[] doubleArray93 = openMapRealVector81.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector94 = openMapRealVector61.ebeDivide(doubleArray93);
        org.apache.commons.math.linear.RealVector realVector95 = openMapRealVector33.combineToSelf((double) 100.0f, (double) (-1), doubleArray93);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector96 = openMapRealVector30.subtract(openMapRealVector33);
        org.apache.commons.math.linear.RealVector realVector98 = openMapRealVector33.mapSubtract(0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertNotNull(openMapRealVector77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(realVector88);
        org.junit.Assert.assertNotNull(openMapRealVector92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(openMapRealVector94);
        org.junit.Assert.assertNotNull(realVector95);
        org.junit.Assert.assertNotNull(openMapRealVector96);
        org.junit.Assert.assertNotNull(realVector98);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) 10, (double) 1);
        int int3 = openIntToDoubleHashMap2.size();
        double double6 = openIntToDoubleHashMap2.put((int) (short) 10, (double) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor7, (-1), (int) (byte) 10, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        double double40 = openMapRealVector27.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double double41 = openMapRealVector16.getL1Distance(openMapRealVector32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray53 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        org.apache.commons.math.linear.RealVector realVector56 = openMapRealVector49.add(doubleArray53);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector49.subtract(openMapRealVector59);
        org.apache.commons.math.linear.RealVector realVector61 = openMapRealVector44.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector60);
        int int62 = openMapRealVector44.getMinIndex();
        boolean boolean63 = openMapRealVector44.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray70 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math.linear.RealVector realVector73 = openMapRealVector66.add(doubleArray70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector76 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = openMapRealVector66.subtract(openMapRealVector76);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector44.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector76);
        double double79 = openMapRealVector16.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector78);
        boolean boolean80 = openMapRealVector16.isNaN();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertNotNull(openMapRealVector77);
        org.junit.Assert.assertNotNull(openMapRealVector78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(6, (int) (short) 1);
        try {
            openMapRealVector2.setEntry((int) (short) 10, (-9.999666653335238E-5d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix12.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = array2DRowRealMatrix19.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix15.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix22);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double32 = array2DRowRealMatrix5.walkInOptimizedOrder(realMatrixPreservingVisitor27, 0, (int) (short) 10, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 52);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 1.0f);
        boolean boolean3 = openIntToDoubleHashMap1.containsKey(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[][] doubleArray23 = array2DRowRealMatrix18.getData();
        array2DRowRealMatrix5.setSubMatrix(doubleArray23, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix5.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = array2DRowRealMatrix30.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix37.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        org.apache.commons.math.linear.RealMatrix realMatrix42 = array2DRowRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix40);
        java.lang.Object obj43 = null;
        boolean boolean44 = array2DRowRealMatrix33.equals(obj43);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix5.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[][] doubleArray23 = array2DRowRealMatrix18.getData();
        array2DRowRealMatrix5.setSubMatrix(doubleArray23, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix5.transpose();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix5.getSubMatrix(52, (int) (byte) 10, (int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7031839360032603E-108d + "'", double1 == 1.7031839360032603E-108d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        array2DRowRealMatrix19.multiplyEntry(1, (int) 'a', 6.0d);
        double[][] doubleArray27 = array2DRowRealMatrix19.getData();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix19.getRowMatrix((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        int int10 = array2DRowRealMatrix8.getColumnDimension();
        java.lang.String str11 = array2DRowRealMatrix8.toString();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(10, 100, (double) (short) 0);
        double[] doubleArray17 = openMapRealVector16.getData();
        try {
            array2DRowRealMatrix8.setRow((int) (short) 0, doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x10 but expected 1x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str11.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 0L);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        boolean boolean3 = iterator2.hasNext();
        try {
            iterator2.advance();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10, (double) 6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor4, (int) 'a', (int) ' ', 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector2.append(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray28 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector24.add(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector19.combineToSelf(0.0d, 0.7615941559557649d, doubleArray28);
        double[] doubleArray34 = null;
        try {
            openMapRealVector19.setSubVector((int) '#', doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector2);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray39 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector35.add(doubleArray39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector35.subtract(openMapRealVector45);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector30.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector50.add(doubleArray54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector50.subtract(openMapRealVector60);
        double[] doubleArray62 = openMapRealVector50.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector30.ebeDivide(doubleArray62);
        org.apache.commons.math.linear.RealVector realVector64 = openMapRealVector2.combineToSelf((double) 100.0f, (double) (-1), doubleArray62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(openMapRealVector46);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(realVector64);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.5707963267948966d), 6.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3132616875182228d + "'", double1 == 1.3132616875182228d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        int int15 = array2DRowRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix18.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
        double[][] doubleArray23 = array2DRowRealMatrix18.getData();
        array2DRowRealMatrix5.setSubMatrix(doubleArray23, 0, (int) (byte) 0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix5.walkInRowOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector33.add(doubleArray37);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector30.add(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray48 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector44.add(doubleArray48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector44.subtract(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray62 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector58.add(doubleArray62);
        double double66 = openMapRealVector44.dotProduct(openMapRealVector58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray78 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math.linear.RealVector realVector81 = openMapRealVector74.add(doubleArray78);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector85 = openMapRealVector74.subtract(openMapRealVector84);
        org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector69.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector85);
        int int87 = openMapRealVector69.getMinIndex();
        double double88 = openMapRealVector58.getL1Distance(openMapRealVector69);
        org.apache.commons.math.linear.RealVector realVector90 = openMapRealVector58.mapSubtractToSelf(3.1622776601683795d);
        double double91 = openMapRealVector30.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector58);
        double double92 = openMapRealVector30.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(openMapRealVector85);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertEquals((double) double92, Double.NaN, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        boolean boolean6 = array2DRowRealMatrix4.equals((java.lang.Object) (-0.9974947163822921d));
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix4.scalarMultiply((double) 127.0f);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector2.mapAddToSelf(10.04987562112089d);
        openMapRealVector32.set((double) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector37.add(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector32.append(doubleArray41);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction46 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector45.mapToSelf(univariateRealFunction46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(openMapRealVector45);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.mapAddToSelf(4.9E-324d);
        double[] doubleArray18 = openMapRealVector12.getData();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray9 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector5.add(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector5.subtract(openMapRealVector15);
        double double17 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector25.subtract(openMapRealVector35);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector20.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray49 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector45.add(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector45.subtract(openMapRealVector55);
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector40.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector56);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector20.projection((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        double double59 = openMapRealVector5.getDistance(openMapRealVector40);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction60 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector61 = openMapRealVector5.mapToSelf(univariateRealFunction60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.9E-324d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (-1.0f), 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.503599627370496E15d) + "'", double2 == (-4.503599627370496E15d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 1, 11.06997501805306d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09008991760634888d + "'", double2 == 0.09008991760634888d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector2.mapMultiply(4.64158883361278d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray18 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector14.add(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = openMapRealVector14.subtract(openMapRealVector24);
        org.apache.commons.math.linear.RealVector realVector26 = openMapRealVector9.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector25);
        int int27 = openMapRealVector9.getMinIndex();
        boolean boolean28 = openMapRealVector9.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray35 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.RealVector realVector38 = openMapRealVector31.add(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector31.subtract(openMapRealVector41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector9.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector2.add((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        double[] doubleArray45 = openMapRealVector41.toArray();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray57 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector53.add(doubleArray57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector53.subtract(openMapRealVector63);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector48.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector64);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray77 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray77);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray77);
        org.apache.commons.math.linear.RealVector realVector80 = openMapRealVector73.add(doubleArray77);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector84 = openMapRealVector73.subtract(openMapRealVector83);
        org.apache.commons.math.linear.RealVector realVector85 = openMapRealVector68.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector84);
        org.apache.commons.math.linear.RealVector realVector86 = openMapRealVector48.projection((org.apache.commons.math.linear.RealVector) openMapRealVector68);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector87 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector88 = openMapRealVector48.append(openMapRealVector87);
        org.apache.commons.math.linear.RealVector realVector90 = openMapRealVector88.mapDivideToSelf((double) (byte) 10);
        double double91 = openMapRealVector41.dotProduct(openMapRealVector88);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(openMapRealVector25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(openMapRealVector84);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertNotNull(openMapRealVector88);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6900760708753189d + "'", double1 == 0.6900760708753189d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[][] doubleArray23 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double29 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor24, (int) (byte) 10, 100, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.9459101490553132d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double[] doubleArray3 = new double[] { 'a', 1.0000001192092896d, 1.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray3);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(realVector24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector(realVector24);
        try {
            org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector4.add(realVector24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[][] doubleArray23 = array2DRowRealMatrix2.getDataRef();
        double[] doubleArray24 = null;
        try {
            double[] doubleArray25 = array2DRowRealMatrix2.preMultiply(doubleArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (int) ' ', (int) ' ');
        int int4 = dimensionMismatchException3.getDimension();
        int int5 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray0, 4.641588833612779d);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapDivide((double) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.41078129050290885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.34414365766927546d + "'", double1 == 0.34414365766927546d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int1 = org.apache.commons.math.util.FastMath.round(127.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 127 + "'", int1 == 127);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        int int45 = openMapRealVector27.getMinIndex();
        double double46 = openMapRealVector16.getL1Distance(openMapRealVector27);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector16.mapSubtractToSelf(3.1622776601683795d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector16.append(openMapRealVector49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(realVector48);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        java.lang.Object obj15 = null;
        boolean boolean16 = array2DRowRealMatrix5.equals(obj15);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor17 = null;
        try {
            double double22 = array2DRowRealMatrix5.walkInRowOrder(realMatrixPreservingVisitor17, (int) 'a', 100, (int) (short) -1, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.3132616875182228d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8386585145575496d + "'", double1 == 0.8386585145575496d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = array2DRowRealMatrix46.scalarMultiply(0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        array2DRowRealMatrix22.addToEntry(0, 32, Double.NaN);
        try {
            org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix22.getRowVector(127);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        int int50 = array2DRowRealMatrix46.getRowDimension();
        try {
            double double51 = array2DRowRealMatrix46.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 127);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 127.0d + "'", double1 == 127.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1L, (java.lang.Number) (-1.0d), (java.lang.Number) 100.0d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double[] doubleArray2 = new double[] { 10L, (-1) };
        double[] doubleArray5 = new double[] { 10L, (-1) };
        double[] doubleArray8 = new double[] { 10L, (-1) };
        double[] doubleArray11 = new double[] { 10L, (-1) };
        double[][] doubleArray12 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        boolean boolean22 = array2DRowRealMatrix19.equals((java.lang.Object) "");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 4x2 but expected 10x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        int int10 = array2DRowRealMatrix8.getColumnDimension();
        java.lang.String str11 = array2DRowRealMatrix8.toString();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix8.power((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str11.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double[] doubleArray2 = new double[] { 1.9459101490553132d, (short) 10 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray2, (double) (-1.0f));
        java.lang.Class<?> wildcardClass5 = doubleArray2.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        double[] doubleArray21 = new double[] { 'a', 1.0000001192092896d, 1.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray21, (-9.999666653335238E-5d));
        try {
            double double25 = openMapRealVector12.getLInfDistance(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0, (-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.41032129904824216d) + "'", double2 == (-0.41032129904824216d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10L, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector((int) 'a', (int) (byte) 1, (double) 20.0f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray12 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector8.add(doubleArray12);
        try {
            org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector3.combineToSelf(0.0d, (double) (byte) 100, (org.apache.commons.math.linear.RealVector) openMapRealVector8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap37 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap38 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap37);
        boolean boolean39 = openMapRealVector25.equals((java.lang.Object) openIntToDoubleHashMap38);
        boolean boolean41 = openIntToDoubleHashMap38.containsKey(10);
        boolean boolean43 = openIntToDoubleHashMap38.containsKey((int) (short) -1);
        boolean boolean45 = openIntToDoubleHashMap38.containsKey((int) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[] doubleArray24 = array2DRowRealMatrix22.getColumn(1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        double[][] doubleArray26 = array2DRowRealMatrix25.getDataRef();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math.util.FastMath.asinh(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.log(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        try {
            array2DRowRealMatrix2.setEntry((int) '#', (-1), 2.6881171418161356E43d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector2.append(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray28 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector24.add(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector19.combineToSelf(0.0d, 0.7615941559557649d, doubleArray28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray39 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector35.add(doubleArray39);
        try {
            org.apache.commons.math.linear.RealVector realVector43 = openMapRealVector19.add((org.apache.commons.math.linear.RealVector) openMapRealVector35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector2.mapMultiply(4.64158883361278d);
        double double7 = openMapRealVector2.getL1Norm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray19 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector15.add(doubleArray19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector15.subtract(openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector10.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray39 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector35.add(doubleArray39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector35.subtract(openMapRealVector45);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector30.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector46);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector10.projection((org.apache.commons.math.linear.RealVector) openMapRealVector30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector10.append(openMapRealVector49);
        double[] doubleArray51 = openMapRealVector10.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector2.subtract(doubleArray51);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(openMapRealVector26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(openMapRealVector46);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(openMapRealVector53);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1), 100);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, 0);
        int int6 = dimensionMismatchException5.getDimension();
        int int7 = dimensionMismatchException5.getDimension();
        dimensionMismatchException2.addSuppressed((java.lang.Throwable) dimensionMismatchException5);
        int int9 = dimensionMismatchException5.getDimension();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 100, (-127), (double) (-127L));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray10 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector6.add(doubleArray10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector6.subtract(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray24 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector20.add(doubleArray24);
        double double28 = openMapRealVector6.dotProduct(openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector31.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = openMapRealVector6.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector6.mapAddToSelf(10.04987562112089d);
        openMapRealVector36.set((double) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray45 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector41.add(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector36.append(doubleArray45);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector3.projection(doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(openMapRealVector34);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        int int20 = openMapRealVector2.getMinIndex();
        boolean boolean21 = openMapRealVector2.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray28 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector24.add(doubleArray28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector24.subtract(openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector2.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector34);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector2.getSubVector((int) (short) -1, 127);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(openMapRealVector36);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray26 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector22.add(doubleArray26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector22.subtract(openMapRealVector32);
        double[] doubleArray34 = openMapRealVector22.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector2.ebeDivide(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector43.add(doubleArray47);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector43.subtract(openMapRealVector53);
        org.apache.commons.math.linear.RealVector realVector55 = openMapRealVector38.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray62 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector58.add(doubleArray62);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = openMapRealVector58.subtract(openMapRealVector68);
        double[] doubleArray70 = openMapRealVector58.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = openMapRealVector38.ebeDivide(doubleArray70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray70, (-0.41032129904824216d));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray70);
        double double75 = openMapRealVector35.getDistance(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(openMapRealVector69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(openMapRealVector71);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 10, (java.lang.Number) 100, (java.lang.Number) 35);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 10 + "'", number4.equals((byte) 10));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        int int10 = array2DRowRealMatrix8.getColumnDimension();
        java.lang.String str11 = array2DRowRealMatrix8.toString();
        double[][] doubleArray12 = array2DRowRealMatrix8.getData();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str11.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 6);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8386585145575496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9404858210416758d + "'", double1 == 0.9404858210416758d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = openMapRealMatrix2.createMatrix(10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix33.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix40.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix36.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = array2DRowRealMatrix26.subtract(array2DRowRealMatrix43);
        double[] doubleArray48 = array2DRowRealMatrix46.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        double double50 = array2DRowRealMatrix46.getFrobeniusNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray57 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector53.add(doubleArray57);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector53.subtract(openMapRealVector63);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray71 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math.linear.RealVector realVector74 = openMapRealVector67.add(doubleArray71);
        double double75 = openMapRealVector53.dotProduct(openMapRealVector67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector80 = openMapRealVector78.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = openMapRealVector53.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector78);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = openMapRealVector53.mapAddToSelf(10.04987562112089d);
        org.apache.commons.math.linear.RealVector realVector85 = openMapRealVector53.mapMultiply(3.0d);
        boolean boolean86 = array2DRowRealMatrix46.equals((java.lang.Object) realVector85);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(openMapRealVector81);
        org.junit.Assert.assertNotNull(openMapRealVector83);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix12.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = array2DRowRealMatrix19.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix15.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix22);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix26 = openMapRealMatrix2.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 97 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double[] doubleArray2 = new double[] { 10L, (-1) };
        double[] doubleArray5 = new double[] { 10L, (-1) };
        double[] doubleArray8 = new double[] { 10L, (-1) };
        double[] doubleArray11 = new double[] { 10L, (-1) };
        double[][] doubleArray12 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix13.createMatrix(52, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[][] doubleArray23 = array2DRowRealMatrix2.getDataRef();
        try {
            org.apache.commons.math.linear.RealVector realVector25 = array2DRowRealMatrix2.getRowVector((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        boolean boolean6 = array2DRowRealMatrix4.equals((java.lang.Object) (-0.9974947163822921d));
        java.lang.String str7 = array2DRowRealMatrix4.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix10.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix17.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix24.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix27);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix20.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix27);
        int int31 = array2DRowRealMatrix10.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix34.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix41.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix52 = array2DRowRealMatrix48.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix51);
        org.apache.commons.math.linear.RealMatrix realMatrix53 = array2DRowRealMatrix44.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix51);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = array2DRowRealMatrix34.subtract(array2DRowRealMatrix51);
        double[] doubleArray56 = array2DRowRealMatrix54.getColumn(1);
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix10.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix54);
        int int58 = array2DRowRealMatrix54.getRowDimension();
        double[][] doubleArray59 = array2DRowRealMatrix54.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59);
        try {
            array2DRowRealMatrix4.setSubMatrix(doubleArray59, 0, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}" + "'", str7.equals("Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}"));
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 10 + "'", int58 == 10);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector2.mapAddToSelf(10.04987562112089d);
        openMapRealVector32.set((double) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector37.add(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = openMapRealVector32.append(doubleArray41);
        double double46 = openMapRealVector45.getNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(openMapRealVector30);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(openMapRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.3440585709080678E43d + "'", double46 == 1.3440585709080678E43d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.multiply(openMapRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 97 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[] doubleArray27 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27, 0.0d);
        try {
            array2DRowRealMatrix19.setColumn((int) (short) 100, doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector2.append(openMapRealVector41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray49 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector45.add(doubleArray49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector45.subtract(openMapRealVector55);
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector55.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector55.mapAddToSelf(4.9E-324d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector55.copy();
        double double62 = openMapRealVector41.dotProduct((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(openMapRealVector60);
        org.junit.Assert.assertNotNull(openMapRealVector61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        try {
            openMapRealMatrix6.setEntry(35, 5, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray15 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector11.add(doubleArray15);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector11.subtract(openMapRealVector21);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector6.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector22);
        int int24 = openMapRealVector6.getMinIndex();
        org.apache.commons.math.linear.RealVector realVector26 = openMapRealVector6.mapDivide(6.228504600082091E-21d);
        try {
            array2DRowRealMatrix2.setColumnVector(6, realVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (6)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double double17 = array2DRowRealMatrix12.getEntry((int) (byte) 1, (int) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray24 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector20.add(doubleArray24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector20.subtract(openMapRealVector30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector34.add(doubleArray38);
        double double42 = openMapRealVector20.dotProduct(openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector45.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector20.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector20.mapAddToSelf(10.04987562112089d);
        try {
            org.apache.commons.math.linear.RealVector realVector51 = array2DRowRealMatrix12.operate((org.apache.commons.math.linear.RealVector) openMapRealVector20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.combineToSelf(0.0d, (double) (-127), (org.apache.commons.math.linear.RealVector) openMapRealVector3);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray16 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector12.add(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector12.subtract(openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector7.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector32.add(doubleArray36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector32.subtract(openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector27.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector7.projection((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector7.append(openMapRealVector46);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector3.projection((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector3.mapAdd(1.9459101490553132d);
        int int51 = openMapRealVector3.getMaxIndex();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(openMapRealVector43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = openMapRealMatrix2.walkInRowOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-4.503599627370496E15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, 5, 6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.220446049250313E-16d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.503599627370496E15d + "'", double2 == 4.503599627370496E15d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        boolean boolean6 = array2DRowRealMatrix4.equals((java.lang.Object) (-0.9974947163822921d));
        java.lang.String str7 = array2DRowRealMatrix4.toString();
        try {
            org.apache.commons.math.linear.RealVector realVector9 = array2DRowRealMatrix4.getRowVector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}" + "'", str7.equals("Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        double[] doubleArray24 = array2DRowRealMatrix22.getColumn(1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix27.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix30);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix34.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix41.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix44);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix37.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix27.subtract(array2DRowRealMatrix44);
        array2DRowRealMatrix44.multiplyEntry(1, (int) 'a', 6.0d);
        double[][] doubleArray52 = array2DRowRealMatrix44.getData();
        try {
            array2DRowRealMatrix22.setSubMatrix(doubleArray52, (int) (short) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        int int24 = array2DRowRealMatrix2.getColumnDimension();
        double[] doubleArray32 = new double[] { 3.141592653589793d, 2.993222846126381d, 35.0d, (byte) -1, (-9.999666653335238E-5d), 0L };
        try {
            array2DRowRealMatrix2.setRow((int) (short) 100, doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector18.add(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector18.subtract(openMapRealVector28);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector28.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector12.add(openMapRealVector28);
        double[] doubleArray36 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector12.projection(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        int int20 = openMapRealVector2.getMinIndex();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction21 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector2.map(univariateRealFunction21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray12 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector8.add(doubleArray12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector8.subtract(openMapRealVector18);
        double double20 = openMapRealVector5.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor21 = openMapRealVector5.iterator();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix22 = openMapRealVector2.outerProduct((org.apache.commons.math.linear.RealVector) openMapRealVector5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor21);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray1 = new java.lang.Double[] {};
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray1, 4.641588833612779d);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (int) ' ', (int) ' ');
        int int4 = dimensionMismatchException3.getDimension();
        java.lang.Number number5 = dimensionMismatchException3.getArgument();
        int int6 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32 + "'", number5.equals(32));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (byte) -1, 0.6483608274590866d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) (byte) 10, (int) 'a');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix6 = openMapRealMatrix2.subtract(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix5.copy();
        try {
            openMapRealMatrix5.setEntry((int) '4', 1, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix6);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.42193247391194444d) + "'", double1 == (-0.42193247391194444d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, true);
        try {
            org.apache.commons.math.linear.RealVector realVector12 = array2DRowRealMatrix10.getRowVector((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        boolean boolean24 = array2DRowRealMatrix2.isSquare();
        double[] doubleArray26 = array2DRowRealMatrix2.getColumn(6);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        double double15 = openMapRealVector2.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 1);
        try {
            double double18 = openMapRealVector2.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap37 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) (short) 10, (double) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap38 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap37);
        boolean boolean39 = openMapRealVector25.equals((java.lang.Object) openIntToDoubleHashMap38);
        boolean boolean41 = openIntToDoubleHashMap38.containsKey(10);
        boolean boolean43 = openIntToDoubleHashMap38.containsKey((int) (short) -1);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap44 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap38);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector25 = array2DRowRealMatrix2.getRowVector((int) (byte) 1);
        try {
            double[] doubleArray27 = array2DRowRealMatrix2.getRow(32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (short) 1, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException4 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = mathArithmeticException4.getContext();
        outOfRangeException3.addSuppressed((java.lang.Throwable) mathArithmeticException4);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix(1, (int) (short) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix12.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix8.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        double[][] doubleArray18 = array2DRowRealMatrix8.getData();
        double double19 = array2DRowRealMatrix8.getNorm();
        int int20 = array2DRowRealMatrix8.getRowDimension();
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix21 = openMapRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 10x100");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-127), (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-127L) + "'", long2 == (-127L));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        int int10 = array2DRowRealMatrix8.getColumnDimension();
        double double13 = array2DRowRealMatrix8.getEntry(0, (int) ' ');
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor14 = null;
        try {
            double double19 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor14, 1, 1, 35, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 10, (int) '#', (double) 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix(1, (int) (short) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix10 = openMapRealMatrix2.multiply(realMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        double double3 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) -1, 6);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix12.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        int int23 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector25 = array2DRowRealMatrix2.getRowVector((int) (byte) 1);
        try {
            double double26 = array2DRowRealMatrix2.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        int int10 = array2DRowRealMatrix8.getRowDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix8.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (10x100) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray11 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector7.add(doubleArray11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector7.subtract(openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray31 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector27.add(doubleArray31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector27.subtract(openMapRealVector37);
        org.apache.commons.math.linear.RealVector realVector39 = openMapRealVector22.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector2.append(openMapRealVector41);
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector42.mapMultiplyToSelf((-1.5707963267948966d));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(realVector44);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(35);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray20 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector16.add(doubleArray20);
        double double24 = openMapRealVector2.dotProduct(openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector2);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector2.mapAdd((double) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray34 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector30.add(doubleArray34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector30.subtract(openMapRealVector40);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray48 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.linear.RealVector realVector51 = openMapRealVector44.add(doubleArray48);
        double double52 = openMapRealVector30.dotProduct(openMapRealVector44);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector30.mapAdd((double) (short) 0);
        double double56 = openMapRealVector2.getDistance(openMapRealVector30);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double[] doubleArray3 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        boolean boolean6 = array2DRowRealMatrix4.equals((java.lang.Object) (-0.9974947163822921d));
        java.lang.String str7 = array2DRowRealMatrix4.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix10.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
        double[][] doubleArray15 = array2DRowRealMatrix10.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        try {
            array2DRowRealMatrix4.setSubMatrix(doubleArray15, (int) ' ', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}" + "'", str7.equals("Array2DRowRealMatrix{{1.3440585709080678E43},{100.0},{10.0}}"));
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
        double double17 = array2DRowRealMatrix12.getEntry((int) (byte) 1, (int) (short) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector21.mapMultiply((double) (short) -1);
        try {
            array2DRowRealMatrix12.setRowVector((int) (byte) 10, (org.apache.commons.math.linear.RealVector) openMapRealVector21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
        double[][] doubleArray7 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getDataRef();
        int int10 = array2DRowRealMatrix8.getColumnDimension();
        double double13 = array2DRowRealMatrix8.getEntry(0, (int) ' ');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray25 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealVector21.add(doubleArray25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = openMapRealVector21.subtract(openMapRealVector31);
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector16.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray45 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector41.add(doubleArray45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector41.subtract(openMapRealVector51);
        org.apache.commons.math.linear.RealVector realVector53 = openMapRealVector36.combineToSelf((double) (short) 10, 2.220446049250313E-16d, (org.apache.commons.math.linear.RealVector) openMapRealVector52);
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector16.projection((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector16.append(openMapRealVector55);
        double[] doubleArray57 = openMapRealVector16.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray57);
        try {
            double[] doubleArray59 = array2DRowRealMatrix8.operate(doubleArray57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(openMapRealVector32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector2.add(doubleArray6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector2.subtract(openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapMultiplyToSelf((double) 0L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector12.append((double) 0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapMultiply((double) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(0, 10);
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 100, 10.0f };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector25.add(doubleArray29);
        double double33 = openMapRealVector20.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector25);
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector12.mapMultiply(1.1102230246251565E-16d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }
}

