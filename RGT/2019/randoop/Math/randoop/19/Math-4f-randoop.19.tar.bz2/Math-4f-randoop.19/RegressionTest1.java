import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (-4));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.0d) + "'", double1 == (-4.0d));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) (-1.0f), (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.356194490192345d) + "'", double2 == (-2.356194490192345d));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        int int1 = org.apache.commons.math3.util.FastMath.round(10.000003f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        double[] doubleArray3 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3);
        double[] doubleArray9 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray9);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) (-1), (-1));
        int int15 = nonMonotonicSequenceException14.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection16 = nonMonotonicSequenceException14.getDirection();
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray9, orderDirection16, false, false);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (byte) 100);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 143.0d + "'", double10 == 143.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = line8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet10);
        double double12 = intervalsSet10.getSup();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree14 = intervalsSet10.getTree(false);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree14);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        line8.setAngle((double) 0.0f);
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = line8.getReverse();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double13 = vector2D12.getNorm();
        java.text.NumberFormat numberFormat14 = null;
        java.lang.String str15 = vector2D12.toString(numberFormat14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double17 = vector2D16.getNorm();
        java.text.NumberFormat numberFormat18 = null;
        java.lang.String str19 = vector2D16.toString(numberFormat18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = line20.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line20, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        double double24 = intervalsSet22.getSup();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine25 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion26 = intervalsSet22.copySelf();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(line11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{(Infinity); (Infinity)}" + "'", str15.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{(Infinity); (Infinity)}" + "'", str19.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion26);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = line8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = line8.wholeSpace();
        double double11 = line8.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double13 = vector2D12.getNorm();
        java.text.NumberFormat numberFormat14 = null;
        java.lang.String str15 = vector2D12.toString(numberFormat14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double17 = vector2D16.getNorm();
        java.text.NumberFormat numberFormat18 = null;
        java.lang.String str19 = vector2D16.toString(numberFormat18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = line20.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line20, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        double double24 = intervalsSet22.getSup();
        boolean boolean25 = intervalsSet22.isEmpty();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector26 = intervalsSet22.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion27 = intervalsSet22.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine9);
        org.junit.Assert.assertNotNull(polygonsSet10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{(Infinity); (Infinity)}" + "'", str15.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{(Infinity); (Infinity)}" + "'", str19.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(euclidean1DVector26);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion27);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double4 = vector2D3.getNorm();
        java.text.NumberFormat numberFormat5 = null;
        java.lang.String str6 = vector2D3.toString(numberFormat5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double8 = vector2D7.getNorm();
        java.text.NumberFormat numberFormat9 = null;
        java.lang.String str10 = vector2D7.toString(numberFormat9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine12 = line11.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine14 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet13);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion15 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine16 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line11, euclidean1DRegion15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double18 = vector2D17.getNorm();
        java.text.NumberFormat numberFormat19 = null;
        java.lang.String str20 = vector2D17.toString(numberFormat19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double22 = vector2D21.getNorm();
        java.text.NumberFormat numberFormat23 = null;
        java.lang.String str24 = vector2D21.toString(numberFormat23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine26 = line25.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line25, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion29 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine30 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line25, euclidean1DRegion29);
        boolean boolean31 = line11.isParallelTo(line25);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine32 = line11.wholeHyperplane();
        double[] doubleArray36 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36);
        double[] doubleArray42 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double43 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray36, doubleArray42);
        java.lang.Class<?> wildcardClass44 = doubleArray42.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line53 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D51, vector3D52);
        double double54 = vector3D48.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        double double55 = vector3D45.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D45.orthogonal();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double58 = vector2D57.getNorm();
        java.text.NumberFormat numberFormat59 = null;
        java.lang.String str60 = vector2D57.toString(numberFormat59);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double62 = vector2D61.getNorm();
        java.text.NumberFormat numberFormat63 = null;
        java.lang.String str64 = vector2D61.toString(numberFormat63);
        org.apache.commons.math3.geometry.euclidean.twod.Line line65 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D57, vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine66 = line65.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet67 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine68 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line65, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet67);
        double double69 = intervalsSet67.getSup();
        boolean boolean70 = intervalsSet67.isEmpty();
        java.lang.Object[] objArray71 = new java.lang.Object[] { subLine32, wildcardClass44, vector3D45, boolean70 };
        org.apache.commons.math3.exception.MathInternalError mathInternalError72 = new org.apache.commons.math3.exception.MathInternalError(localizable2, objArray71);
        org.apache.commons.math3.exception.MathInternalError mathInternalError73 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray71);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray71);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{(Infinity); (Infinity)}" + "'", str6.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{(Infinity); (Infinity)}" + "'", str10.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine12);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.POSITIVE_INFINITY + "'", double18 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{(Infinity); (Infinity)}" + "'", str20.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.POSITIVE_INFINITY + "'", double22 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{(Infinity); (Infinity)}" + "'", str24.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(subLine32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 143.0d + "'", double43 == 143.0d);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.588046279947166d + "'", double54 == 2.588046279947166d);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + Double.POSITIVE_INFINITY + "'", double58 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "{(Infinity); (Infinity)}" + "'", str60.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + Double.POSITIVE_INFINITY + "'", double62 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "{(Infinity); (Infinity)}" + "'", str64.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + Double.POSITIVE_INFINITY + "'", double69 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(objArray71);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        java.text.NumberFormat numberFormat9 = null;
        java.lang.String str10 = vector2D4.toString(numberFormat9);
        double double11 = vector2D4.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double13 = vector2D12.getNorm();
        java.lang.String str14 = vector2D12.toString();
        double double15 = vector2D12.getNorm1();
        double double16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D4, vector2D12);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{(Infinity); (Infinity)}" + "'", str10.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{(Infinity); (Infinity)}" + "'", str14.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(201.0d, 1.454648713412841d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line11 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D9, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double13 = vector3D10.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D5, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D16.normalize();
        double double18 = vector3D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 788.5471832628377d + "'", double18 == 788.5471832628377d);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line4 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D2, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = line4.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line10 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D9);
        double[] doubleArray11 = vector3D9.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = line4.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double14 = vector1D12.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = vector1D12.normalize();
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7273243567064203d + "'", double14 == 0.7273243567064203d);
        org.junit.Assert.assertNotNull(vector1D15);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = line8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet10);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion12 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, euclidean1DRegion12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double15 = vector2D14.getNorm();
        java.text.NumberFormat numberFormat16 = null;
        java.lang.String str17 = vector2D14.toString(numberFormat16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double19 = vector2D18.getNorm();
        java.text.NumberFormat numberFormat20 = null;
        java.lang.String str21 = vector2D18.toString(numberFormat20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = line22.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet24 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine25 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line22, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet24);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion26 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine27 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line22, euclidean1DRegion26);
        boolean boolean28 = line8.isParallelTo(line22);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = line8.wholeHyperplane();
        double double30 = line8.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double32 = vector2D31.getNorm();
        java.text.NumberFormat numberFormat33 = null;
        java.lang.String str34 = vector2D31.toString(numberFormat33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double36 = vector2D35.getNorm();
        java.text.NumberFormat numberFormat37 = null;
        java.lang.String str38 = vector2D35.toString(numberFormat37);
        org.apache.commons.math3.geometry.euclidean.twod.Line line39 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D31, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine40 = line39.wholeHyperplane();
        boolean boolean41 = line8.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line39);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine9);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{(Infinity); (Infinity)}" + "'", str17.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{(Infinity); (Infinity)}" + "'", str21.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(subLine29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.POSITIVE_INFINITY + "'", double32 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{(Infinity); (Infinity)}" + "'", str34.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{(Infinity); (Infinity)}" + "'", str38.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double2 = vector2D1.getNorm();
        java.text.NumberFormat numberFormat3 = null;
        java.lang.String str4 = vector2D1.toString(numberFormat3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double6 = vector2D5.getNorm();
        java.text.NumberFormat numberFormat7 = null;
        java.lang.String str8 = vector2D5.toString(numberFormat7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line9 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, vector2D5);
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double12 = vector2D11.getNorm();
        java.lang.String str13 = vector2D11.toString();
        double double14 = vector2D11.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine15 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D11);
        boolean boolean16 = vector2D0.isInfinite();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{(Infinity); (Infinity)}" + "'", str4.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{(Infinity); (Infinity)}" + "'", str8.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{(Infinity); (Infinity)}" + "'", str13.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((-0.001739546146996826d), (-1.5707963267948966d), (double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double2 = vector2D1.getNorm();
        java.text.NumberFormat numberFormat3 = null;
        java.lang.String str4 = vector2D1.toString(numberFormat3);
        boolean boolean5 = vector2D1.isInfinite();
        boolean boolean6 = vector2D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double9 = vector2D8.getNorm();
        java.text.NumberFormat numberFormat10 = null;
        java.lang.String str11 = vector2D8.toString(numberFormat10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double13 = vector2D12.getNorm();
        java.text.NumberFormat numberFormat14 = null;
        java.lang.String str15 = vector2D12.toString(numberFormat14);
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D8, vector2D12);
        java.text.NumberFormat numberFormat17 = null;
        java.lang.String str18 = vector2D12.toString(numberFormat17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line19 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double21 = vector2D20.getNorm();
        java.text.NumberFormat numberFormat22 = null;
        java.lang.String str23 = vector2D20.toString(numberFormat22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double25 = vector2D24.getNorm();
        java.text.NumberFormat numberFormat26 = null;
        java.lang.String str27 = vector2D24.toString(numberFormat26);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D20, vector2D24);
        line28.setAngle((double) 0.0f);
        org.apache.commons.math3.geometry.euclidean.twod.Line line31 = line28.getReverse();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double33 = vector2D32.getNorm();
        java.text.NumberFormat numberFormat34 = null;
        java.lang.String str35 = vector2D32.toString(numberFormat34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double37 = vector2D36.getNorm();
        java.text.NumberFormat numberFormat38 = null;
        java.lang.String str39 = vector2D36.toString(numberFormat38);
        org.apache.commons.math3.geometry.euclidean.twod.Line line40 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D32, vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine41 = line40.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet42 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine43 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line40, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet42);
        double double44 = intervalsSet42.getSup();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine45 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line31, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double48 = vector2D47.getNorm();
        java.text.NumberFormat numberFormat49 = null;
        java.lang.String str50 = vector2D47.toString(numberFormat49);
        boolean boolean51 = vector2D47.isInfinite();
        boolean boolean52 = vector2D47.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D46.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        line31.translateToPoint(vector2D53);
        double double55 = vector2D0.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{(Infinity); (Infinity)}" + "'", str4.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{(Infinity); (Infinity)}" + "'", str11.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{(Infinity); (Infinity)}" + "'", str15.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{(Infinity); (Infinity)}" + "'", str18.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{(Infinity); (Infinity)}" + "'", str23.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{(Infinity); (Infinity)}" + "'", str27.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(line31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{(Infinity); (Infinity)}" + "'", str35.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{(Infinity); (Infinity)}" + "'", str39.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{(Infinity); (Infinity)}" + "'", str50.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (double) 3, 0.6633731365225841d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 21.22794036872269d + "'", double4 == 21.22794036872269d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        double[] doubleArray3 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3);
        double[] doubleArray9 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line20 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D18, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double22 = vector3D19.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D19.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D14, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Line line26 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D11, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line31 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D29, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double33 = vector3D30.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        boolean boolean34 = vector3D32.isNaN();
        double[] doubleArray38 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38);
        double[] doubleArray44 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray38, doubleArray44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray38);
        org.apache.commons.math3.geometry.euclidean.threed.Line line47 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D32, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        double double49 = vector3D32.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line58 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D56, vector3D57);
        double double59 = vector3D53.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        double double60 = vector3D50.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D50.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D32.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D32.normalize();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 143.0d + "'", double10 == 143.0d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 143.0d + "'", double45 == 143.0d);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 2.588046279947166d + "'", double59 == 2.588046279947166d);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line5 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D3, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double7 = vector3D4.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D4.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line14 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D12, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double16 = vector3D13.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        double double17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D9, vector3D13);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet20 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((double) (-1), 3.1622776601683795d);
        double double21 = intervalsSet20.getInf();
        boolean boolean22 = vector3D9.equals((java.lang.Object) intervalsSet20);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree24 = intervalsSet20.getTree(false);
        double double25 = intervalsSet20.getSize();
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.16227766016838d + "'", double25 == 4.16227766016838d);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, (-0.8390715290764524d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double12 = vector2D11.getNorm();
        java.text.NumberFormat numberFormat13 = null;
        java.lang.String str14 = vector2D11.toString(numberFormat13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D11.scalarMultiply(32.0d);
        double double17 = line10.distance(vector2D16);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{(Infinity); (Infinity)}" + "'", str14.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line7 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D5, vector3D6);
        double[] doubleArray8 = vector3D6.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line13 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D11, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double15 = vector3D12.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D12.orthogonal();
        double double17 = vector3D6.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D2.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line23 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D21, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double25 = vector3D22.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D22.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line31 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D29, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double33 = vector3D30.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        boolean boolean34 = vector3D32.isNaN();
        double double35 = vector3D32.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line40 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D38, vector3D39);
        double double41 = vector3D32.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        double double42 = vector3D26.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line51 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D49, vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double53 = vector3D50.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D50.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D45, vector3D55);
        double double57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D26, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D2.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        boolean boolean59 = vector3D26.isNaN();
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.7056662706478316d + "'", double41 == 1.7056662706478316d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.0d + "'", double42 == 2.0d);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 32.0d + "'", double57 == 32.0d);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = line8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet10);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion12 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, euclidean1DRegion12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double15 = vector2D14.getNorm();
        java.text.NumberFormat numberFormat16 = null;
        java.lang.String str17 = vector2D14.toString(numberFormat16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double19 = vector2D18.getNorm();
        java.text.NumberFormat numberFormat20 = null;
        java.lang.String str21 = vector2D18.toString(numberFormat20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = line22.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet24 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine25 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line22, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet24);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion26 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine27 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line22, euclidean1DRegion26);
        boolean boolean28 = line8.isParallelTo(line22);
        line22.setOriginOffset(20.618312346269263d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double33 = vector2D32.getNorm();
        java.text.NumberFormat numberFormat34 = null;
        java.lang.String str35 = vector2D32.toString(numberFormat34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double37 = vector2D36.getNorm();
        java.text.NumberFormat numberFormat38 = null;
        java.lang.String str39 = vector2D36.toString(numberFormat38);
        org.apache.commons.math3.geometry.euclidean.twod.Line line40 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D32, vector2D36);
        double double41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D31, vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double43 = vector2D42.getNorm();
        java.lang.String str44 = vector2D42.toString();
        double double45 = vector2D42.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine46 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D31, vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Line line48 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D42, (-4.185891831851989d));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double51 = vector2D50.getNorm();
        java.text.NumberFormat numberFormat52 = null;
        java.lang.String str53 = vector2D50.toString(numberFormat52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = vector2D50.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine56 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D49, vector2D55);
        org.apache.commons.math3.geometry.Space space57 = vector2D49.getSpace();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = line48.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D49);
        boolean boolean59 = line22.isParallelTo(line48);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine9);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{(Infinity); (Infinity)}" + "'", str17.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{(Infinity); (Infinity)}" + "'", str21.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{(Infinity); (Infinity)}" + "'", str35.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{(Infinity); (Infinity)}" + "'", str39.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + Double.POSITIVE_INFINITY + "'", double41 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "{(Infinity); (Infinity)}" + "'", str44.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.POSITIVE_INFINITY + "'", double45 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{(Infinity); (Infinity)}" + "'", str53.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(space57);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 10.0d);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) notPositiveException1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line7 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D5, vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double9 = vector3D6.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D6.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line15 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double17 = vector3D14.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        boolean boolean18 = vector3D16.isNaN();
        double double19 = vector3D16.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line24 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D22, vector3D23);
        double double25 = vector3D16.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        double double26 = vector3D10.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line35 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D33, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double37 = vector3D34.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D34.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D29, vector3D39);
        double double41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D10, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line47 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D45, vector3D46);
        double[] doubleArray52 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray52);
        double[] doubleArray58 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double59 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray52, doubleArray58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line65 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D63, vector3D64);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double67 = vector3D64.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D66);
        boolean boolean68 = vector3D66.isNaN();
        double double69 = vector3D66.getY();
        double double70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D60, vector3D66);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(5.298342365610589d, vector3D1, 10.0d, vector3D10, (double) (byte) 1, vector3D46, (double) (-1022.99994f), vector3D66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.7056662706478316d + "'", double25 == 1.7056662706478316d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 32.0d + "'", double41 == 32.0d);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 143.0d + "'", double59 == 143.0d);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 99.0d + "'", double70 == 99.0d);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(0.9518224930797358d, (-3200.0d), 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        float[] floatArray3 = new float[] { (short) 100, 1L, '#' };
        float[] floatArray8 = new float[] { Float.NaN, 10.0f, 0L, 100.0f };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(floatArray3, floatArray8);
        float[] floatArray13 = new float[] { (short) 100, 1L, '#' };
        float[] floatArray18 = new float[] { Float.NaN, 10.0f, 0L, 100.0f };
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equals(floatArray13, floatArray18);
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray8, floatArray13);
        float[] floatArray24 = new float[] { (short) 100, 1L, '#' };
        float[] floatArray29 = new float[] { Float.NaN, 10.0f, 0L, 100.0f };
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equals(floatArray24, floatArray29);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray13, floatArray24);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        double[] doubleArray4 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray10 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray4, doubleArray10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D20, vector3D21);
        double double23 = vector3D17.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        double double24 = vector3D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        double double25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D12, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line31 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D29, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line40 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D38, vector3D39);
        double double41 = vector3D35.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D30.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D35.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line50 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D48, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = line50.pointAt((double) 'a');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line61 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D59, vector3D60);
        double double62 = vector3D56.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D60);
        double double63 = vector3D53.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = vector3D53.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line69 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D67, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = line69.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line75 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D73, vector3D74);
        double[] doubleArray76 = vector3D74.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = line69.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D74);
        line50.reset(vector3D53, vector3D74);
        boolean boolean79 = vector3D74.isInfinite();
        double[] doubleArray84 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray84);
        double[] doubleArray90 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double91 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray84, doubleArray90);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D92 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray84);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D93 = vector3D92.negate();
        double double94 = vector3D93.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D95 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D17, 2.99822295029797d, vector3D35, 1.1895209720049214d, vector3D74, 0.0d, vector3D93);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 143.0d + "'", double11 == 143.0d);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.588046279947166d + "'", double23 == 2.588046279947166d);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 163.0041931164943d + "'", double25 == 163.0041931164943d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.588046279947166d + "'", double41 == 2.588046279947166d);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.588046279947166d + "'", double62 == 2.588046279947166d);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 143.0d + "'", double91 == 143.0d);
        org.junit.Assert.assertNotNull(vector3D93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 113.15476127852509d + "'", double94 == 113.15476127852509d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0d, 99.99999999999999d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1, (java.lang.Number) 100.00001f, 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonicSequenceException3.getSuppressed();
        int int5 = nonMonotonicSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double7 = vector2D6.getNorm();
        java.text.NumberFormat numberFormat8 = null;
        java.lang.String str9 = vector2D6.toString(numberFormat8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double11 = vector2D10.getNorm();
        java.text.NumberFormat numberFormat12 = null;
        java.lang.String str13 = vector2D10.toString(numberFormat12);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double16 = vector2D15.getNorm();
        java.text.NumberFormat numberFormat17 = null;
        java.lang.String str18 = vector2D15.toString(numberFormat17);
        boolean boolean19 = vector2D15.isInfinite();
        boolean boolean20 = vector2D15.isInfinite();
        double double21 = vector2D10.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double24 = vector2D23.getNorm();
        java.text.NumberFormat numberFormat25 = null;
        java.lang.String str26 = vector2D23.toString(numberFormat25);
        boolean boolean27 = vector2D23.isInfinite();
        boolean boolean28 = vector2D23.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 10.000001f, vector2D10, 1.4436354751788103d, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double31 = vector2D30.getNorm();
        java.text.NumberFormat numberFormat32 = null;
        java.lang.String str33 = vector2D30.toString(numberFormat32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D30.scalarMultiply(32.0d);
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D10, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = vector2D0.subtract((double) (-1L), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{(Infinity); (Infinity)}" + "'", str9.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{(Infinity); (Infinity)}" + "'", str13.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{(Infinity); (Infinity)}" + "'", str18.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{(Infinity); (Infinity)}" + "'", str26.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{(Infinity); (Infinity)}" + "'", str33.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D37);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment0 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine1 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = line8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet10);
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList12 = intervalsSet10.asList();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine9);
        org.junit.Assert.assertNotNull(intervalList12);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (short) 100, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        double[] doubleArray3 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3);
        double[] doubleArray9 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray9);
        java.lang.Number number11 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection14 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException16 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number11, (java.lang.Number) 97, 0, orderDirection14, false);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray9, orderDirection14, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly decreasing (-1 <= 100)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 143.0d + "'", double10 == 143.0d);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D0, true);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint3 = orientedPoint2.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double9 = vector2D8.getNorm();
        java.text.NumberFormat numberFormat10 = null;
        java.lang.String str11 = vector2D8.toString(numberFormat10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line12 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = line12.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet14 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine15 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line12, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        double double16 = intervalsSet14.getSup();
        double double17 = intervalsSet14.getSize();
        boolean boolean18 = intervalsSet14.isEmpty();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector19 = null;
        org.apache.commons.math3.geometry.partitioning.Region.Location location20 = intervalsSet14.checkPoint(euclidean1DVector19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line25 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D23, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = line25.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line31 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D29, vector3D30);
        double[] doubleArray32 = vector3D30.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = line25.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double35 = vector1D33.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D34);
        org.apache.commons.math3.geometry.partitioning.Region.Location location36 = intervalsSet14.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D34);
        try {
            double double37 = orientedPoint2.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(subOrientedPoint3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{(Infinity); (Infinity)}" + "'", str11.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + location20 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location20.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.7273243567064203d + "'", double35 == 0.7273243567064203d);
        org.junit.Assert.assertTrue("'" + location36 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location36.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = line8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet10 = line8.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = line8.getReverse();
        line11.revertSelf();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine9);
        org.junit.Assert.assertNotNull(polygonsSet10);
        org.junit.Assert.assertNotNull(line11);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double2 = vector2D1.getNorm();
        java.text.NumberFormat numberFormat3 = null;
        java.lang.String str4 = vector2D1.toString(numberFormat3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double6 = vector2D5.getNorm();
        java.text.NumberFormat numberFormat7 = null;
        java.lang.String str8 = vector2D5.toString(numberFormat7);
        org.apache.commons.math3.geometry.euclidean.twod.Line line9 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double11 = vector2D10.getNorm();
        java.text.NumberFormat numberFormat12 = null;
        java.lang.String str13 = vector2D10.toString(numberFormat12);
        boolean boolean14 = vector2D10.isInfinite();
        boolean boolean15 = vector2D10.isInfinite();
        double double16 = vector2D5.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double19 = vector2D18.getNorm();
        java.text.NumberFormat numberFormat20 = null;
        java.lang.String str21 = vector2D18.toString(numberFormat20);
        boolean boolean22 = vector2D18.isInfinite();
        boolean boolean23 = vector2D18.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 10.000001f, vector2D5, 1.4436354751788103d, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double27 = vector2D26.getNorm();
        java.text.NumberFormat numberFormat28 = null;
        java.lang.String str29 = vector2D26.toString(numberFormat28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D26.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double34 = vector2D33.getNorm();
        java.text.NumberFormat numberFormat35 = null;
        java.lang.String str36 = vector2D33.toString(numberFormat35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double38 = vector2D37.getNorm();
        java.text.NumberFormat numberFormat39 = null;
        java.lang.String str40 = vector2D37.toString(numberFormat39);
        org.apache.commons.math3.geometry.euclidean.twod.Line line41 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D33, vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double45 = vector2D44.getNorm();
        java.text.NumberFormat numberFormat46 = null;
        java.lang.String str47 = vector2D44.toString(numberFormat46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = vector2D44.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine50 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D43, vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double53 = vector2D52.getNorm();
        java.text.NumberFormat numberFormat54 = null;
        java.lang.String str55 = vector2D52.toString(numberFormat54);
        boolean boolean56 = vector2D52.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double59 = vector2D58.getNorm();
        java.text.NumberFormat numberFormat60 = null;
        java.lang.String str61 = vector2D58.toString(numberFormat60);
        boolean boolean62 = vector2D58.isInfinite();
        boolean boolean63 = vector2D58.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = vector2D57.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double66 = vector2D65.getNorm();
        java.text.NumberFormat numberFormat67 = null;
        java.lang.String str68 = vector2D65.toString(numberFormat67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double70 = vector2D69.getNorm();
        java.text.NumberFormat numberFormat71 = null;
        java.lang.String str72 = vector2D69.toString(numberFormat71);
        org.apache.commons.math3.geometry.euclidean.twod.Line line73 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D65, vector2D69);
        java.text.NumberFormat numberFormat74 = null;
        java.lang.String str75 = vector2D69.toString(numberFormat74);
        org.apache.commons.math3.geometry.euclidean.twod.Line line76 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D57, vector2D69);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine77 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D52, vector2D69);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-4), vector2D26, (double) (short) 100, vector2D37, (double) (byte) 1, vector2D43, (-1.5707963267948966d), vector2D69);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = vector2D18.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D69);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = vector2D79.getZero();
        org.apache.commons.math3.geometry.euclidean.twod.Line line82 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D80, (-1.0d));
        line82.revertSelf();
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{(Infinity); (Infinity)}" + "'", str4.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{(Infinity); (Infinity)}" + "'", str8.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{(Infinity); (Infinity)}" + "'", str13.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{(Infinity); (Infinity)}" + "'", str21.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{(Infinity); (Infinity)}" + "'", str29.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + Double.POSITIVE_INFINITY + "'", double34 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{(Infinity); (Infinity)}" + "'", str36.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{(Infinity); (Infinity)}" + "'", str40.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.POSITIVE_INFINITY + "'", double45 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{(Infinity); (Infinity)}" + "'", str47.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "{(Infinity); (Infinity)}" + "'", str55.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{(Infinity); (Infinity)}" + "'", str61.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.POSITIVE_INFINITY + "'", double66 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "{(Infinity); (Infinity)}" + "'", str68.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.POSITIVE_INFINITY + "'", double70 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "{(Infinity); (Infinity)}" + "'", str72.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "{(Infinity); (Infinity)}" + "'", str75.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D80);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line4 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D2, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = line4.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line10 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D9);
        double[] doubleArray11 = vector3D9.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = line4.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double14 = vector1D12.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line20 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D18, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = line20.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line26 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D24, vector3D25);
        double[] doubleArray27 = vector3D25.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = line20.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = vector1D13.subtract(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line35 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D33, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = line35.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line41 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D39, vector3D40);
        double[] doubleArray42 = vector3D40.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = line35.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double45 = vector1D43.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line51 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D49, vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = line51.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line57 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D55, vector3D56);
        double[] doubleArray58 = vector3D56.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = line51.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = vector1D44.subtract(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line66 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D64, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = line66.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line72 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D70, vector3D71);
        double[] doubleArray73 = vector3D71.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = line66.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double76 = vector1D74.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line82 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D80, vector3D81);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = line82.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line88 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D86, vector3D87);
        double[] doubleArray89 = vector3D87.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = line82.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D87);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D91 = vector1D75.subtract(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D90);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D92 = vector1D60.add((double) (short) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D91);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D93 = vector1D13.subtract(1.7056662706478316d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D92);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint95 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D92, true);
        double double96 = vector1D92.getNormSq();
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7273243567064203d + "'", double14 == 0.7273243567064203d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.7273243567064203d + "'", double45 == 0.7273243567064203d);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(vector1D74);
        org.junit.Assert.assertNotNull(vector1D75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.7273243567064203d + "'", double76 == 0.7273243567064203d);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(vector1D90);
        org.junit.Assert.assertNotNull(vector1D91);
        org.junit.Assert.assertNotNull(vector1D92);
        org.junit.Assert.assertNotNull(vector1D93);
        org.junit.Assert.assertEquals((double) double96, Double.NaN, 0);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        line8.setAngle((double) 0.0f);
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = line8.getReverse();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double13 = vector2D12.getNorm();
        java.text.NumberFormat numberFormat14 = null;
        java.lang.String str15 = vector2D12.toString(numberFormat14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double17 = vector2D16.getNorm();
        java.text.NumberFormat numberFormat18 = null;
        java.lang.String str19 = vector2D16.toString(numberFormat18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = line20.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line20, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        double double24 = intervalsSet22.getSup();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine25 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double28 = vector2D27.getNorm();
        java.text.NumberFormat numberFormat29 = null;
        java.lang.String str30 = vector2D27.toString(numberFormat29);
        boolean boolean31 = vector2D27.isInfinite();
        boolean boolean32 = vector2D27.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D26.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        line11.translateToPoint(vector2D33);
        double double35 = vector2D33.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double39 = vector2D38.getNorm();
        java.text.NumberFormat numberFormat40 = null;
        java.lang.String str41 = vector2D38.toString(numberFormat40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double43 = vector2D42.getNorm();
        java.text.NumberFormat numberFormat44 = null;
        java.lang.String str45 = vector2D42.toString(numberFormat44);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D38, vector2D42);
        double double47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D37, vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double49 = vector2D48.getNorm();
        java.lang.String str50 = vector2D48.toString();
        double double51 = vector2D48.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine52 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D37, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D33.add(161.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(line11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{(Infinity); (Infinity)}" + "'", str15.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{(Infinity); (Infinity)}" + "'", str19.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{(Infinity); (Infinity)}" + "'", str30.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{(Infinity); (Infinity)}" + "'", str41.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{(Infinity); (Infinity)}" + "'", str45.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.POSITIVE_INFINITY + "'", double47 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{(Infinity); (Infinity)}" + "'", str50.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D53);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double2 = vector2D1.getNorm();
        java.text.NumberFormat numberFormat3 = null;
        java.lang.String str4 = vector2D1.toString(numberFormat3);
        boolean boolean5 = vector2D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double8 = vector2D7.getNorm();
        java.text.NumberFormat numberFormat9 = null;
        java.lang.String str10 = vector2D7.toString(numberFormat9);
        boolean boolean11 = vector2D7.isInfinite();
        boolean boolean12 = vector2D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double15 = vector2D14.getNorm();
        java.text.NumberFormat numberFormat16 = null;
        java.lang.String str17 = vector2D14.toString(numberFormat16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double19 = vector2D18.getNorm();
        java.text.NumberFormat numberFormat20 = null;
        java.lang.String str21 = vector2D18.toString(numberFormat20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, vector2D18);
        java.text.NumberFormat numberFormat23 = null;
        java.lang.String str24 = vector2D18.toString(numberFormat23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D6, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine26 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D1, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.4711276743037347d, vector2D18);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{(Infinity); (Infinity)}" + "'", str4.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{(Infinity); (Infinity)}" + "'", str10.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{(Infinity); (Infinity)}" + "'", str17.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{(Infinity); (Infinity)}" + "'", str21.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{(Infinity); (Infinity)}" + "'", str24.equals("{(Infinity); (Infinity)}"));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double2 = vector2D1.getNorm();
        java.text.NumberFormat numberFormat3 = null;
        java.lang.String str4 = vector2D1.toString(numberFormat3);
        boolean boolean5 = vector2D1.isInfinite();
        boolean boolean6 = vector2D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double9 = vector2D8.getNorm();
        java.text.NumberFormat numberFormat10 = null;
        java.lang.String str11 = vector2D8.toString(numberFormat10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double13 = vector2D12.getNorm();
        java.text.NumberFormat numberFormat14 = null;
        java.lang.String str15 = vector2D12.toString(numberFormat14);
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D8, vector2D12);
        java.text.NumberFormat numberFormat17 = null;
        java.lang.String str18 = vector2D12.toString(numberFormat17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line19 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double22 = vector2D21.getNorm();
        java.text.NumberFormat numberFormat23 = null;
        java.lang.String str24 = vector2D21.toString(numberFormat23);
        boolean boolean25 = vector2D21.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double28 = vector2D27.getNorm();
        java.text.NumberFormat numberFormat29 = null;
        java.lang.String str30 = vector2D27.toString(numberFormat29);
        boolean boolean31 = vector2D27.isInfinite();
        boolean boolean32 = vector2D27.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D26.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double35 = vector2D34.getNorm();
        java.text.NumberFormat numberFormat36 = null;
        java.lang.String str37 = vector2D34.toString(numberFormat36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double39 = vector2D38.getNorm();
        java.text.NumberFormat numberFormat40 = null;
        java.lang.String str41 = vector2D38.toString(numberFormat40);
        org.apache.commons.math3.geometry.euclidean.twod.Line line42 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D34, vector2D38);
        java.text.NumberFormat numberFormat43 = null;
        java.lang.String str44 = vector2D38.toString(numberFormat43);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D26, vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine46 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D21, vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double50 = vector2D49.getNorm();
        java.text.NumberFormat numberFormat51 = null;
        java.lang.String str52 = vector2D49.toString(numberFormat51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = vector2D49.scalarMultiply(32.0d);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine55 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D48, vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-127L), vector2D38, 0.0d, vector2D54);
        double double57 = vector2D12.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double59 = vector2D58.getNorm();
        java.text.NumberFormat numberFormat60 = null;
        java.lang.String str61 = vector2D58.toString(numberFormat60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double63 = vector2D62.getNorm();
        java.text.NumberFormat numberFormat64 = null;
        java.lang.String str65 = vector2D62.toString(numberFormat64);
        org.apache.commons.math3.geometry.euclidean.twod.Line line66 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D58, vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = vector2D12.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{(Infinity); (Infinity)}" + "'", str4.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{(Infinity); (Infinity)}" + "'", str11.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{(Infinity); (Infinity)}" + "'", str15.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{(Infinity); (Infinity)}" + "'", str18.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.POSITIVE_INFINITY + "'", double22 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{(Infinity); (Infinity)}" + "'", str24.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{(Infinity); (Infinity)}" + "'", str30.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.POSITIVE_INFINITY + "'", double35 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{(Infinity); (Infinity)}" + "'", str37.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{(Infinity); (Infinity)}" + "'", str41.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "{(Infinity); (Infinity)}" + "'", str44.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{(Infinity); (Infinity)}" + "'", str52.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{(Infinity); (Infinity)}" + "'", str61.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + Double.POSITIVE_INFINITY + "'", double63 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "{(Infinity); (Infinity)}" + "'", str65.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D67);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane1 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree2 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane3 = spaceBSPTree2.getCut();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree4 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree5 = spaceBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree6 = spaceBSPTree4.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion10 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint11 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9, euclidean1DRegion10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint14 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint15 = orientedPoint14.wholeHyperplane();
        boolean boolean16 = orientedPoint9.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double18 = vector2D17.getNorm();
        java.text.NumberFormat numberFormat19 = null;
        java.lang.String str20 = vector2D17.toString(numberFormat19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double22 = vector2D21.getNorm();
        java.text.NumberFormat numberFormat23 = null;
        java.lang.String str24 = vector2D21.toString(numberFormat23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine26 = line25.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line25, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion29 = intervalsSet27.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint30 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint14, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree31 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane1, spaceBSPTree2, spaceBSPTree6, (java.lang.Object) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree32 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        java.lang.Object obj33 = spaceBSPTree32.getAttribute();
        spaceBSPTree6.insertInTree(spaceBSPTree32, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree36 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree37 = spaceBSPTree36.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree38 = spaceBSPTree36.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane39 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree40 = spaceBSPTree38.split(spaceSubHyperplane39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line45 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D43, vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine46 = line45.wholeLine();
        java.util.List<org.apache.commons.math3.geometry.euclidean.threed.Segment> segmentList47 = subLine46.getSegments();
        java.util.List<org.apache.commons.math3.geometry.euclidean.threed.Segment> segmentList48 = subLine46.getSegments();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree49 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceBSPTree6, spaceBSPTree40, (java.lang.Object) segmentList48);
        org.junit.Assert.assertNull(spaceSubHyperplane3);
        org.junit.Assert.assertNotNull(spaceBSPTree5);
        org.junit.Assert.assertNotNull(spaceBSPTree6);
        org.junit.Assert.assertNotNull(subOrientedPoint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.POSITIVE_INFINITY + "'", double18 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{(Infinity); (Infinity)}" + "'", str20.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.POSITIVE_INFINITY + "'", double22 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{(Infinity); (Infinity)}" + "'", str24.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine26);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion29);
        org.junit.Assert.assertNull(obj33);
        org.junit.Assert.assertNotNull(spaceBSPTree37);
        org.junit.Assert.assertNotNull(spaceBSPTree38);
        org.junit.Assert.assertNotNull(spaceBSPTree40);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(subLine46);
        org.junit.Assert.assertNotNull(segmentList47);
        org.junit.Assert.assertNotNull(segmentList48);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        int[] intArray1 = new int[] { 100 };
        int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1);
        int[] intArray4 = new int[] { 100 };
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4);
        double double6 = org.apache.commons.math3.util.MathArrays.distance(intArray1, intArray5);
        int[] intArray11 = new int[] { 'a', 1, (short) -1, 'a' };
        int[] intArray12 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11);
        int int13 = org.apache.commons.math3.util.MathArrays.distance1(intArray1, intArray11);
        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1, (int) (byte) 100);
        int[] intArray16 = null;
        try {
            int int17 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 1, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        int int1 = org.apache.commons.math3.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane2 = spaceBSPTree1.getCut();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree3 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree4 = spaceBSPTree3.copySelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree5 = spaceBSPTree3.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion9 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8, euclidean1DRegion9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, true);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint14 = orientedPoint13.wholeHyperplane();
        boolean boolean15 = orientedPoint8.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double17 = vector2D16.getNorm();
        java.text.NumberFormat numberFormat18 = null;
        java.lang.String str19 = vector2D16.toString(numberFormat18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double21 = vector2D20.getNorm();
        java.text.NumberFormat numberFormat22 = null;
        java.lang.String str23 = vector2D20.toString(numberFormat22);
        org.apache.commons.math3.geometry.euclidean.twod.Line line24 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D16, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine25 = line24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet26 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine27 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet26);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion28 = intervalsSet26.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint29 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint13, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet26);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree30 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceBSPTree1, spaceBSPTree5, (java.lang.Object) intervalsSet26);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.Space> spaceHyperplane31 = null;
        try {
            boolean boolean32 = spaceBSPTree1.insertCut(spaceHyperplane31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(spaceSubHyperplane2);
        org.junit.Assert.assertNotNull(spaceBSPTree4);
        org.junit.Assert.assertNotNull(spaceBSPTree5);
        org.junit.Assert.assertNotNull(subOrientedPoint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{(Infinity); (Infinity)}" + "'", str19.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{(Infinity); (Infinity)}" + "'", str23.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine25);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion28);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(96.99999f, (-127));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.701147E-37f + "'", float2 == 5.701147E-37f);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line4 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D2, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine5 = line4.wholeLine();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line10 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line15 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = line10.intersection(line15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = line4.closestPoint(line15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line26 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D24, vector3D25);
        double double27 = vector3D21.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        double double28 = vector3D18.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D18.orthogonal();
        double double30 = line15.distance(vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D29.scalarMultiply((double) (byte) 1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(subLine5);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.588046279947166d + "'", double27 == 2.588046279947166d);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D32);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = line8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet10);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion12 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, euclidean1DRegion12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double15 = vector2D14.getNorm();
        java.text.NumberFormat numberFormat16 = null;
        java.lang.String str17 = vector2D14.toString(numberFormat16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double19 = vector2D18.getNorm();
        java.text.NumberFormat numberFormat20 = null;
        java.lang.String str21 = vector2D18.toString(numberFormat20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = line22.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet24 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine25 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line22, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet24);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion26 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine27 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line22, euclidean1DRegion26);
        boolean boolean28 = line8.isParallelTo(line22);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = line8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = vector1D30.negate();
        java.lang.String str32 = vector1D31.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = line8.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D31);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine9);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{(Infinity); (Infinity)}" + "'", str17.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{(Infinity); (Infinity)}" + "'", str21.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(subLine29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{-0}" + "'", str32.equals("{-0}"));
        org.junit.Assert.assertNotNull(vector2D33);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line4 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D2, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line9 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D7, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = line4.intersection(line9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = line9.getDirection();
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        line8.setAngle((double) 0.0f);
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = line8.getReverse();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double13 = vector2D12.getNorm();
        java.text.NumberFormat numberFormat14 = null;
        java.lang.String str15 = vector2D12.toString(numberFormat14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double17 = vector2D16.getNorm();
        java.text.NumberFormat numberFormat18 = null;
        java.lang.String str19 = vector2D16.toString(numberFormat18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = line20.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line20, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        double double24 = intervalsSet22.getSup();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine25 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double28 = vector2D27.getNorm();
        java.text.NumberFormat numberFormat29 = null;
        java.lang.String str30 = vector2D27.toString(numberFormat29);
        boolean boolean31 = vector2D27.isInfinite();
        boolean boolean32 = vector2D27.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D26.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        line11.translateToPoint(vector2D33);
        double double35 = vector2D33.getNorm();
        java.lang.String str36 = vector2D33.toString();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(line11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{(Infinity); (Infinity)}" + "'", str15.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{(Infinity); (Infinity)}" + "'", str19.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{(Infinity); (Infinity)}" + "'", str30.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{(NaN); (NaN)}" + "'", str36.equals("{(NaN); (NaN)}"));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        double[] doubleArray3 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3);
        double[] doubleArray9 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line16 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D14, vector3D15);
        double[] doubleArray17 = vector3D15.toArray();
        double double18 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray3, doubleArray17);
        double[] doubleArray23 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23);
        double[] doubleArray28 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        double[] doubleArray34 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double35 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray28, doubleArray34);
        double[] doubleArray39 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39);
        double[] doubleArray45 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double46 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray39, doubleArray45);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equals(doubleArray34, doubleArray39);
        boolean boolean48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray24, doubleArray39);
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray3, doubleArray39);
        double[] doubleArray53 = new double[] { '4', (short) 100, 10 };
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray59 = new double[] { (byte) -1, 100.0d, 100L, (byte) 0 };
        double double60 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray53, doubleArray59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray53);
        double double62 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray3, doubleArray53);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 143.0d + "'", double10 == 143.0d);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 143.0d + "'", double35 == 143.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 143.0d + "'", double46 == 143.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 143.0d + "'", double60 == 143.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 12804.0d + "'", double62 == 12804.0d);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double1 = vector2D0.getNorm();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double5 = vector2D4.getNorm();
        java.text.NumberFormat numberFormat6 = null;
        java.lang.String str7 = vector2D4.toString(numberFormat6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = line8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet10 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine11 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double13 = vector2D12.getNorm();
        java.text.NumberFormat numberFormat14 = null;
        java.lang.String str15 = vector2D12.toString(numberFormat14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        double double17 = vector2D16.getNorm();
        java.text.NumberFormat numberFormat18 = null;
        java.lang.String str19 = vector2D16.toString(numberFormat18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = line20.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine23 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line20, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        double double24 = intervalsSet22.getSup();
        boolean boolean25 = intervalsSet22.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine26 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList27 = intervalsSet22.asList();
        double double28 = intervalsSet22.getInf();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(Infinity); (Infinity)}" + "'", str3.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{(Infinity); (Infinity)}" + "'", str7.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine9);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{(Infinity); (Infinity)}" + "'", str15.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{(Infinity); (Infinity)}" + "'", str19.equals("{(Infinity); (Infinity)}"));
        org.junit.Assert.assertNotNull(subLine21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(intervalList27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.NEGATIVE_INFINITY + "'", double28 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line6 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D4, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = line6.pointAt((double) 'a');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, true);
        java.lang.Object[] objArray14 = new java.lang.Object[] { 'a', "{(Infinity); (Infinity)}", 0, orientedPoint13 };
        org.apache.commons.math3.exception.MathInternalError mathInternalError15 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray14);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line4 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D2, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = line4.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line10 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D8, vector3D9);
        double[] doubleArray11 = vector3D9.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = line4.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double14 = vector1D12.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line20 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D18, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = line20.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) -1, (-1.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Line line26 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D24, vector3D25);
        double[] doubleArray27 = vector3D25.toArray();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = line20.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = vector1D13.subtract(Double.NaN, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = vector1D28.negate();
        org.apache.commons.math3.geometry.Space space31 = vector1D30.getSpace();
        double double32 = vector1D30.getX();
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7273243567064203d + "'", double14 == 0.7273243567064203d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(space31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-0.8528331353239157d) + "'", double32 == (-0.8528331353239157d));
    }
}

