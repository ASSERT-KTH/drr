import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(100.0d, 0.0d, (double) (byte) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            long long3 = randomDataImpl0.nextPoisson((double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
        double double4 = normalDistributionImpl2.density((double) 1L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.003989422804014327d + "'", double4 == 0.003989422804014327d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (short) -1, Double.POSITIVE_INFINITY, (double) '4', (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.asin(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.2929849611597304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2848798508461752d + "'", double1 == 0.2848798508461752d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) -1, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6420149920119997d) + "'", double1 == (-0.6420149920119997d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(100.0d, 0.7615941559557649d, 100.0d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.450029527644452d + "'", double1 == 3.450029527644452d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException2.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            int int4 = randomDataImpl0.nextZipf(1, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.sinh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        try {
//            double double4 = randomDataImpl0.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 92L + "'", long2 == 92L);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextBinomial((int) '#', (double) 1);
//        try {
//            long long8 = randomDataImpl0.nextSecureLong(79L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 79 is larger than, or equal to, the maximum (0): lower bound (79) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7615941559557649d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.761594155955765d + "'", double2 == 0.761594155955765d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (short) 10, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.3141304086286656d + "'", double0 == 0.3141304086286656d);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 79L, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.986706960784508d + "'", double2 == 0.986706960784508d);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextBinomial((int) '#', (double) 1);
//        try {
//            long long7 = randomDataImpl0.nextPoisson((double) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 92L + "'", long2 == 92L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
        try {
            double double7 = randomDataImpl0.nextGamma((double) 1L, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.String str6 = outOfRangeException4.toString();
        java.lang.Number number7 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range" + "'", str6.equals("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(3.450029527644452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3358539792705194d + "'", double1 == 0.3358539792705194d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 35);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.761594155955765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.14168768474935d + "'", double1 == 1.14168768474935d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int2 = org.apache.commons.math.util.FastMath.min(100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.25264237123108163d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10L, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.2848798508461752d, (java.lang.Number) 2.220446049250313E-16d, false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            double double4 = randomDataImpl0.nextBeta(0.0d, (-0.7853981633974483d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.566");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray2);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.MaxIterationsExceededException: ", objArray7);
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray13);
        java.lang.Object[] objArray15 = maxIterationsExceededException14.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray15);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8373830985134536d + "'", double1 == 0.8373830985134536d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(Double.NaN, (double) '#', 0.2848798508461752d, (int) (short) 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.505149978319906d, (double) 79L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0685684760124517E14d + "'", double2 == 1.0685684760124517E14d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.657242590218247d) + "'", double1 == (-3.657242590218247d));
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        try {
//            java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.018604050328675292d) + "'", double8 == (-0.018604050328675292d));
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.floor(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        try {
            double double2 = normalDistributionImpl0.inverseCumulativeProbability(Double.NEGATIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -∞ out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.toString();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str4.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        try {
//            int int7 = randomDataImpl0.nextHypergeometric((int) (byte) 0, 0, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.754224577313916d + "'", double3 == 31.754224577313916d);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38905609893065d + "'", double1 == 6.38905609893065d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.7615941559557649d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1L), 0.2848798508461752d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 29L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5061454830783556d + "'", double1 == 0.5061454830783556d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.7615941559557649d, 0.5061454830783556d, (double) 79L, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1), (-0.0038387712000540475d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0038387712000540475d) + "'", double2 == (-0.0038387712000540475d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.141592653589793d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.14168768474935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.851458922995501d + "'", double1 == 0.851458922995501d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray2 = normalDistributionImpl0.sample(10);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long2 = org.apache.commons.math.util.FastMath.min(32L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.450029527644452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int2 = org.apache.commons.math.util.FastMath.min(2, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9226350743220142d) + "'", double1 == (-0.9226350743220142d));
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        try {
//            int int11 = randomDataImpl0.nextBinomial((int) (short) -1, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.508731968631009d) + "'", double8 == (-0.508731968631009d));
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray12);
        java.lang.Object[] objArray14 = maxIterationsExceededException13.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathIllegalArgumentException15.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNull(localizable16);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.0038387712000540475d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.2848798508461752d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28888108287753095d + "'", double1 == 0.28888108287753095d);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl0.reseedRandomGenerator((long) (short) 10);
//        try {
//            double double7 = normalDistributionImpl0.inverseCumulativeProbability((-0.6420149920119997d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.642 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8861300461901891d + "'", double1 == 0.8861300461901891d);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        try {
//            long long9 = randomDataImpl0.nextLong((long) (byte) 100, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 163.9784376814613d + "'", double4 == 163.9784376814613d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.3783618361403873d + "'", double6 == 1.3783618361403873d);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (short) 0 + "'", number2.equals((short) 0));
        org.junit.Assert.assertNull(localizable3);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        try {
//            java.lang.String str9 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104L + "'", long2 == 104L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 18L + "'", long5 == 18L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Object[] objArray12 = mathException10.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("hi!", objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, "", objArray12);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(20.472999632165667d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 35, 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3721518339633933E-13d + "'", double2 == 1.3721518339633933E-13d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.3012440777293522d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.4873480529562464d) + "'", double1 == (-3.4873480529562464d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        java.lang.Number number7 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0f) + "'", number6.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        try {
//            int int12 = randomDataImpl0.nextHypergeometric((-1), (int) (byte) 0, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-3.657242590218247d), (java.lang.Number) (byte) 1, false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
        try {
            int int7 = randomDataImpl0.nextInt((int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (0): lower bound (1) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.986706960784508d, (double) 100.0f, 0.9405152825166656d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 100 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.asin(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double2 = org.apache.commons.math.util.FastMath.min(0.9405152825166656d, 0.986706960784508d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9405152825166656d + "'", double2 == 0.9405152825166656d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (-1L), 30.997419023240273d, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable6, objArray7);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) (-0.7615941559557649d), (java.lang.Number) (-1.0d), false);
        org.junit.Assert.assertNotNull(localizable3);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl0.reseedRandomGenerator((long) (short) 10);
//        try {
//            double double8 = normalDistributionImpl0.cumulativeProbability(0.8373830985134536d, (double) (-1.0f));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9877141391639106d) + "'", double1 == (-0.9877141391639106d));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
//        double double7 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-120.78333931532192d) + "'", double4 == (-120.78333931532192d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 81.25330637390306d + "'", double7 == 81.25330637390306d);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.14168768474935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05754731639635013d + "'", double1 == 0.05754731639635013d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.floor((-3.4873480529562464d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.0d) + "'", double1 == (-4.0d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = mathException2.getArguments();
        java.lang.Object[] objArray5 = mathException2.getArguments();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray8);
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException9, "org.apache.commons.math.MaxIterationsExceededException: ", objArray13);
        mathException2.addSuppressed((java.lang.Throwable) convergenceException15);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(Double.NEGATIVE_INFINITY, (double) 52.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.99080170392026d + "'", double3 == 31.99080170392026d);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray18);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray20);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray26 = mathException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable9, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 0);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable37, objArray38);
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = mathException42.getGeneralPattern();
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("", objArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException46.getGeneralPattern();
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable47, objArray48);
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray52);
        java.lang.Object[] objArray54 = maxIterationsExceededException53.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(localizable33, objArray54);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable3, objArray54);
        java.lang.Class<?> wildcardClass58 = objArray54.getClass();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(wildcardClass58);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.986706960784508d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9867069607845081d + "'", double1 == 0.9867069607845081d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        try {
//            int[] intArray8 = randomDataImpl0.nextPermutation((int) (short) 10, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 88L + "'", long2 == 88L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 29L + "'", long5 == 29L);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0L, (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        try {
//            int int6 = randomDataImpl0.nextHypergeometric(1, (int) (byte) 0, 32);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (1): sample size (32) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.8373830985134536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.Object[] objArray4 = maxIterationsExceededException3.getArguments();
        java.lang.String str5 = maxIterationsExceededException3.getPattern();
        int int6 = maxIterationsExceededException3.getMaxIterations();
        java.lang.Object[] objArray7 = maxIterationsExceededException3.getArguments();
        java.lang.String str8 = maxIterationsExceededException3.toString();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str8.equals("org.apache.commons.math.MaxIterationsExceededException: "));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double10 = normalDistributionImpl7.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.393270460587d + "'", double3 == 32.393270460587d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 138.57706820511154d + "'", double8 == 138.57706820511154d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-3.0787058093669732d) + "'", double9 == (-3.0787058093669732d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 128.12746705480467d + "'", double10 == 128.12746705480467d);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl0.reseedRandomGenerator((long) (short) 10);
//        double double6 = normalDistributionImpl0.getMean();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.34177037923382253d + "'", double1 == 0.34177037923382253d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException9);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.ulp(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        try {
//            double double6 = randomDataImpl0.nextF(0.761594155955765d, (-4.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -4 is smaller than, or equal to, the minimum (0): degrees of freedom (-4)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.32779325811926d + "'", double3 == 31.32779325811926d);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5.298342365610589d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 5.298342365610589d + "'", number2.equals(5.298342365610589d));
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        try {
//            int[] intArray9 = randomDataImpl0.nextPermutation(8, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (8): permutation size (100) exceeds permuation domain (8)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-123.31872439750363d) + "'", double4 == (-123.31872439750363d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4543203063674497d + "'", double6 == 0.4543203063674497d);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 0, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.05754731639635013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05761092702151066d + "'", double1 == 0.05761092702151066d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.0d), 0.003989422804014327d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5668069251552255d) + "'", double2 == (-1.5668069251552255d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.003989422804014327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999920422633997d + "'", double1 == 0.9999920422633997d);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        double double11 = randomDataImpl0.nextWeibull((double) (byte) 1, (double) 10);
//        try {
//            java.lang.String str13 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.143486455841289d + "'", double11 == 4.143486455841289d);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.25264237123108163d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1.5707963267948966d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 16L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.000000000000004d + "'", double1 == 16.000000000000004d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.3358539792705194d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str1 = convergenceException0.getPattern();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "convergence failed" + "'", str1.equals("convergence failed"));
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        try {
//            double double11 = randomDataImpl0.nextF((-3.0787058093669732d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.079 is smaller than, or equal to, the minimum (0): degrees of freedom (-3.079)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        try {
//            double[] doubleArray18 = normalDistributionImpl10.sample((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.266793715188147d + "'", double3 == 31.266793715188147d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-45.54080503024196d) + "'", double8 == (-45.54080503024196d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-9.497442094286566d) + "'", double9 == (-9.497442094286566d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.3865325444429992d) + "'", double11 == (-0.3865325444429992d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.06408187969492422d) + "'", double16 == (-0.06408187969492422d));
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.sin((-3.4873480529562464d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3389074684885896d + "'", double1 == 0.3389074684885896d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray12);
        java.lang.Object[] objArray14 = maxIterationsExceededException13.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number24 = outOfRangeException23.getLo();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException27.getGeneralPattern();
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException31.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable32, objArray33);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException37.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = mathException41.getGeneralPattern();
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable42, objArray43);
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray47);
        java.lang.Object[] objArray49 = maxIterationsExceededException48.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable28, objArray49);
        java.lang.Object[] objArray54 = null;
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("", objArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = mathException55.getGeneralPattern();
        java.lang.Object[] objArray57 = mathException55.getArguments();
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("hi!", objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray57);
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException23, localizable28, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable3, objArray62);
        org.apache.commons.math.exception.util.Localizable localizable66 = convergenceException65.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1L + "'", number24.equals(1L));
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(localizable56);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNull(localizable66);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-12.333300118849895d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-12.0d) + "'", double1 == (-12.0d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.505149978319906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 86.23874129193797d + "'", double1 == 86.23874129193797d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
        try {
            double[] doubleArray4 = normalDistributionImpl2.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        java.lang.Object[] objArray7 = mathException5.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray7);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray7);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray7);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        try {
//            int int7 = randomDataImpl0.nextBinomial((-1), (double) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 92L + "'", long4 == 92L);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 92L, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 91.99999999999999d + "'", double2 == 91.99999999999999d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable4, objArray5);
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable4, objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable4, objArray12);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getGeneralPattern();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable17, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable20, objArray21);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable20, objArray23);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable17);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        randomDataImpl0.reSeed();
        try {
            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.MaxIterationsExceededException: ", "0");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 0");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [0.762, 10] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [0.762, 10] range"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        randomDataImpl0.reSeed();
        try {
            java.lang.String str4 = randomDataImpl0.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 6, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 5.298342365610589d, true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-3.657242590218247d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9986692380450296d) + "'", double1 == (-0.9986692380450296d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(28.22181684539933d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03606876195880223d + "'", double1 == 0.03606876195880223d);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        try {
//            long long13 = randomDataImpl0.nextLong(16L, (long) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 16 is larger than, or equal to, the maximum (0): lower bound (16) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.5005776919172245d) + "'", double8 == (-1.5005776919172245d));
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double2 = org.apache.commons.math.util.FastMath.pow((-72.24238624133257d), (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable23, objArray24);
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray28);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable9, objArray30);
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray38 = mathException36.getArguments();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray38);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable9, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = mathException45.getSpecificPattern();
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException50.getGeneralPattern();
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.exception.util.Localizable localizable55 = mathException54.getGeneralPattern();
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable55, objArray56);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getGeneralPattern();
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = mathException65.getGeneralPattern();
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable66, objArray67);
        java.lang.Object[] objArray71 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray71);
        java.lang.Object[] objArray73 = maxIterationsExceededException72.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, objArray73);
        java.lang.Object[] objArray76 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException57, "hi!", objArray76);
        java.lang.Class<?> wildcardClass79 = objArray76.getClass();
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45, "org.apache.commons.math.MaxIterationsExceededException: ", objArray76);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertNotNull(localizable55);
        org.junit.Assert.assertNotNull(localizable62);
        org.junit.Assert.assertNotNull(localizable66);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(wildcardClass79);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.851458922995501d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 48.78500271639676d + "'", double1 == 48.78500271639676d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-3.657242590218247d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9741964342752427d) + "'", double1 == (-0.9741964342752427d));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math.util.FastMath.acos(86.23874129193797d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9117339147869651d) + "'", double1 == (-0.9117339147869651d));
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextHexString(1);
//        java.lang.Class<?> wildcardClass5 = randomDataImpl0.getClass();
//        try {
//            int int9 = randomDataImpl0.nextHypergeometric(0, (-1), (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "e" + "'", str4.equals("e"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        long long1 = org.apache.commons.math.util.FastMath.round(0.05754731639635013d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.851458922995501d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9581354432636043d + "'", double1 == 0.9581354432636043d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.atan(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            int[] intArray12 = randomDataImpl0.nextPermutation((int) (byte) -1, 6);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 6 is larger than the maximum (-1): permutation size (6) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.61981659544395d + "'", double3 == 31.61981659544395d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-10.729283855816456d) + "'", double8 == (-10.729283855816456d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 81.20054149252742d + "'", double9 == 81.20054149252742d);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl1.reSeed();
        java.lang.Object[] objArray4 = new java.lang.Object[] { randomDataImpl1, 0.2848798508461752d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException5);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(32.9920634214314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.53033097666999d + "'", double1 == 81.53033097666999d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.0f));
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextBinomial((int) '#', (double) 1);
//        randomDataImpl0.reSeedSecure(115L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl0.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.2023073870556353d), (double) (byte) 1, 0.2929849611597304d, 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        long long1 = org.apache.commons.math.util.FastMath.round(0.8575897891663393d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 98L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5605925993009424d + "'", double1 == 1.5605925993009424d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.Object[] objArray4 = maxIterationsExceededException3.getArguments();
        java.lang.String str5 = maxIterationsExceededException3.getPattern();
        int int6 = maxIterationsExceededException3.getMaxIterations();
        java.lang.Object[] objArray7 = maxIterationsExceededException3.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = mathException2.getArguments();
        java.lang.Object[] objArray5 = mathException2.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        try {
//            double double9 = randomDataImpl0.nextF((-1.0842933296684554d), 30.801156128925953d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.084 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.084)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "655599d9e31393bc61076c14d35209df9276773d3d983102f95c97ff70ccff2a00d82f31869b2a807ef95c78419a9503330c" + "'", str4.equals("655599d9e31393bc61076c14d35209df9276773d3d983102f95c97ff70ccff2a00d82f31869b2a807ef95c78419a9503330c"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "25edc7311f34afc1c0a56c2259ecf0e355d7b8982caf4a83f805beabb6ab0af5af9b5f21d068ee46b74dcd36ae6ef5fea592" + "'", str6.equals("25edc7311f34afc1c0a56c2259ecf0e355d7b8982caf4a83f805beabb6ab0af5af9b5f21d068ee46b74dcd36ae6ef5fea592"));
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 50.02274797942717d, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 0.9405152825166656d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl14.reSeed();
//        randomDataImpl14.reSeed();
//        java.lang.String str18 = randomDataImpl14.nextSecureHexString((int) (short) 100);
//        java.lang.String str20 = randomDataImpl14.nextHexString((int) (short) 100);
//        double double22 = randomDataImpl14.nextExponential((double) (byte) 10);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl27 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double28 = randomDataImpl24.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl27);
//        double double30 = randomDataImpl24.nextChiSquare(1.505149978319906d);
//        java.lang.Object[] objArray34 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray34);
//        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException35);
//        java.lang.Object[] objArray38 = null;
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray38);
//        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
//        java.lang.Object[] objArray41 = null;
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable40, objArray41);
//        java.lang.Object[] objArray44 = null;
//        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = mathException45.getGeneralPattern();
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("", objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getGeneralPattern();
//        java.lang.Object[] objArray51 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable50, objArray51);
//        java.lang.Object[] objArray55 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray55);
//        java.lang.Object[] objArray57 = maxIterationsExceededException56.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray57);
//        java.lang.Object[] objArray60 = null;
//        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getGeneralPattern();
//        java.lang.Object[] objArray63 = mathException61.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable46, objArray63);
//        java.lang.Object[] objArray65 = new java.lang.Object[] { randomDataImpl14, 30.801156128925953d, randomDataImpl24, (-3.0955394158806593d), mathException36, mathIllegalArgumentException64 };
//        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable7, objArray65);
//        org.apache.commons.math.exception.util.Localizable localizable67 = convergenceException66.getSpecificPattern();
//        org.junit.Assert.assertNotNull(localizable3);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20a91cc5acd79dcbf03b09417fe7c88b2cb79024f2dafca5cd229bc1b88b730f75e1fca599716d4c16d71bdf65db3ac80768" + "'", str18.equals("20a91cc5acd79dcbf03b09417fe7c88b2cb79024f2dafca5cd229bc1b88b730f75e1fca599716d4c16d71bdf65db3ac80768"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "06a596309d910bbe903f65f356b71c8b9a7584403674925444427458125749227a059d62af1b82982f3b6e3324023aca62c4" + "'", str20.equals("06a596309d910bbe903f65f356b71c8b9a7584403674925444427458125749227a059d62af1b82982f3b6e3324023aca62c4"));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 30.686584702447313d + "'", double22 == 30.686584702447313d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 50.04907906220467d + "'", double28 == 50.04907906220467d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.783794700358193d + "'", double30 == 4.783794700358193d);
//        org.junit.Assert.assertNotNull(objArray34);
//        org.junit.Assert.assertNotNull(localizable40);
//        org.junit.Assert.assertNotNull(localizable46);
//        org.junit.Assert.assertNotNull(localizable50);
//        org.junit.Assert.assertNotNull(objArray55);
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(localizable62);
//        org.junit.Assert.assertNotNull(objArray63);
//        org.junit.Assert.assertNotNull(objArray65);
//        org.junit.Assert.assertNull(localizable67);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.586013452313429E15d + "'", double1 == 1.586013452313429E15d);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        try {
//            double double11 = randomDataImpl0.nextBeta(0.0d, (double) 1L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.982");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        try {
//            randomDataImpl0.setSecureAlgorithm("09f9a0aac00a1f94d834f5846d5f9e1988679a6c9b5becae6f49a3e3d9ced706481a16a6168413f6dca6cce5191a29d7ef9a", "20a91cc5acd79dcbf03b09417fe7c88b2cb79024f2dafca5cd229bc1b88b730f75e1fca599716d4c16d71bdf65db3ac80768");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 20a91cc5acd79dcbf03b09417fe7c88b2cb79024f2dafca5cd229bc1b88b730f75e1fca599716d4c16d71bdf65db3ac80768");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 84L + "'", long2 == 84L);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.586013452313429E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796326794896d + "'", double1 == 1.570796326794896d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 3.0d);
        org.junit.Assert.assertNotNull(localizable3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable18, objArray19);
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray23);
        java.lang.Object[] objArray25 = maxIterationsExceededException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException9, "hi!", objArray28);
        java.lang.Object[] objArray31 = convergenceException30.getArguments();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray31);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            double[] doubleArray11 = normalDistributionImpl7.sample((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.911353098929283d + "'", double3 == 31.911353098929283d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-50.78443343500034d) + "'", double8 == (-50.78443343500034d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 50.247038017683785d + "'", double9 == 50.247038017683785d);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.asin(19.1394405278759d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        double double11 = randomDataImpl0.nextWeibull((double) (byte) 1, (double) 10);
//        double double13 = randomDataImpl0.nextT(16.000000000000004d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.517736520274479d + "'", double11 == 6.517736520274479d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.7608791376126396d) + "'", double13 == (-1.7608791376126396d));
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.toString();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str4.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNull(localizable9);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
//        double double8 = normalDistributionImpl3.density(0.22315113192007208d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-70.60551677167162d) + "'", double4 == (-70.60551677167162d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.003989302426161554d + "'", double8 == 0.003989302426161554d);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        long long1 = org.apache.commons.math.util.FastMath.abs(36L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 36L + "'", long1 == 36L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.14498349703834462d), 0.34177037923382253d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 10, (-117.81841732228152d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-120.78333931532192d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4272753813112566E52d) + "'", double1 == (-1.4272753813112566E52d));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.log10(32.31608050161581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5094186813183996d + "'", double1 == 1.5094186813183996d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1L, (float) 92L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 92.0f + "'", float2 == 92.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.expm1(87.61393312822008d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1226585686029999E38d + "'", double1 == 1.1226585686029999E38d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 79L, (java.lang.Number) 3.141592653589793d, true);
        java.lang.Object[] objArray14 = numberIsTooSmallException13.getArguments();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(35);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.special.Erf.erf(1.570796326794896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9736789250782586d + "'", double1 == 0.9736789250782586d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7568024953079282d) + "'", double1 == (-0.7568024953079282d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        long long1 = org.apache.commons.math.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math.util.FastMath.log(81.25330637390306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.397571514214528d + "'", double1 == 4.397571514214528d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 1.0E-9d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.3389074684885896d, (java.lang.Number) (-70.60551677167162d), false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.38905609893065d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7320010136879552d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.94056868361783d + "'", double1 == 41.94056868361783d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 79L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8976270912904414d + "'", double1 == 1.8976270912904414d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
        double double5 = normalDistributionImpl2.cumulativeProbability(3.450029527644452d, (double) 100);
        double double6 = normalDistributionImpl2.getMean();
        normalDistributionImpl2.reseedRandomGenerator((long) (short) 100);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.32913971458423197d + "'", double5 == 0.32913971458423197d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 116L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 116.0f + "'", float1 == 116.0f);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        try {
//            int int9 = randomDataImpl0.nextInt(100, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10): lower bound (100) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 23L + "'", long4 == 23L);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        try {
//            randomDataImpl0.setSecureAlgorithm("c", "e65f7f88810dc973c2b2b8021702bbcb4c9152a5e13c9a599801b6684d019f7c9603631045e16016d99931a9402d2e7a57a4");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: e65f7f88810dc973c2b2b8021702bbcb4c9152a5e13c9a599801b6684d019f7c9603631045e16016d99931a9402d2e7a57a4");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(19.1394405278759d, 0.0d, 1.7453292519943295d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20766209751368098d + "'", double1 == 0.20766209751368098d);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextCauchy(0.22315113192007208d, 5.298292365610485d);
//        try {
//            double double12 = randomDataImpl0.nextBeta(0.25264237123108163d, (double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.283");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "79a860d84190d75a94f6e88d35e88f84c0aabf50b5e4887ba8c051c1972f28921d16f2c139d347ccf5af315d516ab5182468" + "'", str4.equals("79a860d84190d75a94f6e88d35e88f84c0aabf50b5e4887ba8c051c1972f28921d16f2c139d347ccf5af315d516ab5182468"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "204fb3c376d3605048d658928dd160c2ff6e19404f316590f2060634cdfcaeae9e8d73cd52882e2c002e88b210afd00e0fd1" + "'", str6.equals("204fb3c376d3605048d658928dd160c2ff6e19404f316590f2060634cdfcaeae9e8d73cd52882e2c002e88b210afd00e0fd1"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-20.148999773845528d) + "'", double9 == (-20.148999773845528d));
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 0.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("20a91cc5acd79dcbf03b09417fe7c88b2cb79024f2dafca5cd229bc1b88b730f75e1fca599716d4c16d71bdf65db3ac80768", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.17148525016341d + "'", double3 == 32.17148525016341d);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, 92L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 89L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.233403117511217d) + "'", double1 == (-1.233403117511217d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int2 = org.apache.commons.math.util.FastMath.min(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19086079374478304d + "'", double1 == 0.19086079374478304d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextHexString(1);
//        java.lang.Class<?> wildcardClass5 = randomDataImpl0.getClass();
//        long long7 = randomDataImpl0.nextPoisson(7.105427357601002E-15d);
//        try {
//            double double10 = randomDataImpl0.nextGamma(1.8976270912904414d, (-3.0955394158806593d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.096 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.3358539792705194d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0033585271649166503d + "'", double2 == 0.0033585271649166503d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-12.0d), (java.lang.Number) 81.25330637390306d, (java.lang.Number) 0.2929849611597304d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 98L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010256320350359577d + "'", double1 == 0.010256320350359577d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 101L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 101.0d + "'", double1 == 101.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.Object[] objArray4 = maxIterationsExceededException3.getArguments();
        java.lang.String str5 = maxIterationsExceededException3.getPattern();
        int int6 = maxIterationsExceededException3.getMaxIterations();
        int int7 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.5061454830783556d, 0.9405152825166656d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1727699476927287d + "'", double2 == 0.1727699476927287d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5605925993009424d, 50.02274797942717d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.02274797942717d + "'", double2 == 50.02274797942717d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double5 = normalDistributionImpl3.getStandardDeviation();
//        try {
//            double double8 = normalDistributionImpl3.cumulativeProbability(2.482665399191234d, (-0.9986692380450296d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.236989519272818d) + "'", double4 == (-4.236989519272818d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 89L, (float) 116L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 89.0f + "'", float2 == 89.0f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.special.Erf.erf(128.12746705480467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.tanh(60.40268274916248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.special.Gamma.digamma(32.31608050161581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4600129900961423d + "'", double1 == 3.4600129900961423d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.003989422804014327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0039973911440043d + "'", double1 == 1.0039973911440043d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 98L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.0d + "'", double1 == 98.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(50.02274797942717d, 32.31608050161581d, (-1.4272753813112566E52d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        long long1 = org.apache.commons.math.util.FastMath.round(4.9E-324d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) ' ');
        double double4 = normalDistributionImpl2.density(0.761594155955765d);
        try {
            double[] doubleArray6 = normalDistributionImpl2.sample((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.012463415928158344d + "'", double4 == 0.012463415928158344d);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        long long11 = randomDataImpl0.nextSecureLong((long) 9, (long) (byte) 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9L + "'", long11 == 9L);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) -1, (float) 105L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.003989422804014327d, (double) 98L, 30.686584702447313d, 2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1308751362997987E-47d + "'", double4 == 1.1308751362997987E-47d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable18, objArray19);
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray23);
        java.lang.Object[] objArray25 = maxIterationsExceededException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray25);
        java.lang.Object[] objArray28 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException9, "hi!", objArray28);
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30, "", objArray32);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.9226350743220142d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6025297038402304d) + "'", double1 == (-0.6025297038402304d));
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl0.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 57L + "'", long4 == 57L);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double8 = randomDataImpl0.nextExponential((double) (byte) 10);
//        try {
//            java.lang.String str10 = randomDataImpl0.nextHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4dafc9cad7cda5529fe3735d8b319ff4c6ff57f47be16ff2cac4a1e5ac7f94d8e57228e5550d55a3406b444a6485cd276b34" + "'", str4.equals("4dafc9cad7cda5529fe3735d8b319ff4c6ff57f47be16ff2cac4a1e5ac7f94d8e57228e5550d55a3406b444a6485cd276b34"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3fc58d526e600bb8bd598c1b5def255c70b80e19b49c727e14be12f9b4ad03386b70f76c38a3bbdfc21baec71318ec75c20c" + "'", str6.equals("3fc58d526e600bb8bd598c1b5def255c70b80e19b49c727e14be12f9b4ad03386b70f76c38a3bbdfc21baec71318ec75c20c"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.2754664168864545d + "'", double8 == 3.2754664168864545d);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0713836377950487d) + "'", double8 == (-1.0713836377950487d));
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
//        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 53.16492670164904d + "'", double4 == 53.16492670164904d);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 53.16492670164904d, number1, (java.lang.Number) 32.31622791524749d);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        try {
//            double double19 = normalDistributionImpl10.cumulativeProbability(1.0039973911440043d, 0.0d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.38829960013299d + "'", double3 == 33.38829960013299d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-235.9562680790243d) + "'", double8 == (-235.9562680790243d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-325.167680938502d) + "'", double9 == (-325.167680938502d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.5803363622356492d) + "'", double11 == (-0.5803363622356492d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.0024834612659082418d) + "'", double16 == (-0.0024834612659082418d));
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.sample();
//        try {
//            double double6 = normalDistributionImpl2.inverseCumulativeProbability((double) 21L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 21 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 38.95181445087522d + "'", double4 == 38.95181445087522d);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-3.0787058093669732d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9539812248056353d) + "'", double1 == (-0.9539812248056353d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.705026843555238d + "'", double1 == 0.705026843555238d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.1727699476927287d, 0.0d, (double) 92L, 6);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double8 = randomDataImpl0.nextExponential((double) (byte) 10);
//        randomDataImpl0.reSeedSecure(33L);
//        long long12 = randomDataImpl0.nextPoisson(31.148287514303988d);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "5216bb72175f430d119d3f699bb9e8f4bba5f7bd1919f48bb13aac205d07a605f3c5026eecba27901f659742ed86ddfc2785" + "'", str4.equals("5216bb72175f430d119d3f699bb9e8f4bba5f7bd1919f48bb13aac205d07a605f3c5026eecba27901f659742ed86ddfc2785"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "96fab3868a9e8ef164924c8f8288beaceedbd53efab82be085467011e3591807cfd0139094339ddc1372b09bbd8198f37fb9" + "'", str6.equals("96fab3868a9e8ef164924c8f8288beaceedbd53efab82be085467011e3591807cfd0139094339ddc1372b09bbd8198f37fb9"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.2385996627284923d + "'", double8 == 1.2385996627284923d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 25L + "'", long12 == 25L);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.14498349703834462d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.002530439384374561d) + "'", double1 == (-0.002530439384374561d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.Object[] objArray4 = maxIterationsExceededException3.getArguments();
        int int5 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson((double) 100);
        try {
            double double5 = randomDataImpl0.nextF((-1.2023073870556353d), (double) 52.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.202 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.202)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.0713836377950487d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7899819387239765d) + "'", double1 == (-0.7899819387239765d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.9539812248056353d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.837040108747787d + "'", double1 == 2.837040108747787d);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        try {
//            long long9 = randomDataImpl0.nextLong(116L, (long) 32);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 116 is larger than, or equal to, the maximum (32): lower bound (116) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "88a39ce347c1c3727d16d74f4034645b0e994a45e1080933367cbd3f2974a26561c0013a19cd84500663e90fb93ac96b5b7d" + "'", str4.equals("88a39ce347c1c3727d16d74f4034645b0e994a45e1080933367cbd3f2974a26561c0013a19cd84500663e90fb93ac96b5b7d"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "c53e0689f0c814ee7da5cffaa3081c836424648cb209116f981b34a3327d3a75f1ebdbe2ba458620bcb2b009eb591374c8bb" + "'", str6.equals("c53e0689f0c814ee7da5cffaa3081c836424648cb209116f981b34a3327d3a75f1ebdbe2ba458620bcb2b009eb591374c8bb"));
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) (-1.0f));
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException3);
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable12, objArray13);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray17);
        java.lang.Throwable[] throwableArray19 = maxIterationsExceededException18.getSuppressed();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4, localizable8, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("7c4cacb57", (java.lang.Object[]) throwableArray19);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 7.903197862954781d, (java.lang.Number) 0.0033585271649166503d, (java.lang.Number) 32.31608050161581d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.3989422804014327d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        java.lang.Number number7 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0f) + "'", number6.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.5707963267948966d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 115L, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8427007929497151d + "'", double1 == 0.8427007929497151d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.4928776702458777d, 60.40268274916248d, 1.3721518339633933E-13d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 60.40268274916248d + "'", double4 == 60.40268274916248d);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        double double11 = randomDataImpl0.nextWeibull((double) (byte) 1, (double) 10);
//        try {
//            java.lang.String str13 = randomDataImpl0.nextHexString((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.7294147492297762d + "'", double11 == 2.7294147492297762d);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl0.reseedRandomGenerator((long) (short) 10);
//        double double7 = normalDistributionImpl0.cumulativeProbability(0.2848798508461752d);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8254927181220595d) + "'", double1 == (-1.8254927181220595d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6121319033343199d + "'", double7 == 0.6121319033343199d);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.32913971458423197d, 0.761594155955765d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.13426966306239974d + "'", double2 == 0.13426966306239974d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.Object[] objArray4 = maxIterationsExceededException3.getArguments();
        java.lang.String str5 = maxIterationsExceededException3.getPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.log(0.2929849611597304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2276339983822466d) + "'", double1 == (-1.2276339983822466d));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 100.0f, 53.16492670164904d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.6518355123651055E-9d + "'", double2 == 6.6518355123651055E-9d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.Throwable[] throwableArray4 = maxIterationsExceededException3.getSuppressed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.085536923187668d + "'", double1 == 20.085536923187668d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.toString();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number13 = outOfRangeException12.getLo();
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getGeneralPattern();
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable21, objArray22);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException26.getGeneralPattern();
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable31, objArray32);
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray36);
        java.lang.Object[] objArray38 = maxIterationsExceededException37.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable17, objArray38);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = mathException44.getGeneralPattern();
        java.lang.Object[] objArray46 = mathException44.getArguments();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray46);
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException12, localizable17, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable54, (java.lang.Number) (-1.0f));
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException56);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable59, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray65 = null;
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("", objArray65);
        org.apache.commons.math.exception.util.Localizable localizable67 = mathException66.getGeneralPattern();
        java.lang.Object[] objArray69 = null;
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", objArray69);
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException70.getGeneralPattern();
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, localizable71, objArray72);
        java.lang.Object[] objArray76 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException77 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray76);
        java.lang.Object[] objArray78 = maxIterationsExceededException77.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray78);
        java.lang.Object[] objArray81 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray81);
        java.lang.Object[] objArray86 = null;
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException("", objArray86);
        org.apache.commons.math.exception.util.Localizable localizable88 = mathException87.getGeneralPattern();
        java.lang.Object[] objArray89 = mathException87.getArguments();
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException("hi!", objArray89);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray89);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException63, localizable67, objArray89);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException56, "0", objArray89);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7, localizable17, objArray89);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException98 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 33.939803274997736d, (java.lang.Number) (-1.2023073870556353d), false);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str4.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1L + "'", number13.equals(1L));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(localizable67);
        org.junit.Assert.assertNotNull(localizable71);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(localizable88);
        org.junit.Assert.assertNotNull(objArray89);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextHexString(1);
//        try {
//            double double7 = randomDataImpl0.nextWeibull((double) 32L, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            int int13 = randomDataImpl0.nextHypergeometric((int) (byte) 1, (int) (byte) 0, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (1): sample size (10) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.658187174004244d + "'", double3 == 31.658187174004244d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-120.82485248125748d) + "'", double8 == (-120.82485248125748d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 54.45052811301672d + "'", double9 == 54.45052811301672d);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 1L, (double) 92.0f, 0.7320010136879552d, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 92 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextPascal((int) (short) 100, (double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.7606916767324713d, (java.lang.Number) (-0.5402008533629521d), (java.lang.Number) 0.9867069607845081d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int1 = org.apache.commons.math.util.FastMath.abs(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.1308751362997987E-47d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.244596175267494E-16d + "'", double1 == 2.244596175267494E-16d);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        double double5 = randomDataImpl0.nextExponential((double) ' ');
//        randomDataImpl0.reSeed((long) (byte) 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.626917722645313d + "'", double3 == 31.626917722645313d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 54.40676303424352d + "'", double5 == 54.40676303424352d);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int2 = org.apache.commons.math.util.FastMath.min(19, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        try {
//            long long13 = randomDataImpl0.nextSecureLong(4L, (long) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 4 is larger than, or equal to, the maximum (1): lower bound (4) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextHexString(1);
//        double double7 = randomDataImpl0.nextCauchy((double) 'a', (double) 9);
//        double double10 = randomDataImpl0.nextCauchy(7.105427357601002E-15d, (double) 21L);
//        try {
//            double double13 = randomDataImpl0.nextF((-72.24238624133257d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -72.242 is smaller than, or equal to, the minimum (0): degrees of freedom (-72.242)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9" + "'", str4.equals("9"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 107.55204180651971d + "'", double7 == 107.55204180651971d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 23.801230486261712d + "'", double10 == 23.801230486261712d);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.6025297038402304d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6058445596661167d) + "'", double1 == (-0.6058445596661167d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray2);
        java.lang.Throwable[] throwableArray4 = maxIterationsExceededException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException3.getSpecificPattern();
        java.lang.String str6 = maxIterationsExceededException3.getPattern();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextInt(35, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (1): lower bound (35) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double8 = randomDataImpl0.nextExponential((double) (byte) 10);
//        randomDataImpl0.reSeedSecure(33L);
//        try {
//            int int13 = randomDataImpl0.nextZipf((int) '#', (-0.5063656411097588d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.506 is smaller than, or equal to, the minimum (0): exponent (-0.506)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "abbb54c62e32dd1f53b772fe7ae6991088d108ca5261757547ff780eee9e7a6af66f0cc85f034f1381d44fc739840dfd8961" + "'", str4.equals("abbb54c62e32dd1f53b772fe7ae6991088d108ca5261757547ff780eee9e7a6af66f0cc85f034f1381d44fc739840dfd8961"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0e9d178bb43293b8461b81b83dede46a3114bd399779bafd81b1793b6c70c2b1a5d03490ae2da47fb2291979e41dff7594bc" + "'", str6.equals("0e9d178bb43293b8461b81b83dede46a3114bd399779bafd81b1793b6c70c2b1a5d03490ae2da47fb2291979e41dff7594bc"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.072940418638089d + "'", double8 == 8.072940418638089d);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        randomDataImpl0.reSeed();
        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
        randomDataImpl0.reSeedSecure(21L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3169578969248166d + "'", double1 == 1.3169578969248166d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 100, 0.9999920422633997d, 6.6518355123651055E-9d, 8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 21L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3222192947339193d + "'", double1 == 1.3222192947339193d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.0842933296684554d), 0.012463415928158344d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        try {
//            double double13 = randomDataImpl0.nextF((double) 92L, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double2 = org.apache.commons.math.util.FastMath.max(4.397571514214528d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.397571514214528d + "'", double2 == 4.397571514214528d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double2 = org.apache.commons.math.util.FastMath.max(60.40268274916248d, (-72.24238624133257d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 60.40268274916248d + "'", double2 == 60.40268274916248d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5713088006770572d + "'", double1 == 1.5713088006770572d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(31.29066498393885d, 192.659634754793d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 96L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 96.0f + "'", float1 == 96.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) ' ');
        try {
            double[] doubleArray4 = normalDistributionImpl2.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.3358539792705194d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        long long2 = org.apache.commons.math.util.FastMath.min(116L, 94L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        normalDistributionImpl7.reseedRandomGenerator(0L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.31185484011116d + "'", double3 == 33.31185484011116d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.44389700928131d + "'", double8 == 52.44389700928131d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 18.666423381403394d + "'", double9 == 18.666423381403394d);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 31L, (java.lang.Number) 20.472999632165667d, true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5063656411097588d), (java.lang.Number) (-17.179218031774475d), true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 52.0f, 0.9867069607845081d, (double) 96.0f, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 11L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        try {
//            int int9 = randomDataImpl0.nextZipf((int) (short) 0, (double) 1.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 56.69487479562857d + "'", double4 == 56.69487479562857d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.245406373549029d + "'", double6 == 2.245406373549029d);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextBinomial((int) '#', (double) 1);
//        double double8 = randomDataImpl0.nextGaussian(0.010256320350359577d, (double) 29L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 108L + "'", long2 == 108L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-8.850627923511611d) + "'", double8 == (-8.850627923511611d));
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.8976270912904414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.32104317507867886d) + "'", double1 == (-0.32104317507867886d));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) ' ', (-0.0038387712000540475d), 32.278622772393554d, (int) (short) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        randomDataImpl0.reSeed();
//        try {
//            double double10 = randomDataImpl0.nextUniform((-0.7853981633974483d), (-12.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: -0.785 is larger than, or equal to, the maximum (-12): lower bound (-0.785) must be strictly less than upper bound (-12)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 102L + "'", long4 == 102L);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        double double8 = randomDataImpl0.nextWeibull((double) 1.0f, 3.010291586146758d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 105L + "'", long2 == 105L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 11L + "'", long5 == 11L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.6319441550807121d + "'", double8 == 1.6319441550807121d);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-3.657242590218247d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.3012440777293522d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.152291595471665d + "'", double1 == 12.152291595471665d);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "dec1734184");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: dec1734184");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2L + "'", long5 == 2L);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextHexString(1);
//        double double7 = randomDataImpl0.nextCauchy((double) 'a', (double) 9);
//        double double10 = randomDataImpl0.nextCauchy(7.105427357601002E-15d, (double) 21L);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4" + "'", str4.equals("4"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 99.83340030395857d + "'", double7 == 99.83340030395857d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 14.772405255041159d + "'", double10 == 14.772405255041159d);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.9741964342752427d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9913237518512685d) + "'", double1 == (-0.9913237518512685d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 11, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.29100619138474915d) + "'", double1 == (-0.29100619138474915d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (short) 0, 31.148287514303988d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
        randomDataImpl0.reSeedSecure();
        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
        try {
            int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (0): permutation size (35) exceeds permuation domain (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.6420149920119997d), (java.lang.Number) (-0.6420149920119997d), false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 101L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.04987562112089d + "'", double1 == 10.04987562112089d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 39.3398841871995d + "'", double1 == 39.3398841871995d);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextSecureInt(26, (int) 'a');
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 83L + "'", long2 == 83L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 74 + "'", int5 == 74);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(4, "org.apache.commons.math.exception.NumberIsTooLargeException: 0.253 is larger than, or equal to, the maximum (106,856,847,601,245.17)", objArray2);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
//        java.lang.Object[] objArray7 = null;
//        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
//        java.lang.Object[] objArray10 = null;
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable9, objArray10);
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray14);
//        java.lang.Throwable[] throwableArray16 = maxIterationsExceededException15.getSuppressed();
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable9, (java.lang.Object[]) throwableArray16);
//        java.lang.Number number18 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(number18, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
//        java.lang.Class<?> wildcardClass22 = outOfRangeException21.getClass();
//        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException();
//        java.lang.Object[] objArray25 = null;
//        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable27 = mathException26.getGeneralPattern();
//        java.lang.Object[] objArray28 = null;
//        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable27, objArray28);
//        java.lang.Object[] objArray32 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray32);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable27, objArray32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] {};
//        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException23, localizable27, objArray35);
//        java.lang.Object[] objArray39 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray39);
//        java.lang.Throwable[] throwableArray41 = maxIterationsExceededException40.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException21, localizable27, (java.lang.Object[]) throwableArray41);
//        java.lang.Object[] objArray44 = null;
//        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = mathException45.getGeneralPattern();
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("", objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getGeneralPattern();
//        java.lang.Object[] objArray51 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable50, objArray51);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl53 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl54 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl57 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double58 = randomDataImpl54.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl57);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl60 = new org.apache.commons.math.random.RandomDataImpl();
//        double double63 = randomDataImpl60.nextGaussian((double) ' ', 0.7615941559557649d);
//        java.lang.Object[] objArray64 = new java.lang.Object[] { randomDataImpl53, randomDataImpl54, 3.831008000716577E22d, double63 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable46, objArray64);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
//        java.lang.Object[] objArray68 = maxIterationsExceededException67.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable46, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable9, objArray68);
//        org.junit.Assert.assertNotNull(localizable9);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(localizable27);
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNotNull(throwableArray41);
//        org.junit.Assert.assertNotNull(localizable46);
//        org.junit.Assert.assertNotNull(localizable50);
//        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-212.61694432801252d) + "'", double58 == (-212.61694432801252d));
//        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 29.62103631342405d + "'", double63 == 29.62103631342405d);
//        org.junit.Assert.assertNotNull(objArray64);
//        org.junit.Assert.assertNotNull(objArray68);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        int int13 = randomDataImpl0.nextSecureInt((-1), (int) '4');
//        randomDataImpl0.reSeedSecure((long) 1);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution16 = null;
//        try {
//            int int17 = randomDataImpl0.nextInversionDeviate(integerDistribution16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.558807925945288d) + "'", double8 == (-1.558807925945288d));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.18050318869314488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.6420149920119997d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        double double9 = randomDataImpl0.nextGamma(0.7615941559557649d, (double) (short) 10);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-84.97697915824834d) + "'", double4 == (-84.97697915824834d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2800750084700842d + "'", double6 == 0.2800750084700842d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.6871664517955898d + "'", double9 == 3.6871664517955898d);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.0038387712000540475d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = normalDistributionImpl2.cumulativeProbability((-0.7853981633974483d));
//        double double5 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.4928776702458777d + "'", double4 == 0.4928776702458777d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-129.00504062629426d) + "'", double5 == (-129.00504062629426d));
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-39.46792946335992d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-39.467929463359916d) + "'", double1 == (-39.467929463359916d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.244596175267494E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.244596175267494E-16d + "'", double1 == 2.244596175267494E-16d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 52.0f, (-3.657242590218247d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.7615941559557649d), (java.lang.Number) 60.40268274916248d, (java.lang.Number) (-0.14498349703834462d));
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl0.reseedRandomGenerator((long) (short) 10);
//        try {
//            double double7 = normalDistributionImpl0.inverseCumulativeProbability((-0.5402008533629521d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.54 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.40846931211771814d + "'", double1 == 0.40846931211771814d);
//    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        int int13 = randomDataImpl0.nextSecureInt((-1), (int) '4');
//        randomDataImpl0.reSeedSecure((long) 1);
//        java.lang.String str17 = randomDataImpl0.nextHexString((int) (byte) 10);
//        try {
//            int int20 = randomDataImpl0.nextBinomial(11, (-3.0787058093669732d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -3.079 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.45978269533356286d) + "'", double8 == (-0.45978269533356286d));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 33 + "'", int13 == 33);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "842c801582" + "'", str17.equals("842c801582"));
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 74);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17171734183077755d + "'", double1 == 0.17171734183077755d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double2 = org.apache.commons.math.util.FastMath.max(28.22181684539933d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0554544523933395E-6d + "'", double1 == 6.0554544523933395E-6d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.4928776702458777d, 60.40268274916248d, 1.3721518339633933E-13d);
        try {
            double double6 = normalDistributionImpl3.cumulativeProbability((double) 20L, 0.003989422804014327d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.28888108287753095d, 0.9428082996934846d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.288881082877531d + "'", double2 == 0.288881082877531d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 303.5726559648473d + "'", double1 == 303.5726559648473d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 79L, (java.lang.Number) 3.141592653589793d, true);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException26.getGeneralPattern();
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable27, objArray28);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable37, objArray38);
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray42);
        java.lang.Object[] objArray44 = maxIterationsExceededException43.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable23, objArray44);
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException50.getGeneralPattern();
        java.lang.Object[] objArray52 = mathException50.getArguments();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable9, objArray52);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(30.686584702447313d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable7, objArray8);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable7, objArray10);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = mathException14.getGeneralPattern();
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable15, objArray16);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable25, objArray26);
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray30);
        java.lang.Object[] objArray32 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray32);
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray38 = mathException36.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable21, objArray38);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 0);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = mathException44.getGeneralPattern();
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("", objArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = mathException48.getGeneralPattern();
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable49, objArray50);
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.exception.util.Localizable localizable55 = mathException54.getGeneralPattern();
        java.lang.Object[] objArray57 = null;
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("", objArray57);
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException58.getGeneralPattern();
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable59, objArray60);
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray64);
        java.lang.Object[] objArray66 = maxIterationsExceededException65.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException(localizable45, objArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable15, objArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable7, objArray66);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(localizable49);
        org.junit.Assert.assertNotNull(localizable55);
        org.junit.Assert.assertNotNull(localizable59);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 83L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.564318773958797E35d + "'", double1 == 5.564318773958797E35d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.20766209751368098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.45569956935867406d + "'", double1 == 0.45569956935867406d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 31.29066498393885d, (java.lang.Number) 60.40268274916248d, false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 1, (-12.0d), 22.480177048196566d, 32);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.util.FastMath.cos(192.659634754793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5212486533023993d) + "'", double1 == (-0.5212486533023993d));
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) ' ');
//        double double4 = normalDistributionImpl2.density(0.761594155955765d);
//        double double7 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.46111068456459914d);
//        double double8 = normalDistributionImpl2.sample();
//        double double9 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.012463415928158344d + "'", double4 == 0.012463415928158344d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.005748443190683794d + "'", double7 == 0.005748443190683794d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-39.50132947445295d) + "'", double8 == (-39.50132947445295d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.toString();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number13 = outOfRangeException12.getLo();
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getGeneralPattern();
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable21, objArray22);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException26.getGeneralPattern();
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable31, objArray32);
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray36);
        java.lang.Object[] objArray38 = maxIterationsExceededException37.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable17, objArray38);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = mathException44.getGeneralPattern();
        java.lang.Object[] objArray46 = mathException44.getArguments();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray46);
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException12, localizable17, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable54, (java.lang.Number) (-1.0f));
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException56);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable59, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray65 = null;
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("", objArray65);
        org.apache.commons.math.exception.util.Localizable localizable67 = mathException66.getGeneralPattern();
        java.lang.Object[] objArray69 = null;
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", objArray69);
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException70.getGeneralPattern();
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, localizable71, objArray72);
        java.lang.Object[] objArray76 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException77 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray76);
        java.lang.Object[] objArray78 = maxIterationsExceededException77.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray78);
        java.lang.Object[] objArray81 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray81);
        java.lang.Object[] objArray86 = null;
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException("", objArray86);
        org.apache.commons.math.exception.util.Localizable localizable88 = mathException87.getGeneralPattern();
        java.lang.Object[] objArray89 = mathException87.getArguments();
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException("hi!", objArray89);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray89);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException63, localizable67, objArray89);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException56, "0", objArray89);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7, localizable17, objArray89);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException98 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) (-1.5707963267948966d), (java.lang.Number) 0.05902957475692173d, (java.lang.Number) 31.45279382279303d);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str4.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1L + "'", number13.equals(1L));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(localizable67);
        org.junit.Assert.assertNotNull(localizable71);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(localizable88);
        org.junit.Assert.assertNotNull(objArray89);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(55.10439093655774d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 55.104390936557735d + "'", double2 == 55.104390936557735d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9736789250782586d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        java.lang.Number number2 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(number2, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
//        java.lang.Class<?> wildcardClass6 = outOfRangeException5.getClass();
//        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException();
//        java.lang.Object[] objArray9 = null;
//        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
//        java.lang.Object[] objArray12 = null;
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable11, objArray12);
//        java.lang.Object[] objArray16 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray16);
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable11, objArray16);
//        java.lang.Object[] objArray19 = new java.lang.Object[] {};
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7, localizable11, objArray19);
//        java.lang.Object[] objArray23 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray23);
//        java.lang.Throwable[] throwableArray25 = maxIterationsExceededException24.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable11, (java.lang.Object[]) throwableArray25);
//        java.lang.Object[] objArray28 = null;
//        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray28);
//        org.apache.commons.math.exception.util.Localizable localizable30 = mathException29.getGeneralPattern();
//        java.lang.Object[] objArray32 = null;
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("", objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable34 = mathException33.getGeneralPattern();
//        java.lang.Object[] objArray35 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable34, objArray35);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl37 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl38 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl41 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double42 = randomDataImpl38.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl41);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl44 = new org.apache.commons.math.random.RandomDataImpl();
//        double double47 = randomDataImpl44.nextGaussian((double) ' ', 0.7615941559557649d);
//        java.lang.Object[] objArray48 = new java.lang.Object[] { randomDataImpl37, randomDataImpl38, 3.831008000716577E22d, double47 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable30, objArray48);
//        java.lang.Number number50 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number50, (java.lang.Number) 10L, false);
//        java.lang.Object[] objArray55 = null;
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
//        org.apache.commons.math.exception.util.Localizable localizable57 = mathException56.getGeneralPattern();
//        java.lang.Object[] objArray58 = null;
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable57, objArray58);
//        java.lang.Object[] objArray61 = null;
//        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException("", objArray61);
//        org.apache.commons.math.exception.util.Localizable localizable63 = mathException62.getGeneralPattern();
//        java.lang.Object[] objArray65 = null;
//        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("", objArray65);
//        org.apache.commons.math.exception.util.Localizable localizable67 = mathException66.getGeneralPattern();
//        java.lang.Object[] objArray68 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable67, objArray68);
//        java.lang.Object[] objArray72 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray72);
//        java.lang.Object[] objArray74 = maxIterationsExceededException73.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, objArray74);
//        java.lang.Object[] objArray77 = null;
//        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("", objArray77);
//        org.apache.commons.math.exception.util.Localizable localizable79 = mathException78.getGeneralPattern();
//        java.lang.Object[] objArray80 = mathException78.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable63, objArray80);
//        org.apache.commons.math.exception.util.Localizable localizable82 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl83 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl83.reSeed();
//        java.lang.Object[] objArray86 = new java.lang.Object[] { randomDataImpl83, 0.2848798508461752d };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable82, objArray86);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable57, objArray86);
//        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException("554c720530fa3c0d9ad91990f0c721ca1ad889ddf466d08fa9050e949c7396450dada3517cf836e136dc55d0eeae9a291323", objArray86);
//        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException(localizable0, objArray86);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(objArray19);
//        org.junit.Assert.assertNotNull(throwableArray25);
//        org.junit.Assert.assertNotNull(localizable30);
//        org.junit.Assert.assertNotNull(localizable34);
//        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-59.893170528978594d) + "'", double42 == (-59.893170528978594d));
//        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 30.76334078432671d + "'", double47 == 30.76334078432671d);
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(localizable57);
//        org.junit.Assert.assertNotNull(localizable63);
//        org.junit.Assert.assertNotNull(localizable67);
//        org.junit.Assert.assertNotNull(objArray72);
//        org.junit.Assert.assertNotNull(objArray74);
//        org.junit.Assert.assertNotNull(localizable79);
//        org.junit.Assert.assertNotNull(objArray80);
//        org.junit.Assert.assertNotNull(objArray86);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 20L, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(36L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.4272753813112566E52d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-39.467929463359916d), 2.244596175267494E-16d, 0.851458922995501d, (int) (short) 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        double double7 = randomDataImpl0.nextGaussian((-0.5264219283990733d), 0.2848798508461752d);
//        double double9 = randomDataImpl0.nextExponential(0.22315113192007208d);
//        try {
//            long long11 = randomDataImpl0.nextPoisson((-1.0713836377950487d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.071 is smaller than, or equal to, the minimum (0): mean (-1.071)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.4854804815373696d) + "'", double7 == (-0.4854804815373696d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.04139964623578989d + "'", double9 == 0.04139964623578989d);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        long long12 = randomDataImpl0.nextPoisson(1.0d);
//        try {
//            int int15 = randomDataImpl0.nextSecureInt(100, 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (35): lower bound (100) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.8750978475316031d) + "'", double8 == (-0.8750978475316031d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        randomDataImpl0.reSeed();
//        try {
//            double double8 = randomDataImpl0.nextUniform((double) 33L, 4.783794700358193d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 33 is larger than, or equal to, the maximum (4.784): lower bound (33) must be strictly less than upper bound (4.784)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2af38f950ee1fcba465837779c585e9f457e4e091fd66d2ef23106e075ec2c8054af3270497a2782a77872252803f92635cc" + "'", str4.equals("2af38f950ee1fcba465837779c585e9f457e4e091fd66d2ef23106e075ec2c8054af3270497a2782a77872252803f92635cc"));
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double2 = org.apache.commons.math.util.FastMath.max(31.626917722645313d, (-0.3498335702652908d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.626917722645313d + "'", double2 == 31.626917722645313d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.log1p(16.000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.833213344056216d + "'", double1 == 2.833213344056216d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.010291586146758d, 33.31185484011116d, (double) 83L, (int) '4');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0641695387032314E-12d + "'", double4 == 2.0641695387032314E-12d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double1 = org.apache.commons.math.util.FastMath.cosh(32.278622772393554d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.21672277009497E13d + "'", double1 == 5.21672277009497E13d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextUniform((-3.657242590218247d), (double) 35);
//        double double11 = randomDataImpl0.nextChiSquare(1.7453292519943295d);
//        try {
//            double double14 = randomDataImpl0.nextUniform((-0.7568024953079282d), (-1.3222325732294733d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: -0.757 is larger than, or equal to, the maximum (-1.322): lower bound (-0.757) must be strictly less than upper bound (-1.322)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1d6e843dfc6dd3249c1b58dc10020d69a52fd0d22e8944cdd2f464d9bd5312724fbffa4ea876b7058bc1a7724e518716411b" + "'", str4.equals("1d6e843dfc6dd3249c1b58dc10020d69a52fd0d22e8944cdd2f464d9bd5312724fbffa4ea876b7058bc1a7724e518716411b"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ea9016a4279a67639f1c60dc0831b0aadd7f978238600dd2e810a8ce20f77fbd1a8b0122510f7ffd6ee3b021ed3dfeb43b45" + "'", str6.equals("ea9016a4279a67639f1c60dc0831b0aadd7f978238600dd2e810a8ce20f77fbd1a8b0122510f7ffd6ee3b021ed3dfeb43b45"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.420586288550095d + "'", double9 == 6.420586288550095d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8536806807938813d + "'", double11 == 0.8536806807938813d);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable9, objArray10);
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable9, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable9, objArray17);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = maxIterationsExceededException22.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable9, (java.lang.Object[]) throwableArray23);
        java.lang.Number number25 = outOfRangeException3.getLo();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.761594155955765d + "'", number25.equals(0.761594155955765d));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040", (java.lang.Object[]) throwableArray5);
        java.lang.String str7 = convergenceException6.getPattern();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040" + "'", str7.equals("882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040"));
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        double double7 = randomDataImpl0.nextUniform((-0.29100619138474915d), 0.0d);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "d3da9dd0a91ee3cf8d7a1ab8e8001fd631f054700f15d5461ea36a81a658a79600ee375f87847daeae701fc9f32b03ec2885" + "'", str4.equals("d3da9dd0a91ee3cf8d7a1ab8e8001fd631f054700f15d5461ea36a81a658a79600ee375f87847daeae701fc9f32b03ec2885"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.16166977871501662d) + "'", double7 == (-0.16166977871501662d));
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.3546070464784019d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3404549596623409d) + "'", double1 == (-0.3404549596623409d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(52.44389700928131d, (-1.2023073870556353d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable11, objArray12);
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(35, "", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.ConvergenceException: 882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040", objArray18);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("7c4cacb57", objArray18);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double2 = org.apache.commons.math.util.FastMath.atan2(99.83340030395857d, (-0.7777097040252623d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5785862445016798d + "'", double2 == 1.5785862445016798d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        long long1 = org.apache.commons.math.util.FastMath.round(10.405988201924956d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.761594155955765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19086079374478215d + "'", double1 == 0.19086079374478215d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.Object[] objArray4 = maxIterationsExceededException3.getArguments();
        java.lang.String str5 = maxIterationsExceededException3.getPattern();
        int int6 = maxIterationsExceededException3.getMaxIterations();
        java.lang.Object[] objArray7 = maxIterationsExceededException3.getArguments();
        java.lang.Object[] objArray8 = maxIterationsExceededException3.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9226350743220142d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.016103019841301736d) + "'", double1 == (-0.016103019841301736d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 10.405988201924956d, 5.298292365610485d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.util.FastMath.atan((-72.24238624133257d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5569549216349812d) + "'", double1 == (-1.5569549216349812d));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextUniform((-3.657242590218247d), (double) 35);
//        double double11 = randomDataImpl0.nextChiSquare(1.7453292519943295d);
//        try {
//            long long13 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "d6a5f5032765374dfc3248aa8f92213c91bb32c52df0739f34466093b6d27a39e9b1db039a8c1b01b6a1ac01da79e97fd637" + "'", str4.equals("d6a5f5032765374dfc3248aa8f92213c91bb32c52df0739f34466093b6d27a39e9b1db039a8c1b01b6a1ac01da79e97fd637"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "d543a7e9e15461fb640f50ec4619da64e02c2251801fb58a554b39c989c1b2947d8efc343862d2ab8a540a297de497d3b660" + "'", str6.equals("d543a7e9e15461fb640f50ec4619da64e02c2251801fb58a554b39c989c1b2947d8efc343862d2ab8a540a297de497d3b660"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.17853781861968576d + "'", double9 == 0.17853781861968576d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.7218835284979985d + "'", double11 == 0.7218835284979985d);
//    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        long long12 = randomDataImpl0.nextPoisson(1.0d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.250803321657366d) + "'", double8 == (-1.250803321657366d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 94L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double2 = org.apache.commons.math.util.FastMath.min(0.3141304086286656d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.3222325732294733d), 0.5061454830783556d, (-70.60551677167162d), 13);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray2);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.MaxIterationsExceededException: ", objArray7);
        java.lang.Class<?> wildcardClass10 = maxIterationsExceededException3.getClass();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable12, objArray13);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray22);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
        java.lang.Object[] objArray30 = mathException28.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray30);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable8, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooLargeException4.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNull(localizable34);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        double double18 = normalDistributionImpl10.density(32.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.228784761988596d + "'", double3 == 31.228784761988596d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-36.02962485938712d) + "'", double8 == (-36.02962485938712d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 14.021706690826768d + "'", double9 == 14.021706690826768d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.4687381978634777d) + "'", double11 == (-1.4687381978634777d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.27875879425793665d) + "'", double16 == (-0.27875879425793665d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.746366256758777E-223d + "'", double18 == 1.746366256758777E-223d);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.0f));
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        java.lang.Object[] objArray5 = mathException3.getArguments();
        java.lang.String str6 = mathException3.toString();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.MathException: -1 is smaller than, or equal to, the minimum (0)" + "'", str6.equals("org.apache.commons.math.MathException: -1 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-1.3222325732294733d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.574974135372808d + "'", double1 == 2.574974135372808d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.45569956935867406d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.2001846602937123d) + "'", double1 == (-2.2001846602937123d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray2);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.MaxIterationsExceededException: ", objArray7);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        java.lang.Object[] objArray15 = mathException13.getArguments();
        java.lang.Object[] objArray16 = mathException13.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, "b315c0029184d90607879db9c273ba39d8551b9ed49c662f723971dd3f68daf157e95ddf1fc21c5098d82b613cc7fac23557", objArray16);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray16);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) ' ');
//        double double4 = normalDistributionImpl2.density(0.761594155955765d);
//        double double6 = normalDistributionImpl2.cumulativeProbability(0.0d);
//        double double7 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.012463415928158344d + "'", double4 == 0.012463415928158344d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-73.05162707511295d) + "'", double7 == (-73.05162707511295d));
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 35, (-0.7568024953079282d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.757 is smaller than, or equal to, the minimum (0): standard deviation (-0.757)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        int int16 = randomDataImpl0.nextSecureInt(6, (int) ' ');
//        try {
//            double double19 = randomDataImpl0.nextUniform((double) 6, 1.5713088006770572d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 6 is larger than, or equal to, the maximum (1.571): lower bound (6) must be strictly less than upper bound (1.571)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 88L + "'", long2 == 88L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        randomDataImpl0.reSeed();
//        try {
//            int int10 = randomDataImpl0.nextSecureInt(51, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 51 is larger than, or equal to, the maximum (0): lower bound (51) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 54L + "'", long4 == 54L);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.sinh(32.17642992790359d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.709946449454162E13d + "'", double1 == 4.709946449454162E13d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.05754731639635013d, 3.4600129900961423d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 49);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8815815072720508d + "'", double1 == 3.8815815072720508d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray18);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray20);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray26 = mathException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable9, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 0);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable37, objArray38);
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = mathException42.getGeneralPattern();
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("", objArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException46.getGeneralPattern();
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable47, objArray48);
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray52);
        java.lang.Object[] objArray54 = maxIterationsExceededException53.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(localizable33, objArray54);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable3, objArray54);
        java.lang.String str58 = mathException57.toString();
        java.lang.Throwable throwable59 = null;
        try {
            mathException57.addSuppressed(throwable59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.apache.commons.math.MathException: " + "'", str58.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
        try {
            int int7 = randomDataImpl0.nextPascal(0, 31.228784761988596d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 31.229 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.14168768474935d, (double) '4', (double) (short) 10);
        normalDistributionImpl3.reseedRandomGenerator((long) 35);
        double double7 = normalDistributionImpl3.cumulativeProbability(30.76334078432671d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.715541487385214d + "'", double7 == 0.715541487385214d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(33.331932162107215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.773381345633355d + "'", double1 == 5.773381345633355d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.7608791376126396d), 1.586013452313429E15d, 0.0d, 7);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        int int13 = randomDataImpl0.nextSecureInt((-1), (int) '4');
//        randomDataImpl0.reSeedSecure((long) 1);
//        long long17 = randomDataImpl0.nextPoisson((double) ' ');
//        double double20 = randomDataImpl0.nextCauchy(0.19086079374478215d, 0.288881082877531d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.4548114728744954d) + "'", double8 == (-0.4548114728744954d));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 14 + "'", int13 == 14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 21L + "'", long17 == 21L);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-9.577698381292086d) + "'", double20 == (-9.577698381292086d));
//    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        int int13 = randomDataImpl0.nextSecureInt((-1), (int) '4');
//        randomDataImpl0.reSeedSecure((long) 1);
//        randomDataImpl0.reSeed((long) (byte) -1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.5041554971864843d) + "'", double8 == (-0.5041554971864843d));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 37 + "'", int13 == 37);
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        try {
//            double double15 = randomDataImpl0.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28L + "'", long5 == 28L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("5d639f451b9b826ad58dc3921675a5e8edd278996708de51a61c5f1b15245c6c9d4eab5ed3a2859c8f218a72b4c09fffdf39", "dec1734184");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: dec1734184");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-38.61540476324677d) + "'", double4 == (-38.61540476324677d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.001847187718342642d + "'", double6 == 0.001847187718342642d);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable4, objArray5);
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable4, objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable4, objArray12);
        java.lang.String str14 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) (-1.0f));
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException17);
        mathException0.addSuppressed((java.lang.Throwable) notStrictlyPositiveException17);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (-0.002530439384374561d), (-0.7777097040252623d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.003 is smaller than, or equal to, the minimum (0): standard deviation (-0.003)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        long long8 = randomDataImpl0.nextPoisson(0.45569956935867406d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-40.909038815991956d) + "'", double4 == (-40.909038815991956d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.742422556481208d + "'", double6 == 4.742422556481208d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma(0.3389074684885896d, 20.085536923187668d);
//        try {
//            double double6 = randomDataImpl0.nextF((double) (-1L), (-0.16661738366514878d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): degrees of freedom (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.300689224872137d + "'", double3 == 4.300689224872137d);
//    }
//}

