import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) (-1.2276339983822466d), number4, false);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.exp(303.5726559648473d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.917184222975435E131d + "'", double1 == 6.917184222975435E131d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.3012440777293522d, (java.lang.Number) 96.0f, (java.lang.Number) 100.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable4, objArray5);
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray9);
        java.lang.Throwable[] throwableArray11 = maxIterationsExceededException10.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable4, (java.lang.Object[]) throwableArray11);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathException15.getGeneralPattern();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable20, objArray21);
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray25);
        java.lang.Object[] objArray27 = maxIterationsExceededException26.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray30);
        java.lang.Throwable[] throwableArray32 = mathIllegalArgumentException31.getSuppressed();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable4, (java.lang.Object[]) throwableArray32);
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathException40.getGeneralPattern();
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable41, objArray42);
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = mathException47.getGeneralPattern();
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable52 = mathException51.getGeneralPattern();
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable52, objArray53);
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray57);
        java.lang.Object[] objArray59 = maxIterationsExceededException58.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException43, "hi!", objArray62);
        java.lang.Class<?> wildcardClass65 = objArray62.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray62);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(localizable48);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
        int[] intArray7 = randomDataImpl0.nextPermutation((int) 'a', 2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(intArray7);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        double double11 = randomDataImpl0.nextWeibull((double) (byte) 1, (double) 10);
//        double double14 = randomDataImpl0.nextUniform((-0.7777097040252623d), 1.505149978319906d);
//        try {
//            int int17 = randomDataImpl0.nextBinomial(4, (double) 11L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 11 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 36.77973217661494d + "'", double11 == 36.77973217661494d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9261538842887005d + "'", double14 == 0.9261538842887005d);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 82);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 82.0d + "'", double1 == 82.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.0685684760124517E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7023967071298747d + "'", double1 == 0.7023967071298747d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.0038387712000540475d), (double) 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.4897918583793144E-4d) + "'", double2 == (-3.4897918583793144E-4d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.POSITIVE_INFINITY, 1.4711276743037347d, (-3.4873480529562464d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
        try {
            java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        double double16 = randomDataImpl0.nextWeibull(0.9999920422633997d, 0.5772156649015329d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution17 = null;
//        try {
//            int int18 = randomDataImpl0.nextInversionDeviate(integerDistribution17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 93L + "'", long2 == 93L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 14L + "'", long5 == 14L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.13439381750017598d + "'", double16 == 0.13439381750017598d);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(30.686584702447313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03312427005102646d + "'", double1 == 0.03312427005102646d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(39.3398841871995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.27215147993091d + "'", double1 == 6.27215147993091d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        long long2 = org.apache.commons.math.util.FastMath.min(11L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        try {
//            int int11 = randomDataImpl0.nextBinomial(9, 97.73607423739044d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 97.736 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 42L + "'", long4 == 42L);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.6420149920119997d), (java.lang.Number) (-0.6420149920119997d), false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.6420149920119997d) + "'", number4.equals((-0.6420149920119997d)));
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable4, objArray5);
//        java.lang.Object[] objArray9 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray9);
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable4, objArray9);
//        java.lang.Object[] objArray12 = new java.lang.Object[] {};
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable4, objArray12);
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Number number15 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(number15, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
//        java.lang.Class<?> wildcardClass19 = outOfRangeException18.getClass();
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException();
//        java.lang.Object[] objArray22 = null;
//        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray22);
//        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
//        java.lang.Object[] objArray25 = null;
//        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable24, objArray25);
//        java.lang.Object[] objArray29 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray29);
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable24, objArray29);
//        java.lang.Object[] objArray32 = new java.lang.Object[] {};
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException20, localizable24, objArray32);
//        java.lang.Object[] objArray36 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray36);
//        java.lang.Throwable[] throwableArray38 = maxIterationsExceededException37.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable24, (java.lang.Object[]) throwableArray38);
//        java.lang.Object[] objArray41 = null;
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray41);
//        org.apache.commons.math.exception.util.Localizable localizable43 = mathException42.getGeneralPattern();
//        java.lang.Object[] objArray45 = null;
//        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("", objArray45);
//        org.apache.commons.math.exception.util.Localizable localizable47 = mathException46.getGeneralPattern();
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable47, objArray48);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl50 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl51 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl54 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double55 = randomDataImpl51.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl54);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl57 = new org.apache.commons.math.random.RandomDataImpl();
//        double double60 = randomDataImpl57.nextGaussian((double) ' ', 0.7615941559557649d);
//        java.lang.Object[] objArray61 = new java.lang.Object[] { randomDataImpl50, randomDataImpl51, 3.831008000716577E22d, double60 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable43, objArray61);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
//        java.lang.Object[] objArray65 = maxIterationsExceededException64.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable43, objArray65);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable14, objArray65);
//        org.apache.commons.math.exception.util.Localizable localizable68 = mathIllegalArgumentException67.getGeneralPattern();
//        org.junit.Assert.assertNotNull(localizable4);
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(objArray12);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(localizable24);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(throwableArray38);
//        org.junit.Assert.assertNotNull(localizable43);
//        org.junit.Assert.assertNotNull(localizable47);
//        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-56.54718988916481d) + "'", double55 == (-56.54718988916481d));
//        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 31.742831485100602d + "'", double60 == 31.742831485100602d);
//        org.junit.Assert.assertNotNull(objArray61);
//        org.junit.Assert.assertNotNull(objArray65);
//        org.junit.Assert.assertNull(localizable68);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextUniform((-3.657242590218247d), (double) 35);
//        double double11 = randomDataImpl0.nextChiSquare(1.7453292519943295d);
//        try {
//            int int15 = randomDataImpl0.nextHypergeometric((int) (short) 0, (int) '4', 4);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2d1298c1c859a820e0b2fb85dbbaf05be34d983b5023cc97fac87b08f4c19e6496a35c9443f2d8914ce1031ef052cccdc65e" + "'", str4.equals("2d1298c1c859a820e0b2fb85dbbaf05be34d983b5023cc97fac87b08f4c19e6496a35c9443f2d8914ce1031ef052cccdc65e"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a011f405ed73ed34bd09545453f149753f79cecdbcc786c28284670b60360db638dd3b06b2b464be06f6535ffa5196872b6e" + "'", str6.equals("a011f405ed73ed34bd09545453f149753f79cecdbcc786c28284670b60360db638dd3b06b2b464be06f6535ffa5196872b6e"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 24.08722787078993d + "'", double9 == 24.08722787078993d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6390136200859626d + "'", double11 == 0.6390136200859626d);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        int int9 = randomDataImpl0.nextZipf((int) ' ', 0.851458922995501d);
//        try {
//            int int12 = randomDataImpl0.nextBinomial(0, (-129.00504062629426d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -129.005 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.658991923264398d + "'", double4 == 6.658991923264398d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7855058986749184d + "'", double6 == 0.7855058986749184d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.7568024953079282d), (-175.5556233420654d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -175.556 is smaller than, or equal to, the minimum (0): standard deviation (-175.556)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 0);
//        double double6 = normalDistributionImpl0.cumulativeProbability(0.761594155955765d, 1.0685684760124517E14d);
//        normalDistributionImpl0.reseedRandomGenerator(1L);
//        double double9 = normalDistributionImpl0.getMean();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1107920635975266d + "'", double1 == 1.1107920635975266d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.22315113192007208d + "'", double6 == 0.22315113192007208d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.6025297038402304d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8446163560045811d) + "'", double1 == (-0.8446163560045811d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        java.lang.Number number0 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
//        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
//        java.lang.Object[] objArray7 = null;
//        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
//        java.lang.Object[] objArray10 = null;
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable9, objArray10);
//        java.lang.Object[] objArray14 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray14);
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable9, objArray14);
//        java.lang.Object[] objArray17 = new java.lang.Object[] {};
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable9, objArray17);
//        java.lang.Object[] objArray21 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray21);
//        java.lang.Throwable[] throwableArray23 = maxIterationsExceededException22.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable9, (java.lang.Object[]) throwableArray23);
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("", objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = mathException27.getGeneralPattern();
//        java.lang.Object[] objArray30 = null;
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable32 = mathException31.getGeneralPattern();
//        java.lang.Object[] objArray33 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable32, objArray33);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl36 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl39 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double40 = randomDataImpl36.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl39);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl42 = new org.apache.commons.math.random.RandomDataImpl();
//        double double45 = randomDataImpl42.nextGaussian((double) ' ', 0.7615941559557649d);
//        java.lang.Object[] objArray46 = new java.lang.Object[] { randomDataImpl35, randomDataImpl36, 3.831008000716577E22d, double45 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable28, objArray46);
//        java.lang.Object[] objArray49 = null;
//        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray49);
//        org.apache.commons.math.exception.util.Localizable localizable51 = mathException50.getGeneralPattern();
//        java.lang.Object[] objArray53 = null;
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
//        org.apache.commons.math.exception.util.Localizable localizable55 = mathException54.getGeneralPattern();
//        java.lang.Object[] objArray56 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable55, objArray56);
//        java.lang.Object[] objArray60 = null;
//        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getGeneralPattern();
//        java.lang.Object[] objArray64 = null;
//        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("", objArray64);
//        org.apache.commons.math.exception.util.Localizable localizable66 = mathException65.getGeneralPattern();
//        java.lang.Object[] objArray67 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable66, objArray67);
//        java.lang.Object[] objArray71 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray71);
//        java.lang.Object[] objArray73 = maxIterationsExceededException72.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, objArray73);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { 'a' };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException57, "hi!", objArray76);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray76);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(localizable9);
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(localizable28);
//        org.junit.Assert.assertNotNull(localizable32);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 10.1041026856393d + "'", double40 == 10.1041026856393d);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 32.441916311059714d + "'", double45 == 32.441916311059714d);
//        org.junit.Assert.assertNotNull(objArray46);
//        org.junit.Assert.assertNotNull(localizable51);
//        org.junit.Assert.assertNotNull(localizable55);
//        org.junit.Assert.assertNotNull(localizable62);
//        org.junit.Assert.assertNotNull(localizable66);
//        org.junit.Assert.assertNotNull(objArray71);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertNotNull(objArray76);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 25L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4363323129985824d + "'", double1 == 0.4363323129985824d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.floor(303.5726559648473d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 303.0d + "'", double1 == 303.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.3389074684885896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32650167925162754d + "'", double1 == 0.32650167925162754d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-3.0955394158806593d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.05402735493237955d) + "'", double1 == (-0.05402735493237955d));
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        double double5 = randomDataImpl0.nextExponential((double) ' ');
//        double double8 = randomDataImpl0.nextGamma(0.34177037923382253d, (double) 33L);
//        try {
//            double double11 = randomDataImpl0.nextGamma((-36.02962485938712d), (double) 26);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -36.03 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.79046728074596d + "'", double3 == 31.79046728074596d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.013888404008641851d + "'", double5 == 0.013888404008641851d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 26.386879077061703d + "'", double8 == 26.386879077061703d);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.5569549216349812d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.556954921634981d) + "'", double1 == (-1.556954921634981d));
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
//        java.lang.Object[] objArray4 = null;
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
//        java.lang.Number number6 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(number6, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
//        java.lang.Class<?> wildcardClass10 = outOfRangeException9.getClass();
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
//        java.lang.Object[] objArray13 = null;
//        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray13);
//        org.apache.commons.math.exception.util.Localizable localizable15 = mathException14.getGeneralPattern();
//        java.lang.Object[] objArray16 = null;
//        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable15, objArray16);
//        java.lang.Object[] objArray20 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray20);
//        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable15, objArray20);
//        java.lang.Object[] objArray23 = new java.lang.Object[] {};
//        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11, localizable15, objArray23);
//        java.lang.Object[] objArray27 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray27);
//        java.lang.Throwable[] throwableArray29 = maxIterationsExceededException28.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable15, (java.lang.Object[]) throwableArray29);
//        java.lang.Object[] objArray32 = null;
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("", objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable34 = mathException33.getGeneralPattern();
//        java.lang.Object[] objArray36 = null;
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = mathException37.getGeneralPattern();
//        java.lang.Object[] objArray39 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable38, objArray39);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl41 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl42 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl45 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double46 = randomDataImpl42.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl45);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl48 = new org.apache.commons.math.random.RandomDataImpl();
//        double double51 = randomDataImpl48.nextGaussian((double) ' ', 0.7615941559557649d);
//        java.lang.Object[] objArray52 = new java.lang.Object[] { randomDataImpl41, randomDataImpl42, 3.831008000716577E22d, double51 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable34, objArray52);
//        org.apache.commons.math.exception.util.Localizable localizable54 = mathIllegalArgumentException53.getSpecificPattern();
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
//        java.lang.Object[] objArray57 = maxIterationsExceededException56.getArguments();
//        java.lang.Throwable[] throwableArray58 = maxIterationsExceededException56.getSuppressed();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable54, (java.lang.Object[]) throwableArray58);
//        org.junit.Assert.assertNotNull(localizable3);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(localizable15);
//        org.junit.Assert.assertNotNull(objArray20);
//        org.junit.Assert.assertNotNull(objArray23);
//        org.junit.Assert.assertNotNull(throwableArray29);
//        org.junit.Assert.assertNotNull(localizable34);
//        org.junit.Assert.assertNotNull(localizable38);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-21.07391973301041d) + "'", double46 == (-21.07391973301041d));
//        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 31.28287912965194d + "'", double51 == 31.28287912965194d);
//        org.junit.Assert.assertNotNull(objArray52);
//        org.junit.Assert.assertNotNull(localizable54);
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(throwableArray58);
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        try {
//            int int10 = randomDataImpl0.nextZipf(82, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 89L + "'", long2 == 89L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 17L + "'", long5 == 17L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number12 = outOfRangeException11.getLo();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathException15.getGeneralPattern();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable20, objArray21);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException29.getGeneralPattern();
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable30, objArray31);
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray35);
        java.lang.Object[] objArray37 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable16, objArray37);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = mathException43.getGeneralPattern();
        java.lang.Object[] objArray45 = mathException43.getArguments();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray45);
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException11, localizable16, objArray50);
        org.apache.commons.math.exception.util.Localizable localizable53 = mathException52.getSpecificPattern();
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException57.getGeneralPattern();
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getGeneralPattern();
        java.lang.Object[] objArray63 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable62, objArray63);
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("", objArray67);
        org.apache.commons.math.exception.util.Localizable localizable69 = mathException68.getGeneralPattern();
        java.lang.Object[] objArray71 = null;
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("", objArray71);
        org.apache.commons.math.exception.util.Localizable localizable73 = mathException72.getGeneralPattern();
        java.lang.Object[] objArray74 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, localizable73, objArray74);
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray78);
        java.lang.Object[] objArray80 = maxIterationsExceededException79.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray80);
        java.lang.Object[] objArray83 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray83);
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException64, "hi!", objArray83);
        java.lang.Class<?> wildcardClass86 = objArray83.getClass();
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException52, "org.apache.commons.math.MaxIterationsExceededException: ", objArray83);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) mathException87);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1L + "'", number12.equals(1L));
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNull(localizable53);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(localizable62);
        org.junit.Assert.assertNotNull(localizable69);
        org.junit.Assert.assertNotNull(localizable73);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(wildcardClass86);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 1.5707963267948966d, (double) 9, (int) '4');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        double double5 = randomDataImpl0.nextExponential((double) ' ');
//        int int8 = randomDataImpl0.nextBinomial(4, 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.29072875475221d + "'", double3 == 32.29072875475221d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 11.267669717050374d + "'", double5 == 11.267669717050374d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        int int7 = randomDataImpl0.nextZipf((int) (short) 100, (double) (byte) 10);
//        try {
//            int int10 = randomDataImpl0.nextBinomial((int) (byte) 1, (-1.5569549216349812d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.557 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17aae8ebd3bbcc6f0aeda2af2b158628c305fd6dd16702a8f04a888c3effa939e2b165c69ecb3ec573a6f3c055126730c6a1" + "'", str4.equals("17aae8ebd3bbcc6f0aeda2af2b158628c305fd6dd16702a8f04a888c3effa939e2b165c69ecb3ec573a6f3c055126730c6a1"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextBinomial((int) '#', (double) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl6.inverseCumulativeProbability((double) 0);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 119L + "'", long2 == 119L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.725665082480558d + "'", double9 == 0.725665082480558d);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.floor((-21.143897553601537d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-22.0d) + "'", double1 == (-22.0d));
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        try {
//            long long15 = randomDataImpl0.nextPoisson((-36.02962485938712d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -36.03 is smaller than, or equal to, the minimum (0): mean (-36.03)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 75L + "'", long2 == 75L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 16L + "'", long5 == 16L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.2385996627284923d, (double) 6L, (-12.333300118849895d));
        normalDistributionImpl3.reseedRandomGenerator(116L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.signum(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.FastMath.acos(316.15648150604403d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 33L, (double) 82);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.626432729448789E-10d + "'", double2 == 2.626432729448789E-10d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 31L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double8 = randomDataImpl0.nextExponential((double) (byte) 10);
//        try {
//            double double11 = randomDataImpl0.nextGaussian((double) 11L, (-1.7608791376126396d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.761 is smaller than, or equal to, the minimum (0): standard deviation (-1.761)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4e60f6c0e454fc528a473851fa5df33b69b45fc93741907684161f1faf441d5b89de0865aaa548bc11b900f2e706d4315851" + "'", str4.equals("4e60f6c0e454fc528a473851fa5df33b69b45fc93741907684161f1faf441d5b89de0865aaa548bc11b900f2e706d4315851"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ad6f106a00fd300a33d7e4cf846da06f9f63d35c4afa1d993cb6cbf95125caa64fc305c4667afde156d3c690749b1b9ad22f" + "'", str6.equals("ad6f106a00fd300a33d7e4cf846da06f9f63d35c4afa1d993cb6cbf95125caa64fc305c4667afde156d3c690749b1b9ad22f"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 43.65246580293342d + "'", double8 == 43.65246580293342d);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        double double7 = randomDataImpl0.nextGaussian((-0.5264219283990733d), 0.2848798508461752d);
//        double double9 = randomDataImpl0.nextExponential(0.22315113192007208d);
//        try {
//            double double12 = randomDataImpl0.nextGamma((-0.16166977871501662d), (-39.50132947445295d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.162 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 61L + "'", long4 == 61L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.2779915113804001d) + "'", double7 == (-0.2779915113804001d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.09383593697612763d + "'", double9 == 0.09383593697612763d);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.log1p(6.0554544523933395E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.055436118203042E-6d + "'", double1 == 6.055436118203042E-6d);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        java.lang.String str15 = randomDataImpl0.nextHexString(9);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution16 = null;
//        try {
//            int int17 = randomDataImpl0.nextInversionDeviate(integerDistribution16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3L + "'", long5 == 3L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "7c4cacb57" + "'", str15.equals("7c4cacb57"));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 48L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 48.0f + "'", float2 == 48.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(50.04907906220467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.685236496532474d + "'", double1 == 3.685236496532474d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.toString();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray6);
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable11, objArray12);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getGeneralPattern();
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable21, objArray22);
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray26);
        java.lang.Object[] objArray28 = maxIterationsExceededException27.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray28);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
        java.lang.Object[] objArray34 = mathException32.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable17, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 5.298342365610589d);
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray40);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, localizable17, objArray40);
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray45);
        java.lang.String str47 = maxIterationsExceededException46.toString();
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException46, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException50.getGeneralPattern();
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.exception.util.Localizable localizable55 = mathException54.getGeneralPattern();
        java.lang.Object[] objArray57 = null;
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("", objArray57);
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException58.getGeneralPattern();
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable59, objArray60);
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray64);
        java.lang.Object[] objArray66 = maxIterationsExceededException65.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray66);
        java.lang.Object[] objArray69 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable51, objArray69);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str4.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str47.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertNotNull(localizable55);
        org.junit.Assert.assertNotNull(localizable59);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray69);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.4363323129985824d, 34.65237719675388d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.012591033868252086d + "'", double2 == 0.012591033868252086d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6121319033343199d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06113690537621937d + "'", double2 == 0.06113690537621937d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 303.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) -1);
//        double double21 = normalDistributionImpl10.cumulativeProbability(0.9736789250782586d, Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.991105774106956d + "'", double3 == 32.991105774106956d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 82.6910150165087d + "'", double8 == 82.6910150165087d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 23.7305678972073d + "'", double9 == 23.7305678972073d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0326817164272937d + "'", double11 == 1.0326817164272937d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.2325970215864337d + "'", double16 == 1.2325970215864337d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.16510799230806716d + "'", double21 == 0.16510799230806716d);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5785862445016798d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2375791635936468d + "'", double1 == 1.2375791635936468d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 100.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl0.reseedRandomGenerator((long) (short) 10);
//        double double7 = normalDistributionImpl0.cumulativeProbability(Double.POSITIVE_INFINITY);
//        double double9 = normalDistributionImpl0.density((double) 52.0f);
//        double double10 = normalDistributionImpl0.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4276759322076924d + "'", double1 == 0.4276759322076924d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 79L, 1.5713088006770572d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.57227336717742E-103d + "'", double2 == 7.57227336717742E-103d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6);
        java.lang.String str8 = mathException6.getPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathException15.getGeneralPattern();
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable16, objArray17);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable22, objArray23);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException27.getGeneralPattern();
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException31.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable32, objArray33);
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray37);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray39);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = mathException43.getGeneralPattern();
        java.lang.Object[] objArray45 = mathException43.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable28, objArray45);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 0);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable52 = mathException51.getGeneralPattern();
        java.lang.Object[] objArray54 = null;
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("", objArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = mathException55.getGeneralPattern();
        java.lang.Object[] objArray57 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable56, objArray57);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getGeneralPattern();
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = mathException65.getGeneralPattern();
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable66, objArray67);
        java.lang.Object[] objArray71 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray71);
        java.lang.Object[] objArray73 = maxIterationsExceededException72.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable52, objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable22, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable16, objArray73);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, "5fdf6b8d28e4ccea691080a019a6c8e752d747d6f86632f5e76089b6db842a08416217eca20d07f6add4bc0966b658a2edd9", objArray73);
        java.lang.String str79 = maxIterationsExceededException3.getPattern();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}" + "'", str8.equals("{0}"));
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(localizable56);
        org.junit.Assert.assertNotNull(localizable62);
        org.junit.Assert.assertNotNull(localizable66);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "hi!" + "'", str79.equals("hi!"));
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        int int13 = randomDataImpl0.nextSecureInt((-1), (int) '4');
//        randomDataImpl0.reSeedSecure((long) 1);
//        java.lang.String str17 = randomDataImpl0.nextHexString((int) (byte) 10);
//        try {
//            double double20 = randomDataImpl0.nextF(32.300167856125746d, (-12.333300118849895d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -12.333 is smaller than, or equal to, the minimum (0): degrees of freedom (-12.333)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.3099490644465528d) + "'", double8 == (-0.3099490644465528d));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 14 + "'", int13 == 14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "11d5d45fd3" + "'", str17.equals("11d5d45fd3"));
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        long long2 = org.apache.commons.math.util.FastMath.max(98L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 31L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double2 = org.apache.commons.math.util.FastMath.min(1.570796326794896d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.max(0.05761092702151066d, 4.397571514214528d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.397571514214528d + "'", double2 == 4.397571514214528d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable12, objArray13);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray22);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
        java.lang.Object[] objArray30 = mathException28.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray30);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable8, objArray30);
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable37, objArray38);
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable37, objArray42);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray51 = null;
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("", objArray51);
        org.apache.commons.math.exception.util.Localizable localizable53 = mathException52.getGeneralPattern();
        java.lang.Object[] objArray55 = null;
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.exception.util.Localizable localizable57 = mathException56.getGeneralPattern();
        java.lang.Object[] objArray58 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, localizable57, objArray58);
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray62);
        java.lang.Object[] objArray64 = maxIterationsExceededException63.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, objArray64);
        java.lang.Object[] objArray67 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, objArray67);
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("", objArray72);
        org.apache.commons.math.exception.util.Localizable localizable74 = mathException73.getGeneralPattern();
        java.lang.Object[] objArray75 = mathException73.getArguments();
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("hi!", objArray75);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray75);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException49, localizable53, objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable37, objArray75);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException83 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 0.9867069607845081d, (java.lang.Number) 31L, (java.lang.Number) (-1L));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(localizable57);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(localizable74);
        org.junit.Assert.assertNotNull(objArray75);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.45724149575920725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-26.198007925251503d) + "'", double1 == (-26.198007925251503d));
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.14168768474935d, (double) '4', (double) (short) 10);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 15.061256934740623d + "'", double4 == 15.061256934740623d);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.4100017376549528d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5276356872645951d) + "'", double1 == (-0.5276356872645951d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.715541487385214d, 0.2929849611597304d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9065884633406154d + "'", double2 == 0.9065884633406154d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.special.Gamma.digamma(32.512139616793974d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.466155843421104d + "'", double1 == 3.466155843421104d);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        try {
//            int int11 = randomDataImpl0.nextZipf(14, (-120.78333931532192d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -120.783 is smaller than, or equal to, the minimum (0): exponent (-120.783)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) (short) 10);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-134.03434822822024d) + "'", double4 == (-134.03434822822024d));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "bae2ec4d44" + "'", str6.equals("bae2ec4d44"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) 32);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.0884877457586517d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.14168768474935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        int int7 = randomDataImpl0.nextHypergeometric((int) '4', 0, 0);
//        double double9 = randomDataImpl0.nextT(98.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.29704028828973d + "'", double3 == 31.29704028828973d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.4985822859638542d) + "'", double9 == (-1.4985822859638542d));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 10, (float) 109L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt((int) (short) -1, (int) (short) 100);
//        int[] intArray7 = randomDataImpl0.nextPermutation(100, 100);
//        try {
//            int int11 = randomDataImpl0.nextHypergeometric(1, (int) 'a', 37);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (1): number of successes (97) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertNotNull(intArray7);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        int int7 = randomDataImpl0.nextHypergeometric((int) '4', 0, 0);
//        try {
//            double double10 = randomDataImpl0.nextBeta((-0.8059183304907124d), 5.298292365610485d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.794");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.344903870204494d + "'", double3 == 31.344903870204494d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74 + "'", int2 == 74);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 48L);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextCauchy(0.22315113192007208d, 5.298292365610485d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl0.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "333f8babf504087746e48d7e6621b9ff29cb99f7d0ea5fac5575e1f66723096d9af1217186736ae6d53ef02f1ffa7d5c769d" + "'", str4.equals("333f8babf504087746e48d7e6621b9ff29cb99f7d0ea5fac5575e1f66723096d9af1217186736ae6d53ef02f1ffa7d5c769d"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3e7c7d99eebd48e3a1ae80d11f832a63a2d6b8377bc010584e170dcfb914bcdf2a26d1d5fbdc9300c75e7993073109bd44de" + "'", str6.equals("3e7c7d99eebd48e3a1ae80d11f832a63a2d6b8377bc010584e170dcfb914bcdf2a26d1d5fbdc9300c75e7993073109bd44de"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.284269220450591d + "'", double9 == 8.284269220450591d);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-0.14498349703834462d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 49.65035072484169d + "'", double1 == 49.65035072484169d);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double5 = randomDataImpl0.nextCauchy((double) 35L, 0.8575897891663393d);
//        double double8 = randomDataImpl0.nextWeibull((double) 33L, 91.99999999999999d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104L + "'", long2 == 104L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.02803531837012d + "'", double5 == 35.02803531837012d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 84.58349488006938d + "'", double8 == 84.58349488006938d);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable8, objArray9);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable18, objArray19);
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray23);
        java.lang.Object[] objArray25 = maxIterationsExceededException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable4, objArray25);
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(throwable0, localizable4, objArray30);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 1.570796326794896d, (java.lang.Number) (-73.05162707511295d), (java.lang.Number) 0.9405152825166656d);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.16510799230806716d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
//        double[] doubleArray8 = normalDistributionImpl3.sample(94);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 123.24306196911334d + "'", double4 == 123.24306196911334d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 10, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        int int8 = randomDataImpl0.nextInt((int) (short) -1, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        try {
//            double double13 = randomDataImpl0.nextWeibull(0.715541487385214d, (double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): scale (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        int int7 = randomDataImpl0.nextZipf((int) (short) 100, (double) (byte) 10);
//        double double10 = randomDataImpl0.nextWeibull(1.8976270912904414d, 40.594693073079846d);
//        double double13 = randomDataImpl0.nextGaussian((-0.3498335702652908d), 0.06764166112396071d);
//        try {
//            int int16 = randomDataImpl0.nextPascal((int) 'a', 107.33537657552725d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 107.335 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "de1f8d68d23ff2ee387901c9cd7373a1e583233b950cdf0f36a7682822a46bdd049f42490129a8251cca04af77581f4eb6ef" + "'", str4.equals("de1f8d68d23ff2ee387901c9cd7373a1e583233b950cdf0f36a7682822a46bdd049f42490129a8251cca04af77581f4eb6ef"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 25.86560996396937d + "'", double10 == 25.86560996396937d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.38180802091672106d) + "'", double13 == (-0.38180802091672106d));
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.sin(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 35.0f, 50.04907906220467d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.98940371459523d + "'", double2 == 0.98940371459523d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-129.00504062629426d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.2515627105978826d) + "'", double1 == (-2.2515627105978826d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9428082996934846d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.970983161385142d + "'", double1 == 0.970983161385142d);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        try {
//            double double7 = randomDataImpl0.nextCauchy(100.0d, Double.NEGATIVE_INFINITY);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -∞ is smaller than, or equal to, the minimum (0): scale (-∞)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "8fdee61f2dcd8f07e68a2b79975e739e2263dd367968b194f1335c77cf0c0086b00cd9d5f03b00c28b379c49a93e2a99d07d" + "'", str4.equals("8fdee61f2dcd8f07e68a2b79975e739e2263dd367968b194f1335c77cf0c0086b00cd9d5f03b00c28b379c49a93e2a99d07d"));
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.25264237123108163d, (java.lang.Number) 1.0685684760124517E14d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.25264237123108163d + "'", number4.equals(0.25264237123108163d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0685684760124517E14d + "'", number5.equals(1.0685684760124517E14d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 60.40268274916248d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 105L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 105 + "'", int1 == 105);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-2.2515627105978826d), (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.251562710597882d) + "'", double2 == (-2.251562710597882d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 21L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21 + "'", int1 == 21);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4223903734353027d + "'", double1 == 0.4223903734353027d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (double) (byte) 1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999986171d + "'", double1 == 0.9999999999986171d);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        try {
//            double double10 = randomDataImpl0.nextBeta((-129.00504062629426d), 22.480177048196566d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.731");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 95L + "'", long2 == 95L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl9.sample();
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl9.reseedRandomGenerator((long) (short) 10);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            double double18 = randomDataImpl0.nextGamma(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.5039416237556336d) + "'", double8 == (-0.5039416237556336d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.22989807807246193d + "'", double10 == 0.22989807807246193d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.6026262352236923d) + "'", double15 == (-0.6026262352236923d));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(100, 100, (int) (short) 10);
        int int7 = randomDataImpl0.nextZipf(74, 14.021706690826768d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl1.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray3);
        java.lang.Object[] objArray5 = maxIterationsExceededException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("09f9a0aac00a1f94d834f5846d5f9e1988679a6c9b5becae6f49a3e3d9ced706481a16a6168413f6dca6cce5191a29d7ef9a", objArray5);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        try {
//            int int8 = randomDataImpl0.nextSecureInt(37, 4);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 37 is larger than, or equal to, the maximum (4): lower bound (37) must be strictly less than upper bound (4)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 106L + "'", long2 == 106L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24L + "'", long5 == 24L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100);
        java.lang.Class<?> wildcardClass2 = maxIterationsExceededException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        randomDataImpl0.reSeed();
        try {
            int int5 = randomDataImpl0.nextInt(74, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 74 is larger than, or equal to, the maximum (1): lower bound (74) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        try {
//            double double7 = randomDataImpl0.nextGaussian((-0.16166977871501662d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 95L + "'", long4 == 95L);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 92L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 92 + "'", int1 == 92);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5);
        org.junit.Assert.assertNotNull(localizable3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.32913971458423197d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        try {
//            double double16 = randomDataImpl0.nextCauchy(0.2848798508461752d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 13L + "'", long5 == 13L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.2023073870556353d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36020621686039533d + "'", double1 == 0.36020621686039533d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.33313972587254903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32701173995011046d + "'", double1 == 0.32701173995011046d);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        try {
//            double double6 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 95.05048146419985d + "'", double4 == 95.05048146419985d);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.6058445596661167d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5738301017992413d) + "'", double1 == (-0.5738301017992413d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable7, objArray8);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable7, objArray10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 1.5713088006770572d, (java.lang.Number) 32.31608050161581d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (-39.46792946335992d), (java.lang.Number) 0.5d, false);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException26.getGeneralPattern();
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable27, objArray28);
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray32);
        java.lang.Object[] objArray34 = maxIterationsExceededException33.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable7, objArray34);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray34);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextHexString(1);
//        java.lang.Class<?> wildcardClass5 = randomDataImpl0.getClass();
//        long long7 = randomDataImpl0.nextPoisson(7.105427357601002E-15d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (-1) exceeded");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (-1) exceeded");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "d" + "'", str4.equals("d"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        double double16 = randomDataImpl0.nextWeibull(0.9999920422633997d, 0.5772156649015329d);
//        randomDataImpl0.reSeedSecure(33L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 17L + "'", long5 == 17L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.13439381750017598d + "'", double16 == 0.13439381750017598d);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, 92);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(316.15648150604403d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.780789676109553d + "'", double1 == 17.780789676109553d);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double5 = randomDataImpl0.nextCauchy((double) 35L, 0.8575897891663393d);
//        long long8 = randomDataImpl0.nextLong((long) (byte) 1, 105L);
//        try {
//            double double10 = randomDataImpl0.nextChiSquare((-2.251562710597882d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.126 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.569984529213656d + "'", double5 == 35.569984529213656d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 104L + "'", long8 == 104L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 8L, 0.32701173995011046d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.32701173995011046d + "'", double2 == 0.32701173995011046d);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) ' ');
//        double double4 = normalDistributionImpl2.density(0.761594155955765d);
//        double double7 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.46111068456459914d);
//        double double8 = normalDistributionImpl2.sample();
//        double double9 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.012463415928158344d + "'", double4 == 0.012463415928158344d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.005748443190683794d + "'", double7 == 0.005748443190683794d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.54639188135675d + "'", double8 == 10.54639188135675d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 9L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1972245773362196d + "'", double1 == 2.1972245773362196d);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        int int9 = randomDataImpl0.nextZipf((int) ' ', 0.851458922995501d);
//        double double12 = randomDataImpl0.nextGamma(0.003989302426161554d, (double) 9);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 109.28458237234977d + "'", double4 == 109.28458237234977d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.006718816671587761d + "'", double6 == 0.006718816671587761d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.9E-324d + "'", double12 == 4.9E-324d);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(9);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable9, objArray10);
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable9, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable9, objArray17);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = maxIterationsExceededException22.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable9, (java.lang.Object[]) throwableArray23);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-120.78333931532192d), (java.lang.Number) 0.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException28.getSpecificPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray33);
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException34, "org.apache.commons.math.MaxIterationsExceededException: ", objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable30, objArray38);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray38);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        int int16 = randomDataImpl0.nextSecureInt(6, (int) ' ');
//        try {
//            int int19 = randomDataImpl0.nextPascal((int) (byte) 100, 6.517736520274479d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 6.518 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 103L + "'", long2 == 103L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8L + "'", long5 == 8L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 23 + "'", int16 == 23);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        long long11 = randomDataImpl0.nextSecureLong(98L, (long) 100);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.3035982795524059d) + "'", double8 == (-0.3035982795524059d));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 98L + "'", long11 == 98L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 21L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1203.2113697747288d + "'", double1 == 1203.2113697747288d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.3141304086286656d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.047494196996443d + "'", double1 == 1.047494196996443d);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double8 = randomDataImpl0.nextExponential((double) (byte) 10);
//        randomDataImpl0.reSeedSecure(33L);
//        int int13 = randomDataImpl0.nextSecureInt(0, 19);
//        try {
//            int int16 = randomDataImpl0.nextBinomial((int) '#', (double) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 35 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "418d448328afda6e3caa997996e7be3de6b356af721c74946ed635c6e1aa76a4fecbc1f2cb63ee5018c27b85d3d57ac86674" + "'", str4.equals("418d448328afda6e3caa997996e7be3de6b356af721c74946ed635c6e1aa76a4fecbc1f2cb63ee5018c27b85d3d57ac86674"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a4d23187a8223cc8802227bcf96b96489b258c8b12909a34c6ab0ca9f14fa8113338abec5bf126389db6531e905b0a29ed0e" + "'", str6.equals("a4d23187a8223cc8802227bcf96b96489b258c8b12909a34c6ab0ca9f14fa8113338abec5bf126389db6531e905b0a29ed0e"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 49.140559239828654d + "'", double8 == 49.140559239828654d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(18.666423381403394d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.666423381403398d + "'", double1 == 18.666423381403398d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        randomDataImpl0.reSeed();
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution3 = null;
        try {
            int int4 = randomDataImpl0.nextInversionDeviate(integerDistribution3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
        double double5 = normalDistributionImpl2.cumulativeProbability(3.450029527644452d, (double) 100);
        double[] doubleArray7 = normalDistributionImpl2.sample(17);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.32913971458423197d + "'", double5 == 0.32913971458423197d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable8, objArray9);
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray13);
        java.lang.Object[] objArray15 = maxIterationsExceededException14.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray15);
        java.lang.Class<?> wildcardClass17 = objArray15.getClass();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("4", objArray15);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.3035982795524059d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3134784744087114d) + "'", double1 == (-0.3134784744087114d));
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        int int9 = randomDataImpl0.nextZipf((int) ' ', 0.851458922995501d);
//        int int12 = randomDataImpl0.nextBinomial(31, 0.0d);
//        try {
//            int int15 = randomDataImpl0.nextBinomial(97, (-26.198007925251503d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -26.198 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-175.33823401827013d) + "'", double4 == (-175.33823401827013d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7692165250804885d + "'", double6 == 0.7692165250804885d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        java.lang.Number number2 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(number2, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
//        java.lang.Class<?> wildcardClass6 = outOfRangeException5.getClass();
//        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException();
//        java.lang.Object[] objArray9 = null;
//        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
//        java.lang.Object[] objArray12 = null;
//        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable11, objArray12);
//        java.lang.Object[] objArray16 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray16);
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable11, objArray16);
//        java.lang.Object[] objArray19 = new java.lang.Object[] {};
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7, localizable11, objArray19);
//        java.lang.Object[] objArray23 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray23);
//        java.lang.Throwable[] throwableArray25 = maxIterationsExceededException24.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable11, (java.lang.Object[]) throwableArray25);
//        java.lang.Object[] objArray28 = null;
//        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray28);
//        org.apache.commons.math.exception.util.Localizable localizable30 = mathException29.getGeneralPattern();
//        java.lang.Object[] objArray32 = null;
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("", objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable34 = mathException33.getGeneralPattern();
//        java.lang.Object[] objArray35 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable34, objArray35);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl37 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl38 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl41 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double42 = randomDataImpl38.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl41);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl44 = new org.apache.commons.math.random.RandomDataImpl();
//        double double47 = randomDataImpl44.nextGaussian((double) ' ', 0.7615941559557649d);
//        java.lang.Object[] objArray48 = new java.lang.Object[] { randomDataImpl37, randomDataImpl38, 3.831008000716577E22d, double47 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable30, objArray48);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException(31, "722275302965956802f2358db70364d89a37845801a336141e5a326227320ebb8945e2cd4cb05726f1946760fa6f494331cc", objArray48);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(objArray19);
//        org.junit.Assert.assertNotNull(throwableArray25);
//        org.junit.Assert.assertNotNull(localizable30);
//        org.junit.Assert.assertNotNull(localizable34);
//        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-178.96012138783777d) + "'", double42 == (-178.96012138783777d));
//        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 30.769877625783945d + "'", double47 == 30.769877625783945d);
//        org.junit.Assert.assertNotNull(objArray48);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.7213963121084953d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23540167402062684d + "'", double1 == 0.23540167402062684d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 96.0d + "'", double1 == 96.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9999920422633997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453153631238612d + "'", double1 == 0.017453153631238612d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable4, objArray5);
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable4, objArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable4, objArray12);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, "e65f7f88810dc973c2b2b8021702bbcb4c9152a5e13c9a599801b6684d019f7c9603631045e16016d99931a9402d2e7a57a4", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException0.getGeneralPattern();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 17L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 17.0f + "'", float1 == 17.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        java.lang.String str2 = maxIterationsExceededException1.toString();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (-1) exceeded" + "'", str2.equals("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (-1) exceeded"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        java.lang.Number number0 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
//        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
//        java.lang.Object[] objArray7 = null;
//        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
//        java.lang.Object[] objArray10 = null;
//        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable9, objArray10);
//        java.lang.Object[] objArray14 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray14);
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable9, objArray14);
//        java.lang.Object[] objArray17 = new java.lang.Object[] {};
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable9, objArray17);
//        java.lang.Object[] objArray21 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray21);
//        java.lang.Throwable[] throwableArray23 = maxIterationsExceededException22.getSuppressed();
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable9, (java.lang.Object[]) throwableArray23);
//        java.lang.Object[] objArray26 = null;
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("", objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable28 = mathException27.getGeneralPattern();
//        java.lang.Object[] objArray30 = null;
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable32 = mathException31.getGeneralPattern();
//        java.lang.Object[] objArray33 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable32, objArray33);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl36 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl39 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double40 = randomDataImpl36.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl39);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl42 = new org.apache.commons.math.random.RandomDataImpl();
//        double double45 = randomDataImpl42.nextGaussian((double) ' ', 0.7615941559557649d);
//        java.lang.Object[] objArray46 = new java.lang.Object[] { randomDataImpl35, randomDataImpl36, 3.831008000716577E22d, double45 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable28, objArray46);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 2.244596175267494E-16d, (java.lang.Number) 100, (java.lang.Number) 83.6983166016175d);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(localizable9);
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(localizable28);
//        org.junit.Assert.assertNotNull(localizable32);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 160.53091145672033d + "'", double40 == 160.53091145672033d);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 31.266324527258124d + "'", double45 == 31.266324527258124d);
//        org.junit.Assert.assertNotNull(objArray46);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextBinomial((int) '#', (double) 1);
//        randomDataImpl0.reSeedSecure(115L);
//        randomDataImpl0.reSeed((long) 82);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.05902957475692173d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7182818284590455d + "'", double1 == 2.7182818284590455d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040", (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.3134784744087114d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable23, objArray24);
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray28);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable9, objArray30);
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray38 = mathException36.getArguments();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray38);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable9, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = mathException45.getSpecificPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.25264237123108163d, (java.lang.Number) 1.0685684760124517E14d, false);
        java.lang.Number number51 = numberIsTooLargeException50.getMax();
        mathException45.addSuppressed((java.lang.Throwable) numberIsTooLargeException50);
        boolean boolean53 = numberIsTooLargeException50.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 1.0685684760124517E14d + "'", number51.equals(1.0685684760124517E14d));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 11L, (float) 109L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 109.0f + "'", float2 == 109.0f);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double2 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7341533632591676d + "'", double1 == 0.7341533632591676d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6941806865597749d + "'", double2 == 0.6941806865597749d);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double4 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        try {
//            long long10 = randomDataImpl0.nextPoisson((-8.850627923511611d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -8.851 is smaller than, or equal to, the minimum (0): mean (-8.851)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.7492820892537416d) + "'", double8 == (-0.7492820892537416d));
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double8 = randomDataImpl0.nextExponential((double) (byte) 10);
//        randomDataImpl0.reSeedSecure(33L);
//        double double13 = randomDataImpl0.nextBeta(98.0d, 1.3222192947339193d);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a8363b162040fed655df2e6b13e8028f42859a1ff814ec57d4e18cb1781dfd3d43fb4dceb2eb9eac6a5b98a8763486bfe494" + "'", str4.equals("a8363b162040fed655df2e6b13e8028f42859a1ff814ec57d4e18cb1781dfd3d43fb4dceb2eb9eac6a5b98a8763486bfe494"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0522be9ff2bf707cb384e69dfa82368e8a0383d98f5dfc6229703c42dec3ff93097bdab7a6e501ede150280d7be6c0e7d2e4" + "'", str6.equals("0522be9ff2bf707cb384e69dfa82368e8a0383d98f5dfc6229703c42dec3ff93097bdab7a6e501ede150280d7be6c0e7d2e4"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.4474299470742102d + "'", double8 == 3.4474299470742102d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9838763610727271d + "'", double13 == 0.9838763610727271d);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 50.02274797942717d, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 0.9405152825166656d);
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, number14, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 91.99999999999999d);
        java.lang.Number number18 = outOfRangeException17.getLo();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + Double.NEGATIVE_INFINITY + "'", number18.equals(Double.NEGATIVE_INFINITY));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0326817164272937d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9042952766350614d + "'", double1 == 0.9042952766350614d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        long long2 = org.apache.commons.math.util.FastMath.max(96L, 105L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 105L + "'", long2 == 105L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.22315113192007208d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22500777012747383d + "'", double1 == 0.22500777012747383d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable10, objArray11);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathException15.getGeneralPattern();
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable16, objArray17);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getGeneralPattern();
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable26, objArray27);
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray31);
        java.lang.Object[] objArray33 = maxIterationsExceededException32.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray33);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException37.getGeneralPattern();
        java.lang.Object[] objArray39 = mathException37.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable22, objArray39);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 0);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = mathException45.getGeneralPattern();
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getGeneralPattern();
        java.lang.Object[] objArray51 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable50, objArray51);
        java.lang.Object[] objArray54 = null;
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("", objArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = mathException55.getGeneralPattern();
        java.lang.Object[] objArray58 = null;
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("", objArray58);
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException59.getGeneralPattern();
        java.lang.Object[] objArray61 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable60, objArray61);
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray65);
        java.lang.Object[] objArray67 = maxIterationsExceededException66.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable46, objArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable16, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable10, objArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 0.4223903734353027d, (java.lang.Number) 0.3012440777293522d, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(localizable56);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number7 = outOfRangeException6.getLo();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = mathException14.getGeneralPattern();
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable15, objArray16);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable25, objArray26);
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray30);
        java.lang.Object[] objArray32 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable11, objArray32);
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathException38.getGeneralPattern();
        java.lang.Object[] objArray40 = mathException38.getArguments();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray40);
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException6, localizable11, objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException(0, "d3da9dd0a91ee3cf8d7a1ab8e8001fd631f054700f15d5461ea36a81a658a79600ee375f87847daeae701fc9f32b03ec2885", objArray45);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int2 = org.apache.commons.math.util.FastMath.max(94, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94 + "'", int2 == 94);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        double double5 = randomDataImpl0.nextExponential((double) ' ');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl0.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.67576020487352d + "'", double3 == 31.67576020487352d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 23.398640242946417d + "'", double5 == 23.398640242946417d);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 94L, (java.lang.Number) 101L, (java.lang.Number) (-12.333300118849895d));
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextHexString(1);
//        java.lang.Class<?> wildcardClass5 = randomDataImpl0.getClass();
//        long long7 = randomDataImpl0.nextPoisson(7.105427357601002E-15d);
//        double double10 = randomDataImpl0.nextF(5.298342365610589d, 128.12746705480467d);
//        try {
//            int int13 = randomDataImpl0.nextSecureInt(92, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 92 is larger than, or equal to, the maximum (0): lower bound (92) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.6071151908148607d + "'", double10 == 1.6071151908148607d);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double2 = org.apache.commons.math.util.FastMath.pow(12.152291595471665d, 0.05754731639635013d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1545670725878039d + "'", double2 == 1.1545670725878039d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 97.0d, (java.lang.Number) 1.570796326794896d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.29670597283903605d + "'", double1 == 0.29670597283903605d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 83L, 2.718281828459045d, 0.986706960784508d, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextCauchy(0.22315113192007208d, 5.298292365610485d);
//        long long12 = randomDataImpl0.nextSecureLong((long) 1, 8L);
//        try {
//            int int15 = randomDataImpl0.nextBinomial(74, 15.061256934740623d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 15.061 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9b47fa552d635f2389a464020bd218f18f17938a040563162faf27eaa9c7d114a626b9e76a664387c7ea7dfc51c54753f93a" + "'", str4.equals("9b47fa552d635f2389a464020bd218f18f17938a040563162faf27eaa9c7d114a626b9e76a664387c7ea7dfc51c54753f93a"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "066b0fdec21f29b0d65d348088d0bebc24642b41f4a620a0873a3062a0303b7f08c1109094f80b64b478872e39439a1dad63" + "'", str6.equals("066b0fdec21f29b0d65d348088d0bebc24642b41f4a620a0873a3062a0303b7f08c1109094f80b64b478872e39439a1dad63"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.204268195216105d + "'", double9 == 4.204268195216105d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 6L + "'", long12 == 6L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray3);
        java.lang.String str5 = maxIterationsExceededException4.toString();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException4, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number14 = outOfRangeException13.getLo();
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable22, objArray23);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException27.getGeneralPattern();
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException31.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable32, objArray33);
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray37);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable18, objArray39);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = mathException45.getGeneralPattern();
        java.lang.Object[] objArray47 = mathException45.getArguments();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("hi!", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray47);
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException13, localizable18, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable55, (java.lang.Number) (-1.0f));
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException57);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException64 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable60, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray66 = null;
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("", objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = mathException67.getGeneralPattern();
        java.lang.Object[] objArray70 = null;
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException71.getGeneralPattern();
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, localizable72, objArray73);
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray77);
        java.lang.Object[] objArray79 = maxIterationsExceededException78.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, objArray79);
        java.lang.Object[] objArray82 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, objArray82);
        java.lang.Object[] objArray87 = null;
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException("", objArray87);
        org.apache.commons.math.exception.util.Localizable localizable89 = mathException88.getGeneralPattern();
        java.lang.Object[] objArray90 = mathException88.getArguments();
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException("hi!", objArray90);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray90);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException64, localizable68, objArray90);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException57, "0", objArray90);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8, localizable18, objArray90);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException("c1229f1868a4d26b6bdcc2f2944568fcdfbddccf20ba4064c6ab54dc7e92446daa0186560f2014165c6daf3442804a36e879", objArray90);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str5.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1L + "'", number14.equals(1L));
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(localizable68);
        org.junit.Assert.assertNotNull(localizable72);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(objArray82);
        org.junit.Assert.assertNotNull(localizable89);
        org.junit.Assert.assertNotNull(objArray90);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.970983161385142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable9, objArray10);
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable9, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable9, objArray17);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = maxIterationsExceededException22.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable9, (java.lang.Object[]) throwableArray23);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-120.78333931532192d), (java.lang.Number) 0.0f, false);
        boolean boolean29 = numberIsTooSmallException28.getBoundIsAllowed();
        java.lang.Number number30 = numberIsTooSmallException28.getMin();
        java.lang.Number number31 = numberIsTooSmallException28.getMin();
        boolean boolean32 = numberIsTooSmallException28.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0f + "'", number30.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.0f + "'", number31.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable23, objArray24);
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray28);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable9, objArray30);
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray38 = mathException36.getArguments();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray38);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable9, objArray43);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        java.lang.Number number47 = outOfRangeException4.getHi();
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException50.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Number number54 = notStrictlyPositiveException53.getArgument();
        java.lang.Object[] objArray55 = notStrictlyPositiveException53.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable51, objArray55);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (-1.0f) + "'", number47.equals((-1.0f)));
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (short) 0 + "'", number54.equals((short) 0));
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int2 = org.apache.commons.math.util.FastMath.max(97, 82);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.log(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-32.57791748631743d) + "'", double1 == (-32.57791748631743d));
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        randomDataImpl0.reSeed();
//        double double8 = randomDataImpl0.nextCauchy((double) (byte) 1, (double) 46L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "969c337bc572ce97f3a9135e0e56b510d526f2bd633ac2a7d6baf306543a14f1808c97df566d90d7cc2f1dc4262cad90087c" + "'", str4.equals("969c337bc572ce97f3a9135e0e56b510d526f2bd633ac2a7d6baf306543a14f1808c97df566d90d7cc2f1dc4262cad90087c"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-22.333591004550236d) + "'", double8 == (-22.333591004550236d));
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.log10(123.24306196911334d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0907624798085687d + "'", double1 == 2.0907624798085687d);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        try {
//            int int19 = randomDataImpl0.nextSecureInt((int) '#', (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (10): lower bound (35) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.895916515524814d + "'", double3 == 31.895916515524814d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-38.63679423973019d) + "'", double8 == (-38.63679423973019d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-23.15368245898653d) + "'", double9 == (-23.15368245898653d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.634215451407091d) + "'", double11 == (-0.634215451407091d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.16378738788440841d) + "'", double16 == (-0.16378738788440841d));
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        double double7 = randomDataImpl0.nextGaussian((-0.5264219283990733d), 0.2848798508461752d);
//        double double9 = randomDataImpl0.nextExponential(0.22315113192007208d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 99L + "'", long4 == 99L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.1074102330330102d) + "'", double7 == (-1.1074102330330102d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.3257370380127771d + "'", double9 == 0.3257370380127771d);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.25264237123108163d, (java.lang.Number) 1.0685684760124517E14d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.String str6 = numberIsTooLargeException3.toString();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.25264237123108163d + "'", number4.equals(0.25264237123108163d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 0.253 is larger than, or equal to, the maximum (106,856,847,601,245.17)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 0.253 is larger than, or equal to, the maximum (106,856,847,601,245.17)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0685684760124517E14d + "'", number7.equals(1.0685684760124517E14d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 11L, 0.4363323129985824d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8339069637136437E-12d + "'", double2 == 1.8339069637136437E-12d);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt((int) (short) -1, (int) (short) 100);
//        try {
//            double double6 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 36 + "'", int4 == 36);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.000000000000002d + "'", number6.equals(10.000000000000002d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.0f));
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        java.lang.Object[] objArray5 = mathException3.getArguments();
        java.lang.String str6 = mathException3.getPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        int int5 = randomDataImpl0.nextZipf(11, 1.4711276743037347d);
//        try {
//            int int8 = randomDataImpl0.nextSecureInt(7, (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 7 is larger than, or equal to, the maximum (-1): lower bound (7) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 106L + "'", long2 == 106L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 30.686584702447313d, (java.lang.Number) 31.29066498393885d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable14, objArray15);
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable24, objArray25);
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray29);
        java.lang.Object[] objArray31 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable10, objArray31);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException37.getGeneralPattern();
        java.lang.Object[] objArray39 = mathException37.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("hi!", objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, "org.apache.commons.math.exception.NumberIsTooLargeException: 0.253 is larger than, or equal to, the maximum (106,856,847,601,245.17)", objArray39);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 31.29066498393885d + "'", number4.equals(31.29066498393885d));
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) -1);
//        double double19 = normalDistributionImpl10.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.09285089402156d + "'", double3 == 31.09285089402156d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-46.91750634582616d) + "'", double8 == (-46.91750634582616d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 120.47533949056772d + "'", double9 == 120.47533949056772d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2569336073666446d) + "'", double11 == (-1.2569336073666446d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5724225499147905d + "'", double16 == 0.5724225499147905d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(128.12746705480467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 128.1274670548047d + "'", double1 == 128.1274670548047d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.0d + "'", double1 == 17.0d);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        long long12 = randomDataImpl0.nextPoisson(30.801156128925953d);
//        int int15 = randomDataImpl0.nextZipf((int) '4', (double) 11);
//        try {
//            java.lang.String str17 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.46363636630669913d) + "'", double8 == (-0.46363636630669913d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) (-0.7608336650343721d), (java.lang.Number) 32L, true);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040", (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray2);
        java.lang.Throwable[] throwableArray4 = maxIterationsExceededException3.getSuppressed();
        java.lang.String str5 = maxIterationsExceededException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str5.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-121.63671661277323d) + "'", double3 == (-121.63671661277323d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double2 = org.apache.commons.math.util.FastMath.min(32.441916311059714d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        long long19 = randomDataImpl0.nextSecureLong((long) ' ', (long) 100);
//        java.lang.String str21 = randomDataImpl0.nextSecureHexString(26);
//        try {
//            int[] intArray24 = randomDataImpl0.nextPermutation((int) ' ', 74);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 74 is larger than the maximum (32): permutation size (74) exceeds permuation domain (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.66008224674701d + "'", double3 == 31.66008224674701d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-66.99339210691991d) + "'", double8 == (-66.99339210691991d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-188.93542736081076d) + "'", double9 == (-188.93542736081076d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.20701339362454105d + "'", double11 == 0.20701339362454105d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.1740312620852533d) + "'", double16 == (-1.1740312620852533d));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 61L + "'", long19 == 61L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "41c8e2a3bc6235d8daaf712051" + "'", str21.equals("41c8e2a3bc6235d8daaf712051"));
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.signum(5.21672277009497E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        try {
//            double double9 = randomDataImpl0.nextUniform(0.0d, (-0.29100619138474915d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-0.291): lower bound (0) must be strictly less than upper bound (-0.291)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0bb7ebcf9a1cef302b3edc3bb9249b1436cd33dee0191f6d5f1225aed7f1d569ce0bfb1abc00952a1b9b7b05cbbb17c14312" + "'", str4.equals("0bb7ebcf9a1cef302b3edc3bb9249b1436cd33dee0191f6d5f1225aed7f1d569ce0bfb1abc00952a1b9b7b05cbbb17c14312"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9f8f7cbe448e265a5b416896072e9c763f8ac4c9f36ae78684f8dc2dc179e76ef04703016263199fa0b921544244489c9bf4" + "'", str6.equals("9f8f7cbe448e265a5b416896072e9c763f8ac4c9f36ae78684f8dc2dc179e76ef04703016263199fa0b921544244489c9bf4"));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 7, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray18);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray20);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray26 = mathException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable9, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 0);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getSpecificPattern();
        boolean boolean31 = notStrictlyPositiveException29.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextBeta(0.3141304086286656d, 3.450029527644452d);
//        double double11 = randomDataImpl0.nextCauchy((-2.2001846602937123d), (double) 28L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.024596079672140416d + "'", double8 == 0.024596079672140416d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 41.56487365394409d + "'", double11 == 41.56487365394409d);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.564206993256212d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4101461815019079d) + "'", double1 == (-0.4101461815019079d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable12, objArray13);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray22);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
        java.lang.Object[] objArray30 = mathException28.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray30);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable8, objArray30);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (-1.8254927181220595d), (java.lang.Number) 1.5605925993009424d, (java.lang.Number) 0.8746788966462123d);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        double double8 = randomDataImpl0.nextChiSquare((double) 94);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 102L + "'", long4 == 102L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 81.6617672806631d + "'", double8 == 81.6617672806631d);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(31.626917722645313d, (double) 23L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.050480035095853706d + "'", double2 == 0.050480035095853706d);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextBeta(0.3141304086286656d, 3.450029527644452d);
//        long long10 = randomDataImpl0.nextPoisson((double) ' ');
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.16016844991510112d + "'", double8 == 0.16016844991510112d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 20L + "'", long10 == 20L);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(23.7305678972073d, 0.4276759322076924d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.455754870468327E-33d + "'", double2 == 4.455754870468327E-33d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-36.02962485938712d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6288355820547042d) + "'", double1 == (-0.6288355820547042d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 21L, (float) 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double8 = randomDataImpl0.nextExponential((double) (byte) 10);
//        randomDataImpl0.reSeedSecure(33L);
//        double double13 = randomDataImpl0.nextBeta(2.574974135372808d, (double) 109L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "c33c0d27dbdc2ce2ddebd9682414a650a4797115799bb2e27b3ba656efcf882656cd77400fcc27af04ce04c4dfcad09d8e01" + "'", str4.equals("c33c0d27dbdc2ce2ddebd9682414a650a4797115799bb2e27b3ba656efcf882656cd77400fcc27af04ce04c4dfcad09d8e01"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "485085b4f1c315f3404737a12da9f462ea30eb636c2e0e1efa2be71b82514e700044f2f702770ec89e0e68f92e4a97cb2cbc" + "'", str6.equals("485085b4f1c315f3404737a12da9f462ea30eb636c2e0e1efa2be71b82514e700044f2f702770ec89e0e68f92e4a97cb2cbc"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.2297389596994615d + "'", double8 == 5.2297389596994615d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.02557346117094107d + "'", double13 == 0.02557346117094107d);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.586013452313429E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.69314718055995d + "'", double1 == 35.69314718055995d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.tanh(16.000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999747d + "'", double1 == 0.9999999999999747d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.288241522117258d + "'", double1 == 5.288241522117258d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.4474299470742102d, 0.8746788966462123d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.03606876195880223d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.33040281987214026d + "'", double1 == 0.33040281987214026d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-17.179218031774475d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.5802857099900556d) + "'", double1 == (-2.5802857099900556d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.010291586146758d, 50.02274797942717d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0102915861467583d + "'", double2 == 3.0102915861467583d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        long long1 = org.apache.commons.math.util.FastMath.round(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-9223372036854775808L) + "'", long1 == (-9223372036854775808L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        randomDataImpl0.reSeed();
        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
        randomDataImpl0.reSeed();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double5 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-85.16692558502207d) + "'", double4 == (-85.16692558502207d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-75.33776675182396d) + "'", double5 == (-75.33776675182396d));
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.067661995777765d + "'", double1 == 10.067661995777765d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-70.60551677167162d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable9, objArray10);
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable9, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable9, objArray17);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray21);
        java.lang.Throwable[] throwableArray23 = maxIterationsExceededException22.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable9, (java.lang.Object[]) throwableArray23);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-120.78333931532192d), (java.lang.Number) 0.0f, false);
        boolean boolean29 = numberIsTooSmallException28.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getSpecificPattern();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(localizable31);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(33.939803274997736d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.93980327499774d + "'", double1 == 33.93980327499774d);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        double double5 = randomDataImpl0.nextCauchy((double) 35L, 0.8575897891663393d);
//        long long8 = randomDataImpl0.nextLong((long) (byte) 1, 105L);
//        double double11 = randomDataImpl0.nextGamma((double) 29L, 0.050480035095853706d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 75L + "'", long2 == 75L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 37.15481775686082d + "'", double5 == 37.15481775686082d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 63L + "'", long8 == 63L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.289075177313366d + "'", double11 == 1.289075177313366d);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) ' ');
//        double double4 = normalDistributionImpl2.density(0.761594155955765d);
//        double double7 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.46111068456459914d);
//        double double8 = normalDistributionImpl2.sample();
//        normalDistributionImpl2.reseedRandomGenerator((long) 92);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.012463415928158344d + "'", double4 == 0.012463415928158344d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.005748443190683794d + "'", double7 == 0.005748443190683794d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-2.3126729155144545d) + "'", double8 == (-2.3126729155144545d));
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.toString();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray6);
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable11, objArray12);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getGeneralPattern();
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable21, objArray22);
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray26);
        java.lang.Object[] objArray28 = maxIterationsExceededException27.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray28);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
        java.lang.Object[] objArray34 = mathException32.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable17, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 5.298342365610589d);
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray40);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, localizable17, objArray40);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 0.05761092702151066d, (java.lang.Number) 2, false);
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray49);
        java.lang.String str51 = maxIterationsExceededException50.toString();
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException50);
        java.lang.Object[] objArray53 = convergenceException52.getArguments();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable17, objArray53);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str4.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str51.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(objArray53);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.2929849611597304d, (java.lang.Number) 96L, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.03606876195880223d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 770.2280055899857d + "'", double1 == 770.2280055899857d);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextUniform((-3.657242590218247d), (double) 35);
//        double double11 = randomDataImpl0.nextChiSquare(1.7453292519943295d);
//        randomDataImpl0.reSeedSecure((long) 11);
//        long long16 = randomDataImpl0.nextSecureLong((long) (byte) 1, 89L);
//        double double18 = randomDataImpl0.nextChiSquare((double) 83L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "115f914f0831e881c2acd1634009484ca2aafcdeaef5aa67000175c652503d1c036a1823b2f6da44cb84f25b449685a73c50" + "'", str4.equals("115f914f0831e881c2acd1634009484ca2aafcdeaef5aa67000175c652503d1c036a1823b2f6da44cb84f25b449685a73c50"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5d6ae3f6a6d9cc5ffb57e0f8c8e1d10445ff17f2153101a591d8c930cf6c454b3d203993d32886aa7098ec9b6fdc9b4f686f" + "'", str6.equals("5d6ae3f6a6d9cc5ffb57e0f8c8e1d10445ff17f2153101a591d8c930cf6c454b3d203993d32886aa7098ec9b6fdc9b4f686f"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 31.10892092196422d + "'", double9 == 31.10892092196422d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9342677626948563d + "'", double11 == 0.9342677626948563d);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 121.87667916637812d + "'", double18 == 121.87667916637812d);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, number6, (java.lang.Number) 1.570796326794896d, (java.lang.Number) 32L);
        java.lang.Number number10 = outOfRangeException9.getLo();
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(number11, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
        java.lang.Class<?> wildcardClass15 = outOfRangeException14.getClass();
        outOfRangeException9.addSuppressed((java.lang.Throwable) outOfRangeException14);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1.570796326794896d + "'", number10.equals(1.570796326794896d));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 79L, (java.lang.Number) 3.141592653589793d, true);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Throwable throwable17 = null;
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable25, objArray26);
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable35 = mathException34.getGeneralPattern();
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable35, objArray36);
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray40);
        java.lang.Object[] objArray42 = maxIterationsExceededException41.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable21, objArray42);
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(throwable17, localizable21, objArray47);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray47);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException13, "ebab7dce315423d376aa3fcd7ab3bb61f57a2ce3020c1a3a40c1eb85d833315fc28764dac80986d92fc51e41802780394805", objArray47);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray47);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        long long19 = randomDataImpl0.nextSecureLong((long) ' ', (long) 100);
//        java.lang.String str21 = randomDataImpl0.nextSecureHexString(26);
//        double double24 = randomDataImpl0.nextF(1.8976270912904414d, 2.626432729448789E-10d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.74250423447899d + "'", double3 == 31.74250423447899d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-17.564690242936514d) + "'", double8 == (-17.564690242936514d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-58.03290134135309d) + "'", double9 == (-58.03290134135309d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.07506149566858918d) + "'", double11 == (-0.07506149566858918d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.6208459638644568d + "'", double16 == 1.6208459638644568d);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 50L + "'", long19 == 50L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "e384358a2d6a6e59fde47e74f8" + "'", str21.equals("e384358a2d6a6e59fde47e74f8"));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2210288.849295294d + "'", double24 == 2210288.849295294d);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextChiSquare(0.010256320350359577d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.3624708599983728E-9d + "'", double4 == 1.3624708599983728E-9d);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 92, 1.5095796257023292E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 92.0d + "'", double2 == 92.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.19025861680727713d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18801154070097775d + "'", double1 == 0.18801154070097775d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.1226585686029999E38d, 1.0685684760124517E14d, (-2.251562710597882d));
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl0.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 11L + "'", long5 == 11L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.4928776702458777d, 60.40268274916248d, 1.3721518339633933E-13d);
        double double5 = normalDistributionImpl3.density((-0.32104317507867886d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0066041116928065025d + "'", double5 == 0.0066041116928065025d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int int2 = org.apache.commons.math.util.FastMath.min(1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.4711276743037347d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        double double16 = randomDataImpl0.nextCauchy((-2.5802857099900556d), (double) 1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 11L + "'", long5 == 11L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-3.888767519027845d) + "'", double16 == (-3.888767519027845d));
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        int int9 = randomDataImpl0.nextZipf((int) ' ', 0.851458922995501d);
//        int int12 = randomDataImpl0.nextBinomial(31, 0.0d);
//        randomDataImpl0.reSeedSecure(0L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 39.15762248377668d + "'", double4 == 39.15762248377668d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.1598711920853067d + "'", double6 == 0.1598711920853067d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 50.02274797942717d, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 0.9405152825166656d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl14.reSeed();
//        randomDataImpl14.reSeed();
//        java.lang.String str18 = randomDataImpl14.nextSecureHexString((int) (short) 100);
//        java.lang.String str20 = randomDataImpl14.nextHexString((int) (short) 100);
//        double double22 = randomDataImpl14.nextExponential((double) (byte) 10);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl27 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double28 = randomDataImpl24.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl27);
//        double double30 = randomDataImpl24.nextChiSquare(1.505149978319906d);
//        java.lang.Object[] objArray34 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray34);
//        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException35);
//        java.lang.Object[] objArray38 = null;
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray38);
//        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
//        java.lang.Object[] objArray41 = null;
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable40, objArray41);
//        java.lang.Object[] objArray44 = null;
//        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = mathException45.getGeneralPattern();
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("", objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getGeneralPattern();
//        java.lang.Object[] objArray51 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable50, objArray51);
//        java.lang.Object[] objArray55 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray55);
//        java.lang.Object[] objArray57 = maxIterationsExceededException56.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray57);
//        java.lang.Object[] objArray60 = null;
//        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getGeneralPattern();
//        java.lang.Object[] objArray63 = mathException61.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable46, objArray63);
//        java.lang.Object[] objArray65 = new java.lang.Object[] { randomDataImpl14, 30.801156128925953d, randomDataImpl24, (-3.0955394158806593d), mathException36, mathIllegalArgumentException64 };
//        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable7, objArray65);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 0.986706960784508d, (java.lang.Number) 14, true);
//        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooSmallException70.getSpecificPattern();
//        org.junit.Assert.assertNotNull(localizable3);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0894da2e7616f2b743efdcb0b989fc863f22e1c8ec7a1bb557e9b930a075acdc972b4e6977a4c5a926775527446810e73b49" + "'", str18.equals("0894da2e7616f2b743efdcb0b989fc863f22e1c8ec7a1bb557e9b930a075acdc972b4e6977a4c5a926775527446810e73b49"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "e8257124392a223c5f620bcba2e3fccbb804ed3e279b9a76a17f7e28226823511e9c2b0ce3264560a514e19ff2af61636381" + "'", str20.equals("e8257124392a223c5f620bcba2e3fccbb804ed3e279b9a76a17f7e28226823511e9c2b0ce3264560a514e19ff2af61636381"));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.711292208101145d + "'", double22 == 8.711292208101145d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 37.856696376095435d + "'", double28 == 37.856696376095435d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.42983464289858303d + "'", double30 == 0.42983464289858303d);
//        org.junit.Assert.assertNotNull(objArray34);
//        org.junit.Assert.assertNotNull(localizable40);
//        org.junit.Assert.assertNotNull(localizable46);
//        org.junit.Assert.assertNotNull(localizable50);
//        org.junit.Assert.assertNotNull(objArray55);
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(localizable62);
//        org.junit.Assert.assertNotNull(objArray63);
//        org.junit.Assert.assertNotNull(objArray65);
//        org.junit.Assert.assertNotNull(localizable71);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int[] intArray4 = randomDataImpl1.nextPermutation(100, 35);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.5264219283990733d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int int2 = org.apache.commons.math.util.FastMath.max(4, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.970983161385142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9709831613851421d + "'", double1 == 0.9709831613851421d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.5668069251552255d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1614624156491402d) + "'", double1 == (-1.1614624156491402d));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.19086079374478304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1932126174276923d + "'", double1 == 0.1932126174276923d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
        double double5 = normalDistributionImpl2.cumulativeProbability(3.450029527644452d, (double) 100);
        double double6 = normalDistributionImpl2.getMean();
        double double8 = normalDistributionImpl2.cumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.32913971458423197d + "'", double5 == 0.32913971458423197d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.4960106436853684d + "'", double8 == 0.4960106436853684d);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        double double7 = randomDataImpl0.nextGaussian((-0.5264219283990733d), 0.2848798508461752d);
//        java.lang.String str9 = randomDataImpl0.nextHexString(105);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = normalDistributionImpl10.getStandardDeviation();
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        double[] doubleArray19 = normalDistributionImpl10.sample((int) (short) 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 38L + "'", long4 == 38L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.2824552557177973d) + "'", double7 == (-0.2824552557177973d));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ac6a2403bec4f114edee06f64d358d5154a946337b0c320120541538e51a8015634c50444fb857dd0de20f60870601423a9e85c0b" + "'", str9.equals("ac6a2403bec4f114edee06f64d358d5154a946337b0c320120541538e51a8015634c50444fb857dd0de20f60870601423a9e85c0b"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.7709576648566263d + "'", double11 == 0.7709576648566263d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.11463975895043137d) + "'", double17 == (-0.11463975895043137d));
//        org.junit.Assert.assertNotNull(doubleArray19);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double9 = randomDataImpl0.nextCauchy(0.22315113192007208d, 5.298292365610485d);
//        long long12 = randomDataImpl0.nextSecureLong((long) 1, 8L);
//        try {
//            randomDataImpl0.setSecureAlgorithm("20a91cc5acd79dcbf03b09417fe7c88b2cb79024f2dafca5cd229bc1b88b730f75e1fca599716d4c16d71bdf65db3ac80768", "c33c0d27dbdc2ce2ddebd9682414a650a4797115799bb2e27b3ba656efcf882656cd77400fcc27af04ce04c4dfcad09d8e01");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: c33c0d27dbdc2ce2ddebd9682414a650a4797115799bb2e27b3ba656efcf882656cd77400fcc27af04ce04c4dfcad09d8e01");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "35c1d02227c8f243aae360241e92fd82de4fe0a2972dc9de7fbdf928a51502f41896284129a49e643cb6719325e6fa614df2" + "'", str4.equals("35c1d02227c8f243aae360241e92fd82de4fe0a2972dc9de7fbdf928a51502f41896284129a49e643cb6719325e6fa614df2"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0238921f2eca6e1b9a584e3243b685e0f80af03d7f51629e66ac006c83438409b7344ad25520a641df5bf9e2227628c7b819" + "'", str6.equals("0238921f2eca6e1b9a584e3243b685e0f80af03d7f51629e66ac006c83438409b7344ad25520a641df5bf9e2227628c7b819"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.8364020738220352d) + "'", double9 == (-2.8364020738220352d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.2800750084700842d, (-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.28007500847008415d + "'", double2 == 0.28007500847008415d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(23.7305678972073d, (-79.410981057255d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        double double7 = randomDataImpl0.nextGaussian((-0.5264219283990733d), 0.2848798508461752d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.2385996627284923d, (double) 6L, (-12.333300118849895d));
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        int[] intArray15 = randomDataImpl0.nextPermutation((int) 'a', (int) ' ');
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.4321936919856847d) + "'", double7 == (-0.4321936919856847d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.10660550750636894d) + "'", double12 == (-0.10660550750636894d));
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.toString();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3);
        java.lang.Object[] objArray6 = convergenceException5.getArguments();
        java.lang.Object[] objArray7 = convergenceException5.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str4.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl0.reseedRandomGenerator((long) (short) 10);
//        double double6 = normalDistributionImpl0.sample();
//        double double7 = normalDistributionImpl0.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1633535966879969d + "'", double1 == 1.1633535966879969d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8746788966462123d + "'", double6 == 0.8746788966462123d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        long long1 = org.apache.commons.math.util.FastMath.round((-59.893170528978594d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-60L) + "'", long1 == (-60L));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.atanh(31.29066498393885d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable23, objArray24);
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray28);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable9, objArray30);
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray38 = mathException36.getArguments();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray38);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable9, objArray43);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        java.lang.Object[] objArray47 = outOfRangeException4.getArguments();
        java.lang.Number number48 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 1L + "'", number48.equals(1L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException(throwable0, "org.apache.commons.math.exception.OutOfRangeException: null out of [0.762, 10] range", objArray2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.010291586146758d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0102915861467583d + "'", double1 == 3.0102915861467583d);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        long long6 = randomDataImpl0.nextPoisson((double) 46L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "7135b610be80eb942f9e6fd4e5795c9f83961da48224e98a3220aa5521550708de3c1ecf87b829ce88b8f446ab2fe4fdb91f" + "'", str4.equals("7135b610be80eb942f9e6fd4e5795c9f83961da48224e98a3220aa5521550708de3c1ecf87b829ce88b8f446ab2fe4fdb91f"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 47L + "'", long6 == 47L);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable7, objArray8);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable7, objArray10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 1.5713088006770572d, (java.lang.Number) 32.31608050161581d, false);
        java.lang.Number number16 = numberIsTooLargeException15.getMax();
        java.lang.Number number17 = numberIsTooLargeException15.getMax();
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 32.31608050161581d + "'", number16.equals(32.31608050161581d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 32.31608050161581d + "'", number17.equals(32.31608050161581d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.2569336073666446d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException4.getGeneralPattern();
        java.lang.Object[] objArray6 = mathException4.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray6);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.4928776702458777d, 60.40268274916248d, 1.3721518339633933E-13d);
        double double5 = normalDistributionImpl3.cumulativeProbability(92.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9351076303453175d + "'", double5 == 0.9351076303453175d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        long long2 = org.apache.commons.math.util.FastMath.min(48L, (long) 14);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.toString();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException3.getGeneralPattern();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(number9, (java.lang.Number) 0.761594155955765d, (java.lang.Number) 10.0d);
        java.lang.Class<?> wildcardClass13 = outOfRangeException12.getClass();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable18, objArray19);
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable18, objArray23);
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14, localizable18, objArray26);
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray30);
        java.lang.Throwable[] throwableArray32 = maxIterationsExceededException31.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException12, localizable18, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, localizable18, objArray36);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str4.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable6, objArray7);
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, number9, (java.lang.Number) 1.0039973911440043d, (java.lang.Number) 10.000000000000002d);
        java.lang.Object[] objArray13 = outOfRangeException12.getArguments();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040", (java.lang.Object[]) throwableArray5);
        java.lang.String str7 = convergenceException6.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getSpecificPattern();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.ConvergenceException: 882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040" + "'", str7.equals("org.apache.commons.math.ConvergenceException: 882c47e2f46463a6c3f2247c0e728109e44881b94f6d9dabf5485a69acb302bfb5077f5c841d1ff113edef8b06ae228e2040"));
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray18);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray20);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray26 = mathException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable9, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 0);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getSpecificPattern();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException29);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable30);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextBeta(0.3141304086286656d, 3.450029527644452d);
//        try {
//            int int11 = randomDataImpl0.nextPascal((int) (byte) 100, (double) 101L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 101 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0405473417063834d + "'", double8 == 0.0405473417063834d);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(84.58349488006938d, 316.15648150604403d, (-0.5041554971864843d), 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 316.156 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = normalDistributionImpl3.density((double) (short) 0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-31.327715504697235d) + "'", double4 == (-31.327715504697235d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.003989223337860822d + "'", double6 == 0.003989223337860822d);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.556954921634981d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = randomDataImpl0.nextChiSquare(1.505149978319906d);
//        int int9 = randomDataImpl0.nextZipf((int) ' ', 0.851458922995501d);
//        int int12 = randomDataImpl0.nextBinomial((int) (byte) 1, 0.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-32.560483290881876d) + "'", double4 == (-32.560483290881876d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.2742430466283348d + "'", double6 == 2.2742430466283348d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.570796326794896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8104773809653483d + "'", double1 == 3.8104773809653483d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable4, objArray5);
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, number7, (java.lang.Number) 1.570796326794896d, (java.lang.Number) 32L);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (-1.0f));
        java.lang.Number number16 = outOfRangeException15.getLo();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable24, objArray25);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException29.getGeneralPattern();
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = mathException33.getGeneralPattern();
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable34, objArray35);
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray39);
        java.lang.Object[] objArray41 = maxIterationsExceededException40.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable20, objArray41);
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = mathException47.getGeneralPattern();
        java.lang.Object[] objArray49 = mathException47.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray49);
        java.lang.Object[] objArray54 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException15, localizable20, objArray54);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException15);
        java.lang.Object[] objArray58 = outOfRangeException15.getArguments();
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(throwable0, localizable4, objArray58);
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException59.getGeneralPattern();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1L + "'", number16.equals(1L));
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(localizable48);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable60);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 30L + "'", long4 == 30L);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray18);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray20);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray26 = mathException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable9, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) (-1.0f));
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException31);
        java.lang.Object[] objArray33 = mathException31.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable9, objArray33);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.7568024953079282d), 2.837040108747787d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3790435728221136d + "'", double1 == 0.3790435728221136d);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        try {
//            int int10 = randomDataImpl0.nextPascal(17, 1.4711276743037347d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.471 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 30L + "'", long5 == 30L);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt((int) (short) -1, (int) (short) 100);
//        int[] intArray7 = randomDataImpl0.nextPermutation(100, 100);
//        try {
//            int[] intArray10 = randomDataImpl0.nextPermutation(17, 26);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 26 is larger than the maximum (17): permutation size (26) exceeds permuation domain (17)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
//        org.junit.Assert.assertNotNull(intArray7);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5.298342365610589d);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable14, objArray15);
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray19);
        java.lang.Object[] objArray21 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray24);
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        java.lang.Object[] objArray32 = mathException30.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException6, localizable10, objArray32);
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathException38.getGeneralPattern();
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = mathException42.getGeneralPattern();
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable43, objArray44);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("", objArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = mathException48.getGeneralPattern();
        java.lang.Object[] objArray51 = null;
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("", objArray51);
        org.apache.commons.math.exception.util.Localizable localizable53 = mathException52.getGeneralPattern();
        java.lang.Object[] objArray54 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, localizable53, objArray54);
        java.lang.Object[] objArray58 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray58);
        java.lang.Object[] objArray60 = maxIterationsExceededException59.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(localizable39, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, localizable10, objArray60);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 99.83340030395857d);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(localizable49);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.toString();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, -1] range", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Object[] objArray9 = mathException7.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str4.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.18050318869314488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.42485666841082403d + "'", double1 == 0.42485666841082403d);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double4 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double6 = normalDistributionImpl3.density(32.441916311059714d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 15.126009009284884d + "'", double4 == 15.126009009284884d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0037970211625402215d + "'", double6 == 0.0037970211625402215d);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable13, objArray14);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray18);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray20);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray26 = mathException24.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable9, objArray26);
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        java.lang.Object[] objArray32 = mathException30.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray32);
        java.lang.Throwable throwable36 = null;
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = mathException43.getGeneralPattern();
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable44, objArray45);
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getGeneralPattern();
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException53.getGeneralPattern();
        java.lang.Object[] objArray55 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable54, objArray55);
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray59);
        java.lang.Object[] objArray61 = maxIterationsExceededException60.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, objArray61);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable40, objArray61);
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException(throwable36, localizable40, objArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException("", objArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException33, "f8695786f0bb79b26a413f75876f75bb57fc043cef558d7c005ced19ad0000529f8251631f6d3825f1cf8eaf04694d0719b35efed", objArray66);
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(localizable54);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.14498349703834462d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14549196184523663d) + "'", double1 == (-0.14549196184523663d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.util.FastMath.pow(32.31622791524749d, (-0.11463975895043137d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6713676009461864d + "'", double2 == 0.6713676009461864d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable7, objArray8);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable7, objArray10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 1.5713088006770572d, (java.lang.Number) 32.31608050161581d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (-39.46792946335992d), (java.lang.Number) 0.5d, false);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable23, objArray24);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable33, objArray34);
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray38);
        java.lang.Object[] objArray40 = maxIterationsExceededException39.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray40);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = mathException44.getGeneralPattern();
        java.lang.Object[] objArray46 = mathException44.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable29, objArray46);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable7, objArray46);
        java.lang.Class<?> wildcardClass49 = localizable7.getClass();
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        int int5 = randomDataImpl0.nextBinomial((int) 'a', (double) 0);
//        double double8 = randomDataImpl0.nextUniform((-1.5707963267948966d), 0.0d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl9.sample();
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        normalDistributionImpl9.reseedRandomGenerator((long) (short) 10);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int int18 = randomDataImpl0.nextZipf(14, (double) 99L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.5180170748533364d) + "'", double8 == (-0.5180170748533364d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.395949815394394d + "'", double10 == 0.395949815394394d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.6791474500211767d + "'", double15 == 0.6791474500211767d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (byte) 0);
//        double double5 = normalDistributionImpl0.density(0.0d);
//        double double6 = normalDistributionImpl0.getStandardDeviation();
//        double[] doubleArray8 = normalDistributionImpl0.sample(32);
//        normalDistributionImpl0.reseedRandomGenerator(28L);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.534567433859252d + "'", double1 == 0.534567433859252d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.3989422804014327d + "'", double5 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double2 = org.apache.commons.math.util.FastMath.min(123.24306196911334d, 82.6910150165087d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 82.6910150165087d + "'", double2 == 82.6910150165087d);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 100);
//        int int7 = randomDataImpl0.nextZipf((int) (short) 100, (double) (byte) 10);
//        double double10 = randomDataImpl0.nextWeibull(1.8976270912904414d, 40.594693073079846d);
//        double double13 = randomDataImpl0.nextGaussian((-0.3498335702652908d), 0.06764166112396071d);
//        int int16 = randomDataImpl0.nextInt(82, 92);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a40cf0a128b5cc351668b23220f452430f032fb3a5e72e227ab9e7776d7b4fb98bb2b01dae89390360fcc87423ad0a95400b" + "'", str4.equals("a40cf0a128b5cc351668b23220f452430f032fb3a5e72e227ab9e7776d7b4fb98bb2b01dae89390360fcc87423ad0a95400b"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 31.054301204005995d + "'", double10 == 31.054301204005995d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.3002239421716457d) + "'", double13 == (-0.3002239421716457d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 90 + "'", int16 == 90);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.19086079374478304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43687617667341744d + "'", double1 == 0.43687617667341744d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.3141304086286656d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.30436953262235966d + "'", double1 == 0.30436953262235966d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
        double double5 = normalDistributionImpl2.cumulativeProbability(3.450029527644452d, (double) 100);
        try {
            double double7 = normalDistributionImpl2.inverseCumulativeProbability(31.10892092196422d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 31.109 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.32913971458423197d + "'", double5 == 0.32913971458423197d);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma(0.3389074684885896d, 20.085536923187668d);
//        try {
//            double double5 = randomDataImpl0.nextT((-0.4321936919856847d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.432 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.432)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.514812263668738d + "'", double3 == 7.514812263668738d);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 21, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 38L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong(0L, 116L);
//        double double7 = randomDataImpl0.nextGaussian((-0.5264219283990733d), 0.2848798508461752d);
//        java.lang.String str9 = randomDataImpl0.nextHexString(105);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.14220271846689314d) + "'", double7 == (-0.14220271846689314d));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "18b57e66d04823611e895aeecc7314f7cd56871f23306322faee62f4be143d6180c19df2eed38465540c73070b6c4a365edc99c25" + "'", str9.equals("18b57e66d04823611e895aeecc7314f7cd56871f23306322faee62f4be143d6180c19df2eed38465540c73070b6c4a365edc99c25"));
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.acos(50.04907906220467d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) '#');
//        randomDataImpl0.reSeed((long) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 10, 1.7453292519943295d);
//        double double13 = randomDataImpl0.nextGamma(0.012463415928158344d, (double) 'a');
//        java.lang.String str15 = randomDataImpl0.nextSecureHexString(49);
//        double double17 = randomDataImpl0.nextT(14.021706690826768d);
//        int[] intArray20 = randomDataImpl0.nextPermutation(74, 21);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9L + "'", long5 == 9L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5095796257023292E-9d + "'", double13 == 1.5095796257023292E-9d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ea0baa4b45f2a39c2bd1f1103c72285e7d04d3a37dc453006" + "'", str15.equals("ea0baa4b45f2a39c2bd1f1103c72285e7d04d3a37dc453006"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.839211646711029d) + "'", double17 == (-0.839211646711029d));
//        org.junit.Assert.assertNotNull(intArray20);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.1074102330330102d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) ' ', 0.7615941559557649d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl4 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double8 = randomDataImpl4.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl10.sample();
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double15 = normalDistributionImpl10.density(0.0d);
//        double double16 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        try {
//            double double19 = randomDataImpl0.nextGaussian((double) 82, (double) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.75043026399278d + "'", double3 == 32.75043026399278d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.67294604877265d + "'", double8 == 61.67294604877265d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.861031069755128d) + "'", double9 == (-7.861031069755128d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9092956152659437d + "'", double11 == 0.9092956152659437d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989422804014327d + "'", double15 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.49941026818536094d + "'", double16 == 0.49941026818536094d);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 17, (float) 92);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 92.0f + "'", float2 == 92.0f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 50.02274797942717d, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 0.9405152825166656d);
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, number14, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 91.99999999999999d);
        java.lang.Number number18 = outOfRangeException17.getHi();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 91.99999999999999d + "'", number18.equals(91.99999999999999d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
//        java.lang.Object[] objArray8 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, objArray8);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 50.02274797942717d, (java.lang.Number) 1.7453292519943295d, (java.lang.Number) 0.9405152825166656d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl14.reSeed();
//        randomDataImpl14.reSeed();
//        java.lang.String str18 = randomDataImpl14.nextSecureHexString((int) (short) 100);
//        java.lang.String str20 = randomDataImpl14.nextHexString((int) (short) 100);
//        double double22 = randomDataImpl14.nextExponential((double) (byte) 10);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl27 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 1, (double) 100L);
//        double double28 = randomDataImpl24.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl27);
//        double double30 = randomDataImpl24.nextChiSquare(1.505149978319906d);
//        java.lang.Object[] objArray34 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray34);
//        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException35);
//        java.lang.Object[] objArray38 = null;
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray38);
//        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
//        java.lang.Object[] objArray41 = null;
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable40, objArray41);
//        java.lang.Object[] objArray44 = null;
//        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = mathException45.getGeneralPattern();
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("", objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getGeneralPattern();
//        java.lang.Object[] objArray51 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable50, objArray51);
//        java.lang.Object[] objArray55 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray55);
//        java.lang.Object[] objArray57 = maxIterationsExceededException56.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray57);
//        java.lang.Object[] objArray60 = null;
//        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getGeneralPattern();
//        java.lang.Object[] objArray63 = mathException61.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable46, objArray63);
//        java.lang.Object[] objArray65 = new java.lang.Object[] { randomDataImpl14, 30.801156128925953d, randomDataImpl24, (-3.0955394158806593d), mathException36, mathIllegalArgumentException64 };
//        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable7, objArray65);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 0.986706960784508d, (java.lang.Number) 14, true);
//        java.lang.Object[] objArray71 = numberIsTooSmallException70.getArguments();
//        org.junit.Assert.assertNotNull(localizable3);
//        org.junit.Assert.assertNotNull(localizable7);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9c158c139ee3259d2b9ee154fdaa4c0c3906f92c77e2cb66b1d5152bdb265ee378e5ca2d6381811a42baec1b05d2563903c9" + "'", str18.equals("9c158c139ee3259d2b9ee154fdaa4c0c3906f92c77e2cb66b1d5152bdb265ee378e5ca2d6381811a42baec1b05d2563903c9"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "b343ab3e00df908215681ceb75592a355ce61525d553c31fc355013e48907c0f33741e7a753a49f7696b4800b2ae9bb00ef5" + "'", str20.equals("b343ab3e00df908215681ceb75592a355ce61525d553c31fc355013e48907c0f33741e7a753a49f7696b4800b2ae9bb00ef5"));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 12.959944086403334d + "'", double22 == 12.959944086403334d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 66.18954321971734d + "'", double28 == 66.18954321971734d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.2344185009453956d + "'", double30 == 1.2344185009453956d);
//        org.junit.Assert.assertNotNull(objArray34);
//        org.junit.Assert.assertNotNull(localizable40);
//        org.junit.Assert.assertNotNull(localizable46);
//        org.junit.Assert.assertNotNull(localizable50);
//        org.junit.Assert.assertNotNull(objArray55);
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(localizable62);
//        org.junit.Assert.assertNotNull(objArray63);
//        org.junit.Assert.assertNotNull(objArray65);
//        org.junit.Assert.assertNotNull(objArray71);
//    }
//}

