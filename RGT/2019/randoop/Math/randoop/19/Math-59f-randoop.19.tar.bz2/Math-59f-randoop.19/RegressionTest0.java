import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.rint(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1) + "'", number4.equals((-1)));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6704649792860586d + "'", double2 == 1.6704649792860586d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double2 = org.apache.commons.math.util.FastMath.min((double) ' ', 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1L), (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.028563657838759995d) + "'", double2 == (-0.028563657838759995d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4142135623730951d + "'", double1 == 1.4142135623730951d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.0f), (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int[] intArray3 = new int[] { (short) 10 };
        mersenneTwister1.setSeed(intArray3);
        double double5 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.1724302448642956d) + "'", double5 == (-1.1724302448642956d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int[] intArray6 = new int[] { (byte) 2, (byte) 0, (short) 10, (short) 10 };
        mersenneTwister1.setSeed(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.4142135623730951d, 4.9E-324d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.6704649792860586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0995037190209989d) + "'", double1 == (-0.0995037190209989d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int1 = org.apache.commons.math.util.FastMath.round(100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.78306735f + "'", float2 == 0.78306735f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int2 = org.apache.commons.math.util.FastMath.max((-32767), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (byte) 100, false);
        java.lang.Class<?> wildcardClass5 = numberIsTooSmallException4.getClass();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (100)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (100)"));
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1309659398685306d + "'", double1 == 1.1309659398685306d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018267969E13d + "'", double1 == 7.896296018267969E13d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, (long) 32768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 181.01933598375618d + "'", double1 == 181.01933598375618d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.718281828459045d, (double) (-32767));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.0f, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 10);
        mersenneTwister1.setSeed((int) (byte) 0);
        int[] intArray11 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister1.setSeed(intArray11);
        float float13 = mersenneTwister1.nextFloat();
        byte[] byteArray14 = null;
        try {
            mersenneTwister1.nextBytes(byteArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.48206234f + "'", float13 == 0.48206234f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.1309659398685306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0634688241168757d + "'", double1 == 1.0634688241168757d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.48206234f, (java.lang.Number) (-0.7615941559557649d), true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10L, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E35d + "'", double2 == 1.0E35d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.ulp(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray3 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1622776601683795d + "'", double2 == 3.1622776601683795d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9877659459927356d + "'", double1 == 0.9877659459927356d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.atanh(52.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 0.78306735f, 4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.574710978503383d + "'", double2 == 4.574710978503383d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number11 = numberIsTooSmallException10.getMin();
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", numberIsTooSmallException10, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray14);
        java.lang.Throwable[] throwableArray16 = mathIllegalArgumentException15.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable3, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException17);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1) + "'", number11.equals((-1)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.028563657838759995d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.028571429840395852d) + "'", double1 == (-0.028571429840395852d));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.1309659398685306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7106847695909626d + "'", double1 == 1.7106847695909626d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, (long) (-32767));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2, 1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2904429955089607d + "'", double2 == 3.2904429955089607d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10000);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10000L + "'", long1 == 10000L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.881373587019543d + "'", double1 == 0.881373587019543d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1.0f, (-1.1724302448642956d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        byte[] byteArray9 = new byte[] { (byte) 1, (byte) 0, (byte) 2, (byte) 100, (byte) 1 };
        mersenneTwister1.nextBytes(byteArray9);
        float float11 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.6027633f + "'", float11 == 0.6027633f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(52.0d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(0);
        float float5 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7830674438602419d + "'", double2 == 0.7830674438602419d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.54881346f + "'", float5 == 0.54881346f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0.71518934f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6557603725852823d + "'", double1 == 0.6557603725852823d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.7106847695909626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.532748838900407d + "'", double1 == 4.532748838900407d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9964228836762624d + "'", double1 == 0.9964228836762624d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number11 = numberIsTooSmallException10.getMin();
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", numberIsTooSmallException10, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray14);
        java.lang.Throwable[] throwableArray16 = mathIllegalArgumentException15.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable3, (java.lang.Object[]) throwableArray16);
        java.lang.Throwable[] throwableArray18 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1) + "'", number11.equals((-1)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int1 = org.apache.commons.math.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.7763568394002505E-15d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7763568394002505E-15d + "'", double2 == 1.7763568394002505E-15d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-32767));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9913289158005998d + "'", double1 == 0.9913289158005998d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double2 = org.apache.commons.math.util.FastMath.min(0.9877659459927356d, (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9877659459927356d + "'", double2 == 0.9877659459927356d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.881373587019543d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 8, (-0.0995037190209989d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8130910631730528d + "'", double2 == 0.8130910631730528d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(0);
        try {
            int int6 = mersenneTwister1.nextInt((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7830674438602419d + "'", double2 == 0.7830674438602419d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number11 = numberIsTooSmallException10.getMin();
        java.lang.Object[] objArray14 = new java.lang.Object[] { "hi!", numberIsTooSmallException10, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray14);
        java.lang.Throwable[] throwableArray16 = mathIllegalArgumentException15.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable3, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathRuntimeException17.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1) + "'", number11.equals((-1)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNull(localizable18);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097587d) + "'", double1 == (-0.5063656411097587d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5874010519681996d + "'", double1 == 1.5874010519681996d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.newDfp();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.rint();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp15.subtract(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.rint();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.nextAfter(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.newDfp();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.rint();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.ceil();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp41.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp22.dotrap((int) ' ', "", dfp36, dfp41);
        org.apache.commons.math.dfp.Dfp dfp47 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp22, dfp47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        double[] doubleArray6 = dfp5.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.767330866396152d + "'", double0 == 0.767330866396152d);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 10);
        mersenneTwister1.setSeed((int) (byte) 0);
        int[] intArray11 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister1.setSeed(intArray11);
        long long13 = mersenneTwister1.nextLong();
        java.lang.Class<?> wildcardClass14 = mersenneTwister1.getClass();
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8892481652662305023L + "'", long13 == 8892481652662305023L);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8130910631730528d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 46.58668627962092d + "'", double1 == 46.58668627962092d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int2 = org.apache.commons.math.util.FastMath.max(647325673, 647325673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 647325673 + "'", int2 == 647325673);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 0.78306735f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8849109252457005d + "'", double1 == 0.8849109252457005d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', 0.78306735f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.2904429955089607d, 0.767330866396152d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3416909730105178d + "'", double2 == 1.3416909730105178d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.48564067996642346d) + "'", double3 == (-0.48564067996642346d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 171.49903622517783d + "'", double1 == 171.49903622517783d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        float float2 = org.apache.commons.math.util.FastMath.min(0.6027633f, (float) 10000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.6027633f + "'", float2 == 0.6027633f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.767330866396152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6453747155992683d + "'", double1 == 0.6453747155992683d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-32767));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32767.0f + "'", float1 == 32767.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField13.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp10.add(dfp18);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10000, (long) 32768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32768L + "'", long2 == 32768L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.ceil(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 58.0d + "'", double1 == 58.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.expm1(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 32768L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9278563334139247d + "'", double1 == 0.9278563334139247d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14436016288910833d) + "'", double1 == (-0.14436016288910833d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6557603725852823d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6557603725852823d + "'", double1 == 0.6557603725852823d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double2 = org.apache.commons.math.util.FastMath.max((double) '4', 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 10);
        mersenneTwister1.setSeed((int) (byte) 0);
        mersenneTwister1.setSeed(32768);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister((-1));
        boolean boolean10 = mersenneTwister9.nextBoolean();
        boolean boolean11 = mersenneTwister9.nextBoolean();
        byte[] byteArray17 = new byte[] { (byte) 1, (byte) 0, (byte) 2, (byte) 100, (byte) 1 };
        mersenneTwister9.nextBytes(byteArray17);
        boolean boolean19 = mersenneTwister9.nextBoolean();
        boolean boolean20 = dfp7.equals((java.lang.Object) boolean19);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 32760, (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32760.0d + "'", double2 == 32760.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double2 = org.apache.commons.math.util.FastMath.max(4.158638853279167d, (-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.158638853279167d + "'", double2 == 4.158638853279167d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        java.lang.Class<?> wildcardClass5 = notStrictlyPositiveException1.getClass();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 1 + "'", number3.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 1 + "'", number4.equals((short) 1));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-4));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 2, (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6268604078470186d + "'", double1 == 3.6268604078470186d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9278563334139247d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03251926347482289d) + "'", double1 == (-0.03251926347482289d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 1, (float) (byte) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        double[] doubleArray6 = dfp2.toSplitDouble();
        java.lang.Class<?> wildcardClass7 = dfp2.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.3416909730105178d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.48564067996642346d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4520943050537025d) + "'", double1 == (-0.4520943050537025d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        int int5 = dfp4.log10();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp4.getField();
        dfpField6.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertNotNull(dfpField6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.getTwo();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 10);
        mersenneTwister1.setSeed((int) (byte) 0);
        int[] intArray11 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister1.setSeed(intArray11);
        long long13 = mersenneTwister1.nextLong();
        int[] intArray14 = null;
        mersenneTwister1.setSeed(intArray14);
        boolean boolean16 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8892481652662305023L + "'", long13 == 8892481652662305023L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.sqrt();
        org.apache.commons.math.dfp.Dfp dfp12 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getSqr3();
        boolean boolean18 = dfp10.lessThan(dfp17);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.5063656411097587d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5063656411097587d + "'", double1 == 0.5063656411097587d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0.48206234f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.44789374841029567d + "'", double1 == 0.44789374841029567d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.7830674438602419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.995349391767956d + "'", double1 == 0.995349391767956d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.ceil();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp14.dotrap((int) ' ', "", dfp28, dfp33);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField40.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField40.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField40.getE();
        boolean boolean46 = dfp14.equals((java.lang.Object) dfp45);
        boolean boolean47 = dfp45.isInfinite();
        double[] doubleArray48 = dfp45.toSplitDouble();
        java.lang.String str49 = dfp45.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2.718281828459" + "'", str49.equals("2.718281828459"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        java.lang.Number number7 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        long long1 = org.apache.commons.math.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.nextAfter(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.rint();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp13.subtract(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.rint();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.nextAfter(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.newDfp();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.rint();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.ceil();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp20.dotrap((int) ' ', "", dfp34, dfp39);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.newDfp();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField46.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField46.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField46.getE();
        boolean boolean52 = dfp20.equals((java.lang.Object) dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp2.multiply(dfp20);
        int int54 = dfp53.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-4) + "'", int54 == (-4));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 16);
        int int4 = mersenneTwister1.nextInt();
        boolean boolean5 = mersenneTwister1.nextBoolean();
        double double6 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1325827307) + "'", int4 == (-1325827307));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.511313456171691d + "'", double6 == 0.511313456171691d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance();
        int int16 = dfp15.log10();
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp15.getField();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.ceil();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp8.dotrap(8, "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (100)", dfp15, dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = null;
        try {
            boolean boolean26 = dfp24.lessThan(dfp25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.String str4 = dfp3.toString();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.nextAfter(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp12.subtract(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.rint();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.ceil();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp19.dotrap((int) ' ', "", dfp33, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField45.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField45.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField45.getE();
        boolean boolean51 = dfp19.equals((java.lang.Object) dfp50);
        boolean boolean52 = dfp50.isInfinite();
        double[] doubleArray53 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp3.multiply(dfp50);
        org.apache.commons.math.dfp.Dfp dfp55 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0." + "'", str4.equals("0."));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        int int6 = dfp4.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.nextAfter(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.newDfp();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.rint();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp18.subtract(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.rint();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.nextAfter(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.newDfp();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.rint();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.newInstance();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.ceil();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp44.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp25.dotrap((int) ' ', "", dfp39, dfp44);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.newDfp();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField51.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField51.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField51.getE();
        boolean boolean57 = dfp25.equals((java.lang.Object) dfp56);
        boolean boolean58 = dfp56.isInfinite();
        double[] doubleArray59 = dfp56.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp60 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp61 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp56, dfp60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.028571429840395852d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.028567542729345516d) + "'", double1 == (-0.028567542729345516d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.511313456171691d, (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5113134561716911d + "'", double2 == 0.5113134561716911d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        double double2 = mersenneTwister1.nextDouble();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7830674438602419d + "'", double2 == 0.7830674438602419d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8442657f + "'", float4 == 0.8442657f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (byte) 100, false);
        java.lang.Class<?> wildcardClass5 = numberIsTooSmallException4.getClass();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number13, false);
        java.lang.Number number16 = numberIsTooSmallException15.getMin();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number25 = numberIsTooSmallException24.getMin();
        java.lang.Object[] objArray28 = new java.lang.Object[] { "hi!", numberIsTooSmallException24, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray28);
        java.lang.Throwable[] throwableArray30 = mathIllegalArgumentException29.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable17, (java.lang.Object[]) throwableArray30);
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number33, false);
        java.lang.Number number36 = numberIsTooSmallException35.getMin();
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException35.getGeneralPattern();
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number39, false);
        java.lang.Number number42 = numberIsTooSmallException41.getMin();
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number51 = numberIsTooSmallException50.getMin();
        java.lang.Object[] objArray54 = new java.lang.Object[] { "hi!", numberIsTooSmallException50, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable45, objArray54);
        java.lang.Throwable[] throwableArray56 = mathIllegalArgumentException55.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable43, (java.lang.Object[]) throwableArray56);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) (-0.8390715290764524d));
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.newDfp();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField61.getLn2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable11, localizable37, (java.lang.Object[]) dfpArray64);
        java.lang.Object[] objArray66 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, objArray66);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1) + "'", number25.equals((-1)));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number42);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (-1) + "'", number51.equals((-1)));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(2);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.newInstance("0.");
        org.apache.commons.math.dfp.Dfp dfp13 = null;
        try {
            boolean boolean14 = dfp8.unequal(dfp13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        int int5 = dfp4.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.028567542729345516d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.028571429840395852d) + "'", double1 == (-0.028571429840395852d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        float float2 = org.apache.commons.math.util.FastMath.min(32767.0f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        float float2 = org.apache.commons.math.util.FastMath.max(2.0f, (float) 10000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10000.0f + "'", float2 == 10000.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.881373587019543d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        int int11 = dfp7.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 32.0d, (java.lang.Number) 1.6704649792860586d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (-1));
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField13.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray19);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int[] intArray3 = new int[] { (short) 10 };
        mersenneTwister1.setSeed(intArray3);
        mersenneTwister1.setSeed(0L);
        int int7 = mersenneTwister1.nextInt();
        double double8 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 647325673 + "'", int7 == 647325673);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.3358343618944353d) + "'", double8 == (-1.3358343618944353d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        int int4 = dfp3.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((-0.7615941559557649d));
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.multiply((int) '4');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-4) + "'", int4 == (-4));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-323d + "'", double1 == 1.0E-323d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.acosh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644298430695373d + "'", double1 == 4.644298430695373d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        int int3 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6420149920119997d) + "'", double1 == (-0.6420149920119997d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.abs(58.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 58.0d + "'", double1 == 58.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.8849109252457005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4177597558441295d + "'", double1 == 1.4177597558441295d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int[] intArray3 = new int[] { (short) 10 };
        mersenneTwister1.setSeed(intArray3);
        mersenneTwister1.setSeed(0L);
        int int7 = mersenneTwister1.nextInt();
        long long8 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 647325673 + "'", int7 == 647325673);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 6704147859145430661L + "'", long8 == 6704147859145430661L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        long long2 = org.apache.commons.math.util.FastMath.max(97L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.028563657838759995d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5063656411097587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5578300447656787d + "'", double1 == 0.5578300447656787d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 35L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0.78306735f, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7830673456192017d + "'", double2 == 0.7830673456192017d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5578300447656787d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1596638229046938d + "'", double1 == 1.1596638229046938d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8130910631730528d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 0, (double) 32768);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.89629601826797E13d + "'", double1 == 7.89629601826797E13d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField3.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField3.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField3.getSqr2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField3.setRoundingMode(roundingMode10);
        dfpField1.setRoundingMode(roundingMode10);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 100, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        double double2 = mersenneTwister1.nextDouble();
        float float3 = mersenneTwister1.nextFloat();
        long long4 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7830674438602419d + "'", double2 == 0.7830674438602419d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.71518934f + "'", float3 == 0.71518934f);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2872789959691029693L) + "'", long4 == (-2872789959691029693L));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        dfpField1.clearIEEEFlags();
        int int11 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 16);
        mersenneTwister1.setSeed(0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.1724302448642956d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) 0, (double) 0.8442657f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.881373587019543d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3818891261280049d + "'", double1 == 1.3818891261280049d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.881373587019543d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7224284372420833d + "'", double1 == 0.7224284372420833d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.020683531529582487d) + "'", double1 == (-0.020683531529582487d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 32.0d, (java.lang.Number) 1.6704649792860586d, false);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, number11, (java.lang.Number) (byte) 100, false);
        java.lang.Class<?> wildcardClass15 = numberIsTooSmallException14.getClass();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number17, false);
        java.lang.Number number20 = numberIsTooSmallException19.getMin();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException19.getGeneralPattern();
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number23, false);
        java.lang.Number number26 = numberIsTooSmallException25.getMin();
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number35 = numberIsTooSmallException34.getMin();
        java.lang.Object[] objArray38 = new java.lang.Object[] { "hi!", numberIsTooSmallException34, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray38);
        java.lang.Throwable[] throwableArray40 = mathIllegalArgumentException39.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable27, (java.lang.Object[]) throwableArray40);
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number43, false);
        java.lang.Number number46 = numberIsTooSmallException45.getMin();
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException45.getGeneralPattern();
        java.lang.Number number49 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number49, false);
        java.lang.Number number52 = numberIsTooSmallException51.getMin();
        org.apache.commons.math.exception.util.Localizable localizable53 = numberIsTooSmallException51.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number61 = numberIsTooSmallException60.getMin();
        java.lang.Object[] objArray64 = new java.lang.Object[] { "hi!", numberIsTooSmallException60, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray64);
        java.lang.Throwable[] throwableArray66 = mathIllegalArgumentException65.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable53, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) (-0.8390715290764524d));
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField71.newDfp();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField71.getLn2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException14, localizable21, localizable47, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray74);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1) + "'", number35.equals((-1)));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNull(number46);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1) + "'", number61.equals((-1)));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        int int5 = dfp4.log10();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((double) 0.6027633f);
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp4.multiply(dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfp2.divide(dfp3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp9.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((double) (-1.0f));
        java.lang.Class<?> wildcardClass20 = dfp17.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.644298430695373d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.ceil();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp14.dotrap((int) ' ', "", dfp28, dfp33);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField40.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField40.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField40.getE();
        boolean boolean46 = dfp14.equals((java.lang.Object) dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.Dfp.copysign(dfp45, dfp47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.exp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp9.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        int int21 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField25.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField25.getLn2Split();
        boolean boolean32 = dfp23.equals((java.lang.Object) dfpField25);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField25.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField25.getE();
        boolean boolean36 = dfp17.equals((java.lang.Object) dfpField25);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-4) + "'", int21 == (-4));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister4.setSeed((long) 10);
        mersenneTwister4.setSeed((int) (byte) 0);
        int[] intArray14 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister4.setSeed(intArray14);
        mersenneTwister1.setSeed(intArray14);
        double double17 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.48206239744411117d + "'", double17 == 0.48206239744411117d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int int1 = org.apache.commons.math.util.FastMath.abs(32768);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32768 + "'", int1 == 32768);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10000, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.3440585709080678E43d, number1, true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.44789374841029567d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(8);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35L, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10000L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 10000L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) (-32767));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 10, (java.lang.Number) 181.01933598375618d, true);
        java.lang.Number number59 = numberIsTooSmallException58.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 10 + "'", number59.equals(10));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.511313456171691d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        int int4 = dfp3.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((-0.7615941559557649d));
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.rint();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField14.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField14.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField14.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp11, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp3.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-4) + "'", int4 == (-4));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
        long long2 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7692698082559361259L + "'", long2 == 7692698082559361259L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(2);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        double double12 = dfp10.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0000000000001574E8d + "'", double12 == 1.0000000000001574E8d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', (-1223252363));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        int int4 = dfp3.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-4) + "'", int4 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 32.0d, (java.lang.Number) 1.6704649792860586d, false);
        java.lang.Object[] objArray10 = numberIsTooSmallException9.getArguments();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getESplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.divide(dfp25);
        int int27 = dfp17.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 10);
        mersenneTwister1.setSeed((int) (byte) 0);
        int[] intArray11 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister1.setSeed(intArray11);
        float float13 = mersenneTwister1.nextFloat();
        boolean boolean14 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.48206234f + "'", float13 == 0.48206234f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        java.lang.String str3 = dfp2.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0." + "'", str3.equals("0."));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(181.01933598375618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 181.0193359837562d + "'", double1 == 181.0193359837562d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 10, (byte) 1);
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int2 = org.apache.commons.math.util.FastMath.max(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621956910836314d + "'", double1 == 3.7621956910836314d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.71518934f);
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException52);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException54);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '4', (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        int int5 = dfp4.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9092974268256817d + "'", double1 == 0.9092974268256817d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        int int10 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        boolean boolean6 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Object[] objArray7 = numberIsTooSmallException3.getArguments();
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        int int4 = dfp3.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((-0.7615941559557649d));
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getZero();
        int int11 = dfp10.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp6.nextAfter(dfp10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-4) + "'", int4 == (-4));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-4) + "'", int11 == (-4));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 16);
        int int5 = mersenneTwister1.nextInt(2070442226);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 821656341 + "'", int5 == 821656341);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        float float2 = org.apache.commons.math.util.FastMath.max(0.78306735f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.78306735f + "'", float2 == 0.78306735f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        int int10 = dfp9.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField14.getLn2Split();
        boolean boolean21 = dfp12.equals((java.lang.Object) dfpField14);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField14.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField14.newDfp(32760);
        boolean boolean26 = dfp6.unequal(dfp25);
        int int27 = dfp6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp6.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-4) + "'", int10 == (-4));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10000L, 32767.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32767.0f + "'", float2 == 32767.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double2 = org.apache.commons.math.util.FastMath.max(0.7830673456192017d, (double) 97L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.6453747155992683d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.19018805332755356d) + "'", double1 == (-0.19018805332755356d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        dfpField1.setIEEEFlags((int) (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number4, false);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Number number8 = notStrictlyPositiveException1.getMin();
        java.lang.Number number9 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4142135623730951d + "'", double1 == 1.4142135623730951d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathRuntimeException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-931718226));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.31718226E8d) + "'", double1 == (-9.31718226E8d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.Class<?> wildcardClass4 = dfp2.getClass();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        java.lang.Class<?> wildcardClass11 = dfp9.getClass();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        boolean boolean16 = dfp15.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp2.dotrap((int) (byte) 10, "org.apache.commons.math.exception.MathRuntimeException: ", dfp9, dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp2.newInstance(1);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.rint();
        org.apache.commons.math.dfp.DfpField dfpField30 = dfp29.getField();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.newDfp();
        int int35 = dfp34.log10();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.newDfp();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.getZero();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField39.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField39.getLn2Split();
        boolean boolean46 = dfp37.equals((java.lang.Object) dfpField39);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField39.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField39.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.power10K((-1223252363));
        org.apache.commons.math.dfp.Dfp dfp53 = dfp31.subtract(dfp50);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp25.remainder(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.newDfp();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp57.rint();
        java.lang.Class<?> wildcardClass59 = dfp57.getClass();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.newDfp();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField63.getZero();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.newDfp();
        org.apache.commons.math.dfp.Dfp dfp69 = dfp68.rint();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp68.newInstance();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp70.ceil();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp70.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp74.newInstance((int) '4');
        org.apache.commons.math.dfp.DfpField dfpField77 = dfp74.getField();
        org.apache.commons.math.dfp.Dfp dfp78 = dfp57.dotrap(8, "0.", dfp65, dfp74);
        org.apache.commons.math.dfp.Dfp dfp79 = org.apache.commons.math.dfp.DfpField.computeLn(dfp2, dfp50, dfp74);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpField30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-4) + "'", int35 == (-4));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfpField77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getPiSplit();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getSqr2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField7.setRoundingMode(roundingMode14);
        dfpField4.setRoundingMode(roundingMode14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.Class<?> wildcardClass4 = dfp2.getClass();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        java.lang.Class<?> wildcardClass11 = dfp9.getClass();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        boolean boolean16 = dfp15.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp2.dotrap((int) (byte) 10, "org.apache.commons.math.exception.MathRuntimeException: ", dfp9, dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp2.newInstance(1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp2.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        float float2 = org.apache.commons.math.util.FastMath.max(0.8442657f, (float) 16);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16.0f + "'", float2 == 16.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.acosh(181.01933598375618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.891743405277691d + "'", double1 == 5.891743405277691d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 6704147859145430661L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.704147859145431E18d + "'", double2 == 6.704147859145431E18d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable5, localizable6, objArray7);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 1 + "'", number3.equals((short) 1));
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10000, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10000.0f + "'", float2 == 10000.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.14436016288910833d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13442405642020788d) + "'", double1 == (-0.13442405642020788d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10000, (java.lang.Number) 10000, true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 10);
        mersenneTwister1.setSeed((int) (byte) 0);
        int[] intArray11 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister1.setSeed(intArray11);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        double double14 = mersenneTwister13.nextGaussian();
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.4489218460136957d) + "'", double14 == (-0.4489218460136957d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        int int5 = dfpField4.getIEEEFlags();
        int int6 = dfpField4.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int1 = org.apache.commons.math.util.FastMath.abs(10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 10000L);
        java.lang.Number number53 = notStrictlyPositiveException52.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 10000L + "'", number53.equals(10000L));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.log(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number4, false);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Number number9 = numberIsTooSmallException6.getMin();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable5, localizable6, objArray7);
        java.lang.String str9 = mathRuntimeException8.toString();
        java.lang.String str10 = mathRuntimeException8.toString();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathRuntimeException8.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException8);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 1 + "'", number3.equals((short) 1));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str9.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str10.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number12, false);
        java.lang.Number number15 = numberIsTooSmallException14.getMin();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException14.getGeneralPattern();
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number18, false);
        java.lang.Number number21 = numberIsTooSmallException20.getMin();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        java.lang.Object[] objArray33 = new java.lang.Object[] { "hi!", numberIsTooSmallException29, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray33);
        java.lang.Throwable[] throwableArray35 = mathIllegalArgumentException34.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable22, (java.lang.Object[]) throwableArray35);
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number38, false);
        java.lang.Number number41 = numberIsTooSmallException40.getMin();
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooSmallException40.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number54 = numberIsTooSmallException53.getMin();
        java.lang.Object[] objArray57 = new java.lang.Object[] { "hi!", numberIsTooSmallException53, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable48, objArray57);
        java.lang.Throwable[] throwableArray59 = mathIllegalArgumentException58.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException44, localizable45, localizable46, (java.lang.Object[]) throwableArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable42, (java.lang.Object[]) throwableArray59);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException63 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 10000L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) (-32767));
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number74 = numberIsTooSmallException73.getMin();
        java.lang.Object[] objArray77 = new java.lang.Object[] { "hi!", numberIsTooSmallException73, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, localizable68, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray77);
        boolean boolean81 = dfp10.equals((java.lang.Object) mathIllegalArgumentException80);
        org.apache.commons.math.dfp.Dfp dfp82 = new org.apache.commons.math.dfp.Dfp(dfp10);
        double[] doubleArray83 = dfp10.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (-1) + "'", number30.equals((-1)));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (-1) + "'", number54.equals((-1)));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + (-1) + "'", number74.equals((-1)));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) '4');
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        java.lang.String str15 = dfp14.toString();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.rint();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp20.nextAfter(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.newDfp();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.rint();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp23.subtract(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.rint();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.rint();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp38.nextAfter(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.newDfp();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.rint();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.newInstance();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.ceil();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp49.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp30.dotrap((int) ' ', "", dfp44, dfp49);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.newDfp();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray59 = dfpField56.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField56.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField56.getE();
        boolean boolean62 = dfp30.equals((java.lang.Object) dfp61);
        boolean boolean63 = dfp61.isInfinite();
        double[] doubleArray64 = dfp61.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp14.multiply(dfp61);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp10.nextAfter(dfp14);
        int int67 = dfp14.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0." + "'", str15.equals("0."));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfpArray59);
        org.junit.Assert.assertNotNull(dfpArray60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-4) + "'", int67 == (-4));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 821656341);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int[] intArray3 = new int[] { (short) 10 };
        mersenneTwister1.setSeed(intArray3);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed(8);
        float float9 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8734293f + "'", float9 == 0.8734293f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.4520943050537025d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        java.lang.String str4 = notStrictlyPositiveException1.toString();
        boolean boolean5 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        int int9 = dfp8.intValue();
        boolean boolean10 = dfp8.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int[] intArray3 = new int[] { (short) 10 };
        mersenneTwister1.setSeed(intArray3);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed(8);
        mersenneTwister1.setSeed(8892481652662305023L);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.String str4 = dfp3.toString();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.nextAfter(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp12.subtract(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.rint();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.ceil();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp19.dotrap((int) ' ', "", dfp33, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField45.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField45.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField45.getE();
        boolean boolean51 = dfp19.equals((java.lang.Object) dfp50);
        boolean boolean52 = dfp50.isInfinite();
        double[] doubleArray53 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp3.multiply(dfp50);
        org.apache.commons.math.dfp.Dfp dfp55 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp56 = dfp3.add(dfp55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0." + "'", str4.equals("0."));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-2872789959691029693L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.8727899596910295E18d) + "'", double1 == (-2.8727899596910295E18d));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.6704649792860586d, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.032113282889666216d + "'", double2 == 0.032113282889666216d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.Class<?> wildcardClass4 = dfp2.getClass();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        java.lang.Class<?> wildcardClass11 = dfp9.getClass();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        boolean boolean16 = dfp15.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp2.dotrap((int) (byte) 10, "org.apache.commons.math.exception.MathRuntimeException: ", dfp9, dfp17);
        int int19 = dfp18.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.3358343618944353d), (double) 16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        int int4 = dfp3.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((-0.7615941559557649d));
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getZero();
        int int11 = dfp10.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp6.nextAfter(dfp10);
        int int13 = dfp6.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-4) + "'", int4 == (-4));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-4) + "'", int11 == (-4));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.71518934f);
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException52);
        java.lang.Object[] objArray55 = mathRuntimeException54.getArguments();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.Class<?> wildcardClass4 = dfp2.getClass();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        java.lang.Class<?> wildcardClass11 = dfp9.getClass();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        boolean boolean16 = dfp15.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp2.dotrap((int) (byte) 10, "org.apache.commons.math.exception.MathRuntimeException: ", dfp9, dfp17);
        java.lang.String str19 = dfp17.toString();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp17.newInstance((long) 35);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0." + "'", str19.equals("0."));
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField7.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray12);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        boolean boolean9 = dfp8.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10000.0f, 3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9999.999999999998d + "'", double2 == 9999.999999999998d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp2);
        boolean boolean5 = dfp2.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        long long1 = org.apache.commons.math.util.FastMath.abs(97L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.power10((-1));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable5, localizable6, objArray7);
        java.lang.String str9 = mathRuntimeException8.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray12 = notStrictlyPositiveException11.getArguments();
        java.lang.Number number13 = notStrictlyPositiveException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException11, localizable15, localizable16, objArray17);
        mathRuntimeException8.addSuppressed((java.lang.Throwable) mathRuntimeException18);
        java.lang.Throwable[] throwableArray20 = mathRuntimeException8.getSuppressed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 1 + "'", number3.equals((short) 1));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str9.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 1 + "'", number13.equals((short) 1));
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.4097900908384d + "'", double1 == 148.4097900908384d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.String str4 = dfp3.toString();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.nextAfter(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp12.subtract(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.rint();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.ceil();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp19.dotrap((int) ' ', "", dfp33, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField45.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField45.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField45.getE();
        boolean boolean51 = dfp19.equals((java.lang.Object) dfp50);
        boolean boolean52 = dfp50.isInfinite();
        double[] doubleArray53 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp3.multiply(dfp50);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp50.getOne();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.newDfp();
        int int59 = dfp58.log10();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp58.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.newDfp();
        int int65 = dfp64.log10();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp58.multiply(dfp64);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField68.newDfp();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.getZero();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField68.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField68.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField68.getLn2();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp58.add(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp50.nextAfter(dfp76);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0." + "'", str4.equals("0."));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-4) + "'", int59 == (-4));
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-4) + "'", int65 == (-4));
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        int int3 = dfp2.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        float float2 = org.apache.commons.math.util.FastMath.max(0.71518934f, (float) (byte) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1223252363), 0.9913289158005998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.223252363E9d) + "'", double2 == (-1.223252363E9d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 52L, 0.71518934f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField18.getLn2Split();
        boolean boolean25 = dfp16.equals((java.lang.Object) dfpField18);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField18.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField18.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10K((-1223252363));
        org.apache.commons.math.dfp.Dfp dfp32 = dfp10.subtract(dfp29);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp4.remainder(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField35.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField35.getE();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10K(2);
        boolean boolean45 = dfp29.greaterThan(dfp44);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-4) + "'", int14 == (-4));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) '4');
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp(100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getESplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp7.add(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField23 = dfp21.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpField23);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.ulp(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 10, (byte) 1);
        int int7 = dfpField1.getRadixDigits();
        int int8 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.4489218460136957d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 10000L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) (-32767));
        boolean boolean55 = notStrictlyPositiveException54.getBoundIsAllowed();
        java.lang.Number number56 = notStrictlyPositiveException54.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-32767) + "'", number56.equals((-32767)));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.891743405277691d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7702438243724615d + "'", double1 == 0.7702438243724615d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp9.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.ceil();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((double) (-1.0f));
        try {
            org.apache.commons.math.dfp.Dfp dfp21 = dfp17.newInstance((-2872789959691029693L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfp4.divide(dfp5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        int int9 = dfp8.log10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField13.getLn2Split();
        boolean boolean20 = dfp11.equals((java.lang.Object) dfpField13);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField13.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K((-1223252363));
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.subtract(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.rint();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(0.7830673456192017d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-4) + "'", int9 == (-4));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-931718226));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1));
        java.lang.Class<?> wildcardClass3 = notStrictlyPositiveException2.getClass();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (-1));
        java.lang.Class<?> wildcardClass9 = notStrictlyPositiveException8.getClass();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException8);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1) + "'", number4.equals((-1)));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        int int4 = dfp3.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((-0.7615941559557649d));
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.rint();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField14.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField14.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField14.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp11, dfp23);
        int int25 = dfp24.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.rint();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance();
        int int31 = dfp30.log10();
        org.apache.commons.math.dfp.DfpField dfpField32 = dfp30.getField();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.newInstance((double) 0.6027633f);
        boolean boolean35 = dfp24.greaterThan(dfp30);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp24.newInstance((long) (byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-4) + "'", int4 == (-4));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-4) + "'", int31 == (-4));
        org.junit.Assert.assertNotNull(dfpField32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 10);
        boolean boolean7 = dfp4.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.704147859145431E18d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8341541820517105E188d + "'", double2 == 1.8341541820517105E188d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.7182818284590453d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int[] intArray6 = new int[] { 647325673, (-4), (short) 100, (byte) 0, (byte) 3, (byte) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5113134561716911d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5610843976766142d + "'", double1 == 0.5610843976766142d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 10, (byte) 1);
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("0.");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        float float2 = org.apache.commons.math.util.FastMath.max(0.48206234f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.48206234f + "'", float2 == 0.48206234f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField7.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.Class<?> wildcardClass4 = dfp2.getClass();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.ceil();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((int) '4');
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp19.getField();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.dotrap(8, "0.", dfp10, dfp19);
        double double24 = dfp19.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("1.732050807569");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.abs((-9.31718226E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.31718226E8d + "'", double1 == 9.31718226E8d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp(4L);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField4.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        long long1 = org.apache.commons.math.util.FastMath.round(9.31718226E8d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 931718226L + "'", long1 == 931718226L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField27.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray33);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray33);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10000.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        java.lang.String str9 = dfp8.toString();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.newDfp();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.rint();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.rint();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp17.subtract(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.newDfp();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.rint();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp32.nextAfter(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.rint();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.ceil();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp24.dotrap((int) ' ', "", dfp38, dfp43);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.newDfp();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField50.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField50.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.getE();
        boolean boolean56 = dfp24.equals((java.lang.Object) dfp55);
        boolean boolean57 = dfp55.isInfinite();
        double[] doubleArray58 = dfp55.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp8.multiply(dfp55);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp4.subtract(dfp8);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0." + "'", str9.equals("0."));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.1724302448642956d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(35L);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.072853684f + "'", float2 == 0.072853684f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.ceil();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp14.dotrap((int) ' ', "", dfp28, dfp33);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.getTwo();
        org.apache.commons.math.dfp.Dfp dfp40 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp41 = dfp39.divide(dfp40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(0.511313456171691d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField7.newDfp("1.732050807569");
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.newDfp(32768);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField7.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int[] intArray3 = new int[] { (short) 10 };
        mersenneTwister1.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getESplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp7.add(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.ceil();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp14.dotrap((int) ' ', "", dfp28, dfp33);
        java.lang.String str39 = dfp28.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0." + "'", str39.equals("0."));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5610843976766142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.25097180774844463d) + "'", double1 == (-0.25097180774844463d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        dfpField4.setIEEEFlagsBits((-1325827307));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int int1 = org.apache.commons.math.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8862269254527579d + "'", double1 == 0.8862269254527579d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getESplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.divide(dfp25);
        java.lang.String str27 = dfp25.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2." + "'", str27.equals("2."));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(2);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.newInstance("0.");
        int int13 = dfp12.log10K();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.multiply((int) (short) 10);
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField7.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField7.getOne();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField7.getLn5();
        boolean boolean21 = dfp20.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.floor(5.891743405277691d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp5.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp5.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.rint();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.newDfp();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.rint();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp24.subtract(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField34.getESplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp24.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.power10((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp5.subtract(dfp39);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable5, localizable6, objArray7);
        java.lang.String str9 = mathRuntimeException8.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray12 = notStrictlyPositiveException11.getArguments();
        java.lang.Number number13 = notStrictlyPositiveException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException11, localizable15, localizable16, objArray17);
        mathRuntimeException8.addSuppressed((java.lang.Throwable) mathRuntimeException18);
        java.lang.String str20 = mathRuntimeException18.toString();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 1 + "'", number3.equals((short) 1));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str9.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 1 + "'", number13.equals((short) 1));
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str20.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (byte) 100, false);
        java.lang.Class<?> wildcardClass5 = numberIsTooSmallException4.getClass();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number13, false);
        java.lang.Number number16 = numberIsTooSmallException15.getMin();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number25 = numberIsTooSmallException24.getMin();
        java.lang.Object[] objArray28 = new java.lang.Object[] { "hi!", numberIsTooSmallException24, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray28);
        java.lang.Throwable[] throwableArray30 = mathIllegalArgumentException29.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable17, (java.lang.Object[]) throwableArray30);
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number33, false);
        java.lang.Number number36 = numberIsTooSmallException35.getMin();
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException35.getGeneralPattern();
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number39, false);
        java.lang.Number number42 = numberIsTooSmallException41.getMin();
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number51 = numberIsTooSmallException50.getMin();
        java.lang.Object[] objArray54 = new java.lang.Object[] { "hi!", numberIsTooSmallException50, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable45, objArray54);
        java.lang.Throwable[] throwableArray56 = mathIllegalArgumentException55.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable43, (java.lang.Object[]) throwableArray56);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) (-0.8390715290764524d));
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.newDfp();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField61.getLn2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable11, localizable37, (java.lang.Object[]) dfpArray64);
        boolean boolean66 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1) + "'", number25.equals((-1)));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number42);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (-1) + "'", number51.equals((-1)));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) '4');
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        java.lang.String str15 = dfp14.toString();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.rint();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp20.nextAfter(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.newDfp();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.rint();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp23.subtract(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.rint();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.rint();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp38.nextAfter(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.newDfp();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.rint();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.newInstance();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.ceil();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp49.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp30.dotrap((int) ' ', "", dfp44, dfp49);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.newDfp();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray59 = dfpField56.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField56.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField56.getE();
        boolean boolean62 = dfp30.equals((java.lang.Object) dfp61);
        boolean boolean63 = dfp61.isInfinite();
        double[] doubleArray64 = dfp61.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp14.multiply(dfp61);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp10.nextAfter(dfp14);
        org.apache.commons.math.dfp.Dfp dfp67 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0." + "'", str15.equals("0."));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfpArray59);
        org.junit.Assert.assertNotNull(dfpArray60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((-1.0d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.ceil();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp7, dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        int int26 = dfp25.log10();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.rint();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.nextAfter(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.newDfp();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.rint();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp36.subtract(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.rint();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.newDfp();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp54.rint();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.newInstance();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp51.nextAfter(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.newDfp();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp60.rint();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.newInstance();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp62.ceil();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp62.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp43.dotrap((int) ' ', "", dfp57, dfp62);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.newDfp();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField69.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray72 = dfpField69.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray73 = dfpField69.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField69.getE();
        boolean boolean75 = dfp43.equals((java.lang.Object) dfp74);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp25.multiply(dfp43);
        boolean boolean77 = dfp20.lessThan(dfp43);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp20.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp80 = dfp15.add(dfp79);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-4) + "'", int26 == (-4));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfpArray72);
        org.junit.Assert.assertNotNull(dfpArray73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        int int9 = dfp8.log10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField13.getLn2Split();
        boolean boolean20 = dfp11.equals((java.lang.Object) dfpField13);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField13.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10K((-1223252363));
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.subtract(dfp24);
        double[] doubleArray28 = dfp5.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-4) + "'", int9 == (-4));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getESplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.divide(dfp25);
        int int27 = dfp17.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0.8734293f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7665357410554234d + "'", double1 == 0.7665357410554234d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int int2 = mersenneTwister1.nextInt();
        int int4 = mersenneTwister1.nextInt(32768);
        byte[] byteArray5 = null;
        try {
            mersenneTwister1.nextBytes(byteArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-931718226) + "'", int2 == (-931718226));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21243 + "'", int4 == 21243);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 32768L, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.8341541820517105E188d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3183461601731589d) + "'", double1 == (-0.3183461601731589d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 647325673, (float) (byte) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 10);
        mersenneTwister1.setSeed((int) (byte) 0);
        int[] intArray11 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister1.setSeed(intArray11);
        long long13 = mersenneTwister1.nextLong();
        int[] intArray14 = null;
        mersenneTwister1.setSeed(intArray14);
        mersenneTwister1.setSeed((int) 'a');
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8892481652662305023L + "'", long13 == 8892481652662305023L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5309649148733836d) + "'", double1 == (-0.5309649148733836d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance("hi!");
        double[] doubleArray12 = dfp9.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp9);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(0.511313456171691d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField7.newDfp("1.732050807569");
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.newDfp(32768);
        int int22 = dfp21.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.rint();
        java.lang.String str10 = dfp9.toString();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.subtract(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.newInstance((int) '4');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0." + "'", str10.equals("0."));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.ceil();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp14.dotrap((int) ' ', "", dfp28, dfp33);
        boolean boolean39 = dfp33.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) '4');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 32768);
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.71518934f);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode56 = dfpField54.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField54.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, (java.lang.Object[]) dfpArray57);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + roundingMode56 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode56.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray57);
    }
}

