import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.71518934f);
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        boolean boolean54 = notStrictlyPositiveException52.getBoundIsAllowed();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double2 = org.apache.commons.math.util.FastMath.atan2(7.896296018267969E13d, 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267936682d + "'", double2 == 1.5707963267936682d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.ceil();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp14.dotrap((int) ' ', "", dfp28, dfp33);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField40 = dfp38.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpField40);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        int int5 = dfp4.log10();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp4.getField();
        int int7 = dfp4.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.String str4 = dfp3.toString();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.rint();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.newDfp();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.rint();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.nextAfter(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.newDfp();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.rint();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp21.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.newDfp();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp13, dfp29, dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp3.subtract(dfp35);
        double double37 = dfp35.toDouble();
        boolean boolean38 = dfp35.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0." + "'", str4.equals("0."));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.NEGATIVE_INFINITY + "'", double37 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.7106847695909626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3079314850522419d + "'", double1 == 1.3079314850522419d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) '4');
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField12.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp10.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp10.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        int int24 = dfp10.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.8130910631730528d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6872563251426251d + "'", double1 == 0.6872563251426251d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.multiply((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField7.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.newDfp(0.881373587019543d);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int int2 = mersenneTwister1.nextInt();
        int int3 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-931718226) + "'", int2 == (-931718226));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1748719057) + "'", int3 == (-1748719057));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018268069E13d + "'", double1 == 7.896296018268069E13d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        int[] intArray3 = new int[] { (short) 10 };
        mersenneTwister1.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double7 = mersenneTwister6.nextGaussian();
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister((-1));
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister((-1));
        boolean boolean12 = mersenneTwister11.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister14.setSeed((long) 10);
        mersenneTwister14.setSeed((int) (byte) 0);
        int[] intArray24 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister14.setSeed(intArray24);
        mersenneTwister11.setSeed(intArray24);
        mersenneTwister9.setSeed(intArray24);
        mersenneTwister6.setSeed(intArray24);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.1724302448642956d) + "'", double7 == (-1.1724302448642956d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        long long2 = org.apache.commons.math.util.FastMath.min(7692698082559361259L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number4, false);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Number number8 = notStrictlyPositiveException1.getMin();
        boolean boolean9 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        int int10 = dfp9.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField14.getLn2Split();
        boolean boolean21 = dfp12.equals((java.lang.Object) dfpField14);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField14.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField14.newDfp(32760);
        boolean boolean26 = dfp6.unequal(dfp25);
        double[] doubleArray27 = dfp6.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-4) + "'", int10 == (-4));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2070442226);
        float float2 = mersenneTwister1.nextFloat();
        mersenneTwister1.setSeed((long) (-931718226));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.22650862f + "'", float2 == 0.22650862f);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        int[] intArray0 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
//        double double2 = mersenneTwister1.nextDouble();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.788878635576294d + "'", double2 == 0.788878635576294d);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1));
        java.lang.Class<?> wildcardClass3 = notStrictlyPositiveException2.getClass();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number6 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1) + "'", number4.equals((-1)));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.028571429840395852d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.028579206919282955d) + "'", double1 == (-0.028579206919282955d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1578212823495775d + "'", double1 == 1.1578212823495775d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField8.getRoundingMode();
        dfpField4.setRoundingMode(roundingMode15);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3110011563655863d + "'", double1 == 1.3110011563655863d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        int int4 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.multiply(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 21243);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4824676047053768d) + "'", double1 == (-0.4824676047053768d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.newDfp(0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray9 = new byte[] { (byte) 0, (byte) 0, (byte) 2, (byte) 3 };
        mersenneTwister4.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.ceil();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp7, dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance("hi!");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getLn10();
        double double8 = dfp7.toDouble();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.302585092994d + "'", double8 == 2.302585092994d);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-4) + "'", int14 == (-4));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.1724302448642956d), (java.lang.Number) (-1.1724302448642956d), false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(0.511313456171691d);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField7.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray18);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1071487177940904d + "'", double1 == 1.1071487177940904d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.71518934f);
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable53, (java.lang.Number) (-32767));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(100L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int int2 = org.apache.commons.math.util.FastMath.max(32, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 10000L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) (-32767));
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number63 = numberIsTooSmallException62.getMin();
        java.lang.Object[] objArray66 = new java.lang.Object[] { "hi!", numberIsTooSmallException62, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray66);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.7702438243724615d);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + (-1) + "'", number63.equals((-1)));
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 3, (long) 32768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-4) + "'", int14 == (-4));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        double double2 = mersenneTwister1.nextDouble();
        int int3 = mersenneTwister1.nextInt();
        mersenneTwister1.setSeed(52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7830674438602419d + "'", double2 == 0.7830674438602419d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1223252363) + "'", int3 == (-1223252363));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(0.511313456171691d);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField7.newDfp((long) (byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.ceil();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp14.dotrap((int) ' ', "", dfp28, dfp33);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField40.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField40.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField40.getE();
        boolean boolean46 = dfp14.equals((java.lang.Object) dfp45);
        boolean boolean47 = dfp45.isInfinite();
        double[] doubleArray48 = dfp45.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.newDfp();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getZero();
        int int53 = dfp52.log10();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.newDfp();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp57.rint();
        java.lang.String str59 = dfp58.toString();
        boolean boolean60 = dfp58.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp54.multiply(dfp58);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(8);
        boolean boolean64 = dfp58.isNaN();
        boolean boolean65 = dfp45.greaterThan(dfp58);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-4) + "'", int53 == (-4));
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0." + "'", str59.equals("0."));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.48564067996642346d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.504956530201482d) + "'", double1 == (-0.504956530201482d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.644298430695373d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.5610843976766142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5087815681624547d + "'", double1 == 0.5087815681624547d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.3358343618944353d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp(4L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 2070442226);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2070442226L + "'", long2 == 2070442226L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.71518934f);
        java.lang.Object[] objArray53 = notStrictlyPositiveException52.getArguments();
        java.lang.Throwable[] throwableArray54 = notStrictlyPositiveException52.getSuppressed();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray54);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        double[] doubleArray5 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((double) 10000);
        java.lang.Class<?> wildcardClass8 = dfp7.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0);
        boolean boolean5 = dfp4.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0);
        int int7 = dfp6.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp8);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10((int) (short) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 0, (byte) 2, (byte) 3 };
        mersenneTwister0.nextBytes(byteArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 0, (byte) 2, (byte) 3 };
        mersenneTwister7.nextBytes(byteArray12);
        mersenneTwister0.nextBytes(byteArray12);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2070442226);
        float float2 = mersenneTwister1.nextFloat();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.22650862f + "'", float2 == 0.22650862f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        int int13 = dfp12.log10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField17.getLn2Split();
        boolean boolean24 = dfp15.equals((java.lang.Object) dfpField17);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField17.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField17.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10K((-1223252363));
        org.apache.commons.math.dfp.Dfp dfp31 = dfp9.subtract(dfp28);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp2.multiply(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.newDfp();
        int int36 = dfp35.log10();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.newInstance();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp32.multiply(dfp35);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-4) + "'", int36 == (-4));
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.302585092994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994d + "'", double1 == 2.302585092994d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.atan(46.58668627962092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5493342625215114d + "'", double1 == 1.5493342625215114d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 16.0d, (java.lang.Number) 8, true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2490457723982544d + "'", double1 == 1.2490457723982544d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.newDfp();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.rint();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.ceil();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((int) '4');
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField27.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField27.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp25.newInstance(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp25.sqrt();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp5.remainder(dfp36);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 1 + "'", number3.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 1 + "'", number4.equals((short) 1));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 1);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getESplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.divide(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getESplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.getOne();
        boolean boolean32 = dfp17.unequal(dfp31);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(32);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        int int10 = dfp9.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.nextAfter(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.rint();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp20.subtract(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.rint();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.rint();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp35.nextAfter(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.newDfp();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.rint();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.ceil();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp46.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp27.dotrap((int) ' ', "", dfp41, dfp46);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.newDfp();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray56 = dfpField53.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField53.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField53.getE();
        boolean boolean59 = dfp27.equals((java.lang.Object) dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp9.multiply(dfp27);
        boolean boolean61 = dfp4.lessThan(dfp27);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp4.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp4.multiply((int) '#');
        double double66 = dfp65.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-4) + "'", int10 == (-4));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfpArray56);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.NEGATIVE_INFINITY + "'", double66 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister4.setSeed((long) 10);
        mersenneTwister4.setSeed((int) (byte) 0);
        int[] intArray14 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister4.setSeed(intArray14);
        mersenneTwister1.setSeed(intArray14);
        int[] intArray23 = new int[] { 647325673, (-4), (short) 100, (byte) 0, (byte) 3, (byte) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister24 = new org.apache.commons.math.random.MersenneTwister(intArray23);
        mersenneTwister1.setSeed(intArray23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        double double2 = mersenneTwister1.nextDouble();
        float float3 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7830674438602419d + "'", double2 == 0.7830674438602419d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.71518934f + "'", float3 == 0.71518934f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        boolean boolean6 = dfp5.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10000.0f, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10000.0d + "'", double2 == 10000.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(0.511313456171691d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField7.newDfp("1.732050807569");
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField7.newDfp((double) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.rint();
        org.apache.commons.math.dfp.DfpField dfpField28 = dfp27.getField();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.newDfp();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.rint();
        java.lang.String str34 = dfp33.toString();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.newDfp();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.rint();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.newDfp();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.rint();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.newInstance();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.nextAfter(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.newDfp();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp48.rint();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp42.subtract(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.newDfp();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp55.rint();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp55.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.newDfp();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp60.rint();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.newInstance();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp57.nextAfter(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField65.newDfp();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp66.rint();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp66.newInstance();
        org.apache.commons.math.dfp.Dfp dfp69 = dfp68.ceil();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp49.dotrap((int) ' ', "", dfp63, dfp68);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField75.newDfp();
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField75.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray78 = dfpField75.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray79 = dfpField75.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField75.getE();
        boolean boolean81 = dfp49.equals((java.lang.Object) dfp80);
        boolean boolean82 = dfp80.isInfinite();
        double[] doubleArray83 = dfp80.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp84 = dfp33.multiply(dfp80);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp29.nextAfter(dfp33);
        java.lang.Class<?> wildcardClass86 = dfp29.getClass();
        org.apache.commons.math.dfp.Dfp dfp87 = dfp23.subtract(dfp29);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpField28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0." + "'", str34.equals("0."));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfpArray78);
        org.junit.Assert.assertNotNull(dfpArray79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertNotNull(dfp87);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.FastMath.ulp(32760.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.ceil();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp14.dotrap((int) ' ', "", dfp28, dfp33);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField40.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField40.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField40.getE();
        boolean boolean46 = dfp14.equals((java.lang.Object) dfp45);
        boolean boolean47 = dfp45.isInfinite();
        double[] doubleArray48 = dfp45.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number7, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number19 = numberIsTooSmallException18.getMin();
        java.lang.Object[] objArray22 = new java.lang.Object[] { "hi!", numberIsTooSmallException18, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable11, (java.lang.Object[]) throwableArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, number27, false);
        java.lang.Number number30 = numberIsTooSmallException29.getMin();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) (-1), false);
        java.lang.Number number43 = numberIsTooSmallException42.getMin();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!", numberIsTooSmallException42, (-1.0d), false };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray46);
        java.lang.Throwable[] throwableArray48 = mathIllegalArgumentException47.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 10000L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) (-32767));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 10, (java.lang.Number) 181.01933598375618d, true);
        org.apache.commons.math.exception.util.Localizable localizable59 = numberIsTooSmallException58.getGeneralPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1) + "'", number19.equals((-1)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1) + "'", number43.equals((-1)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        float float2 = org.apache.commons.math.util.FastMath.max((float) ' ', (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5578300447656788d) + "'", double1 == (-0.5578300447656788d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 10, (byte) 1);
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((byte) 10, (byte) 1);
        int int15 = dfpField9.getRadixDigits();
        boolean boolean16 = dfp7.equals((java.lang.Object) dfpField9);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField9.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (100)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        boolean boolean8 = dfp7.isNaN();
        boolean boolean9 = dfp7.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        int int4 = dfp3.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.rint();
        java.lang.String str10 = dfp9.toString();
        boolean boolean11 = dfp9.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.multiply(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        int int16 = dfp15.log10();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp15.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.newDfp();
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp15.multiply(dfp21);
        double[] doubleArray24 = dfp15.toSplitDouble();
        boolean boolean25 = dfp9.lessThan(dfp15);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-4) + "'", int4 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0." + "'", str10.equals("0."));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-4) + "'", int22 == (-4));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.log10((-9.31718226E8d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3010299956639812d + "'", double1 == 0.3010299956639812d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) (short) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        int int9 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(0.511313456171691d);
        dfpField7.setIEEEFlagsBits((int) (byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.multiply((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getLn2Split();
        boolean boolean14 = dfp5.equals((java.lang.Object) dfpField7);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(7.896296018267969E13d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField7.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10K((-1223252363));
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.newInstance(0.5087815681624547d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getESplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.divide(dfp25);
        boolean boolean27 = dfp17.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.String str4 = dfp3.toString();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.nextAfter(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp12.subtract(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.rint();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.ceil();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.newInstance((byte) -1, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp19.dotrap((int) ' ', "", dfp33, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField45.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField45.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField45.getE();
        boolean boolean51 = dfp19.equals((java.lang.Object) dfp50);
        boolean boolean52 = dfp50.isInfinite();
        double[] doubleArray53 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp3.multiply(dfp50);
        double double55 = dfp3.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0." + "'", str4.equals("0."));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + Double.NEGATIVE_INFINITY + "'", double55 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.newInstance((byte) 100, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((byte) -1, (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
        mersenneTwister1.setSeed((long) 10);
        mersenneTwister1.setSeed((int) (byte) 0);
        int[] intArray11 = new int[] { 4, (-1), (byte) 1, 'a', 100 };
        mersenneTwister1.setSeed(intArray11);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        int int14 = mersenneTwister13.nextInt();
        int int15 = mersenneTwister13.nextInt();
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2070442226 + "'", int14 == 2070442226);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-560103169) + "'", int15 == (-560103169));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.637978807091713E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.767330866396152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0138041427035833d + "'", double1 == 1.0138041427035833d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.floor(171.49903622517783d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 171.0d + "'", double1 == 171.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5874010519681996d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2422869359501354d + "'", double1 == 1.2422869359501354d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', (-4));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.732511156817248d + "'", double1 == 3.732511156817248d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1), 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0.8734293f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9887965171426321d + "'", double1 == 0.9887965171426321d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        boolean boolean3 = dfp2.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0L);
        double[] doubleArray5 = dfp4.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance();
        int int5 = dfp4.log10();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((double) 0.6027633f);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField10.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((-1));
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.add(dfp13);
        boolean boolean15 = dfp13.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.rint();
        java.lang.Class<?> wildcardClass4 = dfp2.getClass();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.rint();
        java.lang.Class<?> wildcardClass11 = dfp9.getClass();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        boolean boolean16 = dfp15.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp2.dotrap((int) (byte) 10, "org.apache.commons.math.exception.MathRuntimeException: ", dfp9, dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.newDfp();
        boolean boolean22 = dfp21.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp23 = new org.apache.commons.math.dfp.Dfp(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 10);
        boolean boolean26 = dfp17.lessThan(dfp25);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }
}

