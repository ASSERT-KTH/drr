import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8795122390062857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6310122958424929d + "'", double1 == 0.6310122958424929d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(6.907755278982137d, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4538776394910684d + "'", double2 == 3.4538776394910684d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.737102242198924d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5554256074534483d + "'", double1 == 1.5554256074534483d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(57.29577951308232d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 114.59155902616465d + "'", double2 == 114.59155902616465d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray15 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection17, false);
        double[] doubleArray21 = new double[] { (byte) -1 };
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray21);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false);
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection39, false);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray37);
        java.lang.Class<?> wildcardClass43 = doubleArray31.getClass();
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray31);
        double[] doubleArray46 = new double[] { (byte) -1 };
        double[] doubleArray48 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray48);
        double[] doubleArray52 = new double[] { (byte) -1 };
        double[] doubleArray54 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray54);
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray52);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray48);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray31);
        double[] doubleArray61 = null;
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1386122689, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        long long1 = org.apache.commons.math.util.FastMath.round(7.72769467795052E24d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(611175361L, (long) (-456387814));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1079504351), (-58), (-704643071));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 0.9985900724399912d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 13566);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 7227194, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7227194.0d + "'", double2 == 7227194.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double[] doubleArray4 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = new double[] { (byte) -1 };
        double[] doubleArray12 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        double[] doubleArray18 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection20, false);
        double[] doubleArray24 = new double[] { (byte) -1 };
        double[] doubleArray26 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray26);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray35 = new double[] { (byte) -1 };
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray37);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number48 = nonMonotonousSequenceException47.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = nonMonotonousSequenceException47.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection49, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7876260917919922d, (java.lang.Number) 100.00000000000001d, (-1221515391), orderDirection49, true);
        java.lang.Throwable[] throwableArray58 = nonMonotonousSequenceException57.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number63 = nonMonotonousSequenceException62.getArgument();
        java.lang.Number number64 = nonMonotonousSequenceException62.getPrevious();
        java.lang.String str65 = nonMonotonousSequenceException62.toString();
        java.lang.Number number66 = nonMonotonousSequenceException62.getArgument();
        nonMonotonousSequenceException57.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException62);
        java.lang.Number number68 = nonMonotonousSequenceException62.getPrevious();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 10.0f + "'", number48.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 10 + "'", number63.equals(10));
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 10.0f + "'", number64.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str65.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 10 + "'", number66.equals(10));
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 10.0f + "'", number68.equals(10.0f));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double[] doubleArray4 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = new double[] { (byte) -1 };
        double[] doubleArray12 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        double[] doubleArray18 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection20, false);
        double[] doubleArray24 = new double[] { (byte) -1 };
        double[] doubleArray26 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray26);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray35 = new double[] { (byte) -1 };
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray37);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number48 = nonMonotonousSequenceException47.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = nonMonotonousSequenceException47.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection49, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7876260917919922d, (java.lang.Number) 100.00000000000001d, (-1221515391), orderDirection49, true);
        java.lang.Throwable[] throwableArray58 = nonMonotonousSequenceException57.getSuppressed();
        java.lang.Number number59 = nonMonotonousSequenceException57.getPrevious();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 10.0f + "'", number48.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 100.00000000000001d + "'", number59.equals(100.00000000000001d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.2748734119735194E-306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.58E-322d + "'", double1 == 1.58E-322d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int1 = org.apache.commons.math.util.FastMath.abs((-897303147));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 897303147 + "'", int1 == 897303147);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-252951790L), (double) (-830895578), 21);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1386101647L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1074790722, 1074790410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 312 + "'", int2 == 312);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double1 = org.apache.commons.math.util.FastMath.expm1(73.86141734396143d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1956552579925175E32d + "'", double1 == 1.1956552579925175E32d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9999999714987686d, (java.lang.Number) (-1192192432), (-1192192432));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.032847325E9d, 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2180227413180416E18d + "'", double2 == 2.2180227413180416E18d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 1000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.7182818247238476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3100528141747028d + "'", double1 == 1.3100528141747028d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1067417600), 1.5972596945288E167d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5972596945288E167d + "'", double2 == 1.5972596945288E167d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1905685947, 35, 488887457);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int int2 = org.apache.commons.math.util.FastMath.max(1074790399, (-1079504351));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790399 + "'", int2 == 1074790399);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(358, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.2870641716678042E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.287064172E9d + "'", double1 == 2.287064172E9d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1386122689, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1386122689L + "'", long2 == 1386122689L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray6 = new double[] { (byte) -1 };
        double[] doubleArray8 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection11, true);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.7935607365300265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7276321353997605d + "'", double1 == 0.7276321353997605d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.17453292519943295d, 3.1622776601683795d, (double) 1138480784);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(21L, (long) (-830895578));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-17448807138L) + "'", long2 == (-17448807138L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray11);
        try {
            double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 90.0f);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10 + "'", number8.equals(10));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0f + "'", number9.equals(10.0f));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        long long2 = org.apache.commons.math.util.FastMath.max(83462400L, (long) 358);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 83462400L + "'", long2 == 83462400L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1074790399, (long) 20990);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074769409L + "'", long2 == 1074769409L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-456387814));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.56387808E8f + "'", float1 == 4.56387808E8f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((-1652499824388974448L), (long) 132);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.58665617E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.090870207939166E10d + "'", double1 == 9.090870207939166E10d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 897303147);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.97303147E8d + "'", double1 == 8.97303147E8d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        double double1 = org.apache.commons.math.util.FastMath.acosh(65.10120968855118d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.869031318628972d + "'", double1 == 4.869031318628972d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 718503581, (double) 96549157373046880L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.654915737304688E16d + "'", double2 == 9.654915737304688E16d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1032847395);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 21000, 0.0d, 3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-213909503), (-0.23528072998266963d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 100, 132);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(16.984748479054833d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.98474847905483d + "'", double2 == 16.98474847905483d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1097L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-6.135448506003595d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.418109456420578d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.2246186123224d + "'", double1 == 11.2246186123224d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(476);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 21L, (double) 220496090649893265L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2049609064989328E17d + "'", double2 == 2.2049609064989328E17d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5514266812416906d + "'", double1 == 0.5514266812416906d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 5, (double) (-1074790400L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0747904016116989E9d) + "'", double2 == (-1.0747904016116989E9d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 83462400L, (float) 323);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 323.0f + "'", float2 == 323.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1386101689);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1349212274) + "'", int1 == (-1349212274));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-456387814L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        long long1 = org.apache.commons.math.util.FastMath.round(1.1786670007231652d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9999999714987686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999857493842d + "'", double1 == 0.9999999857493842d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.907755278982137d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) '#', (long) (-213909503));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7486832605L + "'", long2 == 7486832605L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1055123539));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1386122689, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1067417600), 1137893781);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) -1, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 2704L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        double double1 = org.apache.commons.math.util.FastMath.asin(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5972596945288E167d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        java.lang.Class<?> wildcardClass9 = orderDirection8.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection8, true);
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException11.getClass();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 7227194);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 184.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9765843832906294d + "'", double1 == 0.9765843832906294d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-704643071), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011872827488d + "'", double1 == 1.1752011872827488d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.52587890625E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.816479930623699d) + "'", double1 == (-4.816479930623699d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.7345175425633101d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double2 = org.apache.commons.math.util.FastMath.max(6.203097420189161d, 1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.203097420189161d + "'", double2 == 6.203097420189161d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.6881171418161737E43d, (double) (-897303147), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 924);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1347167864733188375L, 2.384185791015625E-7d, (double) 4.56387808E8f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.58E-322d, (-0.9300727311045811d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-213909503));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5515679276951895d, (double) 100.0f, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-35), (-1672638911));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        int int2 = org.apache.commons.math.util.FastMath.max(1079525376, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079525376 + "'", int2 == 1079525376);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.8516124473481776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3850743778308299d + "'", double1 == 1.3850743778308299d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1138480784, (-1067417600));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-1074790400));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0747904E9f) + "'", float2 == (-1.0747904E9f));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.2825359543734787d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9085533240245162d + "'", double1 == 0.9085533240245162d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 718503581, 320, (-1055123539));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) -1, (-242306127));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.7182818247238476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0437346730649275d + "'", double1 == 1.0437346730649275d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.5127742681331149d, 1.0613084341780446E57d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.512774268133115d + "'", double2 == 0.512774268133115d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (-704643071));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(11, (-1074790369));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790380 + "'", int2 == 1074790380);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1775275193, (-0.0037035886157206215d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7752751929999998E9d + "'", double2 == 1.7752751929999998E9d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        double double1 = org.apache.commons.math.util.FastMath.asin(5.052166389484759d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.05224159391082094d, 0, 1032847325);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1055123539), (double) (-48), 1000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0f + "'", number8.equals(10.0f));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1386101647L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1386101632) + "'", int1 == (-1386101632));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.1075066744876776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019329637957623057d + "'", double1 == 0.019329637957623057d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 21);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 100L, (-0.8334276796443637d), (double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection16, false);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray14);
        double[] doubleArray21 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection23, false);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray27);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double[] doubleArray35 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection37, false);
        double[] doubleArray41 = new double[] { (byte) -1 };
        double[] doubleArray43 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray43);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray41);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray41);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1000);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(312, (-830895578));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 830895890 + "'", int2 == 830895890);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-252951790));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray26 = new double[] { (byte) -1 };
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray28);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number39 = nonMonotonousSequenceException38.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = nonMonotonousSequenceException38.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection40, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection40, true);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray28);
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number59 = nonMonotonousSequenceException58.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = nonMonotonousSequenceException58.getDirection();
        java.lang.Class<?> wildcardClass61 = orderDirection60.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException63 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection60, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 488887457, (java.lang.Number) 3.637978807091713E-12d, (-1067417600), orderDirection60, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException67 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-790417455), number47, 31, orderDirection60, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection60, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 31 + "'", int31 == 31);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 10.0f + "'", number39.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 10.0f + "'", number59.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection60.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass61);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number10 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        java.lang.Class<?> wildcardClass12 = orderDirection11.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.890349128221754d, (java.lang.Number) 0.17453292519943295d, (int) '4', orderDirection11, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1001L), (java.lang.Number) 2.21802260173160448E18d, 1079525376, orderDirection11, false);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0f + "'", number10.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 3628800L, 42);
        int int7 = nonMonotonousSequenceException6.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.52951792E8f, (java.lang.Number) 156.3608363030788d, 1137893781, orderDirection9, false);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 42 + "'", int7 == 42);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 156.3608363030788d + "'", number12.equals(156.3608363030788d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9085533240245162d, (double) 1064753020);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-1.6543768726206873d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(10, 1000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 10, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        long long2 = org.apache.commons.math.util.FastMath.max(20L, 1074790399L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790399L + "'", long2 == 1074790399L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1386101632), (-456387814));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 358);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5010478116816466E155d + "'", double1 == 1.5010478116816466E155d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.7752751929999998E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.775275192E9d + "'", double1 == 1.775275192E9d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double1 = org.apache.commons.math.util.FastMath.asinh(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.466711037884725d + "'", double1 == 3.466711037884725d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1672638911), 1137893781);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(13566, 184);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.7658461948190802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9616411655135638d + "'", double1 == 0.9616411655135638d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(32L, (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-132));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-58), 10000);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '#', (float) 7486832605L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.4868326E9f + "'", float2 == 7.4868326E9f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1563677856);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-456387814L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        try {
            double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 1.7182818247238476d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1905685947, (long) (-1067417600));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray5 = new double[] { (byte) -1 };
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray11);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray11);
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        double[] doubleArray33 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray33);
        double[] doubleArray39 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection41, false);
        double[] doubleArray45 = new double[] { (byte) -1 };
        double[] doubleArray47 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray47);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray45);
        double[] doubleArray54 = new double[] { (byte) -1 };
        double[] doubleArray56 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection59, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        double[] doubleArray64 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray54);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray54);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 3628800L, 42);
        int int77 = nonMonotonousSequenceException76.getIndex();
        java.lang.Throwable[] throwableArray78 = nonMonotonousSequenceException76.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = nonMonotonousSequenceException76.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.52951792E8f, (java.lang.Number) 156.3608363030788d, 1137893781, orderDirection79, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection79, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 42 + "'", int77 == 42);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException3.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1079525341);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        float float2 = org.apache.commons.math.util.FastMath.max(2704.0f, (float) 16L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16.0f + "'", float2 == 16.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1024.0d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5677081748343342d + "'", double2 == 1.5677081748343342d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5349248203221212E69d, 1.582002422E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.534924820322121E69d + "'", double2 == 1.534924820322121E69d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.23851102429896254d), (java.lang.Number) 4.1268741377911216d, 13566);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 33000.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33000.0d + "'", double1 == 33000.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray11 = new int[] { ' ', (byte) 10 };
        int[] intArray16 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray16);
        int[] intArray24 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray24);
        int[] intArray27 = null;
        try {
            int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 68.8839603971781d + "'", double17 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double double1 = org.apache.commons.math.util.FastMath.log(6.907755278982137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9326447339160655d + "'", double1 == 1.9326447339160655d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, false);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray8);
        java.lang.Class<?> wildcardClass14 = doubleArray2.getClass();
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray19);
        double[] doubleArray23 = new double[] { (byte) -1 };
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray19);
        double[] doubleArray32 = new double[] { (byte) -1 };
        double[] doubleArray34 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray34);
        double[] doubleArray38 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray38);
        double[] doubleArray42 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        java.lang.Class<?> wildcardClass44 = doubleArray42.getClass();
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray42);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number51 = nonMonotonousSequenceException50.getArgument();
        java.lang.Number number52 = nonMonotonousSequenceException50.getPrevious();
        java.lang.Throwable[] throwableArray53 = nonMonotonousSequenceException50.getSuppressed();
        java.lang.String str54 = nonMonotonousSequenceException50.toString();
        boolean boolean55 = nonMonotonousSequenceException50.getStrict();
        boolean boolean56 = nonMonotonousSequenceException50.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = nonMonotonousSequenceException50.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection57, true);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 10 + "'", number51.equals(10));
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 10.0f + "'", number52.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str54.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number10 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 156.36083630307883d, 0, orderDirection11, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11.7910068511973d, number1, (int) (short) 1, orderDirection11, true);
        java.lang.Class<?> wildcardClass16 = nonMonotonousSequenceException15.getClass();
        java.lang.Number number17 = nonMonotonousSequenceException15.getArgument();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0f + "'", number10.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 11.7910068511973d + "'", number17.equals(11.7910068511973d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double1 = org.apache.commons.math.util.MathUtils.sign(534.4916555247646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-1349212274));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.5274985276365916d), 1.1078671099555852E12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5274985276365913d) + "'", double2 == (-1.5274985276365913d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.9997860728793259d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.449875158542808d) + "'", double1 == (-8.449875158542808d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1386122689L, 2146435072, 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable throwable8 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 7227194);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.9326447339160655d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1000, (-252951790));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        int int1 = org.apache.commons.math.util.FastMath.abs(1775275193);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1775275193 + "'", int1 == 1775275193);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.36787944117144233d, (double) 20990L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.21382567815214598d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-12.25130890964066d) + "'", double1 == (-12.25130890964066d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        long long1 = org.apache.commons.math.util.FastMath.round(7.600902709541988d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, false);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray8);
        java.lang.Class<?> wildcardClass14 = doubleArray2.getClass();
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray19);
        double[] doubleArray23 = new double[] { (byte) -1 };
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray19);
        double[] doubleArray32 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection34, false);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray45 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45, orderDirection47, false);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray45);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray45);
        double[] doubleArray53 = new double[] { (byte) -1 };
        double[] doubleArray55 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double[] doubleArray60 = new double[] { (byte) -1 };
        double[] doubleArray62 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray62);
        double[] doubleArray66 = new double[] { (byte) -1 };
        double[] doubleArray68 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray68);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray66);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray62);
        double[] doubleArray74 = new double[] { (byte) -1 };
        double[] doubleArray76 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray76);
        double[] doubleArray80 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray80);
        double[] doubleArray84 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray84);
        java.lang.Class<?> wildcardClass86 = doubleArray84.getClass();
        double double87 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray76, doubleArray84);
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray76);
        double double90 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray76);
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0d + "'", double71 == 1.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1586656170, (long) 1074790399);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790399L + "'", long2 == 1074790399L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        int int2 = org.apache.commons.math.util.MathUtils.pow(320, 2146435072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.234021194410018d + "'", double1 == 2.234021194410018d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7853981631185015d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7071067813837927d + "'", double1 == 0.7071067813837927d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray7);
        double[] doubleArray13 = null;
        try {
            double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.1956552579925175E32d, (double) (-805.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 323.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 323.0d + "'", double1 == 323.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-790417455));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 385L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1079504351));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1079504351L + "'", long1 == 1079504351L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double1 = org.apache.commons.math.util.FastMath.acosh(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.019830962520319934d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        double[] doubleArray10 = null;
        double[] doubleArray12 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection14, false);
        double[] doubleArray18 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection20, false);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray18);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray18);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray18);
        try {
            double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 8376.897143089807d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 31 + "'", int26 == 31);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        float float1 = org.apache.commons.math.util.FastMath.abs(7.4868326E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.4868326E9f + "'", float1 == 7.4868326E9f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-9.297528369843588d), 7.72769467795052E24d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.297528369843587d) + "'", double2 == (-9.297528369843587d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.026931837701290245d, (java.lang.Number) (-1L), (int) '4');
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1074790399, (long) 1032847395);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 41943004L + "'", long2 == 41943004L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.1078671099555852E12d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 718546557 + "'", int1 == 718546557);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 22L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999608263946371d) + "'", double1 == (-0.9999608263946371d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 6993833231716193505L, (float) 1074790380);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0747904E9f + "'", float2 == 1.0747904E9f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1 };
        double[] doubleArray14 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection17, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 9.6549155E16f, 0.0d, 3.637978807091713E-12d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.853988047997524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.074790368999999E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4562840656627033d + "'", double1 == 0.4562840656627033d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1024.0d, 0.0d, (double) (-1221515391));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass11 = doubleArray3.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = new double[] { (byte) -1 };
        double[] doubleArray10 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray10);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection18, false);
        double[] doubleArray22 = new double[] { (byte) -1 };
        double[] doubleArray24 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray24);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray22);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray22);
        double[] doubleArray30 = null;
        double[] doubleArray32 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection34, false);
        double[] doubleArray38 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray38);
        java.lang.Class<?> wildcardClass44 = doubleArray32.getClass();
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray32);
        double[] doubleArray47 = new double[] { (byte) -1 };
        double[] doubleArray49 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray49);
        double[] doubleArray53 = new double[] { (byte) -1 };
        double[] doubleArray55 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray53);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray49);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray32);
        double[] doubleArray63 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray63);
        try {
            double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(312);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1483.6077018175952d + "'", double1 == 1483.6077018175952d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double2 = org.apache.commons.math.util.FastMath.max(0.05224159391082094d, (double) 8023796054858137600L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0237960548581376E18d + "'", double2 == 8.0237960548581376E18d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.7182818247238476d, (double) (-1074790369L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.14159265199108d + "'", double2 == 3.14159265199108d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1074790410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double1 = org.apache.commons.math.util.FastMath.ceil(6.203097420189161d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        long long2 = org.apache.commons.math.util.MathUtils.pow(11L, 1074790410);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7518480283977535271L) + "'", long2 == (-7518480283977535271L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 74, (-1192192432));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.2999448210687674E42d, (-5.424641371532627E-7d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.2121999967334905d), (double) 7.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.937392482107302E-5d) + "'", double2 == (-1.937392482107302E-5d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-830895578), (-1079504351));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int int2 = org.apache.commons.math.util.MathUtils.pow(41, 23L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-118448423) + "'", int2 == (-118448423));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.552713678800501E-15d, (-1925533311));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7996809277222553E101d + "'", double2 == 2.7996809277222553E101d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 322);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1074790337L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 83462400L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        float float2 = org.apache.commons.math.util.FastMath.max((-1.0f), (float) 924);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 924.0f + "'", float2 == 924.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, false);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray8);
        java.lang.Class<?> wildcardClass14 = doubleArray2.getClass();
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        java.lang.Class<?> wildcardClass20 = doubleArray17.getClass();
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-6264507081672359936L), (double) 1079525376);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.079525376E9d + "'", double2 == 1.079525376E9d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1079525376);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.0482269650408105d, 22.0d, 21000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.17175799968977123d), (double) 42);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 42.0d + "'", double2 == 42.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 718546557);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.39274105887887d + "'", double1 == 20.39274105887887d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 8023796055476540155L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1137893781 + "'", int1 == 1137893781);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double[] doubleArray21 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray21);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray17);
        double[] doubleArray27 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 31 + "'", int24 == 31);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number26 = nonMonotonousSequenceException25.getArgument();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        java.lang.Number number28 = nonMonotonousSequenceException25.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException25.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection29, false);
        double[] doubleArray33 = new double[] { (byte) -1 };
        double[] doubleArray35 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray35);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray33);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 3628800L, 42);
        int int44 = nonMonotonousSequenceException43.getIndex();
        java.lang.Throwable[] throwableArray45 = nonMonotonousSequenceException43.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = nonMonotonousSequenceException43.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection46, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10 + "'", number26.equals(10));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10.0f + "'", number27.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10.0f + "'", number28.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 42 + "'", int44 == 42);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection46.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        double double1 = org.apache.commons.math.util.FastMath.ceil(21.000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.0d + "'", double1 == 22.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(515.8908245878225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.713230166311057d + "'", double1 == 22.713230166311057d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection11, false);
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        double[] doubleArray22 = new double[] { (byte) -1 };
        double[] doubleArray24 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray24);
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray28);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray28);
        double[] doubleArray34 = new double[] { (byte) -1 };
        double[] doubleArray36 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray36);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number47 = nonMonotonousSequenceException46.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = nonMonotonousSequenceException46.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection48, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection48, true);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray36);
        double[] doubleArray55 = new double[] { (byte) -1 };
        double[] doubleArray57 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray57);
        double[] doubleArray61 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray61);
        double[] doubleArray65 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65);
        java.lang.Class<?> wildcardClass67 = doubleArray65.getClass();
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray57, doubleArray65);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number74 = nonMonotonousSequenceException73.getArgument();
        java.lang.Number number75 = nonMonotonousSequenceException73.getPrevious();
        java.lang.Throwable[] throwableArray76 = nonMonotonousSequenceException73.getSuppressed();
        java.lang.String str77 = nonMonotonousSequenceException73.toString();
        boolean boolean78 = nonMonotonousSequenceException73.getStrict();
        boolean boolean79 = nonMonotonousSequenceException73.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = nonMonotonousSequenceException73.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection80, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection80, false);
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 10.0f + "'", number47.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + 10 + "'", number74.equals(10));
        org.junit.Assert.assertTrue("'" + number75 + "' != '" + 10.0f + "'", number75.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str77.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.386101689E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1138480784, (-41));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.7658461948190802d, 6.907755278982137d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1097L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 167, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 166L + "'", long2 == 166L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1024L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1024L + "'", long1 == 1024L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4391749470972324d + "'", double1 == 0.4391749470972324d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection16, false);
        double[] doubleArray20 = new double[] { (byte) -1 };
        double[] doubleArray22 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray22);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double[] doubleArray34 = new double[] { (byte) -1 };
        double[] doubleArray36 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray34);
        double[] doubleArray42 = null;
        double[] doubleArray44 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection46, false);
        double[] doubleArray50 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection52, false);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray50);
        java.lang.Class<?> wildcardClass56 = doubleArray44.getClass();
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray44);
        double[] doubleArray59 = new double[] { (byte) -1 };
        double[] doubleArray61 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray61);
        double[] doubleArray65 = new double[] { (byte) -1 };
        double[] doubleArray67 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray61, doubleArray65);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray61);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray44);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray44);
        double[] doubleArray76 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        double[] doubleArray80 = new double[] { (byte) -1 };
        double[] doubleArray82 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray82);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray80, doubleArray82);
        double[] doubleArray86 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray82, doubleArray86);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray86);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        int int1 = org.apache.commons.math.util.FastMath.abs((-456387814));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 456387814 + "'", int1 == 456387814);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(322, 488887457);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0979311860144625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1192192432));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 320, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-5479429532463080511L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.4794295324630804E18d) + "'", double1 == (-5.4794295324630804E18d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double double2 = org.apache.commons.math.util.FastMath.atan2(21.000000000000004d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1263771168937977d + "'", double2 == 1.1263771168937977d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.232423355522014d, 1.386101689E9d, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-456387814), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2006768640) + "'", int2 == (-2006768640));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-805L), (-704643071));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 1079525376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079525376 + "'", int2 == 1079525376);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray15 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray15);
        int[] intArray23 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray23);
        int[] intArray27 = new int[] { ' ', (byte) 10 };
        int[] intArray32 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray32);
        int[] intArray40 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray40);
        int[] intArray48 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray48);
        int[] intArray54 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray61 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray54, intArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray61);
        int[] intArray66 = new int[] { ' ', (byte) 10 };
        int[] intArray71 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray71);
        java.lang.Class<?> wildcardClass73 = intArray66.getClass();
        int[] intArray76 = new int[] { ' ', (byte) 10 };
        int[] intArray81 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray81);
        java.lang.Class<?> wildcardClass83 = intArray76.getClass();
        int[] intArray87 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray94 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int95 = org.apache.commons.math.util.MathUtils.distanceInf(intArray87, intArray94);
        int int96 = org.apache.commons.math.util.MathUtils.distanceInf(intArray76, intArray87);
        int int97 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray76);
        try {
            int int98 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray76);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 323 + "'", int24 == 323);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 68.8839603971781d + "'", double33 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 100 + "'", int41 == 100);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 323 + "'", int49 == 323);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1074790722 + "'", int62 == 1074790722);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.8475328855259755E9d + "'", double63 == 1.8475328855259755E9d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 68.8839603971781d + "'", double72 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 68.8839603971781d + "'", double82 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1074790722 + "'", int95 == 1074790722);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1074790410 + "'", int96 == 1074790410);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double[] doubleArray21 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray21);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray17);
        double[] doubleArray27 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection29, false);
        double[] doubleArray33 = new double[] { (byte) -1 };
        double[] doubleArray35 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray35);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray33);
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection42, false);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray40);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 31 + "'", int24 == 31);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double2 = org.apache.commons.math.util.FastMath.atan2(156.36083630307883d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5069286754431488d + "'", double2 == 1.5069286754431488d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        int[] intArray6 = new int[] { 13566, 1067417600, (-35), 1074790399, 618402555, (byte) 10 };
        int[] intArray9 = new int[] { ' ', (byte) 10 };
        int[] intArray14 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray14);
        int[] intArray16 = new int[] {};
        int[] intArray19 = new int[] { ' ', (byte) 10 };
        int[] intArray24 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray24);
        int[] intArray28 = new int[] { ' ', (byte) 10 };
        int[] intArray33 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray33);
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray28);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray19);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray19);
        try {
            int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 68.8839603971781d + "'", double15 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 68.8839603971781d + "'", double25 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 68.8839603971781d + "'", double34 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5776108220048384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5776108220048386d + "'", double1 == 1.5776108220048386d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 31L + "'", long1 == 31L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        long long1 = org.apache.commons.math.util.FastMath.round(184.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 184L + "'", long1 == 184L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        long long2 = org.apache.commons.math.util.FastMath.min((-7518480283977535271L), 1079525376L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7518480283977535271L) + "'", long2 == (-7518480283977535271L));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray12 = new int[] { ' ', (byte) 10 };
        int[] intArray17 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray17);
        int[] intArray21 = new int[] { ' ', (byte) 10 };
        int[] intArray26 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray21);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray21);
        int[] intArray32 = new int[] { ' ', (byte) 10 };
        int[] intArray37 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray37);
        int[] intArray45 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray32);
        try {
            int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 68.8839603971781d + "'", double18 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 68.8839603971781d + "'", double27 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 68.8839603971781d + "'", double38 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(8376.897143089807d, 866451.2375383462d, 1.0437346730649275d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double[] doubleArray13 = new double[] { (byte) -1 };
        double[] doubleArray15 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray15);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray13);
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double[] doubleArray26 = new double[] { (byte) -1 };
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray26);
        double[] doubleArray33 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray7);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1074790369) + "'", int42 == (-1074790369));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33000.0d, (java.lang.Number) 160.0d, 1032847325);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1032847325 + "'", int4 == 1032847325);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double2 = org.apache.commons.math.util.FastMath.min(2.234021194410018d, (double) 1032847395);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.234021194410018d + "'", double2 == 2.234021194410018d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number26 = nonMonotonousSequenceException25.getArgument();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        java.lang.Number number28 = nonMonotonousSequenceException25.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException25.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection29, false);
        double[] doubleArray33 = new double[] { (byte) -1 };
        double[] doubleArray35 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray35);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10 + "'", number26.equals(10));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10.0f + "'", number27.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10.0f + "'", number28.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.1263771168937977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.704333640160956d + "'", double1 == 1.704333640160956d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 220496090649893265L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.20496096E17f + "'", float1 == 2.20496096E17f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1055123539), 488887457);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.2870641716678042E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.24368199147464d + "'", double1 == 22.24368199147464d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(42, (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.775275192E9d, (double) 50590358L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 7.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1096.6331584284585d + "'", double1 == 1096.6331584284585d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1074790400L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-6993833231716193506L), 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray8 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, false);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double[] doubleArray21 = new double[] { (byte) -1 };
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray23);
        double[] doubleArray27 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray27);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray27);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 31 + "'", int32 == 31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(33000.0d, 10000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.8677338100080094E-68d) + "'", double2 == (-1.8677338100080094E-68d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.853988047997524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 48.9299109048737d + "'", double1 == 48.9299109048737d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1563677856);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 184);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 1079525376);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-1.6543768726206873d), (-1672638911));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.552252975304735E-135d) + "'", double2 == (-4.552252975304735E-135d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException11.getPrevious();
        java.lang.String str14 = nonMonotonousSequenceException11.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str24 = nonMonotonousSequenceException11.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException11.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10 + "'", number20.equals(10));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.7846220049470427d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03114752988986843d + "'", double1 == 0.03114752988986843d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        double double1 = org.apache.commons.math.util.FastMath.expm1(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.019830962520319934d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019828363307654893d + "'", double1 == 0.019828363307654893d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        int int2 = org.apache.commons.math.util.FastMath.min(323, 20990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 323 + "'", int2 == 323);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.806217383937352E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.80621738397436E-6d + "'", double1 == 4.80621738397436E-6d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1507257537, (double) 83824.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.8795122390062857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9581068881068266d + "'", double1 == 0.9581068881068266d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        int int1 = org.apache.commons.math.util.FastMath.abs(1067417500);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1067417500 + "'", int1 == 1067417500);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 1, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1775275193);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1775275193L + "'", long1 == 1775275193L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1074790722);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        long long2 = org.apache.commons.math.util.FastMath.min(1074769409L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1925533311), (long) 1563677856);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 663106714341011457L + "'", long2 == 663106714341011457L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 1386101689);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1386101689L + "'", long2 == 1386101689L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(476, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 97, (-1386101647L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1386101744L + "'", long2 == 1386101744L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray14 = null;
        try {
            double double15 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 4.806217383937352E-6d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 4.806217383937352E-6d + "'", number6.equals(4.806217383937352E-6d));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 4.806217383937352E-6d + "'", number9.equals(4.806217383937352E-6d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1349212274), (-5479429532463080511L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(5, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 52L, (float) 1326442914);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.32644288E9f + "'", float2 == 1.32644288E9f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 488887457);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.log(0.04742161873168638d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0486770628733795d) + "'", double1 == (-3.0486770628733795d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-790417455), 74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-790417529) + "'", int2 == (-790417529));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1074790399, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5024878349045192d, (java.lang.Number) 10L, 322);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1074790369L), number1, 1079525376);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,079,525,375 and 1,079,525,376 are not strictly increasing (null >= -1,074,790,369)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,079,525,375 and 1,079,525,376 are not strictly increasing (null >= -1,074,790,369)"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        long long2 = org.apache.commons.math.util.MathUtils.pow(935L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3708780787583609177L) + "'", long2 == (-3708780787583609177L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1386101689L, 2146435072);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.386101689E9d + "'", double2 == 1.386101689E9d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 0, (int) ' ', orderDirection12, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        int int16 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10 + "'", number7.equals(10));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        long long1 = org.apache.commons.math.util.MathUtils.sign(96549157373046875L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 4.56387808E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5638780800000006E8d + "'", double1 == 4.5638780800000006E8d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-897303147), (long) 476);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-897302671L) + "'", long2 == (-897302671L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 2L, 0, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-790417529), 1137893781);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException6.getPrevious();
        java.lang.String str9 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.737102242198924d, (java.lang.Number) 1.5349248203221212E69d, (-897303147), orderDirection10, false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10 + "'", number7.equals(10));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0f + "'", number8.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1079504351));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963258685456d) + "'", double1 == (-1.5707963258685456d));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.1516670284837467d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1516670284837465d) + "'", double1 == (-1.1516670284837465d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.806217383937352E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000048062289337d + "'", double1 == 1.0000048062289337d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1000, 1386102689L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10000.0d + "'", double1 == 10000.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1074790399L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0747903990000002E9d + "'", double1 == 1.0747903990000002E9d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-252951790L), 0.9602802547032059d, (-0.41305910221224357d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1067417600);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.019828363307654893d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-799641669) + "'", int1 == (-799641669));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(8376.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 146.18877814704504d + "'", double1 == 146.18877814704504d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1386101647), 74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76531041 + "'", int2 == 76531041);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-52L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-53.0d) + "'", double1 == (-53.0d));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1067418535L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1074790369), 320);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 16L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(456387814, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 456387762 + "'", int2 == 456387762);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1386101689);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2704, 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2704.0f + "'", float2 == 2704.0f);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        double double1 = org.apache.commons.math.util.FastMath.signum(11013.232920103304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1074790722);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.488538982924613d + "'", double1 == 21.488538982924613d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(52, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.05221786022585878d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3737716494901388d + "'", double1 == 0.3737716494901388d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(20990L, 47510973960L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 997255343420400L + "'", long2 == 997255343420400L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double double2 = org.apache.commons.math.util.FastMath.max(1.7846220049470427d, (double) 16.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray15 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray15);
        int[] intArray17 = null;
        try {
            int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 488887457);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22110.79955587314d + "'", double1 == 22110.79955587314d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1079525376L, (int) '#', 323);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.9085533240245162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 456387762, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.806217383937352E-6d, 8.97303147E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.6065306597126334d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34.751646946819406d + "'", double1 == 34.751646946819406d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        int int2 = org.apache.commons.math.util.FastMath.max((-1221515391), 1067417500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1067417500 + "'", int2 == 1067417500);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 897303147);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        double double1 = org.apache.commons.math.util.FastMath.exp((-8.353694411064845E-19d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        int int1 = org.apache.commons.math.util.FastMath.abs((-704643071));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 704643071 + "'", int1 == 704643071);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        double double2 = org.apache.commons.math.util.FastMath.min(160.0d, 1.4301250134917418E26d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 160.0d + "'", double2 == 160.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.4391749470972324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (0 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (0 >= 10)"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-4.816479930623699d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 0, 41943004L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(32L, 132L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1056L + "'", long2 == 1056L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-1349212274), 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.349212274E9d) + "'", double2 == (-1.349212274E9d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.4125699280672959d), 323);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.049952142100532E96d) + "'", double2 == (-7.049952142100532E96d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.375426387680723d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        float float1 = org.apache.commons.math.util.MathUtils.sign(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1032847325, (-790417529));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1507257537, (double) (-6264507081672359935L), (double) 8023796055476540155L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0613084341780446E57d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.257772911327683E28d + "'", double1 == 3.257772911327683E28d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = new double[] { (byte) -1 };
        double[] doubleArray10 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray10);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double[] doubleArray21 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray21);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number40 = nonMonotonousSequenceException39.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException39.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection41, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection41, true);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray29);
        double[] doubleArray48 = new double[] { (byte) -1 };
        double[] doubleArray50 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray50);
        double[] doubleArray54 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray54);
        double[] doubleArray58 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        java.lang.Class<?> wildcardClass60 = doubleArray58.getClass();
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray58);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number67 = nonMonotonousSequenceException66.getArgument();
        java.lang.Number number68 = nonMonotonousSequenceException66.getPrevious();
        java.lang.Throwable[] throwableArray69 = nonMonotonousSequenceException66.getSuppressed();
        java.lang.String str70 = nonMonotonousSequenceException66.toString();
        boolean boolean71 = nonMonotonousSequenceException66.getStrict();
        boolean boolean72 = nonMonotonousSequenceException66.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection73 = nonMonotonousSequenceException66.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58, orderDirection73, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection73, false);
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 31 + "'", int32 == 31);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 10.0f + "'", number40.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 10 + "'", number67.equals(10));
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 10.0f + "'", number68.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str70.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection73.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { ' ', (byte) 10 };
        int[] intArray8 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray8);
        int[] intArray12 = new int[] { ' ', (byte) 10 };
        int[] intArray17 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray12);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 68.8839603971781d + "'", double9 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 68.8839603971781d + "'", double18 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9602802547032059d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8530067752659565d + "'", double1 == 0.8530067752659565d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5127742681331149d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0d + "'", number6.equals(10.0d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 320, (java.lang.Number) 68.00000000000001d, 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8344632077604134d + "'", double1 == 0.8344632077604134d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.534924820322121E69d, 1.5707963143112151d, (double) 22L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1074790380);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 33000.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1452L), 0.7208307687693356d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray34 = new double[] { (byte) -1 };
        double[] doubleArray36 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray36);
        double[] doubleArray40 = new double[] { (byte) -1 };
        double[] doubleArray42 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray40);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray36);
        double[] doubleArray48 = new double[] { (byte) -1 };
        double[] doubleArray50 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray50);
        double[] doubleArray54 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray54);
        double[] doubleArray58 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        java.lang.Class<?> wildcardClass60 = doubleArray58.getClass();
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray58);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray50);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray29);
        double[] doubleArray66 = new double[] { (byte) -1 };
        double[] doubleArray68 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray68);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66, orderDirection71, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66);
        double[] doubleArray76 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray76);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.5274985276365913d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 488887457L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 1079525376);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(31, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.012097700501686678d, 9.090870207939166E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3307527469836286E-13d + "'", double2 == 1.3307527469836286E-13d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1032847360L, 1386101744L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-2006768640), (float) (-830895578));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.00676864E9f) + "'", float2 == (-2.00676864E9f));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1386101632), (-242306127));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray5 = new double[] { (byte) -1 };
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray11);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray11);
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        double[] doubleArray33 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray33);
        double[] doubleArray39 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection41, false);
        double[] doubleArray45 = new double[] { (byte) -1 };
        double[] doubleArray47 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray47);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray45);
        double[] doubleArray54 = new double[] { (byte) -1 };
        double[] doubleArray56 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection59, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        double[] doubleArray64 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray54);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray54);
        java.lang.Class<?> wildcardClass70 = doubleArray54.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass70);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1905685947);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1905685888 + "'", int1 == 1905685888);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection8, true);
        java.lang.Class<?> wildcardClass11 = orderDirection8.getClass();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 323, 96549157373046880L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 323L + "'", long2 == 323L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        long long1 = org.apache.commons.math.util.FastMath.abs(997255343420400L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 997255343420400L + "'", long1 == 997255343420400L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 16L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.464757906675863d + "'", double1 == 3.464757906675863d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1672638911), (-1064753152));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1586656170, (-42));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1563677856);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 45L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 184L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.Number number3 = null;
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection18, false);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray16);
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = new double[] { (byte) -1 };
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray31);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray29);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection39, false);
        double[] doubleArray43 = new double[] { (byte) -1 };
        double[] doubleArray45 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray45);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray43);
        double[] doubleArray51 = null;
        double[] doubleArray53 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection55, false);
        double[] doubleArray59 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59, orderDirection61, false);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray59);
        java.lang.Class<?> wildcardClass65 = doubleArray53.getClass();
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray53);
        double[] doubleArray68 = new double[] { (byte) -1 };
        double[] doubleArray70 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray70);
        double[] doubleArray74 = new double[] { (byte) -1 };
        double[] doubleArray76 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray76);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray70, doubleArray74);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray70);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray53);
        double double83 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray53);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray53);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        boolean boolean89 = nonMonotonousSequenceException88.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection90 = nonMonotonousSequenceException88.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection90, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException94 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 1.5349248203221212E69d, 1074790369, orderDirection90, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException96 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2704L, (java.lang.Number) (-0.17175799968977123d), (-252951790), orderDirection90, true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + orderDirection90 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection90.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(76531041, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1507257537);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1507257537L + "'", long1 == 1507257537L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 718546557);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.737102242198924d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        int int1 = org.apache.commons.math.util.MathUtils.sign(184);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.8677338100080094E-68d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5776108220048384d, 0.0d, (-4.816479930623699d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.012097700501686678d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999268237137646d + "'", double1 == 0.9999268237137646d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 167, (long) 1586656170);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1586656337L + "'", long2 == 1586656337L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection27, false);
        double[] doubleArray31 = new double[] { (byte) -1 };
        double[] doubleArray33 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray33);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray31);
        double[] doubleArray39 = null;
        double[] doubleArray41 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection43, false);
        double[] doubleArray47 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection49, false);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray47);
        java.lang.Class<?> wildcardClass53 = doubleArray41.getClass();
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray41);
        double[] doubleArray56 = new double[] { (byte) -1 };
        double[] doubleArray58 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray58);
        double[] doubleArray62 = new double[] { (byte) -1 };
        double[] doubleArray64 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray64);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray62);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray58);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray41);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray41);
        double[] doubleArray73 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double[] doubleArray76 = null;
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray73, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1096.6331584284585d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(33000.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1890760.7239317165d + "'", double1 == 1890760.7239317165d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        java.lang.Class<?> wildcardClass15 = orderDirection14.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 488887457, (java.lang.Number) 3.637978807091713E-12d, (-1067417600), orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-790417455), number1, 31, orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException21.getDirection();
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-42), 57.29577951308232d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.6126156408942305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-23.898454622449663d) + "'", double1 == (-23.898454622449663d));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1000L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1083129856 + "'", int1 == 1083129856);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException11.getPrevious();
        java.lang.String str14 = nonMonotonousSequenceException11.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number24 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10 + "'", number20.equals(10));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 10.0f + "'", number24.equals(10.0f));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.9048849665246426E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6643764855286345E15d + "'", double1 == 1.6643764855286345E15d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(21000, 1563677856);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 1032847260L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1032847260L + "'", long2 == 1032847260L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1032847360L, (-1221515391));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        double double1 = org.apache.commons.math.util.FastMath.log(5.214935757608986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6515267696058114d + "'", double1 == 1.6515267696058114d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 1386101689);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { ' ', (byte) 10 };
        int[] intArray8 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray8);
        int[] intArray12 = new int[] { ' ', (byte) 10 };
        int[] intArray17 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray17);
        int[] intArray25 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray25);
        try {
            int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 68.8839603971781d + "'", double9 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 68.8839603971781d + "'", double18 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) '#', 385L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-252951790L), 312);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.1105536880976113E102d) + "'", double2 == (-2.1105536880976113E102d));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        int int2 = org.apache.commons.math.util.FastMath.min(2146435072, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.52587890625E-5d, (-12.25130890964066d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.019021828530846E59d + "'", double2 == 1.019021828530846E59d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray12 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection14, false);
        double[] doubleArray18 = new double[] { (byte) -1 };
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray20);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        double[] doubleArray26 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection28, false);
        double[] doubleArray32 = new double[] { (byte) -1 };
        double[] doubleArray34 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray34);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray32);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray43 = new double[] { (byte) -1 };
        double[] doubleArray45 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray45);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number56 = nonMonotonousSequenceException55.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = nonMonotonousSequenceException55.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException59 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection57, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45, orderDirection57, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection57, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7876260917919922d, (java.lang.Number) 100.00000000000001d, (-1221515391), orderDirection57, true);
        java.lang.Throwable[] throwableArray66 = nonMonotonousSequenceException65.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException70 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number71 = nonMonotonousSequenceException70.getArgument();
        java.lang.Number number72 = nonMonotonousSequenceException70.getPrevious();
        java.lang.String str73 = nonMonotonousSequenceException70.toString();
        java.lang.Number number74 = nonMonotonousSequenceException70.getArgument();
        nonMonotonousSequenceException65.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException70);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = nonMonotonousSequenceException70.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection76, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 31 + "'", int48 == 31);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 10.0f + "'", number56.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertTrue("'" + number71 + "' != '" + 10 + "'", number71.equals(10));
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 10.0f + "'", number72.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str73.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + 10 + "'", number74.equals(10));
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 4074);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 71.10471372624899d + "'", double1 == 71.10471372624899d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5024878349045192d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17681096436514165d + "'", double1 == 0.17681096436514165d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 322, (-6264507081672359936L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.20496096E17f, (java.lang.Number) 41, 1074790399);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 166L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-39088492512L), (long) 1825403137);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        double double1 = org.apache.commons.math.util.FastMath.floor((-58.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-59.0d) + "'", double1 == (-59.0d));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1079504351), 358);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(37.14833901501544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2128.4430414815583d + "'", double1 == 2128.4430414815583d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97, (float) 1000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1000.0f + "'", float2 == 1000.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 663106714341011457L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.1075066744876776d, 1024.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 67.88156874510734d + "'", double2 == 67.88156874510734d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 132.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.489125293076057d + "'", double1 == 11.489125293076057d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1563677856, 6.123233995736766E-17d, (double) (-58));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray15 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection17, false);
        double[] doubleArray21 = new double[] { (byte) -1 };
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false);
        double[] doubleArray37 = new double[] { (byte) -1 };
        double[] doubleArray39 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray37);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        double[] doubleArray45 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45, orderDirection47, false);
        double[] doubleArray51 = new double[] { (byte) -1 };
        double[] doubleArray53 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray53);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray51);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray51);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException70 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number71 = nonMonotonousSequenceException70.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = nonMonotonousSequenceException70.getDirection();
        java.lang.Class<?> wildcardClass73 = orderDirection72.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException75 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection72, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException77 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 488887457, (java.lang.Number) 3.637978807091713E-12d, (-1067417600), orderDirection72, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection72, false);
        double[] doubleArray80 = null;
        try {
            double double81 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + number71 + "' != '" + 10.0f + "'", number71.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1032847395, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (-3708780787583609177L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3708780787583609177L) + "'", long2 == (-3708780787583609177L));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1032847395, (long) 312);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 22L, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-897303147), (-252951790));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        double double2 = org.apache.commons.math.util.FastMath.max(0.4476577640910703d, (double) (-6993833231716193506L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4476577640910703d + "'", double2 == 0.4476577640910703d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 830895890);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1067417500, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 635.4616044236789d + "'", double2 == 635.4616044236789d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 42);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7330382858376184d + "'", double1 == 0.7330382858376184d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(704643071, 1079525341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int1 = org.apache.commons.math.util.FastMath.abs(1386122689);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1386122689 + "'", int1 == 1386122689);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1032847325);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-6264507081672359935L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1386122689);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.04977625399846d + "'", double1 == 21.04977625399846d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-6993833231716193506L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1386101744L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1386101744L + "'", long1 == 1386101744L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        long long2 = org.apache.commons.math.util.FastMath.max(1586656337L, (long) (-213909503));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1586656337L + "'", long2 == 1586656337L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        int int2 = org.apache.commons.math.util.FastMath.max(10000, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.0017829817524246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5635323758074704d + "'", double1 == 1.5635323758074704d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5776108220048386d, (double) 41, 0.7350525871447157d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.2261911708835171d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.408223442335828d + "'", double1 == 3.408223442335828d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(16.98474847905483d, 11.7910068511973d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1192192432));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-35), 476);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1138480784, 62134631755L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 184);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.908090322302644d + "'", double1 == 5.908090322302644d);
    }
}

