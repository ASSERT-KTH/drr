import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1192192432), (-0.4125699280672959d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963271409564d) + "'", double2 == (-1.5707963271409564d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1079525376, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079525376L + "'", long2 == 1079525376L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double1 = org.apache.commons.math.util.FastMath.asin(21.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 21000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.023904801749939406d) + "'", double1 == (-0.023904801749939406d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(320.0f, 100, (-213909503));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-7227194), (-7L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50590358L + "'", long2 == 50590358L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(13566, (-42));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        long long2 = org.apache.commons.math.util.MathUtils.pow(488887457L, (long) 618402555);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6993833231716193505L + "'", long2 == 6993833231716193505L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 10, 96549157373046880L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96549157373046890L + "'", long2 == 96549157373046890L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int2 = org.apache.commons.math.util.FastMath.min(1032847360, 1586656170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1032847360 + "'", int2 == 1032847360);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.463686903863763E44d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2999448210687674E42d + "'", double1 == 4.2999448210687674E42d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-805L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1064753152) + "'", int1 == (-1064753152));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1386101647));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-42));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-213909503));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1), (long) 1000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1001L) + "'", long2 == (-1001L));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1386101647), 90L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1386101647L) + "'", long2 == (-1386101647L));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(35, 323);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 358 + "'", int2 == 358);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 4.806217383937352E-6d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        try {
            java.lang.Class<?> wildcardClass8 = orderDirection7.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 4.806217383937352E-6d + "'", number6.equals(4.806217383937352E-6d));
        org.junit.Assert.assertNull(orderDirection7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1386101689, 21000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1386122689 + "'", int2 == 1386122689);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1507257537);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1905685947 + "'", int1 == 1905685947);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.7170586110041572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 68L, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 68.00000000000001d + "'", double2 == 68.00000000000001d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.4301250134917418E26d, (double) 13566.0f, (double) (-1055123539));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.463686903863763E44d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3340854567177434d) + "'", double1 == (-1.3340854567177434d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        long long1 = org.apache.commons.math.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0000000000000002d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1032847325);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-41));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(65.10120968855118d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1362304560964502d + "'", double1 == 1.1362304560964502d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1067417600L), 21, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0674176E9f) + "'", float3 == (-1.0674176E9f));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1079525376L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-35), 1079525376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079525341 + "'", int2 == 1079525341);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1076232192, 1079525341);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.023904801749939406d), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.023904801749939406d) + "'", double2 == (-0.023904801749939406d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-213909503), 6.907755278982137d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.685714066028595d + "'", double2 == 7.685714066028595d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1905685947);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str9 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.21802260173160448E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.6881171418161737E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.42944819032519d + "'", double1 == 43.42944819032519d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1586656170, (double) 1032847260L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(132, 1032847325);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1221515391), 1586656170);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0d, (java.lang.Number) 3628800L, 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        int int1 = org.apache.commons.math.util.FastMath.abs((-41));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 41 + "'", int1 == 41);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 488887457, 534.4916555247646d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 534.4916555247646d + "'", double2 == 534.4916555247646d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 83824);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 10.0f, 1074790410, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 1.0613084341780446E57d, (int) (short) -1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (1,061,308,434,178,044,600,000,000,000,000,000,000,000,000,000,000,000,000,000 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (1,061,308,434,178,044,600,000,000,000,000,000,000,000,000,000,000,000,000,000 >= 0)"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21 + "'", int1 == 21);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection32, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-5479429532463080511L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.4794295324630794E18d) + "'", double1 == (-5.4794295324630794E18d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(323);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(2704);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1386102689L, 358);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.138302973034538E116d + "'", double2 == 8.138302973034538E116d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-52L), (float) 90L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 90.0f + "'", float2 == 90.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        int int9 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0f + "'", number8.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-1.5274985276365916d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-1221515391));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 100, (-1067417600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1067417600 + "'", int2 == 1067417600);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.tan(534.4916555247646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4476577640910703d + "'", double1 == 0.4476577640910703d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 156.3608363030788d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 7227194);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double1 = org.apache.commons.math.util.FastMath.acosh(110.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.393606884554982d + "'", double1 == 5.393606884554982d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(488887457, 1074790399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1563677856 + "'", int2 == 1563677856);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { ' ', (byte) 10 };
        int[] intArray8 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray8);
        int[] intArray16 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray16);
        int[] intArray24 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray24);
        int[] intArray28 = new int[] { ' ', (byte) 10 };
        int[] intArray33 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray33);
        int[] intArray41 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray41);
        int[] intArray49 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray49);
        int[] intArray55 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray62 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray62);
        try {
            int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 68.8839603971781d + "'", double9 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 323 + "'", int25 == 323);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 68.8839603971781d + "'", double34 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 323 + "'", int50 == 323);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1074790722 + "'", int63 == 1074790722);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.8475328855259755E9d + "'", double64 == 1.8475328855259755E9d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(32L, (long) 1074790369);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790337L) + "'", long2 == (-1074790337L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        float float1 = org.apache.commons.math.util.FastMath.abs(13566.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 13566.0f + "'", float1 == 13566.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.7935607365300265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-42));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) (-1064753152));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.6102871923992833E-232d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 7227194, (-0.9300727311045811d), 2.154434690031884d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1452L), 184);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-252951790));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-252951790L) + "'", long1 == (-252951790L));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.17453292519943295d, number1, 1074790399);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.5274985276365916d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1516670284837467d) + "'", double1 == (-1.1516670284837467d));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(22L, (-7L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1386101689, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080869E43d + "'", double1 == 1.3440585709080869E43d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 74);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-48), 1386122689);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1074790400), 1563677856);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 1074790399);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.9009256457704354d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.61923715774417d + "'", double1 == 51.61923715774417d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1563677856);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double[] doubleArray4 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = new double[] { (byte) -1 };
        double[] doubleArray12 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        double[] doubleArray18 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection20, false);
        double[] doubleArray24 = new double[] { (byte) -1 };
        double[] doubleArray26 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray26);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray35 = new double[] { (byte) -1 };
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray37);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number48 = nonMonotonousSequenceException47.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = nonMonotonousSequenceException47.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection49, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7876260917919922d, (java.lang.Number) 100.00000000000001d, (-1221515391), orderDirection49, true);
        java.lang.Throwable[] throwableArray58 = nonMonotonousSequenceException57.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number63 = nonMonotonousSequenceException62.getArgument();
        java.lang.Number number64 = nonMonotonousSequenceException62.getPrevious();
        java.lang.String str65 = nonMonotonousSequenceException62.toString();
        java.lang.Number number66 = nonMonotonousSequenceException62.getArgument();
        nonMonotonousSequenceException57.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException62);
        java.lang.Class<?> wildcardClass68 = nonMonotonousSequenceException62.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 10.0f + "'", number48.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 10 + "'", number63.equals(10));
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 10.0f + "'", number64.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str65.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 10 + "'", number66.equals(10));
        org.junit.Assert.assertNotNull(wildcardClass68);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1386101647), 21.49293449538204d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.49293449538204d + "'", double2 == 21.49293449538204d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double2 = org.apache.commons.math.util.FastMath.max(0.8414709848078965d, 2.524630659933467d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.524630659933467d + "'", double2 == 2.524630659933467d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 132L, (java.lang.Number) 2.2250738585072014E-308d, 0, orderDirection7, true);
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 132L + "'", number10.equals(132L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.6881171418161737E43d, 41, 320);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-41), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 8023796054858137600L, (double) 1032847325L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.032847325E9d + "'", double2 == 1.032847325E9d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.463686903863763E44d, (double) 323);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-897303147), 132.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.973031469999999E8d) + "'", double2 == (-8.973031469999999E8d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) (-1386101647));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1386101647L) + "'", long2 == (-1386101647L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7658461948190802d + "'", double1 == 0.7658461948190802d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-132), (long) 167);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-132L) + "'", long2 == (-132L));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 21000, 74);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = new double[] { (byte) -1 };
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray31);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray29);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection43, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        double[] doubleArray48 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray38);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int int2 = org.apache.commons.math.util.MathUtils.pow(32, 1076232192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.0037035886157206215d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.003703571682350835d) + "'", double1 == (-0.003703571682350835d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 4.806217383937352E-6d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.String str15 = nonMonotonousSequenceException11.toString();
        boolean boolean16 = nonMonotonousSequenceException11.getStrict();
        boolean boolean17 = nonMonotonousSequenceException11.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException11.getDirection();
        int int19 = nonMonotonousSequenceException11.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 4.806217383937352E-6d + "'", number6.equals(4.806217383937352E-6d));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2772L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0413270358064386d + "'", double1 == 2.0413270358064386d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 618402555, 7L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 618402562L + "'", long2 == 618402562L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double3 = org.apache.commons.math.util.MathUtils.round((-1.0d), 924, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { ' ', (byte) 10 };
        int[] intArray8 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray8);
        int[] intArray12 = new int[] { ' ', (byte) 10 };
        int[] intArray17 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray12);
        java.lang.Class<?> wildcardClass20 = intArray12.getClass();
        try {
            int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 68.8839603971781d + "'", double9 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 68.8839603971781d + "'", double18 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-39088492512L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(7.72769467795052E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9999999958776927d, (java.lang.Number) (-0.8373983731296123d), 1386122689);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, (-1386101647));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1386101647) + "'", int2 == (-1386101647));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0536712127723509E-8d, (-5.4794295324630794E18d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(7227194, (long) (-48));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 96549157373046880L, (int) (short) 1, orderDirection8, false);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Class<?> wildcardClass12 = number11.getClass();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 96549157373046880L + "'", number11.equals(96549157373046880L));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.7658461948190802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.15081361216741d + "'", double1 == 2.15081361216741d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) -1, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 1386101689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1386101689 + "'", int2 == 1386101689);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-252951790));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int2 = org.apache.commons.math.util.FastMath.min(2704, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.23528072998266963d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-2.13909504E8f), 0.0d, (double) 184);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 83824);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.336474641648001d + "'", double1 == 11.336474641648001d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1032847360L, (long) (-48));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-49576673280L) + "'", long2 == (-49576673280L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 935L, (double) 167);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7481849279883415d + "'", double2 == 0.7481849279883415d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1032847325, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1032847325 + "'", int2 == 1032847325);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        long long1 = org.apache.commons.math.util.FastMath.round((double) Float.NaN);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2704);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 154927.7878033746d + "'", double1 == 154927.7878033746d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray15 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray15);
        int[] intArray23 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray23);
        int[] intArray28 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray35 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray35);
        try {
            int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 323 + "'", int24 == 323);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1074790722 + "'", int36 == 1074790722);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1.192192432E9d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(100, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1074790399, 1079525376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        long long1 = org.apache.commons.math.util.FastMath.abs(1074790410L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1074790410L + "'", long1 == 1074790410L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-35), 1032847260L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1032847225L + "'", long2 == 1032847225L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = new double[] { (byte) -1 };
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray11);
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection24, false);
        double[] doubleArray28 = new double[] { (byte) -1 };
        double[] doubleArray30 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray28);
        double[] doubleArray35 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection37, false);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray35);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { ' ', (byte) 10 };
        int[] intArray8 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray8);
        int[] intArray16 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray16);
        int[] intArray24 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray24);
        int[] intArray28 = new int[] { ' ', (byte) 10 };
        int[] intArray33 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray33);
        int[] intArray41 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray41);
        int[] intArray49 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray49);
        int[] intArray54 = new int[] { ' ', (byte) 10 };
        int[] intArray59 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray59);
        int[] intArray67 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray54, intArray67);
        int[] intArray75 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray67);
        try {
            int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 68.8839603971781d + "'", double9 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 323 + "'", int25 == 323);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 68.8839603971781d + "'", double34 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 323 + "'", int50 == 323);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 68.8839603971781d + "'", double60 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 100 + "'", int68 == 100);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 323 + "'", int76 == 323);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 323 + "'", int77 == 323);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.MathUtils.sign(230.97419898843916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 2704L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 618402555, (long) 7227194);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 611175361L + "'", long2 == 611175361L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(8.138302973034538E116d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double2 = org.apache.commons.math.util.FastMath.max(0.5403023058681398d, 1.1078671099555852E12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1078671099555852E12d + "'", double2 == 1.1078671099555852E12d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1074790410, (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 83824);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 83824.0d + "'", double1 == 83824.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.118248651196143E224d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.2748734119735194E-306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-305.8945329361796d) + "'", double1 == (-305.8945329361796d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1074790369));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '#', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-307.6526555685888d) + "'", double1 == (-307.6526555685888d));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.floor((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-58.0d) + "'", double1 == (-58.0d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection32, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double[] doubleArray37 = new double[] { (byte) -1 };
        double[] doubleArray39 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray39);
        double[] doubleArray43 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray43);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray43);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.004202383670873878d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.asin(11.7910068511973d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number26 = nonMonotonousSequenceException25.getArgument();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        java.lang.Number number28 = nonMonotonousSequenceException25.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException25.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection29, false);
        double[] doubleArray36 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection38, false);
        double[] doubleArray42 = new double[] { (byte) -1 };
        double[] doubleArray44 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray44);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        double[] doubleArray50 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection52, false);
        double[] doubleArray56 = new double[] { (byte) -1 };
        double[] doubleArray58 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray58);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray56);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray56);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double[] doubleArray67 = new double[] { (byte) -1 };
        double[] doubleArray69 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray69);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException79 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number80 = nonMonotonousSequenceException79.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection81 = nonMonotonousSequenceException79.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException83 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection81, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection81, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56, orderDirection81, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException89 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7876260917919922d, (java.lang.Number) 100.00000000000001d, (-1221515391), orderDirection81, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection81, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10 + "'", number26.equals(10));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10.0f + "'", number27.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10.0f + "'", number28.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 31 + "'", int72 == 31);
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + 10.0f + "'", number80.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection81 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection81.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5515679276951895d + "'", double1 == 1.5515679276951895d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1064753152), (-41));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1386101647), 132);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.288004850734253d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9602802547032059d + "'", double1 == 0.9602802547032059d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0747904100000021E9d, 1.52587890625E-5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.074790410000002E9d + "'", double2 == 1.074790410000002E9d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException4.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException4.getDirection();
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1386101689, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.386101689E9d + "'", double2 == 1.386101689E9d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10 + "'", number9.equals(10));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0f + "'", number10.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10.0f + "'", number11.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.283185307179586d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1032847225L, (-0.8373983731296123d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.8291817334359745E-8d + "'", double2 == 2.8291817334359745E-8d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(618402562L, 8023796054858137600L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8023796055476540162L + "'", long2 == 8023796055476540162L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1067417600, 8023796055476540162L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.6543768726206876d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6543768726206873d) + "'", double2 == (-1.6543768726206873d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double double1 = org.apache.commons.math.util.FastMath.sinh(160.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5349248203221212E69d + "'", double1 == 1.5349248203221212E69d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(21.488538654488526d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.074790368999999E9d + "'", double1 == 1.074790368999999E9d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double2 = org.apache.commons.math.util.FastMath.pow(8376.0d, 4.806217383937352E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000434161084752d + "'", double2 == 1.0000434161084752d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1032847360L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(11013.232920103304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 8023796054858137600L, 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 1563677856);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, false);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray8);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray8);
        try {
            double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5637291368821689d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(2L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(618402555, (-1074790369));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-456387814) + "'", int2 == (-456387814));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 184);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 184L + "'", long1 == 184L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.00000000000001d, (java.lang.Number) Double.NaN, 10);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-1.5962947873834027E-19d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5962947873834027E-19d) + "'", double1 == (-1.5962947873834027E-19d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 20990);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(42, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4074 + "'", int2 == 4074);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        long long1 = org.apache.commons.math.util.FastMath.round(1023.9999994287169d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1024L + "'", long1 == 1024L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.0328473E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 32);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.5704932965011418d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.473814720414451d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 184L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1563677856, (float) 1032847360);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.03284736E9f + "'", float2 == 1.03284736E9f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.214935757608986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.214935757608987d + "'", double1 == 5.214935757608987d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1032847360, 1.1479952104287463E-53d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.5349248203221212E69d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 8023796055476540162L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1137893781 + "'", int1 == 1137893781);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.141380652391393d, (-2.3012989023072947d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07177562623257451d + "'", double2 == 0.07177562623257451d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2146435072 + "'", int1 == 2146435072);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.3754263876807227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1192192432));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.6360472921856655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.238443181663616d + "'", double1 == 2.238443181663616d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.abs(6.080849404003989E58d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.080849404003989E58d + "'", double1 == 6.080849404003989E58d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.cos(21.488538654488526d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8763283117957299d) + "'", double1 == (-0.8763283117957299d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1074790369, 1905685947);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-830895578) + "'", int2 == (-830895578));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        int[] intArray0 = new int[] {};
        int[] intArray3 = new int[] { ' ', (byte) 10 };
        int[] intArray8 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray8);
        int[] intArray12 = new int[] { ' ', (byte) 10 };
        int[] intArray17 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray12);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray12);
        int[] intArray23 = new int[] { ' ', (byte) 10 };
        int[] intArray28 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray28);
        int[] intArray36 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray23);
        int[] intArray39 = new int[] {};
        int[] intArray42 = new int[] { ' ', (byte) 10 };
        int[] intArray47 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray47);
        int[] intArray51 = new int[] { ' ', (byte) 10 };
        int[] intArray56 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray51);
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray51);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray51);
        int[] intArray63 = new int[] { ' ', (byte) 10 };
        int[] intArray68 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray68);
        int[] intArray72 = new int[] { ' ', (byte) 10 };
        int[] intArray77 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray72);
        java.lang.Class<?> wildcardClass80 = intArray72.getClass();
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray72);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 68.8839603971781d + "'", double9 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 68.8839603971781d + "'", double18 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 68.8839603971781d + "'", double29 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 68.8839603971781d + "'", double48 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 68.8839603971781d + "'", double57 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 68.8839603971781d + "'", double69 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 68.8839603971781d + "'", double78 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 13566);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(2704, (-252951790));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.0536712127723509E-8d, (double) 618402555);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, false);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray8);
        java.lang.Class<?> wildcardClass14 = doubleArray2.getClass();
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray19);
        double[] doubleArray23 = new double[] { (byte) -1 };
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray19);
        double[] doubleArray32 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection34, false);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray38);
        double[] doubleArray45 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45, orderDirection47, false);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray45);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray45);
        java.lang.Class<?> wildcardClass52 = doubleArray45.getClass();
        try {
            double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (-0.8373983731296123d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.023904801749939406d), 0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.17453292519943295d + "'", double2 == 0.17453292519943295d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5127742681331149d + "'", double1 == 0.5127742681331149d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1074790369), (long) 1074790410);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790369L) + "'", long2 == (-1074790369L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-3.9088493E10f), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.705429428472229d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8516124473481776d + "'", double1 == 0.8516124473481776d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        long long1 = org.apache.commons.math.util.FastMath.round(132.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 132L + "'", long1 == 132L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1386122689);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1, (double) 1032847360);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1067417600, (-8.353694411064845E-19d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0674175999999999E9d + "'", double2 == 1.0674175999999999E9d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 6993833231716193505L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.00717126795679E20d + "'", double1 == 4.00717126795679E20d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1000, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1000L + "'", long2 == 1000L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1024L, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1024.0d + "'", double2 == 1024.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double[] doubleArray4 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = new double[] { (byte) -1 };
        double[] doubleArray12 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        double[] doubleArray18 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection20, false);
        double[] doubleArray24 = new double[] { (byte) -1 };
        double[] doubleArray26 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray26);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray35 = new double[] { (byte) -1 };
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray37);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number48 = nonMonotonousSequenceException47.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = nonMonotonousSequenceException47.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection49, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7876260917919922d, (java.lang.Number) 100.00000000000001d, (-1221515391), orderDirection49, true);
        java.lang.Class<?> wildcardClass58 = nonMonotonousSequenceException57.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 10.0f + "'", number48.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass58);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.2121999967334905d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.21382567815214598d) + "'", double1 == (-0.21382567815214598d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-9.297528369843588d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int int1 = org.apache.commons.math.util.FastMath.abs(1032847325);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1032847325 + "'", int1 == 1032847325);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-1074790337L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray11 = new int[] { ' ', (byte) 10 };
        int[] intArray16 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray11);
        int[] intArray19 = new int[] {};
        int[] intArray22 = new int[] { ' ', (byte) 10 };
        int[] intArray27 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray27);
        int[] intArray31 = new int[] { ' ', (byte) 10 };
        int[] intArray36 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray31);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray31);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray31);
        int[] intArray43 = new int[] { ' ', (byte) 10 };
        int[] intArray48 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray48);
        int[] intArray52 = new int[] { ' ', (byte) 10 };
        int[] intArray57 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray57);
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray52);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray52);
        int[] intArray63 = new int[] { ' ', (byte) 10 };
        int[] intArray68 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray68);
        java.lang.Class<?> wildcardClass70 = intArray63.getClass();
        int[] intArray73 = new int[] { ' ', (byte) 10 };
        int[] intArray78 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray78);
        java.lang.Class<?> wildcardClass80 = intArray73.getClass();
        int[] intArray84 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray91 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray84, intArray91);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray73, intArray84);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray63, intArray73);
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray63);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 68.8839603971781d + "'", double17 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 68.8839603971781d + "'", double28 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 68.8839603971781d + "'", double37 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 68.8839603971781d + "'", double49 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 68.8839603971781d + "'", double58 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 68.8839603971781d + "'", double69 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 68.8839603971781d + "'", double79 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1074790722 + "'", int92 == 1074790722);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1074790410 + "'", int93 == 1074790410);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1386101589);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1386122689);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        long long2 = org.apache.commons.math.util.MathUtils.pow(23L, (long) 1074790369);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1347167864733188375L + "'", long2 == 1347167864733188375L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(29937.07084924806d, (double) 1079525376, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) -1, 6993833231716193505L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6993833231716193506L) + "'", long2 == (-6993833231716193506L));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.524630659933467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.203097420189161d + "'", double1 == 6.203097420189161d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(35, 2704);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94640 + "'", int2 == 94640);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (-1221515391));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1386101647L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-1001L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 35, (-0.23851102429896254d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5776108220048384d + "'", double2 == 1.5776108220048384d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int int2 = org.apache.commons.math.util.FastMath.max(13566, 1074790399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790399 + "'", int2 == 1074790399);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1074790400));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.23851102429896254d), 1.288004850734253d, (-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 488887457, (double) 50590358L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double1 = org.apache.commons.math.util.FastMath.log(3.141380652391393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1446624014950488d + "'", double1 == 1.1446624014950488d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        double[] doubleArray23 = new double[] { (byte) -1 };
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray25);
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray25);
        double[] doubleArray35 = new double[] { (byte) -1 };
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection40, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 31 + "'", int32 == 31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 320, (long) (-42));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 362L + "'", long2 == 362L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1386102689L, (double) 618402562L, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2704, (long) 20990);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20990L + "'", long2 == 20990L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) (-1386101647), 1905685947);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1L), 1.7345175425633101d, 0.8516124473481776d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.1362304560964502d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019830962520319934d + "'", double1 == 0.019830962520319934d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(94640, (-58));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.6197751905438615d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9630885089556035d + "'", double1 == 0.9630885089556035d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.6197751905438615d, 4074);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6197751905438615d + "'", double2 == 1.6197751905438615d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double2 = org.apache.commons.math.util.FastMath.min(1833.4649444186343d, 8376.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1833.4649444186343d + "'", double2 == 1833.4649444186343d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-1.1283155162826222d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7070120829360398d + "'", double1 == 1.7070120829360398d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(20990, 1079525341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1079504351) + "'", int2 == (-1079504351));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-48));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 132L, 65.10120968855118d, 0.012097405411982188d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-252951790L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.52951792E8f + "'", float1 == 2.52951792E8f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number26 = nonMonotonousSequenceException25.getArgument();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        java.lang.Number number28 = nonMonotonousSequenceException25.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException25.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection29, false);
        double[] doubleArray33 = new double[] { (byte) -1 };
        double[] doubleArray35 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray35);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10 + "'", number26.equals(10));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10.0f + "'", number27.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10.0f + "'", number28.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 37.14833901501544d + "'", double1 == 37.14833901501544d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(488887457, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 488887457 + "'", int2 == 488887457);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.375426387680723d, (-48));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.atanh(9.332621544395286E157d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        long long2 = org.apache.commons.math.util.FastMath.min(52L, 96549157373046880L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 35, 4.6360472921856655d, 8376.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1032847260L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (-830895578));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 23L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 4074);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int[] intArray0 = new int[] {};
        int[] intArray3 = new int[] { ' ', (byte) 10 };
        int[] intArray8 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray8);
        int[] intArray16 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray16);
        int[] intArray24 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray24);
        int[] intArray28 = new int[] { ' ', (byte) 10 };
        int[] intArray33 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray33);
        int[] intArray41 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray41);
        int[] intArray49 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray49);
        int[] intArray55 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray62 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray62);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray24);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 68.8839603971781d + "'", double9 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 323 + "'", int25 == 323);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 68.8839603971781d + "'", double34 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 323 + "'", int50 == 323);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1074790722 + "'", int63 == 1074790722);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.8475328855259755E9d + "'", double64 == 1.8475328855259755E9d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str10 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10 + "'", number7.equals(10));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 32L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1516670284837467d), (java.lang.Number) 1.5704932965011418d, 31);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.sinh(184.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.065881102564072E79d + "'", double1 == 4.065881102564072E79d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35, (float) 1000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 0.0f, (double) 323);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.737102242198924d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1672638911) + "'", int1 == (-1672638911));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1001L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0025215808021860583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.065881102564072E79d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 184.0d + "'", double1 == 184.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-252951790), (double) (-1055123539), 1.1479952104287463E-53d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-49576673280L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 132);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9985900724399912d + "'", double1 == 0.9985900724399912d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double2 = org.apache.commons.math.util.FastMath.pow(5.393606884554982d, (double) 1032847395);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1079525376, 1586656170);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 100, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 1.0613084341780446E57d, (int) (short) -1);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0613084341780446E57d + "'", number6.equals(1.0613084341780446E57d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(3628800L, 184L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 83462400L + "'", long2 == 83462400L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1067417600, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1067417500 + "'", int2 == 1067417500);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.7481849279883415d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8199681418075612d + "'", double1 == 0.8199681418075612d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1032847260L, 0.9602802547032059d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0019527324735895803d) + "'", double2 == (-0.0019527324735895803d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-35), (-52L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(924, (-704643071));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 11, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 385L + "'", long2 == 385L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.7208307687693356d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7848963167190028d + "'", double1 == 0.7848963167190028d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 9.999999999999998d, (int) (byte) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 68L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-132), (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.026802175208931d, 0.0025215808021860583d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0017829817524246d + "'", double2 == 1.0017829817524246d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1074790369L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1192192432), (long) 1386101589);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1652499824388974448L) + "'", long2 == (-1652499824388974448L));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.FastMath.log10(515.8908245878225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.712557803767253d + "'", double1 == 2.712557803767253d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2704L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2704.0f + "'", float1 == 2704.0f);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 184L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.065881102564072E79d + "'", double1 == 4.065881102564072E79d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.05224159391082094d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05221786022585878d + "'", double1 == 0.05221786022585878d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(22.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1260.507149287811d + "'", double1 == 1260.507149287811d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 924);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double2 = org.apache.commons.math.util.MathUtils.log(11013.232920103304d, 1.0747904100000021E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.234417145184986d + "'", double2 == 2.234417145184986d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.rint(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.3012989023072947d, 6.080849404003989E58d, (double) 4074);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1032847325);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1, (long) (-456387814));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-456387814L) + "'", long2 == (-456387814L));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (byte) -1, (double) 83824.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1000, 320);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.76317775494066E270d + "'", double2 == 4.76317775494066E270d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.335686945314077E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-830895578), (int) (short) 10, 1074790410);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-42), 13566);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13566 + "'", int2 == 13566);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-49576673280L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1.0328473E9f, (double) 1032847395);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981154716825d + "'", double2 == 0.7853981154716825d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray1);
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection16, false);
        double[] doubleArray20 = new double[] { (byte) -1 };
        double[] doubleArray22 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray22);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double[] doubleArray34 = new double[] { (byte) -1 };
        double[] doubleArray36 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray34);
        double[] doubleArray42 = null;
        double[] doubleArray44 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection46, false);
        double[] doubleArray50 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection52, false);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray50);
        java.lang.Class<?> wildcardClass56 = doubleArray44.getClass();
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray44);
        double[] doubleArray59 = new double[] { (byte) -1 };
        double[] doubleArray61 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray61);
        double[] doubleArray65 = new double[] { (byte) -1 };
        double[] doubleArray67 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray61, doubleArray65);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray61);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray44);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray44);
        double[] doubleArray76 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76, orderDirection78, false);
        double[] doubleArray82 = new double[] { (byte) -1 };
        double[] doubleArray84 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray84);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray82, doubleArray84);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray82);
        double[] doubleArray89 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray89);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection91 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray89, orderDirection91, false);
        double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray82, doubleArray89);
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray89);
        double double96 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray89);
        int int97 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 1.0d + "'", double94 == 1.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 31 + "'", int97 == 31);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-805L), 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-805.0f) + "'", float2 == (-805.0f));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1067417500, 1032847395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 322, 320, 1076232192);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.99168E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2870641716678042E9d + "'", double1 == 2.2870641716678042E9d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 184);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.065881102564072E79d + "'", double1 == 4.065881102564072E79d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 21);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double2 = org.apache.commons.math.util.FastMath.min(0.012097405411982188d, 6.123233995736766E-17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.123233995736766E-17d + "'", double2 == 6.123233995736766E-17d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1386101589);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1114.97471947615d + "'", double1 == 1114.97471947615d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double2 = org.apache.commons.math.util.MathUtils.round(11.0d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1074790369), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790369L) + "'", long2 == (-1074790369L));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0025215808021860583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1074790399);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1074790399L + "'", long1 == 1074790399L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.031814983519345d) + "'", double1 == (-1.031814983519345d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.546002635479441d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1079504351));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) (-830895578), (-213909503));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 8023796054858137600L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1138480784 + "'", int1 == 1138480784);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1563677856, (long) (-1067417600));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(154927.7878033746d, 83824, 320);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 0, (int) ' ', orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0f + "'", number9.equals(0.0f));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-6264507081672359935L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(73.86141734396143d, (double) 362L, 6.907755278982137d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 0, (int) ' ', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(184, 1386101589);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1097L, 1.335686945314077E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1097.0000000000002d + "'", double2 == 1097.0000000000002d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5704932965011418d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9171041915039453d + "'", double1 == 0.9171041915039453d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1137893781);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1386101689, (long) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1775275193 + "'", int2 == 1775275193);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 21L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-1.6102871923992833E-232d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int2 = org.apache.commons.math.util.MathUtils.pow(167, 4074);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-242306127) + "'", int2 == (-242306127));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1221515391), (long) 20990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1825403137 + "'", int2 == 1825403137);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.2261911708835171d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.070334181256781d + "'", double1 == 1.070334181256781d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9999999714987686d, 222.89575234721096d, (-1.1516670284837467d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (byte) -1 };
        double[] doubleArray4 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection7, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        double[] doubleArray12 = new double[] { (byte) -1 };
        double[] doubleArray14 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray14);
        double[] doubleArray18 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray18);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray18);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number27 = nonMonotonousSequenceException26.getArgument();
        java.lang.Number number28 = nonMonotonousSequenceException26.getPrevious();
        java.lang.Number number29 = nonMonotonousSequenceException26.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException26.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection30, false);
        double[] doubleArray34 = new double[] { (byte) -1 };
        double[] doubleArray36 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray34);
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number47 = nonMonotonousSequenceException46.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = nonMonotonousSequenceException46.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number40, (java.lang.Number) 156.36083630307883d, 0, orderDirection48, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection48, true);
        double[] doubleArray54 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection56, false);
        double[] doubleArray60 = new double[] { (byte) -1 };
        double[] doubleArray62 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray62);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray60);
        double[] doubleArray67 = new double[] { (byte) -1 };
        double[] doubleArray69 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray69);
        double[] doubleArray73 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray73);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray73);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray73);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10 + "'", number27.equals(10));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10.0f + "'", number28.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 10.0f + "'", number29.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 10.0f + "'", number47.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-704643071), 1.2261911708835171d, 83824);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray15 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray15);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int[] intArray21 = new int[] { ' ', (byte) 10 };
        int[] intArray26 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray26);
        int[] intArray30 = new int[] { ' ', (byte) 10 };
        int[] intArray35 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray30);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray30);
        int[] intArray41 = new int[] { ' ', (byte) 10 };
        int[] intArray46 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray46);
        int[] intArray54 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray41);
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray30);
        int[] intArray58 = new int[] {};
        int[] intArray61 = new int[] { ' ', (byte) 10 };
        int[] intArray66 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray66);
        int[] intArray70 = new int[] { ' ', (byte) 10 };
        int[] intArray75 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray70, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray70);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray70);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray58);
        try {
            double double80 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 68.8839603971781d + "'", double27 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 68.8839603971781d + "'", double36 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 68.8839603971781d + "'", double47 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 100 + "'", int55 == 100);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 68.8839603971781d + "'", double67 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 68.8839603971781d + "'", double76 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.940141468803501d + "'", double1 == 11.940141468803501d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1079525376L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1079525341);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        double double2 = org.apache.commons.math.util.MathUtils.log(11013.232920103324d, (-0.21382567815214598d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        java.lang.Class<?> wildcardClass15 = orderDirection14.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 488887457, (java.lang.Number) 3.637978807091713E-12d, (-1067417600), orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1076232192, (java.lang.Number) 0.012097700501686678d, 20990, orderDirection14, false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-41), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 1825403137);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1137893781, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1137893781L + "'", long2 == 1137893781L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 385L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5972596945288E167d + "'", double1 == 1.5972596945288E167d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 132L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 132L + "'", long1 == 132L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1L), (float) 33000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 33000.0f + "'", float2 == 33000.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 1079525341);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int int2 = org.apache.commons.math.util.FastMath.max(1074790399, (-48));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790399 + "'", int2 == 1074790399);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 385L, 4.806217383912514E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963143112151d + "'", double2 == 1.5707963143112151d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9132181497465548d) + "'", double1 == (-0.9132181497465548d));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double1 = org.apache.commons.math.util.FastMath.signum(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5707963143112151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1624473484301645d + "'", double1 == 1.1624473484301645d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 10L, 2146435072, 167);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 31, 1067418535L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1328146545015742687L + "'", long2 == 1328146545015742687L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int int2 = org.apache.commons.math.util.MathUtils.pow(31, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1925533311) + "'", int2 == (-1925533311));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-132), (-1064753152));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1064753020 + "'", int2 == 1064753020);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.7182818247238476d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 718503581 + "'", int1 == 718503581);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1032847260L, (long) 184);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 47510973960L + "'", long2 == 47510973960L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 94640);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1074790410, (double) 90L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 91.35289525985718d + "'", double2 == 91.35289525985718d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        long long1 = org.apache.commons.math.util.FastMath.abs(68L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 68L + "'", long1 == 68L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1097L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int int2 = org.apache.commons.math.util.MathUtils.pow(21, 1586656170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-869579111) + "'", int2 == (-869579111));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1137893781L, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.11042278791613983d + "'", double2 == 0.11042278791613983d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(32, (-132));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1032847260L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '4', 7.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.17542037193601015d, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.17542d + "'", double2 == 0.17542d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.026802175208931d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1326442914 + "'", int1 == 1326442914);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1079525376);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.079525376E9d + "'", double1 == 1.079525376E9d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1775275193, (long) (-35));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62134631755L + "'", long2 == 62134631755L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-5.424641371532628E-7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.424641371532627E-7d) + "'", double1 == (-5.424641371532627E-7d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray11 = new int[] { ' ', (byte) 10 };
        int[] intArray16 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray11);
        int[] intArray19 = new int[] {};
        int[] intArray22 = new int[] { ' ', (byte) 10 };
        int[] intArray27 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray27);
        int[] intArray31 = new int[] { ' ', (byte) 10 };
        int[] intArray36 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray31);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray31);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray31);
        int[] intArray41 = new int[] {};
        int[] intArray44 = new int[] { ' ', (byte) 10 };
        int[] intArray49 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray49);
        int[] intArray53 = new int[] { ' ', (byte) 10 };
        int[] intArray58 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray53);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray44);
        try {
            int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 68.8839603971781d + "'", double17 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 68.8839603971781d + "'", double28 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 68.8839603971781d + "'", double37 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 68.8839603971781d + "'", double50 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 68.8839603971781d + "'", double59 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.718281828459045d, 0.9999999714987686d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1652499824388974448L), (double) (byte) 1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.2261911708835171d, (double) 618402562L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.184025596888063E8d + "'", double2 == 6.184025596888063E8d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-704643071));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int[] intArray3 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray10 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray14 = new int[] { ' ', (byte) 10 };
        int[] intArray19 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray19);
        int[] intArray27 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray27);
        int[] intArray31 = new int[] { ' ', (byte) 10 };
        int[] intArray36 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray36);
        int[] intArray44 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray44);
        int[] intArray52 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray52);
        int[] intArray56 = new int[] { ' ', (byte) 10 };
        int[] intArray61 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray61);
        int[] intArray69 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray69);
        int[] intArray77 = new int[] { (-42), (byte) 10, (short) 0, 21, 32, 52 };
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray69, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray77);
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray52);
        try {
            int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1074790722 + "'", int11 == 1074790722);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 68.8839603971781d + "'", double20 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 68.8839603971781d + "'", double37 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 323 + "'", int53 == 323);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 68.8839603971781d + "'", double62 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 100 + "'", int70 == 100);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 323 + "'", int78 == 323);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 74 + "'", int80 == 74);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.11042278791613983d, (double) (-35), 476);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0d + "'", number6.equals(10.0d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1074790369L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.488538654488526d) + "'", double1 == (-21.488538654488526d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.019830962520319934d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1362304560964502d + "'", double1 == 1.1362304560964502d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.6065306597126334d, (-41));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.758182107357395E-13d + "'", double2 == 2.758182107357395E-13d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(83824.0d, (double) 167, (double) 13566);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        int int8 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 83824, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 0, (int) ' ', orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2704L, (java.lang.Number) 1.1786670007231652d, 1074790410);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(32.0d, 1.6126156408942305d, (-0.003703571682350835d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        double[] doubleArray4 = new double[] { (byte) -1 };
        double[] doubleArray6 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray6);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number21 = nonMonotonousSequenceException20.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException20.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.052166389484759d, (java.lang.Number) Double.NEGATIVE_INFINITY, 35, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number11, (java.lang.Number) 45L, (-1074790400), orderDirection22, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.030303029375481E-5d, (java.lang.Number) (-0.004202383670873878d), (int) (byte) 10, orderDirection22, true);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        java.lang.Class<?> wildcardClass9 = orderDirection8.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection8, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 0, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        java.lang.Class<?> wildcardClass14 = doubleArray3.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(21.000000000000004d, 4.806217383912514E-6d, 2.238443181663616d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 20L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.52587890625E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.52587890625E-5d + "'", double1 == 1.52587890625E-5d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1586656170);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.58665617E9d + "'", double1 == 1.58665617E9d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.0000000000000002d, 51.61923715774417d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33000L, number1, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33000L, (java.lang.Number) (-0.0037035886157206215d), 31);
        java.lang.Number number8 = nonMonotonousSequenceException7.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        boolean boolean10 = nonMonotonousSequenceException7.getStrict();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-0.0037035886157206215d) + "'", number8.equals((-0.0037035886157206215d)));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1067418535L, (long) 1032847395);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 220496090649893265L + "'", long2 == 220496090649893265L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-252951790L), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.52951792E8f) + "'", float2 == (-2.52951792E8f));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException14.getDirection();
        java.lang.Class<?> wildcardClass17 = orderDirection16.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.890349128221754d, (java.lang.Number) 0.17453292519943295d, (int) '4', orderDirection16, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 4.890349128221754d + "'", number21.equals(4.890349128221754d));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-6264507081672359935L), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1064753020, (-1079504351));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 83824);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.375426387680723d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        int int2 = org.apache.commons.math.util.FastMath.max((-456387814), (-1386101647));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-456387814) + "'", int2 == (-456387814));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6931471805599453d, 0.04742161873168638d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5024878349045192d + "'", double2 == 1.5024878349045192d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 1586656170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1586656170 + "'", int2 == 1586656170);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.9985900724399912d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-9.297528369843588d), (double) 1775275193, (-0.8334276796443637d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 11.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1074790337L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int1 = org.apache.commons.math.util.FastMath.abs(1074790369);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1074790369 + "'", int1 == 1074790369);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 5, (-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        long long2 = org.apache.commons.math.util.MathUtils.pow(23L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        int int2 = org.apache.commons.math.util.FastMath.min(1067417500, 132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132 + "'", int2 == 132);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 132L, number1, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double double1 = org.apache.commons.math.util.FastMath.log(2.9048849665246426E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.999999999999964d + "'", double1 == 30.999999999999964d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-3.9088493E10f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }
}

