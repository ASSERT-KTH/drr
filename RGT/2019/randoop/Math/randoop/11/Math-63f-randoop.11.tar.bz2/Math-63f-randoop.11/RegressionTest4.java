import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        double double2 = org.apache.commons.math.util.FastMath.max(156.3608363030788d, 5.393606884554982d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 156.3608363030788d + "'", double2 == 156.3608363030788d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1563677856);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1074790399);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger13);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, number19, (int) '4');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.704333640160956d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.839807269118314d + "'", double1 == 2.839807269118314d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1L, (-1.5707963271409564d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963271409564d) + "'", double2 == (-1.5707963271409564d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray11 = new int[] { ' ', (byte) 10 };
        int[] intArray16 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray11);
        int[] intArray22 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray29 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray29);
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray29);
        int[] intArray34 = new int[] { ' ', (byte) 10 };
        int[] intArray39 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray39);
        java.lang.Class<?> wildcardClass41 = intArray34.getClass();
        int[] intArray45 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray52 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray52);
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray45);
        try {
            double double55 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 68.8839603971781d + "'", double17 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1074790722 + "'", int30 == 1074790722);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 476 + "'", int31 == 476);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 68.8839603971781d + "'", double40 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1074790722 + "'", int53 == 1074790722);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1074790410 + "'", int54 == 1074790410);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1079525341, (-1386101632));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1890760.7239317165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0833260955038755E8d + "'", double1 == 1.0833260955038755E8d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray16 = new double[] { (byte) -1 };
        double[] doubleArray18 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection21, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        double[] doubleArray26 = new double[] { (byte) -1 };
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray28);
        double[] doubleArray32 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray32);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray32);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        double[] doubleArray44 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray44);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray40);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1507257537);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        int int2 = org.apache.commons.math.util.FastMath.max(42, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1032847225L, 8.97303147E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.032847225E9d + "'", double2 == 1.032847225E9d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9999999986258976d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999986258977d + "'", double1 == 0.9999999986258977d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-869579111));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 869579111 + "'", int2 == 869579111);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 2772L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        long long1 = org.apache.commons.math.util.FastMath.round(4.00717126795679E20d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 94640);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 94640.0f + "'", float1 == 94640.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 156.36083630307883d, 0, orderDirection8, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number15 = nonMonotonousSequenceException14.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException14.getPrevious();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.String str18 = nonMonotonousSequenceException14.toString();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        int int20 = nonMonotonousSequenceException14.getIndex();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10 + "'", number15.equals(10));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10.0f + "'", number16.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 11);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 11.0f + "'", float1 == 11.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(2, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 83824.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 289.52374686716115d + "'", double1 == 289.52374686716115d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-35));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-35) + "'", int1 == (-35));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        long long2 = org.apache.commons.math.util.FastMath.max(323L, (long) (-1055123539));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 323L + "'", long2 == 323L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        double double2 = org.apache.commons.math.util.FastMath.min((-4.816479930623699d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.816479930623699d) + "'", double2 == (-4.816479930623699d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 1.0613084341780446E57d, (int) (short) -1);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0613084341780446E57d + "'", number6.equals(1.0613084341780446E57d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray26 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection28, false);
        double[] doubleArray32 = new double[] { (byte) -1 };
        double[] doubleArray34 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray34);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection42, false);
        double[] doubleArray46 = new double[] { (byte) -1 };
        double[] doubleArray48 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray48);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray46);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray46);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 94640);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.460616277097798d + "'", double1 == 0.460616277097798d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = new double[] { (byte) -1 };
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray31);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray29);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection43, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        double[] doubleArray48 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray38);
        double[] doubleArray54 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        java.lang.Class<?> wildcardClass56 = doubleArray54.getClass();
        java.lang.Class<?> wildcardClass57 = doubleArray54.getClass();
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 7L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1138480784);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 9.6549155E16f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.991801083044374d + "'", double1 == 4.991801083044374d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1074790399);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        long long2 = org.apache.commons.math.util.FastMath.min(96549157373046875L, 62134631755L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62134631755L + "'", long2 == 62134631755L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = new double[] { (byte) -1 };
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray31);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray29);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        double[] doubleArray44 = new double[] { (byte) -1 };
        double[] doubleArray46 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray46);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray44);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray40);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        long long2 = org.apache.commons.math.util.FastMath.min(50590358L, (long) (-1386101632));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1386101632L) + "'", long2 == (-1386101632L));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.6881171418161737E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3986257671685822d) + "'", double1 == (-1.3986257671685822d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.6543768726206873d), (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 153.58347943834983d + "'", double2 == 153.58347943834983d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(618402555, 83824);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(184);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        double double1 = org.apache.commons.math.util.FastMath.tan(114.59155902616465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.03392823907221d + "'", double1 == 13.03392823907221d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1386122689);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.026931837701290245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0003626838621282d + "'", double1 == 1.0003626838621282d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1925533311), 8L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5480065050160172033L + "'", long2 == 5480065050160172033L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 'a', 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        double double1 = org.apache.commons.math.util.FastMath.abs((-3.9088492544E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9088492544E10d + "'", double1 == 3.9088492544E10d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.3440585709080869E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.345824740199579E41d + "'", double1 == 2.345824740199579E41d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        double double1 = org.apache.commons.math.util.FastMath.asin(21.000000000000004d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray17);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = null;
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray24);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection32, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray37);
        double[] doubleArray43 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection45, false);
        double[] doubleArray49 = new double[] { (byte) -1 };
        double[] doubleArray51 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray51);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
        double[] doubleArray57 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray57);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray57, orderDirection59, false);
        double[] doubleArray63 = new double[] { (byte) -1 };
        double[] doubleArray65 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray65);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray63);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray63);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray74 = new double[] { (byte) -1 };
        double[] doubleArray76 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray76);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number87 = nonMonotonousSequenceException86.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection88 = nonMonotonousSequenceException86.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException90 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection88, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76, orderDirection88, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection88, true);
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray63);
        double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 31 + "'", int79 == 31);
        org.junit.Assert.assertTrue("'" + number87 + "' != '" + 10.0f + "'", number87.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection88 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection88.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 1.0d + "'", double95 == 1.0d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 1.0d + "'", double96 == 1.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 5L, (-2006768640));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.7813423231340017E-308d) + "'", double2 == (-2.7813423231340017E-308d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(132, 7227194);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 953989608 + "'", int2 == 953989608);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0025215808021860583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1361102911957924d + "'", double1 == 0.1361102911957924d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.853988047997524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6173390205196068d + "'", double1 == 0.6173390205196068d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(34.751646946819406d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 869579111);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 869579136 + "'", int1 == 869579136);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = new double[] { (byte) -1 };
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray31);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray29);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection43, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        double[] doubleArray48 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray38);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1074790369) + "'", int54 == (-1074790369));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        int int2 = org.apache.commons.math.util.MathUtils.pow(320, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-6993833231716193506L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1905685888);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9394506844065109d + "'", double1 == 0.9394506844065109d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1386101632), 1326442914);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1074769409L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1386101744L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number26 = nonMonotonousSequenceException25.getArgument();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        java.lang.Number number28 = nonMonotonousSequenceException25.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException25.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection29, false);
        double[] doubleArray33 = new double[] { (byte) -1 };
        double[] doubleArray35 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray35);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray33);
        try {
            double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10 + "'", number26.equals(10));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10.0f + "'", number27.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10.0f + "'", number28.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        double double2 = org.apache.commons.math.util.FastMath.max(48.9299109048737d, 0.17681096436514165d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 48.9299109048737d + "'", double2 == 48.9299109048737d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.61512051684126d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.3754263876807227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3754263876807227d + "'", double1 == 1.3754263876807227d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        java.lang.Class<?> wildcardClass15 = orderDirection14.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 488887457, (java.lang.Number) 3.637978807091713E-12d, (-1067417600), orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.9300727311045811d), (java.lang.Number) 100.00000000000001d, (-1067417600), orderDirection14, true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        float float2 = org.apache.commons.math.util.FastMath.max(35.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) 869579111);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 166L, (float) 1586656337L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.58665638E9f + "'", float2 == 1.58665638E9f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 935L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1368683772161603E-13d + "'", double1 == 1.1368683772161603E-13d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 897303147);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-2147483648), (-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-55.21798849105835d) + "'", double2 == (-55.21798849105835d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 8023796054858137600L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.40041659665806064E17d + "'", double1 == 1.40041659665806064E17d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray14 = null;
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection18, false);
        double[] doubleArray22 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection24, false);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray22);
        java.lang.Class<?> wildcardClass28 = doubleArray16.getClass();
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double[] doubleArray31 = new double[] { (byte) -1 };
        double[] doubleArray33 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray33);
        double[] doubleArray37 = new double[] { (byte) -1 };
        double[] doubleArray39 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray39);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray37);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray33);
        double[] doubleArray46 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46, orderDirection48, false);
        double[] doubleArray52 = new double[] { (byte) -1 };
        double[] doubleArray54 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        double[] doubleArray59 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59, orderDirection61, false);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray59);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray59);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray16);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 8023796055476540162L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8023796055476540416L + "'", long1 == 8023796055476540416L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(22L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 572L + "'", long2 == 572L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.Number number4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number6, (java.lang.Number) 156.36083630307883d, 0, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11.7910068511973d, number4, (int) (short) 1, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1260.507149287811d, (java.lang.Number) 6.184025596888063E8d, 21, orderDirection14, true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1192192432));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        int int2 = org.apache.commons.math.util.MathUtils.pow(21, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.17542d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17725332186153167d + "'", double1 == 0.17725332186153167d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1067417600), (long) 1825403137);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1825403137L + "'", long2 == 1825403137L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1055123539));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1055123539L + "'", long1 == 1055123539L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        java.lang.Class<?> wildcardClass9 = orderDirection8.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.890349128221754d, (java.lang.Number) 0.17453292519943295d, (int) '4', orderDirection8, false);
        int int12 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number17 = nonMonotonousSequenceException16.getArgument();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        java.lang.Number number19 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 10 + "'", number17.equals(10));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 10.0f + "'", number18.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 10 + "'", number19.equals(10));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9009256457704354d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1074790380);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.795391484163137d + "'", double1 == 20.795391484163137d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        int int2 = org.apache.commons.math.util.FastMath.max(1326442914, (-7227194));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1326442914 + "'", int2 == 1326442914);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1386101689);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3861016890000002E9d + "'", double1 == 1.3861016890000002E9d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-23.898454622449663d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1055123539), 1079525376L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2134648915L) + "'", long2 == (-2134648915L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) '#', (-3708780787583609177L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3708780787583609142L) + "'", long2 == (-3708780787583609142L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(16L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 132.0d, (java.lang.Number) 0.0d, (-132), orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        java.lang.Class<?> wildcardClass9 = orderDirection8.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 96549157373046880L, (java.lang.Number) (-0.9300727311045811d), 0, orderDirection8, false);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (-0.93 > 96,549,157,373,046,880)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (-0.93 > 96,549,157,373,046,880)"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1386122689, 1074790410, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 74);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        double[] doubleArray23 = new double[] { (byte) -1 };
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray25);
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray25);
        double[] doubleArray35 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection37, false);
        double[] doubleArray41 = new double[] { (byte) -1 };
        double[] doubleArray43 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray43);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray41);
        double[] doubleArray48 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48, orderDirection50, false);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray48);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 31 + "'", int32 == 31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.052166389484759d, (java.lang.Number) Double.NEGATIVE_INFINITY, 35, orderDirection19, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number8, (java.lang.Number) 45L, (-1074790400), orderDirection19, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection19, true);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection32, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 10.0f + "'", number18.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1064753152), (float) 1076232192);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.06475315E9f) + "'", float2 == (-1.06475315E9f));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-21.488538654488526d), (double) (-805.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-806.8867020519367d) + "'", double2 == (-806.8867020519367d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 1563677856);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 1563677856);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 32);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1074790380);
        try {
            java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1064753020, 4074);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException11.getPrevious();
        java.lang.String str14 = nonMonotonousSequenceException11.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException11.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10 + "'", number20.equals(10));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-806.8867020519367d), (int) '#', 1074790410);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.019021828530846E59d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 1074790410);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        double double2 = org.apache.commons.math.util.FastMath.max(534.4916555247646d, 0.07177562623257451d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 534.4916555247646d + "'", double2 == 534.4916555247646d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0613084341780446E57d, (java.lang.Number) 4.1268741377911216d, (-48));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1563677856);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1074790399);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 96549157373046875L);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 630.2535746439055d + "'", double1 == 630.2535746439055d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1074790380, 1064753020);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.3754263876807227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(35L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1064753020, (-456387814));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray26 = null;
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double[] doubleArray34 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection36, false);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray34);
        java.lang.Class<?> wildcardClass40 = doubleArray28.getClass();
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray28);
        java.lang.Class<?> wildcardClass42 = doubleArray28.getClass();
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray28);
        double[] doubleArray45 = new double[] { (byte) -1 };
        double[] doubleArray47 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray47);
        double[] doubleArray51 = new double[] { (byte) -1 };
        double[] doubleArray53 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray51);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        double[] doubleArray59 = new double[] { (byte) -1 };
        double[] doubleArray61 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray61);
        double[] doubleArray65 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray65);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray61);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 31 + "'", int68 == 31);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 156.36083630307883d, 0, orderDirection8, true);
        int int11 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        int[] intArray0 = new int[] {};
        int[] intArray3 = new int[] { ' ', (byte) 10 };
        int[] intArray8 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray8);
        int[] intArray12 = new int[] { ' ', (byte) 10 };
        int[] intArray17 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray12);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray12);
        int[] intArray23 = new int[] { ' ', (byte) 10 };
        int[] intArray28 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray28);
        int[] intArray36 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray23);
        int[] intArray42 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray49 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray49);
        int[] intArray52 = new int[] {};
        int[] intArray53 = new int[] {};
        int[] intArray56 = new int[] { ' ', (byte) 10 };
        int[] intArray61 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray61);
        int[] intArray65 = new int[] { ' ', (byte) 10 };
        int[] intArray70 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray65, intArray70);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray65);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray65);
        int[] intArray76 = new int[] { ' ', (byte) 10 };
        int[] intArray81 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray81);
        int[] intArray89 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int90 = org.apache.commons.math.util.MathUtils.distanceInf(intArray76, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray76);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray65);
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray65);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 68.8839603971781d + "'", double9 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 68.8839603971781d + "'", double18 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 68.8839603971781d + "'", double29 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1074790722 + "'", int50 == 1074790722);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 312 + "'", int51 == 312);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 68.8839603971781d + "'", double62 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 68.8839603971781d + "'", double71 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 68.8839603971781d + "'", double82 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 100 + "'", int90 == 100);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number10 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        java.lang.Class<?> wildcardClass12 = orderDirection11.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection11, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.15081361216741d, (java.lang.Number) 1.9833289421008786d, (int) (short) -1, orderDirection11, true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0f + "'", number10.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1.0674176E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-8.973031469999999E8d), (double) 358);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 356.27568531036377d + "'", double2 == 356.27568531036377d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.1362304560964502d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray12 = new int[] { ' ', (byte) 10 };
        int[] intArray17 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray17);
        int[] intArray21 = new int[] { ' ', (byte) 10 };
        int[] intArray26 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray21);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray21);
        int[] intArray32 = new int[] { ' ', (byte) 10 };
        int[] intArray37 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray37);
        int[] intArray45 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray32);
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray32);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 68.8839603971781d + "'", double18 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 68.8839603971781d + "'", double27 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 68.8839603971781d + "'", double38 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 100, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3100 + "'", int2 == 3100);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 0, 1074790410L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790410L + "'", long2 == 1074790410L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 362L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.195443362911738E156d + "'", double1 == 8.195443362911738E156d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1000.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1368683772161603E-13d + "'", double1 == 1.1368683772161603E-13d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1825403137, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.23528072998266963d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6173462100539796d) + "'", double1 == (-0.6173462100539796d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 94640.0f, (double) 7.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 94639.99999999999d + "'", double2 == 94639.99999999999d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1079525376, 0.853988047997524d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.079525376E9d + "'", double2 == 1.079525376E9d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(3L, (-7518480283977535271L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7518480283977535268L) + "'", long2 == (-7518480283977535268L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-897303147), 1032847395);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.762747174039086d + "'", double1 == 1.762747174039086d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.019828363307654893d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5509666639575672d + "'", double1 == 1.5509666639575672d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-841025708) + "'", int1 == (-841025708));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 7227194);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 1);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(96549157373046890L, (long) 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2027532304833984690L + "'", long2 == 2027532304833984690L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection27, false);
        double[] doubleArray31 = new double[] { (byte) -1 };
        double[] doubleArray33 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray33);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray31);
        double[] doubleArray39 = null;
        double[] doubleArray41 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection43, false);
        double[] doubleArray47 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection49, false);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray47);
        java.lang.Class<?> wildcardClass53 = doubleArray41.getClass();
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray41);
        double[] doubleArray56 = new double[] { (byte) -1 };
        double[] doubleArray58 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray58);
        double[] doubleArray62 = new double[] { (byte) -1 };
        double[] doubleArray64 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray64);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray62);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray58);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray41);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray41);
        double[] doubleArray73 = new double[] { (byte) -1 };
        double[] doubleArray75 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray73, doubleArray75);
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 31 + "'", int78 == 31);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        int int2 = org.apache.commons.math.util.FastMath.min(830895890, 20990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20990 + "'", int2 == 20990);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1067417600, (-799641669));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(83462400L, (long) (-242306127));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4347L + "'", long2 == 4347L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35.0f, 1.0000434161084752d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1067418535L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.4476577640910703d, 132, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        float float2 = org.apache.commons.math.util.MathUtils.round(1.03284736E9f, 1386101689);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        long long2 = org.apache.commons.math.util.MathUtils.pow(5480065050160172033L, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5480065050160172033L + "'", long2 == 5480065050160172033L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        double double1 = org.apache.commons.math.util.FastMath.atan(30.999999999999964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5385494443596426d + "'", double1 == 1.5385494443596426d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(358);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.9036922050915067d), 4.9E-324d, 1.5460026354794412d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray4 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection19, false);
        double[] doubleArray23 = new double[] { (byte) -1 };
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray25);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false);
        double[] doubleArray37 = new double[] { (byte) -1 };
        double[] doubleArray39 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray37);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray37);
        double[] doubleArray45 = null;
        double[] doubleArray47 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection49, false);
        double[] doubleArray53 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection55, false);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray53);
        java.lang.Class<?> wildcardClass59 = doubleArray47.getClass();
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray47);
        double[] doubleArray62 = new double[] { (byte) -1 };
        double[] doubleArray64 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray64);
        double[] doubleArray68 = new double[] { (byte) -1 };
        double[] doubleArray70 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray70);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray68);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray64);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray47);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray47);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray47);
        double[] doubleArray80 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray80);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection82 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray80, orderDirection82, false);
        double[] doubleArray86 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection88 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86, orderDirection88, false);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray80, doubleArray86);
        java.lang.Class<?> wildcardClass92 = doubleArray80.getClass();
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        double[] doubleArray23 = new double[] { (byte) -1 };
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray25);
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray25);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1074790380, (int) (short) 1, (-1079504351));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-118448423));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.18448424E8f + "'", float1 == 1.18448424E8f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1386101632), (double) (short) -1, 0.9616411655135638d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 132L, number1, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 132L + "'", number4.equals(132L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 74);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 184);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.220355825078324d + "'", double1 == 5.220355825078324d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.7276321353997605d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2766121739048544d + "'", double1 == 1.2766121739048544d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        double double1 = org.apache.commons.math.util.FastMath.signum(9.090870207939166E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.7182818247238476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 96549157373046880L, (int) (short) 1, orderDirection8, false);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 96549157373046880L + "'", number11.equals(96549157373046880L));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 96549157373046880L + "'", number12.equals(96549157373046880L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 156.36083630307883d, 0, orderDirection8, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number15 = nonMonotonousSequenceException14.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException14.getPrevious();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.String str18 = nonMonotonousSequenceException14.toString();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        java.lang.String str20 = nonMonotonousSequenceException14.toString();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10 + "'", number15.equals(10));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10.0f + "'", number16.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 718546557);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 718546557L + "'", long1 == 718546557L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int2 = org.apache.commons.math.util.FastMath.max(1074790410, (-790417529));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790410 + "'", int2 == 1074790410);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3596375654124956d + "'", double1 == 0.3596375654124956d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 47510973960L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.277373732600303d + "'", double1 == 25.277373732600303d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1032847225L, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963258266993d + "'", double2 == 1.5707963258266993d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 1074790380);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790380L) + "'", long2 == (-1074790380L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.3754263876807227d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.7330382858376184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8227781018288688d + "'", double1 == 0.8227781018288688d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        double double2 = org.apache.commons.math.util.FastMath.min(0.3737716494901388d, 3.257772911327683E28d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3737716494901388d + "'", double2 == 0.3737716494901388d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1032847325, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 663106714341011457L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 663106714341011456L + "'", long1 == 663106714341011456L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        int[] intArray2 = new int[] { ' ', (byte) 10 };
        int[] intArray7 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray7);
        java.lang.Class<?> wildcardClass9 = intArray2.getClass();
        int[] intArray13 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray20 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray13);
        int[] intArray23 = new int[] {};
        int[] intArray26 = new int[] { ' ', (byte) 10 };
        int[] intArray31 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray31);
        int[] intArray35 = new int[] { ' ', (byte) 10 };
        int[] intArray40 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray35);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray26);
        int[] intArray44 = new int[] {};
        int[] intArray47 = new int[] { ' ', (byte) 10 };
        int[] intArray52 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray52);
        int[] intArray56 = new int[] { ' ', (byte) 10 };
        int[] intArray61 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray61);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray56);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray56);
        int[] intArray67 = new int[] { ' ', (byte) 10 };
        int[] intArray72 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray72);
        int[] intArray80 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray67, intArray80);
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray67);
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray56);
        double double84 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray26);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 68.8839603971781d + "'", double8 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1074790722 + "'", int21 == 1074790722);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1074790410 + "'", int22 == 1074790410);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 68.8839603971781d + "'", double32 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 68.8839603971781d + "'", double41 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 68.8839603971781d + "'", double53 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 68.8839603971781d + "'", double62 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 68.8839603971781d + "'", double73 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        double double1 = org.apache.commons.math.util.FastMath.asinh(5.052166389484759d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.32261802886362d + "'", double1 == 2.32261802886362d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-213909503));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.1263771168937977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1d + "'", double1 == 2.1d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        double double2 = org.apache.commons.math.util.FastMath.min(1.335686945314077E22d, 4.80621738397436E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.80621738397436E-6d + "'", double2 == 4.80621738397436E-6d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1067417600, 7227194);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 0, (int) ' ', orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.7853981154716825d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999999904148473d + "'", double1 == 0.999999904148473d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1386122689L, 0.9999999994421064d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3861226727220185E9d + "'", double2 == 1.3861226727220185E9d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0747904100000021E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.074790411E9d + "'", double1 == 1.074790411E9d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-53.0d), (-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.0613084341780446E57d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0613084341780446E57d + "'", double1 == 1.0613084341780446E57d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(2027532304833984690L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2027532304833984690L + "'", long2 == 2027532304833984690L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        double double1 = org.apache.commons.math.util.FastMath.cos(34.751646946819406d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.981216307773556d) + "'", double1 == (-0.981216307773556d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(1386102689L, 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.718281828459045d, 0.0d, 1.7345175425633101d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.3805346802806d + "'", double1 == 2979.3805346802806d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) -1, 1079525341);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.074790411E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        double double2 = org.apache.commons.math.util.FastMath.max(23.849755852798292d, (-1.5274985276365913d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 23.849755852798292d + "'", double2 == 23.849755852798292d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.9165215479156338d), 320);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9165215479156338d) + "'", double2 == (-0.9165215479156338d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        int int2 = org.apache.commons.math.util.FastMath.max(704643071, 897303147);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 897303147 + "'", int2 == 897303147);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1032847325);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 1563677856);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 1032847325L);
        try {
            java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (-1064753152));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        int int2 = org.apache.commons.math.util.FastMath.min(1074790722, 312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 312 + "'", int2 == 312);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1032847395, 1055123539L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1631124539 + "'", int2 == 1631124539);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1074790380);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(50590358L, 68L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1720072172L + "'", long2 == 1720072172L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.7935607365300265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 167);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 167L + "'", long1 == 167L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        int int1 = org.apache.commons.math.util.FastMath.abs(3100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3100 + "'", int1 == 3100);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.5707963258266993d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1811449240 + "'", int1 == 1811449240);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        double double2 = org.apache.commons.math.util.MathUtils.log(5.298292365610485d, 0.6173390205196068d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2892775593915794d) + "'", double2 == (-0.2892775593915794d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.393606884554982d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(68.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 4074);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4074L + "'", long2 == 4074L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 456387814, 7L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 456387807L + "'", long2 == 456387807L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(230.97419898843916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.135563990100564d + "'", double1 == 6.135563990100564d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-869579111));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-5.424641371532627E-7d), (java.lang.Number) 6.080849404003989E58d, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (60,808,494,040,039,890,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (60,808,494,040,039,890,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-7L), (float) 13566);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13566.0f + "'", float2 == 13566.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.4562840656627033d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5781985931267138d + "'", double1 == 0.5781985931267138d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.1075066744876776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1067417500);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.48165519726812d + "'", double1 == 21.48165519726812d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 5480065050160172033L, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-456387814L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.56387808E8f + "'", float1 == 4.56387808E8f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        java.lang.Class<?> wildcardClass15 = orderDirection14.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 488887457, (java.lang.Number) 3.637978807091713E-12d, (-1067417600), orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-790417455), number1, 31, orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number26 = nonMonotonousSequenceException25.getArgument();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        java.lang.Number number28 = nonMonotonousSequenceException25.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException25.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number40 = nonMonotonousSequenceException39.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException39.getDirection();
        java.lang.Class<?> wildcardClass42 = orderDirection41.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection41, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 488887457, (java.lang.Number) 3.637978807091713E-12d, (-1067417600), orderDirection41, false);
        nonMonotonousSequenceException25.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException46);
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException46);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10 + "'", number26.equals(10));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10.0f + "'", number27.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10.0f + "'", number28.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 10.0f + "'", number40.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        double double2 = org.apache.commons.math.util.MathUtils.round((-8.973031469999999E8d), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.97303147E8d) + "'", double2 == (-8.97303147E8d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) (-252951790));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0747904100000021E9d, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.074790410000002E9d + "'", double2 == 1.074790410000002E9d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 2146435072);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray8 = new double[] { (byte) -1 };
        double[] doubleArray10 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray10);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray14);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray10);
        double[] doubleArray22 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection24, false);
        double[] doubleArray28 = new double[] { (byte) -1 };
        double[] doubleArray30 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray28);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        double[] doubleArray36 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection38, false);
        double[] doubleArray42 = new double[] { (byte) -1 };
        double[] doubleArray44 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray44);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray42);
        double[] doubleArray50 = null;
        double[] doubleArray52 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection54, false);
        double[] doubleArray58 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58, orderDirection60, false);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray58);
        java.lang.Class<?> wildcardClass64 = doubleArray52.getClass();
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray52);
        double[] doubleArray67 = new double[] { (byte) -1 };
        double[] doubleArray69 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray69);
        double[] doubleArray73 = new double[] { (byte) -1 };
        double[] doubleArray75 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray73, doubleArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray73);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray69);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray52);
        double[] doubleArray83 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray83);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection85 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray83, orderDirection85, false);
        double[] doubleArray89 = new double[] { (byte) -1 };
        double[] doubleArray91 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray91);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray89, doubleArray91);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray83, doubleArray89);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray89);
        double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray42, doubleArray89);
        double double97 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 1.0d + "'", double97 == 1.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1720072172L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 5, 4074L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4079L + "'", long2 == 4079L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1563677856);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1074790399);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 96549157373046875L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 1083129856);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger20);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger27);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 1563677856);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 1074790399);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger28);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (int) '4');
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0L);
        java.math.BigInteger bigInteger40 = null;
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 0L);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger42);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 1032847325);
        java.math.BigInteger bigInteger46 = null;
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, 0L);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 0L);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, bigInteger51);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, 1563677856);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, bigInteger52);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.String str23 = nonMonotonousSequenceException19.toString();
        boolean boolean24 = nonMonotonousSequenceException19.getStrict();
        boolean boolean25 = nonMonotonousSequenceException19.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection26, true);
        java.lang.Class<?> wildcardClass29 = orderDirection26.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10 + "'", number20.equals(10));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0f + "'", number9.equals(10.0f));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        double double2 = org.apache.commons.math.util.FastMath.min(0.04742161873168638d, 1890760.7239317165d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.04742161873168638d + "'", double2 == 0.04742161873168638d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 41, 1032847225L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 41L + "'", long2 == 41L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(21.49293449538204d, 110.0d, 51.61923715774417d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-252951790L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) 618402555);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 618402555L + "'", long2 == 618402555L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (0 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (0 >= 10)"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 52, (long) (-2147483648));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 132, 456387807L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 60243190524L + "'", long2 == 60243190524L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray4 = new int[] { ' ', (byte) 10 };
        int[] intArray9 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray9);
        int[] intArray13 = new int[] { ' ', (byte) 10 };
        int[] intArray18 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray18);
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray13);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray13);
        int[] intArray24 = new int[] { ' ', (byte) 10 };
        int[] intArray29 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray29);
        int[] intArray37 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray24);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray13);
        int[] intArray41 = new int[] {};
        int[] intArray44 = new int[] { ' ', (byte) 10 };
        int[] intArray49 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray49);
        int[] intArray53 = new int[] { ' ', (byte) 10 };
        int[] intArray58 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray53);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray53);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray41);
        java.lang.Class<?> wildcardClass63 = intArray0.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 68.8839603971781d + "'", double10 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 68.8839603971781d + "'", double19 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 68.8839603971781d + "'", double30 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 68.8839603971781d + "'", double50 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 68.8839603971781d + "'", double59 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(wildcardClass63);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray4 = null;
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double[] doubleArray13 = new double[] { (byte) -1 };
        double[] doubleArray15 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray15);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray13);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        double[] doubleArray21 = new double[] { (byte) -1 };
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray23);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray23);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(11013.232920103304d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.232920103303d + "'", double2 == 11013.232920103303d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        double double1 = org.apache.commons.math.util.FastMath.exp(23.849755852798292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2793832975715534E10d + "'", double1 == 2.2793832975715534E10d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-704643071), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-704643071L) + "'", long2 == (-704643071L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 132);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5632207141437011d + "'", double1 == 1.5632207141437011d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-305.8945329361796d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1074790410);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1, 1079525376L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1079525375L) + "'", long2 == (-1079525375L));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-49576673280L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-49576673280L) + "'", long2 == (-49576673280L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (0 >= 10)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (0 >= 10)"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1563677856);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger16);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 1563677856);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 1074790399);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1074790400L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = new double[] { (byte) -1 };
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray31);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray29);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray29);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection43, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        double[] doubleArray48 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray38);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1074790369) + "'", int53 == (-1074790369));
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.2825359543734787d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2825359543734787d + "'", double1 == 1.2825359543734787d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.04742161873168638d, (java.lang.Number) 1.5707963260734488d, 322);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.00000000000001d, (java.lang.Number) Double.NaN, 10);
        int int8 = nonMonotonousSequenceException7.getIndex();
        java.lang.Number number9 = nonMonotonousSequenceException7.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException7.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100.00000000000001d + "'", number9.equals(100.00000000000001d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        double double1 = org.apache.commons.math.util.FastMath.atan(11.336474641648001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.482813214212472d + "'", double1 == 1.482813214212472d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) ' ', 2.2924316695611777d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5840734641020688d + "'", double2 == 0.5840734641020688d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1563677856);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1074790399);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 96549157373046875L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 1563677856);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-456387814));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.700888353141718E44d + "'", double1 == 7.700888353141718E44d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        double double1 = org.apache.commons.math.util.FastMath.signum((-2.7813423231340017E-308d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        int int2 = org.apache.commons.math.util.FastMath.min(1074790399, 1074790410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790399 + "'", int2 == 1074790399);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1.38610163E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1032847225L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 8023796055476540416L, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.2180227413180416E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2180227413180416E18d + "'", double1 == 2.2180227413180416E18d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1079525375L), (long) 1032847360);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-46678015L) + "'", long2 == (-46678015L));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.257772911327683E28d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.138302973034538E116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 269.88959964617754d + "'", double1 == 269.88959964617754d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1775275193, (-1386101632));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 76531041);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(32, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 352 + "'", int2 == 352);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        long long2 = org.apache.commons.math.util.FastMath.max(7486832605L, (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7486832605L + "'", long2 == 7486832605L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(230.97419898843916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        double double1 = org.apache.commons.math.util.FastMath.signum(21.49293449538204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        int int2 = org.apache.commons.math.util.FastMath.min(1074790369, (-2147483648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 100, (-1067417600));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-456387814L), 0.9999999994421064d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-790417529));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double[] doubleArray13 = new double[] { (byte) -1 };
        double[] doubleArray15 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray15);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray13);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        double[] doubleArray21 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection23, false);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray27);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray27);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number51 = nonMonotonousSequenceException50.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException50.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection52, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection52, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection52, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7876260917919922d, (java.lang.Number) 100.00000000000001d, (-1221515391), orderDirection52, true);
        java.lang.Throwable[] throwableArray61 = nonMonotonousSequenceException60.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number66 = nonMonotonousSequenceException65.getArgument();
        java.lang.Number number67 = nonMonotonousSequenceException65.getPrevious();
        java.lang.String str68 = nonMonotonousSequenceException65.toString();
        java.lang.Number number69 = nonMonotonousSequenceException65.getArgument();
        nonMonotonousSequenceException60.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = nonMonotonousSequenceException65.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.6543768726206873d), (java.lang.Number) 21.488538654488526d, 618402555, orderDirection71, false);
        java.lang.Number number74 = nonMonotonousSequenceException73.getPrevious();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 31 + "'", int43 == 31);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 10.0f + "'", number51.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 10 + "'", number66.equals(10));
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 10.0f + "'", number67.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str68.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 10 + "'", number69.equals(10));
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection71.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + 21.488538654488526d + "'", number74.equals(21.488538654488526d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 7227194);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 42);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (-35));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0025215808021860583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05021534429022725d + "'", double1 == 0.05021534429022725d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 1.288004850734253d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1055123539), (-1.0674176E9f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0674176E9f) + "'", float2 == (-1.0674176E9f));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(488887457, 1507257537);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1362304560964502d, 0.4391749470972324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1362304560964502d + "'", double2 == 1.1362304560964502d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1563677856);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1074790399);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 96549157373046875L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) '4');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException11.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number15 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Number number22 = nonMonotonousSequenceException19.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException19.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Class<?> wildcardClass25 = nonMonotonousSequenceException19.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10 + "'", number20.equals(10));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0f + "'", number22.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1055123539L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.055123539E9d + "'", double1 == 1.055123539E9d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        int int2 = org.apache.commons.math.util.FastMath.min(1076101120, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1386101689, (-2147483648));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = new double[] { (byte) -1 };
        double[] doubleArray10 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray10);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double[] doubleArray21 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray21);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray27 = null;
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection31, false);
        double[] doubleArray35 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection37, false);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray35);
        java.lang.Class<?> wildcardClass41 = doubleArray29.getClass();
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        java.lang.Class<?> wildcardClass43 = doubleArray29.getClass();
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray29);
        try {
            double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 31 + "'", int26 == 31);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.074790368999999E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection16, false);
        double[] doubleArray20 = new double[] { (byte) -1 };
        double[] doubleArray22 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray22);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double[] doubleArray34 = new double[] { (byte) -1 };
        double[] doubleArray36 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray34);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        double[] doubleArray44 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection46, false);
        double[] doubleArray50 = new double[] { (byte) -1 };
        double[] doubleArray52 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray52);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray50);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        double[] doubleArray58 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58, orderDirection60, false);
        double[] doubleArray64 = new double[] { (byte) -1 };
        double[] doubleArray66 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray66);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray64);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray64);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray64);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException83 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number84 = nonMonotonousSequenceException83.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection85 = nonMonotonousSequenceException83.getDirection();
        java.lang.Class<?> wildcardClass86 = orderDirection85.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.118248651196143E224d, (java.lang.Number) 0.9999999994421064d, 13566, orderDirection85, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException90 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 488887457, (java.lang.Number) 3.637978807091713E-12d, (-1067417600), orderDirection85, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection85, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection85, false);
        double double95 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + number84 + "' != '" + 10.0f + "'", number84.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection85 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection85.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 1.0d + "'", double95 == 1.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11.7910068511973d, (-8.973031469999999E8d), 2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1074790410L, (long) 1137893781);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 407665774472480070L + "'", long2 == 407665774472480070L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException3.getClass();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        double double1 = org.apache.commons.math.util.FastMath.sinh(635.4616044236789d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.74720806645828E275d + "'", double1 == 4.74720806645828E275d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-869579111), (long) 322);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 322L + "'", long2 == 322L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.7996809277222553E101d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray12 = new double[] { (byte) -1 };
        double[] doubleArray14 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection17, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        double[] doubleArray22 = new double[] { (byte) -1 };
        double[] doubleArray24 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray24);
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray28);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray28);
        double[] doubleArray34 = new double[] { (byte) -1 };
        double[] doubleArray36 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray36);
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray40);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 31 + "'", int43 == 31);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        double double2 = org.apache.commons.math.util.FastMath.min((-23.898454622449663d), 11013.232920103303d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-23.898454622449663d) + "'", double2 == (-23.898454622449663d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.234417145184986d, (java.lang.Number) 0.705429428472229d, 1563677856);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(34.751646946819406d, 269.88959964617754d, (-4.122307281809905E-9d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 3628800L, 42);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        java.lang.Class<?> wildcardClass7 = number6.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 42 + "'", int4 == 42);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.6483608274590866d + "'", number6.equals(0.6483608274590866d));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1631124539, 2146435072);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 312);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1081311232 + "'", int1 == 1081311232);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.17453292519943295d, (double) 924);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8888844493909296E-4d + "'", double2 == 1.8888844493909296E-4d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        double double1 = org.apache.commons.math.util.FastMath.floor(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        double double1 = org.apache.commons.math.util.FastMath.asin(2979.3805346802806d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 132L, number1, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.052166389484759d, (java.lang.Number) Double.NEGATIVE_INFINITY, 35, orderDirection13, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException15.getDirection();
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException15.getClass();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 132L + "'", number4.equals(132L));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10.0f + "'", number12.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1076101120, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 323);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        double double1 = org.apache.commons.math.util.FastMath.signum((-8.973031469999999E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 69.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 167);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-1672638911));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 358);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 358.00000000000006d + "'", double1 == 358.00000000000006d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(20990);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 187904.2064981895d + "'", double1 == 187904.2064981895d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2.13909504E8f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33000L, (java.lang.Number) (-0.0037035886157206215d), 31);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.052166389484759d, (java.lang.Number) Double.NEGATIVE_INFINITY, 35, orderDirection13, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean17 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.0037035886157206215d) + "'", number4.equals((-0.0037035886157206215d)));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10.0f + "'", number12.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int int1 = org.apache.commons.math.util.FastMath.abs(1386101589);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1386101589 + "'", int1 == 1386101589);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        long long1 = org.apache.commons.math.util.MathUtils.sign(935L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-805L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-14.049900478554353d) + "'", double1 == (-14.049900478554353d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-7227194));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.11042278791613983d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11675011911931638d + "'", double1 == 0.11675011911931638d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1076101120);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07610112E9f + "'", float1 == 1.07610112E9f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1074790399);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1074790400 + "'", int1 == 1074790400);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 2704);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1055123539L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1055123520 + "'", int1 == 1055123520);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray13);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray17);
        double[] doubleArray22 = null;
        try {
            double double23 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 96549157373046875L, 4.5638780800000006E8d, 1.52587890625E-5d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException11.getPrevious();
        java.lang.String str14 = nonMonotonousSequenceException11.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str24 = nonMonotonousSequenceException11.toString();
        java.lang.Number number25 = nonMonotonousSequenceException11.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10 + "'", number20.equals(10));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 10 + "'", number25.equals(10));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 7227194);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 42);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (byte) 10);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 1563677856);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 1074790399);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger26);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 869579136);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.03114752988986843d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1074790400, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 1.0613084341780446E57d, (int) (short) -1);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        int int12 = nonMonotonousSequenceException9.getIndex();
        boolean boolean13 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number18 = nonMonotonousSequenceException17.getArgument();
        java.lang.Number number19 = nonMonotonousSequenceException17.getPrevious();
        java.lang.String str20 = nonMonotonousSequenceException17.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number26 = nonMonotonousSequenceException25.getArgument();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.String str30 = nonMonotonousSequenceException17.toString();
        int int31 = nonMonotonousSequenceException17.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.Throwable[] throwableArray33 = nonMonotonousSequenceException17.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10 + "'", number10.equals(10));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10.0f + "'", number11.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 10 + "'", number18.equals(10));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 10.0f + "'", number19.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10 + "'", number26.equals(10));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10.0f + "'", number27.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str30.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(throwableArray33);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 7227194);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 42);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (byte) 10);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 1563677856);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 184);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.23851102429896254d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 953989608);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 953989632 + "'", int1 == 953989632);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray14 = null;
        try {
            double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-805L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6833057347140384d) + "'", double1 == (-0.6833057347140384d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        double double1 = org.apache.commons.math.util.FastMath.log(1.7345175425633101d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.55072930127869d + "'", double1 == 0.55072930127869d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException11.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException11.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        java.lang.String str22 = nonMonotonousSequenceException19.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number28 = nonMonotonousSequenceException27.getArgument();
        java.lang.Number number29 = nonMonotonousSequenceException27.getPrevious();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Number number31 = nonMonotonousSequenceException19.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number36 = nonMonotonousSequenceException35.getArgument();
        java.lang.Number number37 = nonMonotonousSequenceException35.getPrevious();
        java.lang.Number number38 = nonMonotonousSequenceException35.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = nonMonotonousSequenceException35.getDirection();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number42 = nonMonotonousSequenceException19.getPrevious();
        boolean boolean43 = nonMonotonousSequenceException19.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10 + "'", number20.equals(10));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10 + "'", number28.equals(10));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 10.0f + "'", number29.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 10.0f + "'", number31.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 10 + "'", number36.equals(10));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 10.0f + "'", number37.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 10.0f + "'", number38.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 10.0f + "'", number42.equals(10.0f));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(21, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 8L, 323);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1563677856);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1074790399);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger13);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 869579136);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 1032847225L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(23L, (long) 320);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 343L + "'", long2 == 343L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 31, 21L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 25.277373732600303d, 1067417600);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        double[] doubleArray7 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double[] doubleArray13 = new double[] { (byte) -1 };
        double[] doubleArray15 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray15);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray13);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        double[] doubleArray21 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection23, false);
        double[] doubleArray27 = new double[] { (byte) -1 };
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray27);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray27);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray38 = new double[] { (byte) -1 };
        double[] doubleArray40 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray40);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number51 = nonMonotonousSequenceException50.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException50.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection52, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection52, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection52, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7876260917919922d, (java.lang.Number) 100.00000000000001d, (-1221515391), orderDirection52, true);
        java.lang.Throwable[] throwableArray61 = nonMonotonousSequenceException60.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number66 = nonMonotonousSequenceException65.getArgument();
        java.lang.Number number67 = nonMonotonousSequenceException65.getPrevious();
        java.lang.String str68 = nonMonotonousSequenceException65.toString();
        java.lang.Number number69 = nonMonotonousSequenceException65.getArgument();
        nonMonotonousSequenceException60.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = nonMonotonousSequenceException65.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.6543768726206873d), (java.lang.Number) 21.488538654488526d, 618402555, orderDirection71, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = nonMonotonousSequenceException73.getDirection();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 31 + "'", int43 == 31);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 10.0f + "'", number51.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 10 + "'", number66.equals(10));
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 10.0f + "'", number67.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str68.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 10 + "'", number69.equals(10));
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection71.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.40041659665806064E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.23851102429896254d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1019069665) + "'", int1 == (-1019069665));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1563677856);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 1563677856);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 32);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 718503581);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.569554091409037d, 21000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.387335627076591E156d + "'", double2 == 5.387335627076591E156d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 352);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9899882421792622d + "'", double1 == 0.9899882421792622d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 362L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, 1825403137L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(2704.0f, 83824, (-1019069665));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963271409564d), (java.lang.Number) 5.052166389484759d, 20990);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963271409564d) + "'", number4.equals((-1.5707963271409564d)));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1386102689L, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1386102786L + "'", long2 == 1386102786L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int[] intArray3 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray10 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray14 = new int[] { ' ', (byte) 10 };
        int[] intArray19 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray19);
        int[] intArray23 = new int[] { ' ', (byte) 10 };
        int[] intArray28 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray23);
        int[] intArray34 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray41 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray41);
        int[] intArray45 = new int[] {};
        int[] intArray48 = new int[] { ' ', (byte) 10 };
        int[] intArray53 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray53);
        int[] intArray57 = new int[] { ' ', (byte) 10 };
        int[] intArray62 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray57);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray57);
        int[] intArray68 = new int[] { ' ', (byte) 10 };
        int[] intArray73 = new int[] { (byte) 100, (byte) -1, (byte) 0, (byte) 100 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray73);
        int[] intArray81 = new int[] { 132, (byte) 10, (short) 0, 100, (byte) 10, 100 };
        int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray68, intArray81);
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray68);
        int[] intArray87 = new int[] { (short) 100, (-1074790400), 1 };
        int[] intArray94 = new int[] { (-132), 322, 20990, 1386101689, (-1221515391), 42 };
        int int95 = org.apache.commons.math.util.MathUtils.distanceInf(intArray87, intArray94);
        int int96 = org.apache.commons.math.util.MathUtils.distanceInf(intArray68, intArray94);
        try {
            double double97 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1074790722 + "'", int11 == 1074790722);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 68.8839603971781d + "'", double20 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 68.8839603971781d + "'", double29 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1074790722 + "'", int42 == 1074790722);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 476 + "'", int43 == 476);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0747907222049663E9d + "'", double44 == 1.0747907222049663E9d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 68.8839603971781d + "'", double54 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 68.8839603971781d + "'", double63 == 68.8839603971781d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 68.8839603971781d + "'", double74 == 68.8839603971781d);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 100 + "'", int82 == 100);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1074790722 + "'", int95 == 1074790722);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 312 + "'", int96 == 312);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-897303147), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(456387814, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray9 = new double[] { (byte) -1 };
        double[] doubleArray11 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray11);
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray15);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8E-322d + "'", double1 == 2.8E-322d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(718546557L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 718546557L + "'", long2 == 718546557L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection12, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray19);
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray23);
        double[] doubleArray29 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection31, false);
        double[] doubleArray35 = new double[] { (byte) -1 };
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray37);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray35);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray35);
        double[] doubleArray44 = new double[] { (byte) -1 };
        double[] doubleArray46 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        double[] doubleArray54 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray54);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray44);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 320.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.839903786706788d + "'", double1 == 6.839903786706788d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1386101589);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1802197106) + "'", int1 == (-1802197106));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-2.13909504E8f), 5.052166389484759d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.1390950399999997E8d) + "'", double2 == (-2.1390950399999997E8d));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 8023796055476540162L, (-790417455), (-799641669));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-805.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-897303147));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.13248690517083d + "'", double1 == 2.13248690517083d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.1446624014950488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1386101689L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.386101689E9d + "'", double1 == 1.386101689E9d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 362L, 11.2246186123224d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.41043032631993d + "'", double2 == 0.41043032631993d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray4 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection19, false);
        double[] doubleArray23 = new double[] { (byte) -1 };
        double[] doubleArray25 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray25);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false);
        double[] doubleArray37 = new double[] { (byte) -1 };
        double[] doubleArray39 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray37);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray37);
        double[] doubleArray45 = null;
        double[] doubleArray47 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection49, false);
        double[] doubleArray53 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection55, false);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray53);
        java.lang.Class<?> wildcardClass59 = doubleArray47.getClass();
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray47);
        double[] doubleArray62 = new double[] { (byte) -1 };
        double[] doubleArray64 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray64);
        double[] doubleArray68 = new double[] { (byte) -1 };
        double[] doubleArray70 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray70);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray68);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray64);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray47);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray47);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray47);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException82 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = nonMonotonousSequenceException82.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection83, false);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection83.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 31 + "'", int86 == 31);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        long long2 = org.apache.commons.math.util.MathUtils.pow(45L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        double[] doubleArray4 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = new double[] { (byte) -1 };
        double[] doubleArray12 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        double[] doubleArray18 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection20, false);
        double[] doubleArray24 = new double[] { (byte) -1 };
        double[] doubleArray26 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray26);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray35 = new double[] { (byte) -1 };
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray37);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number48 = nonMonotonousSequenceException47.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = nonMonotonousSequenceException47.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection49, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection49, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7876260917919922d, (java.lang.Number) 100.00000000000001d, (-1221515391), orderDirection49, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = nonMonotonousSequenceException57.getDirection();
        boolean boolean59 = nonMonotonousSequenceException57.getStrict();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 10.0f + "'", number48.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        int int2 = org.apache.commons.math.util.FastMath.max((-1802197106), 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1386101632));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (10 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1074790337L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0747903369999998E9d) + "'", double1 == (-1.0747903369999998E9d));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 897303147);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray15 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection17, false);
        double[] doubleArray21 = new double[] { (byte) -1 };
        double[] doubleArray23 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray21);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false);
        double[] doubleArray37 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection39, false);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray37);
        java.lang.Class<?> wildcardClass43 = doubleArray31.getClass();
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray31);
        double[] doubleArray46 = new double[] { (byte) -1 };
        double[] doubleArray48 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray48);
        double[] doubleArray52 = new double[] { (byte) -1 };
        double[] doubleArray54 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray54);
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray52);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray48);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray31);
        double[] doubleArray62 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray62);
        double[] doubleArray67 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67, orderDirection69, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67);
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 31 + "'", int73 == 31);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        double[] doubleArray1 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray16);
        double[] doubleArray20 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray26 = new double[] { (byte) -1 };
        double[] doubleArray28 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray28);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 10.0f, 0);
        java.lang.Number number39 = nonMonotonousSequenceException38.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = nonMonotonousSequenceException38.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.080849404003989E58d, (java.lang.Number) 0.17453292519943295d, (-1), orderDirection40, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection40, true);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray28);
        double[] doubleArray47 = new double[] { (byte) -1 };
        double[] doubleArray49 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection52, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        double[] doubleArray57 = new double[] { (byte) -1 };
        double[] doubleArray59 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray59);
        double[] doubleArray63 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray63);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray63);
        double[] doubleArray69 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection71, false);
        double[] doubleArray75 = new double[] { (byte) -1 };
        double[] doubleArray77 = new double[] { (short) 0 };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray75, doubleArray77);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray75);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray75);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray75);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 31 + "'", int31 == 31);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 10.0f + "'", number39.equals(10.0f));
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.0d + "'", double83 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }
}

