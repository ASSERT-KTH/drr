import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double8 = randomDataImpl0.nextF((double) 8L, 22026.465794806718d);
//        int int11 = randomDataImpl0.nextBinomial(5, 0.579081227485662d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1551.6807392241983d) + "'", double5 == (-1551.6807392241983d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.5800276068259267d + "'", double8 == 2.5800276068259267d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (-1));
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.setSeed((long) '4');
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 100L);
        java.lang.Class<?> wildcardClass2 = notStrictlyPositiveException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((-0.0d), (double) 9.0f, 61326.09864298752d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.17453292519943295d, (double) 35.000004f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 32, (double) 1.0f, (double) (byte) 1);
        double double4 = fDistribution3.getNumeratorDegreesOfFreedom();
        double double6 = fDistribution3.probability(69.23939445067559d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextGaussian();
        byte[] byteArray20 = new byte[] { (byte) 100, (byte) 1, (byte) 1, (byte) 100, (byte) 0 };
        well19937c6.nextBytes(byteArray20);
        double double22 = well19937c6.nextGaussian();
        int int24 = well19937c6.nextInt((int) (short) 100);
        double double25 = well19937c6.nextGaussian();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.19208726106988616d) + "'", double14 == (-0.19208726106988616d));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0977237767437487d + "'", double22 == 1.0977237767437487d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 65 + "'", int24 == 65);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-0.20713550270884132d) + "'", double25 == (-0.20713550270884132d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        long long1 = org.apache.commons.math3.util.FastMath.round(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.926433545773006d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.16596472818899644d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        randomDataGenerator14.reSeedSecure(6L);
        double double22 = randomDataGenerator14.nextCauchy(1.323855013488585d, (double) 32);
        try {
            int int25 = randomDataGenerator14.nextInt(65, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (65) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.104676167044543d + "'", double22 == 5.104676167044543d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(0, (int) '4', 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 35 is smaller than, or equal to, the minimum (52)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 3.883769450489952d, (java.lang.Number) 2.197178925104706d, (java.lang.Number) 0.7845295083467018d);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.7845295083467018d + "'", number5.equals(0.7845295083467018d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math3.util.FastMath.log(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int2 = org.apache.commons.math3.util.FastMath.max(65, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65 + "'", int2 == 65);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        boolean boolean1 = uniformRealDistribution0.isSupportConnected();
        double double2 = uniformRealDistribution0.getNumericalMean();
        boolean boolean3 = uniformRealDistribution0.isSupportLowerBoundInclusive();
        double double5 = uniformRealDistribution0.density(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        double double20 = randomDataGenerator14.nextGaussian(0.2775708784361457d, (double) '4');
        int int23 = randomDataGenerator14.nextInt((int) (short) -1, 6);
        int int26 = randomDataGenerator14.nextInt(1, (int) (short) 10);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-82.32202111518593d) + "'", double20 == (-82.32202111518593d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
//        double double1 = well19937c0.nextDouble();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2333410772653135d + "'", double1 == 0.2333410772653135d);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution18 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.17453292519943295d, (double) 13L, 0.0d);
        int int19 = well19937c6.nextInt();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2775708784361457d + "'", double14 == 0.2775708784361457d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1986701681) + "'", int19 == (-1986701681));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        boolean boolean1 = uniformRealDistribution0.isSupportConnected();
        uniformRealDistribution0.reseedRandomGenerator((long) (short) 10);
        double double4 = uniformRealDistribution0.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(0, (double) 3.0000002f, (-57.29577951308232d));
        double double4 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-57.29577951308232d) + "'", double4 == (-57.29577951308232d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        double double7 = randomDataImpl0.nextUniform(0.3057575137911129d, 1.5430806348152437d, false);
//        double double9 = randomDataImpl0.nextExponential(0.8486051191164776d);
//        double double13 = randomDataImpl0.nextUniform((double) (byte) -1, 0.9412667968004289d, true);
//        int[] intArray19 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c20 = new org.apache.commons.math3.random.Well19937c(intArray19);
//        org.apache.commons.math3.distribution.FDistribution fDistribution24 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c20, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        double double25 = fDistribution24.getSupportUpperBound();
//        double double27 = fDistribution24.density((double) 10.0f);
//        double double28 = fDistribution24.getSupportUpperBound();
//        try {
//            double double29 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution24);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ConvergenceException; message: illegal state: Continued fraction diverged to NaN for value 0");
//        } catch (org.apache.commons.math3.exception.ConvergenceException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9641824774802d + "'", double3 == 0.9641824774802d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.2955140467835364d + "'", double7 == 1.2955140467835364d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1136411794749174d + "'", double9 == 0.1136411794749174d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.9917270154849734d) + "'", double13 == (-0.9917270154849734d));
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString((int) (byte) 10);
//        double double8 = randomDataImpl0.nextGaussian((double) (-0.99999994f), 49.457940388075684d);
//        double double11 = randomDataImpl0.nextGamma((double) 6, 31.95163256506926d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ea9456a32b" + "'", str5.equals("ea9456a32b"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-28.09018758529326d) + "'", double8 == (-28.09018758529326d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 309.23266053822704d + "'", double11 == 309.23266053822704d);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        double double5 = randomDataImpl0.nextCauchy(1.5395564933646284d, (double) (byte) 100);
//        double double7 = randomDataImpl0.nextChiSquare((double) (short) 1);
//        randomDataImpl0.reSeed((long) (short) 0);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-67.32069967510876d) + "'", double5 == (-67.32069967510876d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.02771458540812899d + "'", double7 == 0.02771458540812899d);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((-67.32069967510876d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.749803534235227d, (double) 1.4E-45f, 8.271806125530277E-25d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0.75) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double21 = randomDataGenerator14.nextGaussian((-0.8414709848078965d), 0.5028800360316223d);
//        int[] intArray24 = randomDataGenerator14.nextPermutation(35, 35);
//        randomDataGenerator14.reSeedSecure(0L);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0e637d208c8763c91285011d2077d95b609c38a272e977a1a90191ba2cdda2853496076d03956ffc49c9a78833320f9fa8e2" + "'", str18.equals("0e637d208c8763c91285011d2077d95b609c38a272e977a1a90191ba2cdda2853496076d03956ffc49c9a78833320f9fa8e2"));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.6402726347684728d) + "'", double21 == (-1.6402726347684728d));
//        org.junit.Assert.assertNotNull(intArray24);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(5.916079783099616d, (double) 3.37769972E15f, 2.154434690031884d);
        double double4 = fDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0000000000000007d + "'", double4 == 1.0000000000000007d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(1731.1173711867675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.14966962228343d + "'", double1 == 8.14966962228343d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, number1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 27.75708784361457d, (java.lang.Number) 3.0d, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.0d + "'", number5.equals(3.0d));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.45698066507140545d, (java.lang.Number) 0.47010374157643864d, false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(5.916079783099616d, (double) 3.37769972E15f, 2.154434690031884d);
        double double4 = fDistribution3.getDenominatorDegreesOfFreedom();
        fDistribution3.reseedRandomGenerator(8L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.377699720527872E15d + "'", double4 == 3.377699720527872E15d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        boolean boolean1 = uniformRealDistribution0.isSupportConnected();
//        double double2 = uniformRealDistribution0.getSupportLowerBound();
//        double double3 = uniformRealDistribution0.sample();
//        double double4 = uniformRealDistribution0.getNumericalVariance();
//        double double5 = uniformRealDistribution0.getSupportUpperBound();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7596547542428691d + "'", double3 == 0.7596547542428691d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08333333333333333d + "'", double4 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((-3.288230404428106d), 0.0d, 9.525653231972898d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-3.288)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 2.5800276068259267d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (-1));
        double double2 = well19937c1.nextGaussian();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08971084836383868d + "'", double2 == 0.08971084836383868d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.1972245773362196d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-575.3905953692303d), (java.lang.Number) 0.984807753012208d, false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
        double double19 = randomDataGenerator14.nextBeta((double) 13L, (double) 2147483647);
        randomDataGenerator14.reSeedSecure();
        try {
            int int23 = randomDataGenerator14.nextBinomial(51, (double) 4L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 4 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 6.271995040159838E-9d + "'", double19 == 6.271995040159838E-9d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        long long1 = org.apache.commons.math3.util.FastMath.round(0.5d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        try {
//            double double8 = randomDataImpl0.nextF((double) 4L, (-28.09018758529326d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-28.09)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 10.0f, 2.718281828459045d, (double) (-8532818744013321543L));
        double double4 = fDistribution3.getSupportUpperBound();
        double double5 = fDistribution3.getSupportUpperBound();
        double double6 = fDistribution3.getSupportUpperBound();
        boolean boolean7 = fDistribution3.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 7.105427357601002E-15d, (java.lang.Number) 8.5328188E18f, false);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathInternalError mathInternalError8 = new org.apache.commons.math3.exception.MathInternalError(localizable6, objArray7);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double2 = org.apache.commons.math3.util.FastMath.log(54.360088752006774d, (-2.9895353071018667d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (byte) 0, 32, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -1,023 is smaller than, or equal to, the minimum (32)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double8 = randomDataImpl0.nextWeibull(0.5008686546137775d, (double) 3.0000002f);
//        int int11 = randomDataImpl0.nextInt(3, 65);
//        try {
//            int int15 = randomDataImpl0.nextHypergeometric((int) (byte) 10, (int) (byte) -1, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-1)");
//        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 23.763690524495672d + "'", double5 == 23.763690524495672d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.665970612539258d + "'", double8 == 2.665970612539258d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        boolean boolean1 = uniformRealDistribution0.isSupportConnected();
        double double2 = uniformRealDistribution0.getSupportLowerBound();
        boolean boolean3 = uniformRealDistribution0.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math3.util.FastMath.floor(3.7240048879664336d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(1648.268331381476d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        well19937c6.setSeed((long) '4');
        boolean boolean14 = well19937c6.nextBoolean();
        byte[] byteArray16 = new byte[] { (byte) 100 };
        well19937c6.nextBytes(byteArray16);
        double double18 = well19937c6.nextGaussian();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4495057192753555d + "'", double18 == 1.4495057192753555d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 35.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248699370183246d + "'", double1 == 4.248699370183246d);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        randomDataImpl0.reSeedSecure();
//        double double6 = randomDataImpl0.nextWeibull((double) 1, 0.5028800360316223d);
//        double double9 = randomDataImpl0.nextBeta(3.377699720527872E15d, 49.457940388075684d);
//        try {
//            double double11 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07448806449187435d + "'", double6 == 0.07448806449187435d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.3949340668481562d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.628055216336872d + "'", double1 == 22.628055216336872d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextGaussian();
        org.apache.commons.math3.distribution.FDistribution fDistribution18 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.47010374157643864d, (double) ' ', 1.5430806348152437d);
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution22 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 8.647204328473636d, (-0.6995216443485196d), (-0.045013400852844d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-0.7)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.19208726106988616d) + "'", double14 == (-0.19208726106988616d));
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double21 = randomDataGenerator14.nextGaussian((-0.8414709848078965d), 0.5028800360316223d);
//        int int24 = randomDataGenerator14.nextPascal((int) (byte) 1, 0.579081227485662d);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "7b781ce12213b37d474ea027a28f558a70e48060137fb8e4af934551890684de05e170d3acfa9a210a8c232a5ced888b1bbc" + "'", str18.equals("7b781ce12213b37d474ea027a28f558a70e48060137fb8e4af934551890684de05e170d3acfa9a210a8c232a5ced888b1bbc"));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.6402726347684728d) + "'", double21 == (-1.6402726347684728d));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        try {
            double double17 = randomDataGenerator14.nextWeibull((double) 1.4E-45f, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double1 = uniformRealDistribution0.getNumericalVariance();
//        double double2 = uniformRealDistribution0.sample();
//        boolean boolean3 = uniformRealDistribution0.isSupportConnected();
//        try {
//            double double5 = uniformRealDistribution0.inverseCumulativeProbability((double) 3.0000002f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 3 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8954884432631842d + "'", double2 == 0.8954884432631842d);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str5 = randomDataImpl0.nextHexString(32);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "e52af8e4aad08216a247239172d5a184" + "'", str5.equals("e52af8e4aad08216a247239172d5a184"));
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        boolean boolean1 = uniformRealDistribution0.isSupportConnected();
//        double double2 = uniformRealDistribution0.getSupportLowerBound();
//        double double3 = uniformRealDistribution0.sample();
//        double double4 = uniformRealDistribution0.sample();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5472753744058174d + "'", double3 == 0.5472753744058174d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09927004713221677d + "'", double4 == 0.09927004713221677d);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math3.util.FastMath.atan(6.408381213480005E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.408381213480005E-17d + "'", double1 == 6.408381213480005E-17d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double2 = org.apache.commons.math3.util.FastMath.pow(27.75708784361457d, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0168766701379063E140d + "'", double2 == 1.0168766701379063E140d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int int17 = randomDataGenerator14.nextInt((int) ' ', (int) 'a');
        int int20 = randomDataGenerator14.nextInt((int) '#', 65);
        int int23 = randomDataGenerator14.nextBinomial(35, 0.8827857294048556d);
        try {
            double double26 = randomDataGenerator14.nextGamma(0.0d, 1731.1173711867677d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 50 + "'", int17 == 50);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 51 + "'", int20 == 51);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(1.3862944207245336d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.7240048879664336d, 0.16596472818899644d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999315662177644d + "'", double2 == 0.9999315662177644d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double20 = randomDataGenerator14.nextUniform(0.0d, 22026.465794806718d, false);
        randomDataGenerator14.reSeed();
        try {
            int int25 = randomDataGenerator14.nextHypergeometric((-1986701681), 64, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-1,986,701,681)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11837.793094904797d + "'", double20 == 11837.793094904797d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((-15.887498983989955d), 0.9866275920404853d, 0.0d);
        double double5 = uniformRealDistribution3.inverseCumulativeProbability(0.1858543065259476d);
        double double7 = uniformRealDistribution3.cumulativeProbability(148.4131591025766d);
        double double10 = uniformRealDistribution3.probability(6.006523924199709E-46d, (double) 16L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-12.751369890970755d) + "'", double5 == (-12.751369890970755d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05846984657813237d + "'", double10 == 0.05846984657813237d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) 1, 0.926433545773006d, 0.984807753012208d);
        int int4 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getIterations();
        double double7 = iterativeLegendreGaussIntegrator3.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.926433545773006d + "'", double7 == 0.926433545773006d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            double double5 = org.apache.commons.math3.special.Beta.regularizedBeta(0.6914113787084667d, 1.2184249125858766d, 0.021967607863831368d, 2.2240228754933433d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: Continued fraction convergents failed to converge (in less than -1 iterations) for value 0.309");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double1 = uniformRealDistribution0.getSupportLowerBound();
        double double2 = uniformRealDistribution0.getNumericalVariance();
        double double3 = uniformRealDistribution0.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08333333333333333d + "'", double2 == 0.08333333333333333d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 4L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(69.23939445067559d, (double) 1630068543L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.247636993426451E-8d + "'", double2 == 4.247636993426451E-8d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int int17 = randomDataGenerator14.nextInt((int) ' ', (int) 'a');
        int int20 = randomDataGenerator14.nextZipf((int) ' ', 7.436292814753874d);
        try {
            long long23 = randomDataGenerator14.nextSecureLong((long) 35, 4L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (35) must be strictly less than upper bound (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 50 + "'", int17 == 50);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution(5.502107925979938d, 309.23266053822704d, (-0.12467276988103379d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.19066703818164438d), 0.0d, 5.104676167044543d, 50);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextGaussian();
        org.apache.commons.math3.distribution.FDistribution fDistribution18 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.47010374157643864d, (double) ' ', 1.5430806348152437d);
        boolean boolean19 = fDistribution18.isSupportConnected();
        double double21 = fDistribution18.cumulativeProbability(7.436292814753874d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.19208726106988616d) + "'", double14 == (-0.19208726106988616d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.9736918662369052d + "'", double21 == 0.9736918662369052d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-23) + "'", int1 == (-23));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(16.0d, 6.271995040159838E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0634780582037416E-9d + "'", double2 == 3.0634780582037416E-9d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(16L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (-1));
        double double2 = well19937c1.nextGaussian();
        double double3 = well19937c1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08971084836383868d + "'", double2 == 0.08971084836383868d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3629014047559318d + "'", double3 == 1.3629014047559318d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(1.5395564933646284d, 1.1712659507785417d, (-0.026843950388637516d));
        boolean boolean4 = fDistribution3.isSupportLowerBoundInclusive();
        boolean boolean5 = fDistribution3.isSupportConnected();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.17453292519943295d, 33.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double21 = randomDataGenerator14.nextGaussian((-0.8414709848078965d), 0.5028800360316223d);
//        double double23 = randomDataGenerator14.nextChiSquare(258.91533352550596d);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "bb20bf59ca8bb5126bfd1b28e807fc733c81c1531ef4719a8f1873ea94da973d77ff2bce1cc1bfb4ecec4aba2f3c50d6740d" + "'", str18.equals("bb20bf59ca8bb5126bfd1b28e807fc733c81c1531ef4719a8f1873ea94da973d77ff2bce1cc1bfb4ecec4aba2f3c50d6740d"));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.6402726347684728d) + "'", double21 == (-1.6402726347684728d));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 275.95151185815865d + "'", double23 == 275.95151185815865d);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 6L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math3.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution(3.7844223823546663d, 0.22857961842557895d, 0.5123616548188537d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (3.784) must be strictly less than upper bound (0.229)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double2 = org.apache.commons.math3.special.Beta.logBeta(2.2240228754933433d, 11837.793094904797d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-20.749154736244236d) + "'", double2 == (-20.749154736244236d));
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double1 = uniformRealDistribution0.getNumericalVariance();
//        double double2 = uniformRealDistribution0.sample();
//        double double4 = uniformRealDistribution0.probability(3.377699720543769E15d);
//        boolean boolean5 = uniformRealDistribution0.isSupportLowerBoundInclusive();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07800545831125949d + "'", double2 == 0.07800545831125949d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] { 10.0d };
        org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray2);
        org.junit.Assert.assertNotNull(objArray2);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double21 = randomDataGenerator14.nextGaussian((-0.8414709848078965d), 0.5028800360316223d);
//        randomDataGenerator14.reSeed((long) 2147483647);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "dabd587da3a429498494cf8da6a34d9dcd41475a19ee4b391f694672e52d3cbef480c039a3567d511b4c68e21fc5b7d9fbd7" + "'", str18.equals("dabd587da3a429498494cf8da6a34d9dcd41475a19ee4b391f694672e52d3cbef480c039a3567d511b4c68e21fc5b7d9fbd7"));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.6402726347684728d) + "'", double21 == (-1.6402726347684728d));
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) '#', (int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -1 is smaller than, or equal to, the minimum (32)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 181, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.868059483016369E31d + "'", double2 == 2.868059483016369E31d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution18 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.0d, 3.883769450489952d, (double) (byte) -1);
        double double19 = uniformRealDistribution18.sample();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.078021298015963d + "'", double19 == 1.078021298015963d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(1.5395564933646284d, 1.1712659507785417d, (-0.026843950388637516d));
        try {
            double double6 = fDistribution3.cumulativeProbability(0.9935002386419477d, 0.749803534235227d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.994) must be less than or equal to upper endpoint (0.75)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(1.5395564933646284d, 1.1712659507785417d, (-0.026843950388637516d));
        double double4 = fDistribution3.getNumericalVariance();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 10.0f, 2.718281828459045d, (double) (-8532818744013321543L));
        double double4 = fDistribution3.getSupportUpperBound();
        double double5 = fDistribution3.getSupportUpperBound();
        double double6 = fDistribution3.getNumericalMean();
        double double7 = fDistribution3.getNumericalVariance();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.7844223823546663d + "'", double6 == 3.7844223823546663d);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeedSecure();
        long long19 = randomDataGenerator14.nextPoisson(10.0d);
        double double23 = randomDataGenerator14.nextUniform(0.6567298707825913d, 0.9075712110370514d, true);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 13L + "'", long19 == 13L);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.8752504460641392d + "'", double23 == 0.8752504460641392d);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double21 = randomDataGenerator14.nextGaussian((-0.8414709848078965d), 0.5028800360316223d);
//        int[] intArray24 = randomDataGenerator14.nextPermutation(35, 35);
//        randomDataGenerator14.reSeed();
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "4f5a2d0afa029d3b3c073441f62f72f625dfa6738dd9af24cb15e162d58ebb13f0e93f44fc6365e99f319ca3103cd0593fee" + "'", str18.equals("4f5a2d0afa029d3b3c073441f62f72f625dfa6738dd9af24cb15e162d58ebb13f0e93f44fc6365e99f319ca3103cd0593fee"));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.6402726347684728d) + "'", double21 == (-1.6402726347684728d));
//        org.junit.Assert.assertNotNull(intArray24);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, (double) 10, 8.14966962228343d, 0.5123616548188537d);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        double double11 = fDistribution10.getSupportUpperBound();
        double double13 = fDistribution10.density((double) 10.0f);
        boolean boolean14 = fDistribution10.isSupportUpperBoundInclusive();
        double double15 = fDistribution10.getNumeratorDegreesOfFreedom();
        boolean boolean16 = fDistribution10.isSupportLowerBoundInclusive();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7845295083467018d + "'", double15 == 0.7845295083467018d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        randomDataImpl0.reSeedSecure(0L);
//        int int7 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 100);
//        long long9 = randomDataImpl0.nextPoisson(1.7182818284590453d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 82 + "'", int7 == 82);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(1.3902777590909514d, 10.0d);
        double double3 = uniformRealDistribution2.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.695138879545476d + "'", double3 == 5.695138879545476d);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        double double8 = randomDataImpl0.nextF(3.141592653589793d, 0.3949340668481562d);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) (short) 1);
//        double double14 = randomDataImpl0.nextUniform((-57.29577951308232d), 1.0E-9d, true);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3L + "'", long5 == 3L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.12088430427920262d + "'", double8 == 0.12088430427920262d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-38.013656321781895d) + "'", double14 == (-38.013656321781895d));
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math3.util.FastMath.log10(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3010299956639812d + "'", double1 == 0.3010299956639812d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(0, (double) 3.0000002f, (-57.29577951308232d));
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getEvaluations();
        double double6 = iterativeLegendreGaussIntegrator3.getAbsoluteAccuracy();
        int int7 = iterativeLegendreGaussIntegrator3.getIterations();
        double double8 = iterativeLegendreGaussIntegrator3.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-57.29577951308232d) + "'", double6 == (-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.000000238418579d + "'", double8 == 3.000000238418579d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math3.util.FastMath.floor(0.003476002462657224d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (-1023));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1023.0f + "'", float1 == 1023.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math3.exception.MathInternalError mathInternalError6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.String str7 = mathInternalError6.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100 + "'", number5.equals(100));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH" + "'", str7.equals("org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) (short) 0, 3.000000238418579d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.000000238418579d + "'", double2 == 3.000000238418579d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeedSecure();
        long long19 = randomDataGenerator14.nextPoisson(10.0d);
        try {
            long long21 = randomDataGenerator14.nextPoisson((-44.65733451834925d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-44.657)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 13L + "'", long19 == 13L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double19 = randomDataGenerator14.nextGaussian((-0.5440211108893698d), 1.5395564933646284d);
        try {
            double double21 = randomDataGenerator14.nextChiSquare((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.9895353071018667d) + "'", double19 == (-2.9895353071018667d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) (-23));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 0.4329944622372981d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) -1, (float) (-8532818744013321543L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.5328188E18f) + "'", float2 == (-8.5328188E18f));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math3.util.FastMath.sin(0.2333410772653135d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23122933970701368d + "'", double1 == 0.23122933970701368d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 50);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        boolean boolean13 = fDistribution10.isSupportConnected();
        boolean boolean14 = fDistribution10.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 10, (-8532818744013321543L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 10.0f, 2.718281828459045d, (double) (-8532818744013321543L));
        double double5 = fDistribution3.density((double) 181);
        double double6 = fDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.343178141479146E-6d + "'", double5 == 8.343178141479146E-6d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.7844223823546663d + "'", double6 == 3.7844223823546663d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(0.92643344f, 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4679924E29f + "'", float2 == 1.4679924E29f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution18 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.0d, 3.883769450489952d, (double) (byte) -1);
        well19937c6.setSeed(2147483647);
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution24 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, (double) (-4114307074210296442L), 0.8349501560111403d, 15.999999999999998d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-4,114,307,074,210,296,300)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        randomDataGenerator14.reSeedSecure(6L);
        double double22 = randomDataGenerator14.nextCauchy(1.323855013488585d, (double) 32);
        try {
            int int25 = randomDataGenerator14.nextPascal(2, (double) 65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 65 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.104676167044543d + "'", double22 == 5.104676167044543d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.24304578269029964d, (java.lang.Number) (-0.99999994f), false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
        long long18 = randomDataGenerator14.nextPoisson(32.94631867978169d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 50L + "'", long18 == 50L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        try {
            long long5 = randomDataImpl0.nextLong((long) 42, 9L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (42) must be strictly less than upper bound (9)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        int int8 = well19937c6.nextInt((int) 'a');
        byte[] byteArray14 = new byte[] { (byte) 10, (byte) 1, (byte) 0, (byte) -1, (byte) -1 };
        well19937c6.nextBytes(byteArray14);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(byteArray14);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        double double20 = randomDataGenerator14.nextGaussian(0.2775708784361457d, (double) '4');
        int int23 = randomDataGenerator14.nextInt((int) (short) -1, 6);
        double double26 = randomDataGenerator14.nextGamma((double) 3, 0.9577392927696378d);
        java.lang.String str28 = randomDataGenerator14.nextHexString((int) (byte) 100);
        double double32 = randomDataGenerator14.nextUniform(0.4140610839920738d, 1.0436130487672481d, false);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-82.32202111518593d) + "'", double20 == (-82.32202111518593d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.003677274821031d + "'", double26 == 2.003677274821031d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "6cf8103514078176e5999df40c4bb2a2bf5e430c66ac7a601bf058427c3ce377fdd901bd2c0116b891b83056afb311a72927" + "'", str28.equals("6cf8103514078176e5999df40c4bb2a2bf5e430c66ac7a601bf058427c3ce377fdd901bd2c0116b891b83056afb311a72927"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.9474165136451307d + "'", double32 == 0.9474165136451307d);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextGamma(0.45698066507140545d, 0.24304578269029964d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.13698445140916538d + "'", double5 == 0.13698445140916538d);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        double double11 = fDistribution10.getSupportUpperBound();
        double double13 = fDistribution10.density((double) 10.0f);
        double double14 = fDistribution10.getSupportUpperBound();
        boolean boolean15 = fDistribution10.isSupportConnected();
        double double16 = fDistribution10.getNumericalMean();
        boolean boolean17 = fDistribution10.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        randomDataImpl0.reSeedSecure();
        try {
            int int6 = randomDataImpl0.nextBinomial(0, 8.647204328473636d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 8.647 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.13698445140916538d, 0.9935002386419477d, (double) 1.59209126E9f, (double) 30);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) Double.POSITIVE_INFINITY);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: ∞ is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: ∞ is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.6914113787084667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8277116552486821d + "'", double1 == 0.8277116552486821d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(1.5395564933646284d, 3.4670597006538995E-46d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5395564933646284d + "'", double2 == 1.5395564933646284d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 51, 82);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.4662087E26f + "'", float2 == 2.4662087E26f);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double20 = randomDataGenerator14.nextChiSquare((double) 9L);
//        double double22 = randomDataGenerator14.nextExponential((double) (short) 1);
//        double double25 = randomDataGenerator14.nextCauchy(0.579081227485662d, 1.0000000000000007d);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1909efc193b596729415cefdf5c9a8a4b26a8bb803c2761efb374c0213820a4664e1e88734e9c821d0cfaef7c1366b34992a" + "'", str18.equals("1909efc193b596729415cefdf5c9a8a4b26a8bb803c2761efb374c0213820a4664e1e88734e9c821d0cfaef7c1366b34992a"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.729964732145538d + "'", double20 == 8.729964732145538d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7467840434044638d + "'", double22 == 0.7467840434044638d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.7646582882491093d + "'", double25 == 1.7646582882491093d);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 'a');
        int int8 = randomDataImpl0.nextPascal((int) (byte) 100, 0.3949340668481562d);
        try {
            int int11 = randomDataImpl0.nextZipf(0, (double) 50L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: dimension (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 181 + "'", int8 == 181);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 65);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.189654742026425d + "'", double1 == 4.189654742026425d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        double double11 = fDistribution10.getSupportUpperBound();
        double double13 = fDistribution10.density((double) 10.0f);
        double double14 = fDistribution10.getSupportUpperBound();
        boolean boolean15 = fDistribution10.isSupportConnected();
        fDistribution10.reseedRandomGenerator((-4114307074210296442L));
        boolean boolean18 = fDistribution10.isSupportConnected();
        boolean boolean19 = fDistribution10.isSupportLowerBoundInclusive();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(1.1218305233661046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8082046914372129d + "'", double1 == 0.8082046914372129d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(48.06172475249776d, (double) (byte) 1, 9.525653231972898d);
        double double4 = fDistribution3.getSupportUpperBound();
        double double5 = fDistribution3.getNumeratorDegreesOfFreedom();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 48.06172475249776d + "'", double5 == 48.06172475249776d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 65L, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 65.0d + "'", double2 == 65.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos(33.815878625720785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3486225058117667d + "'", double1 == 1.3486225058117667d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeed();
        int int20 = randomDataGenerator14.nextPascal(50, 0.0d);
        randomDataGenerator14.reSeed();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.6914113787084667d, 64);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2754288752685758E19d + "'", double2 == 1.2754288752685758E19d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        boolean boolean13 = fDistribution10.isSupportConnected();
        double double14 = fDistribution10.getNumeratorDegreesOfFreedom();
        double double16 = fDistribution10.density((double) 8.5328188E18f);
        double double18 = fDistribution10.probability(22.628055216336872d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7845295083467018d + "'", double14 == 0.7845295083467018d);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int int2 = org.apache.commons.math3.util.FastMath.min(30, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math3.util.FastMath.signum(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double20 = randomDataGenerator14.nextChiSquare((double) 9L);
//        randomDataGenerator14.reSeedSecure();
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "fa9a6004de3e8e8a183927cb31a5d67b2c22dd4c5ec3c327e92df1697ad3786f3fda40acbc8893d4c162c6a0fde7e3ba48a8" + "'", str18.equals("fa9a6004de3e8e8a183927cb31a5d67b2c22dd4c5ec3c327e92df1697ad3786f3fda40acbc8893d4c162c6a0fde7e3ba48a8"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.729964732145538d + "'", double20 == 8.729964732145538d);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        double double20 = randomDataGenerator14.nextGaussian(0.2775708784361457d, (double) '4');
        int int23 = randomDataGenerator14.nextInt((int) (short) -1, 6);
        double double26 = randomDataGenerator14.nextGamma((double) 3, 0.9577392927696378d);
        try {
            int int29 = randomDataGenerator14.nextBinomial(82, (double) (-1986701681));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -1,986,701,681 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-82.32202111518593d) + "'", double20 == (-82.32202111518593d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.003677274821031d + "'", double26 == 2.003677274821031d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int int1 = org.apache.commons.math3.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double21 = randomDataGenerator14.nextUniform(0.0d, (double) 50);
//        randomDataGenerator14.reSeedSecure((-4114307074210296442L));
//        double double25 = randomDataGenerator14.nextChiSquare(0.9264335457730059d);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "8b26393cca778231774a1d0f19a241078a09fe4349f7126bc1e593d1cca63d160bc57b98c6dcb93e75c13d3943b965299800" + "'", str18.equals("8b26393cca778231774a1d0f19a241078a09fe4349f7126bc1e593d1cca63d160bc57b98c6dcb93e75c13d3943b965299800"));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 26.871748752575296d + "'", double21 == 26.871748752575296d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.08902439512989148d + "'", double25 == 0.08902439512989148d);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        boolean boolean13 = fDistribution10.isSupportConnected();
        double double14 = fDistribution10.getNumeratorDegreesOfFreedom();
        double double15 = fDistribution10.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7845295083467018d + "'", double14 == 0.7845295083467018d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(32);
        double double2 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05138095084936123d + "'", double2 == 0.05138095084936123d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        try {
            double double5 = org.apache.commons.math3.special.Beta.regularizedBeta((double) (byte) 1, 4.247636993426451E-8d, (double) 100.0f, 0.9536893818313428d, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: Continued fraction convergents failed to converge (in less than -1 iterations) for value 0");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeedSecure();
        try {
            randomDataGenerator14.setSecureAlgorithm("7b781ce12213b37d474ea027a28f558a70e48060137fb8e4af934551890684de05e170d3acfa9a210a8c232a5ced888b1bbc", "org.apache.commons.math3.exception.NumberIsTooLargeException: 32 is larger than, or equal to, the maximum (3)");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.NumberIsTooLargeException: 32 is larger than, or equal to, the maximum (3)");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 2.166761329997479d);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        double double14 = fDistribution10.density((-0.20713550270884132d));
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math3.util.FastMath.rint(1.0E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        double double7 = randomDataImpl0.nextUniform(0.3057575137911129d, 1.5430806348152437d, false);
//        try {
//            long long10 = randomDataImpl0.nextLong((long) 2, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (2) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9379330266076785d + "'", double3 == 0.9379330266076785d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.4863734418418689d + "'", double7 == 0.4863734418418689d);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 51);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 35, (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        randomDataImpl0.reSeedSecure(0L);
//        int int7 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 100);
//        double double9 = randomDataImpl0.nextExponential(1.5440680443502757d);
//        try {
//            int int12 = randomDataImpl0.nextPascal((-1), 16.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of successes (-1)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 25 + "'", int7 == 25);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.33114683319267163d + "'", double9 == 0.33114683319267163d);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 3, (java.lang.Number) 1.0E-9d, number3);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        java.lang.Number number7 = outOfRangeException4.getHi();
        java.lang.Number number8 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0E-9d + "'", number5.equals(1.0E-9d));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 'a', 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.00000000000001d + "'", double2 == 97.00000000000001d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.7467840434044638d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        double double5 = randomDataImpl0.nextCauchy(1.5395564933646284d, (double) (byte) 100);
//        double double7 = randomDataImpl0.nextChiSquare((double) (short) 1);
//        int int10 = randomDataImpl0.nextInt(0, 1);
//        double double12 = randomDataImpl0.nextChiSquare((double) 1.4E-45f);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 54.392245166752446d + "'", double5 == 54.392245166752446d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7574342719449616d + "'", double7 == 0.7574342719449616d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.995389989640588E-23d + "'", double12 == 3.995389989640588E-23d);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(48.06172475249776d, (double) (byte) 1, 9.525653231972898d);
        double double5 = fDistribution3.cumulativeProbability((double) 5L);
        fDistribution3.reseedRandomGenerator(0L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.6567298707825913d + "'", double5 == 0.6567298707825913d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        int int20 = randomDataGenerator14.nextHypergeometric(100, 3, (int) (byte) 0);
        int[] intArray23 = randomDataGenerator14.nextPermutation(35, 35);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 3, (java.lang.Number) 1.0E-9d, number3);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertNull(number5);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        long long8 = randomDataImpl0.nextSecureLong(0L, (long) 10);
//        randomDataImpl0.reSeed();
//        int int12 = randomDataImpl0.nextSecureInt(0, 2);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 68.01794091656453d + "'", double5 == 68.01794091656453d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3L + "'", long8 == 3L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        try {
            double double1 = org.apache.commons.math3.special.Gamma.logGamma1p((-38.013656321781895d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -38.014 is smaller than the minimum (-0.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math3.util.FastMath.tan(80.3430694304528d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.224109085568925d) + "'", double1 == (-4.224109085568925d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 65L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.867475273605342d + "'", double1 == 4.867475273605342d);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double7 = randomDataImpl0.nextExponential(1.81454966921062784E18d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 36.944100072961d + "'", double5 == 36.944100072961d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.48323089566397363E18d + "'", double7 == 1.48323089566397363E18d);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(2.9999998f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.9999998f + "'", float2 == 2.9999998f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextDouble();
        long long15 = well19937c6.nextLong();
        long long16 = well19937c6.nextLong();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2775708784361457d + "'", double14 == 0.2775708784361457d);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-8532818744013321543L) + "'", long15 == (-8532818744013321543L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 4859042445956413845L + "'", long16 == 4859042445956413845L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0000002f + "'", float1 == 2.0000002f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        randomDataGenerator14.reSeed((long) 1);
        try {
            int[] intArray22 = randomDataGenerator14.nextPermutation(1, (-23));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (-23");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 'a');
        double double8 = randomDataImpl0.nextWeibull((double) 35, 1731.1173711867675d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1777.1972779026437d + "'", double8 == 1777.1972779026437d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        double double20 = randomDataGenerator14.nextGaussian(0.2775708784361457d, (double) '4');
        int int23 = randomDataGenerator14.nextInt((int) (short) -1, 6);
        double double26 = randomDataGenerator14.nextCauchy((double) ' ', 2.471053506302818d);
        double double29 = randomDataGenerator14.nextCauchy(1.0E-9d, 0.926433545773006d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-82.32202111518593d) + "'", double20 == (-82.32202111518593d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 29.817114515879094d + "'", double26 == 29.817114515879094d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.7150593657582222d + "'", double29 == 0.7150593657582222d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int int17 = randomDataGenerator14.nextInt((int) ' ', (int) 'a');
        int int20 = randomDataGenerator14.nextInt((int) '#', 65);
        int int23 = randomDataGenerator14.nextBinomial(35, 0.8827857294048556d);
        randomDataGenerator14.reSeedSecure(13L);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 50 + "'", int17 == 50);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 51 + "'", int20 == 51);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double8 = randomDataImpl0.nextWeibull(0.5008686546137775d, (double) 3.0000002f);
//        double double10 = randomDataImpl0.nextChiSquare(3.141592653589793d);
//        double double13 = randomDataImpl0.nextCauchy(3.377699720527872E15d, 22026.465794806718d);
//        try {
//            int int16 = randomDataImpl0.nextPascal(65, (double) (-8532818744013321543L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -8,532,818,744,013,321,200 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 43.7107948559039d + "'", double5 == 43.7107948559039d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.964063270682399d + "'", double8 == 1.964063270682399d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.279521560900992d + "'", double10 == 4.279521560900992d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.3776997205575385E15d + "'", double13 == 3.3776997205575385E15d);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double19 = randomDataGenerator14.nextGaussian((-0.5440211108893698d), 1.5395564933646284d);
        double double21 = randomDataGenerator14.nextExponential(0.7845295083467018d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.9895353071018667d) + "'", double19 == (-2.9895353071018667d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.43457125554357545d + "'", double21 == 0.43457125554357545d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(5.916079783099616d, (double) 3.37769972E15f, 2.154434690031884d);
        double double4 = fDistribution3.getNumeratorDegreesOfFreedom();
        double double6 = fDistribution3.probability(0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.916079783099616d + "'", double4 == 5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.17453292519943295d, 10 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray4);
        org.apache.commons.math3.exception.MathInternalError mathInternalError6 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathInternalError6.getContext();
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathInternalError6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        boolean boolean13 = fDistribution10.isSupportLowerBoundInclusive();
        boolean boolean14 = fDistribution10.isSupportUpperBoundInclusive();
        try {
            double double17 = fDistribution10.cumulativeProbability((double) 35.000004f, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ConvergenceException; message: illegal state: Continued fraction diverged to NaN for value 0");
        } catch (org.apache.commons.math3.exception.ConvergenceException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        double double20 = randomDataGenerator14.nextGamma(8.343178141479146E-6d, 0.9999999999999971d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double1 = uniformRealDistribution0.getNumericalVariance();
        double double2 = uniformRealDistribution0.getSupportLowerBound();
        try {
            double double5 = uniformRealDistribution0.cumulativeProbability((double) 35L, 8.647204328473636d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (35) must be less than or equal to upper endpoint (8.647)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0, (java.lang.Number) (byte) -1, (java.lang.Number) (-1.0d));
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        try {
            double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.296908309475615d, 5.502107925979938d, 0.0d, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: Continued fraction convergents failed to converge (in less than 100 iterations) for value 5.502");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution18 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.0d, 3.883769450489952d, (double) (byte) -1);
        well19937c6.setSeed(2147483647);
        float float21 = well19937c6.nextFloat();
        float float22 = well19937c6.nextFloat();
        int[] intArray28 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c29 = new org.apache.commons.math3.random.Well19937c(intArray28);
        well19937c6.setSeed(intArray28);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.032178402f + "'", float21 == 0.032178402f);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.22311318f + "'", float22 == 0.22311318f);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(68.52864065924804d, (-1.0d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 8.5328188E18f, 0.8486051191164776d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.003765992514090955d) + "'", double2 == (-0.003765992514090955d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        boolean boolean1 = uniformRealDistribution0.isSupportConnected();
        uniformRealDistribution0.reseedRandomGenerator((long) (short) 10);
        double double5 = uniformRealDistribution0.probability(7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        randomDataImpl0.reSeedSecure((long) (short) 0);
        randomDataImpl0.reSeedSecure();
        try {
            int int8 = randomDataImpl0.nextSecureInt((int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math3.util.FastMath.exp((-8.737800781375096d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.604062687400389E-4d + "'", double1 == 1.604062687400389E-4d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 3L, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextDouble();
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution18 = new org.apache.commons.math3.distribution.UniformRealDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.17453292519943295d, (double) 13L, 0.0d);
        double double20 = uniformRealDistribution18.probability((double) 10.0f);
        double double21 = uniformRealDistribution18.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2775708784361457d + "'", double14 == 0.2775708784361457d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.17453292519943295d + "'", double21 == 0.17453292519943295d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(100.0f, (float) 13L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        long long8 = randomDataImpl0.nextSecureLong(0L, (long) 10);
//        randomDataImpl0.reSeed();
//        try {
//            randomDataImpl0.setSecureAlgorithm("3321d6782f718f292b75c8f96e131e8a365eb2ecb4c7d5faf320fd74ce7a3dd951d2c765bbed422139c6c3c51d7005fd6ceb", "org.apache.commons.math3.exception.NumberIsTooSmallException: 1.386 is smaller than, or equal to, the minimum (32.946)");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.NumberIsTooSmallException: 1.386 is smaller than, or equal to, the minimum (32.946)");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 53.320767818729124d + "'", double5 == 53.320767818729124d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double2 = org.apache.commons.math3.util.FastMath.min((-1.0d), 3.377699720543769E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
        try {
            int int19 = randomDataGenerator14.nextBinomial((-1), (double) 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of trials (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.47010374157643864d, (java.lang.Number) 0.579081227485662d, (java.lang.Number) 1.2112921755133716d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) 5.502107925979938d, (java.lang.Number) 0.8349501560111403d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int1 = org.apache.commons.math3.util.FastMath.abs(64);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double1 = uniformRealDistribution0.getNumericalVariance();
//        double double2 = uniformRealDistribution0.sample();
//        boolean boolean3 = uniformRealDistribution0.isSupportConnected();
//        double double4 = uniformRealDistribution0.sample();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2631338929020286d + "'", double2 == 0.2631338929020286d);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7864906766800992d + "'", double4 == 0.7864906766800992d);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.7240048879664336d, (double) 3.37769999E15f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        randomDataImpl0.reSeedSecure();
//        double double6 = randomDataImpl0.nextWeibull((double) 1, 0.5028800360316223d);
//        double double9 = randomDataImpl0.nextBeta(3.377699720527872E15d, 49.457940388075684d);
//        double double12 = randomDataImpl0.nextWeibull(0.1092498765095964d, 3.7240048879664336d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.1449430562061707d + "'", double6 == 0.1449430562061707d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.8151161492531973d + "'", double12 == 0.8151161492531973d);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) (byte) 100);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        double double8 = randomDataImpl0.nextF(3.141592653589793d, 0.3949340668481562d);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) (short) 1);
//        double double14 = randomDataImpl0.nextUniform((-57.29577951308232d), 1.0E-9d, true);
//        int int17 = randomDataImpl0.nextBinomial(100, 0.0d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 75.63782982631449d + "'", double8 == 75.63782982631449d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5" + "'", str10.equals("5"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-11.696474099085862d) + "'", double14 == (-11.696474099085862d));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        double double11 = fDistribution10.getSupportUpperBound();
        double double13 = fDistribution10.density((double) 10.0f);
        double double14 = fDistribution10.getSupportUpperBound();
        boolean boolean15 = fDistribution10.isSupportConnected();
        double double16 = fDistribution10.getNumericalVariance();
        double double17 = fDistribution10.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        double double8 = randomDataImpl0.nextF(3.141592653589793d, 0.3949340668481562d);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) (short) 1);
//        randomDataImpl0.reSeed((long) 3);
//        try {
//            int int15 = randomDataImpl0.nextPascal(0, (-67.32069967510876d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of successes (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9L + "'", long5 == 9L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18853248162563394d + "'", double8 == 0.18853248162563394d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a" + "'", str10.equals("a"));
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextDouble();
        long long15 = well19937c6.nextLong();
        boolean boolean16 = well19937c6.nextBoolean();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2775708784361457d + "'", double14 == 0.2775708784361457d);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-8532818744013321543L) + "'", long15 == (-8532818744013321543L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 52.0f, (-1.0d), 0.19696440544303725d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(2.9999998f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.3841858E-7f + "'", float1 == 2.3841858E-7f);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        double double5 = randomDataImpl0.nextCauchy(1.5395564933646284d, (double) (byte) 100);
//        double double7 = randomDataImpl0.nextChiSquare((double) (short) 1);
//        int int10 = randomDataImpl0.nextInt(0, 1);
//        randomDataImpl0.reSeed(10L);
//        long long15 = randomDataImpl0.nextLong((long) 5, 44L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-323.05522556514745d) + "'", double5 == (-323.05522556514745d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.687755435677728d + "'", double7 == 2.687755435677728d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 21L + "'", long15 == 21L);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double21 = randomDataGenerator14.nextF(1648.268331381476d, (double) 'a');
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a08646212081f310e0b851efdbe012104e62965cb0592205c2e93580ff1e1d13e4fe3681512e70f56232886d6f20a044a04d" + "'", str18.equals("a08646212081f310e0b851efdbe012104e62965cb0592205c2e93580ff1e1d13e4fe3681512e70f56232886d6f20a044a04d"));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0206448478220622d + "'", double21 == 1.0206448478220622d);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        try {
            double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1(1.5440680443502757d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1.544 is larger than the maximum (1.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double19 = randomDataGenerator14.nextUniform((double) 1.1920929E-7f, 0.5d);
        try {
            int int22 = randomDataGenerator14.nextZipf((int) '4', (-12.751369890970755d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (-12.751)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.26871754266780096d + "'", double19 == 0.26871754266780096d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double2 = org.apache.commons.math3.util.FastMath.min(3.1909099185344844E-8d, 3716.0962449481235d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1909099185344844E-8d + "'", double2 == 3.1909099185344844E-8d);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double1 = uniformRealDistribution0.getNumericalVariance();
//        double double2 = uniformRealDistribution0.sample();
//        double double4 = uniformRealDistribution0.probability(3.377699720543769E15d);
//        double double7 = uniformRealDistribution0.probability(6.271995040159838E-9d, 0.9412668030724239d);
//        double double8 = uniformRealDistribution0.sample();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45649315877767305d + "'", double2 == 0.45649315877767305d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9412667968004289d + "'", double7 == 0.9412667968004289d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.06441233855853401d + "'", double8 == 0.06441233855853401d);
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double8 = randomDataImpl0.nextWeibull(0.5008686546137775d, (double) 3.0000002f);
//        double double10 = randomDataImpl0.nextChiSquare(3.141592653589793d);
//        double double13 = randomDataImpl0.nextCauchy(3.377699720527872E15d, 22026.465794806718d);
//        try {
//            double double17 = randomDataImpl0.nextUniform((double) 100.0f, 0.05846984657813237d, true);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (100) must be strictly less than upper bound (0.058)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 73.71373744270122d + "'", double5 == 73.71373744270122d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.56048109664214d + "'", double8 == 10.56048109664214d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.8714806523661918d + "'", double10 == 2.8714806523661918d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.377699720503331E15d + "'", double13 == 3.377699720503331E15d);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(3.377699720543769E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.449118497230025d + "'", double1 == 36.449118497230025d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 22026.465794806718d);
        java.lang.Throwable[] throwableArray2 = maxCountExceededException1.getSuppressed();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 32, (java.lang.Number) 3.0000002f, false);
        maxCountExceededException1.addSuppressed((java.lang.Throwable) numberIsTooLargeException6);
        boolean boolean8 = numberIsTooLargeException6.getBoundIsAllowed();
        boolean boolean9 = numberIsTooLargeException6.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(5.916079783099616d, (double) 3.37769972E15f, 2.154434690031884d);
        double double4 = fDistribution3.getDenominatorDegreesOfFreedom();
        double double5 = fDistribution3.getNumeratorDegreesOfFreedom();
        double double6 = fDistribution3.getNumericalMean();
        double double8 = fDistribution3.density((double) 52L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.377699720527872E15d + "'", double4 == 3.377699720527872E15d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.916079783099616d + "'", double5 == 5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0000000000000007d + "'", double6 == 1.0000000000000007d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.8946403116483003E-63d + "'", double8 == 2.8946403116483003E-63d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 6.082818640342675E62d);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        java.lang.Throwable[] throwableArray3 = maxCountExceededException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 6.082818640342675E62d + "'", number2.equals(6.082818640342675E62d));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator5 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(5, 0.5677523773762474d, 0.23940749620295418d, 16, 51);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.7574342719449616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9115524247642202d + "'", double1 == 0.9115524247642202d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        boolean boolean1 = uniformRealDistribution0.isSupportConnected();
        boolean boolean2 = uniformRealDistribution0.isSupportLowerBoundInclusive();
        double double4 = uniformRealDistribution0.density((double) (short) 1);
        double double5 = uniformRealDistribution0.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        double double7 = randomDataImpl0.nextUniform(0.3057575137911129d, 1.5430806348152437d, false);
//        double double9 = randomDataImpl0.nextExponential(0.8486051191164776d);
//        double double13 = randomDataImpl0.nextUniform((double) (byte) -1, 0.9412667968004289d, true);
//        try {
//            randomDataImpl0.setSecureAlgorithm("81f47775fd08c68e8366e8efdf3e3cbfe9a2686c95e4d1676166ff6e664593db9440cecd3369bf4473fdcebe79b0d6cb850a", "5");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 5");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8875715746335641d + "'", double3 == 0.8875715746335641d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.3191444592741344d + "'", double7 == 1.3191444592741344d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1704862833333517d + "'", double9 == 0.1704862833333517d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.8131693647910132d + "'", double13 == 0.8131693647910132d);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed((long) 'a');
        int int8 = randomDataImpl0.nextPascal((int) (byte) 100, 0.3949340668481562d);
        try {
            double double10 = randomDataImpl0.nextT(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 181 + "'", int8 == 181);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        double double5 = randomDataImpl0.nextCauchy(1.5395564933646284d, (double) (byte) 100);
//        double double7 = randomDataImpl0.nextChiSquare((double) (short) 1);
//        randomDataImpl0.reSeed(1592091222L);
//        double double12 = randomDataImpl0.nextCauchy((-0.562453851238172d), 1.1218305233661046d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-18.99665145910341d) + "'", double5 == (-18.99665145910341d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.1167907943036681d + "'", double7 == 1.1167907943036681d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.04835521213287075d + "'", double12 == 0.04835521213287075d);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        randomDataImpl0.reSeedSecure(0L);
//        int int7 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 100);
//        randomDataImpl0.reSeedSecure();
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(2L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.579081227485662d, (java.lang.Number) 0.8349501560111403d, false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math3.util.FastMath.floor(69.44349531847722d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 69.0d + "'", double1 == 69.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double2 = uniformRealDistribution0.density(Double.POSITIVE_INFINITY);
        double double5 = uniformRealDistribution0.cumulativeProbability((-0.026843950388637516d), (double) 35);
        boolean boolean6 = uniformRealDistribution0.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((-3.288230404428106d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9626801679928071d) + "'", double1 == (-0.9626801679928071d));
    }
}

