import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.apache.commons.math3.analysis.integration.BaseAbstractUnivariateIntegrator.DEFAULT_MIN_ITERATIONS_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.apache.commons.math3.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math3.util.FastMath.exp(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test013");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.6914113787084667d + "'", double0 == 0.6914113787084667d);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double2 = org.apache.commons.math3.util.FastMath.min(22026.465794806718d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double0 = org.apache.commons.math3.special.Gamma.LANCZOS_G;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 4.7421875d + "'", double0 == 4.7421875d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator5 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) 1, (double) '#', 3.0d, 3, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (3)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math3.util.FastMath.acos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (-1L), (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.apache.commons.math3.distribution.FDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 1L, (double) 1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.0000002f + "'", float1 == 3.0000002f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 3.0000002f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3862944207245336d + "'", double1 == 1.3862944207245336d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int2 = org.apache.commons.math3.util.FastMath.max((-1), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math3.util.FastMath.atan((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6995216443485196d) + "'", double1 == (-0.6995216443485196d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math3.special.Gamma.trigamma(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3949340668481562d + "'", double1 == 0.3949340668481562d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0f), (java.lang.Number) 10L, (java.lang.Number) 1.3862944207245336d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math3.random.RandomGenerator randomGenerator0 = null;
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution4 = new org.apache.commons.math3.distribution.FDistribution(randomGenerator0, (double) 0L, (double) (byte) -1, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math3.special.Gamma.trigamma((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double5 = org.apache.commons.math3.special.Beta.regularizedBeta((-0.0d), (double) (short) -1, 3.0d, (double) '#', (int) '4');
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(10.0f, 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) -1, 10, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 1 is smaller than, or equal to, the minimum (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((double) 1.0f, 0.6914113787084667d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5008686546137775d + "'", double2 == 0.5008686546137775d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta((double) 0L, (double) (-1.0f), 3.0d, (int) (short) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        float float2 = org.apache.commons.math3.util.FastMath.max(100.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((double) (short) 10, (-0.5440211108893698d), (double) (short) 1, (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.5008686546137775d, 0.0d, 0.0d, (int) (byte) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator5 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) 10, 3.0d, (double) 10L, (int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 1 is smaller than, or equal to, the minimum (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.6914113787084667d, (double) 10L, 0.0d, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: Continued fraction convergents failed to converge (in less than 97 iterations) for value 10");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.6914113787084667d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.94631867978169d + "'", double1 == 32.94631867978169d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(1.3862944207245336d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 3, (java.lang.Number) 1.0E-9d, number3);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass12 = numberIsTooLargeException11.getClass();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = numberIsTooLargeException11.getContext();
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), 0L, numberIsTooLargeException11 };
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) outOfRangeException4, localizable5, objArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) '4', (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextF((double) 0.0f, (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextUniform((double) 32, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (32) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int2 = org.apache.commons.math3.util.FastMath.max(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math3.util.FastMath.tan((-0.6995216443485196d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078964d) + "'", double1 == (-0.8414709848078964d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        try {
            double double6 = randomDataImpl0.nextUniform(1.3862944207245336d, (double) 0L, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (1.386) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (byte) 100, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1712659507785417d + "'", double1 == 1.1712659507785417d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.5008686546137775d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7077207462084021d + "'", double1 == 0.7077207462084021d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double0 = org.apache.commons.math3.analysis.integration.BaseAbstractUnivariateIntegrator.DEFAULT_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-15d + "'", double0 == 1.0E-15d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 1.0f, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math3.util.FastMath.acos(0.7077207462084021d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7845295083467018d + "'", double1 == 0.7845295083467018d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        try {
            long long5 = randomDataImpl0.nextLong((long) 100, (long) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (100) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370514d + "'", double1 == 0.9075712110370514d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-0.8414709848078965d), 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1909099185344844E-8d + "'", double2 == 3.1909099185344844E-8d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            int int4 = randomDataImpl0.nextHypergeometric(0, (int) (byte) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextInt((int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (35) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta((-1.0d), (double) (short) 1, 0.7845295083467018d, 0.9577392927696378d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(4.7421875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(32.94631867978169d, (-57.29577951308232d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (32.946) must be strictly less than upper bound (-57.296)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution((-0.6995216443485196d), 0.5008686546137775d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-0.7)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math3.util.FastMath.signum(4.7421875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.984807753012208d + "'", double1 == 0.984807753012208d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        try {
            java.lang.String str4 = randomDataImpl0.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 0.17453292519943295d, 10 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray3);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass12 = numberIsTooLargeException11.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass23 = numberIsTooLargeException22.getClass();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext24 = numberIsTooLargeException22.getContext();
        java.lang.Object[] objArray25 = new java.lang.Object[] { 100.0f, wildcardClass12, "", true, 1, numberIsTooLargeException22 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable6, objArray25);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalArgumentException4, localizable5, objArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(exceptionContext24);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.7845295083467018d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.323855013488585d + "'", double1 == 1.323855013488585d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) ' ', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(1.1712659507785417d, Double.POSITIVE_INFINITY, (double) (-1.0f), (int) (byte) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(6, (int) 'a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -1 is smaller than, or equal to, the minimum (97)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9319894568729709d + "'", double1 == 0.9319894568729709d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        try {
            double double14 = fDistribution10.cumulativeProbability(0.2775708784361457d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ConvergenceException; message: illegal state: Continued fraction diverged to NaN for value 0");
        } catch (org.apache.commons.math3.exception.ConvergenceException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2240228754933433d + "'", double1 == 2.2240228754933433d);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        try {
//            int int7 = randomDataImpl0.nextHypergeometric((-1), (int) (short) -1, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-1)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8690349170989957d + "'", double3 == 0.8690349170989957d);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        double double14 = fDistribution10.density(0.3949340668481562d);
        boolean boolean15 = fDistribution10.isSupportLowerBoundInclusive();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math3.util.FastMath.atan(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-9d + "'", double1 == 1.0E-9d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(1.0d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.296908309475615d + "'", double2 == 3.296908309475615d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double2 = org.apache.commons.math3.util.FastMath.pow(2.2240228754933433d, 0.984807753012208d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.197178925104706d + "'", double2 == 2.197178925104706d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((double) 1.1920929E-7f, 0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double5 = org.apache.commons.math3.special.Beta.regularizedBeta(0.17453292519943295d, 0.0d, Double.NEGATIVE_INFINITY, 0.579081227485662d, 32);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) 1, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(0, (double) 3.0000002f, (-57.29577951308232d));
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        try {
            double double9 = iterativeLegendreGaussIntegrator3.integrate(50, univariateFunction6, (double) 20.0f, 0.6914113787084667d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta(2.197178925104706d, 22026.465794806718d, 1.5430806348152437d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextGaussian();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.433034161491429d + "'", double12 == 1.433034161491429d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int2 = org.apache.commons.math3.util.FastMath.max(2147483647, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        try {
            double double14 = fDistribution10.inverseCumulativeProbability((double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 100 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, (-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int int17 = randomDataGenerator14.nextInt((int) ' ', (int) 'a');
        try {
            double double19 = randomDataGenerator14.nextExponential((-0.19208726106988616d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-0.192)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 50 + "'", int17 == 50);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int int17 = randomDataGenerator14.nextInt((int) ' ', (int) 'a');
        try {
            double double20 = randomDataGenerator14.nextWeibull(0.0d, Double.NEGATIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 50 + "'", int17 == 50);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) 10, 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int2 = org.apache.commons.math3.util.FastMath.max(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(4.7421875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.39959540883049d + "'", double1 == 16.39959540883049d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int2 = org.apache.commons.math3.util.FastMath.max(3, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        org.apache.commons.math3.distribution.RealDistribution realDistribution1 = null;
        try {
            double double2 = randomDataImpl0.nextInversionDeviate(realDistribution1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.197178925104706d, 2.2240228754933433d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.026843950388637516d) + "'", double2 == (-0.026843950388637516d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int int17 = randomDataGenerator14.nextInt((int) ' ', (int) 'a');
        try {
            double double19 = randomDataGenerator14.nextT(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 50 + "'", int17 == 50);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (-8532818744013321543L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.5328188E18f + "'", float1 == 8.5328188E18f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math3.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextUniform(1.1712659507785417d, 0.17453292519943295d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (1.171) must be strictly less than upper bound (0.175)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 3, 0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.9999998f + "'", float2 == 2.9999998f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double1 = uniformRealDistribution0.getNumericalVariance();
        double double4 = uniformRealDistribution0.cumulativeProbability((-1.0d), (double) 3.0000002f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        try {
            long long5 = randomDataImpl0.nextLong((long) 35, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (35) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator5 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(2147483647, 0.08333333333333333d, (double) '#', 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((double) (short) 0, 16.39959540883049d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int[] intArray20 = new int[] { '4', (byte) 0, 100, 50, '#' };
        well19937c6.setSeed(intArray20);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 32, (double) 1.0f, (double) (byte) 1);
        double double4 = fDistribution3.getNumericalVariance();
        double double5 = fDistribution3.getNumericalVariance();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(32.94631867978169d, 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.94631867978169d + "'", double2 == 32.94631867978169d);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        try {
//            double double7 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0, (java.lang.Number) (byte) -1, (java.lang.Number) (-1.0d));
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) -1 + "'", number4.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(0, (double) 3.0000002f, (-57.29577951308232d));
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        try {
            double double9 = iterativeLegendreGaussIntegrator3.integrate(2147483647, univariateFunction6, (double) (-1.0f), 8.881784197001252E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        java.lang.Class<?> wildcardClass11 = fDistribution10.getClass();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math3.special.Gamma.trigamma((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9099903498550976d + "'", double3 == 0.9099903498550976d);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.17453292519943295d, 10 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray4);
        org.apache.commons.math3.exception.MathInternalError mathInternalError6 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathInternalError6.getContext();
        try {
            java.lang.String str8 = mathInternalError6.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.7077207462084021d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (short) -1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(1.0E-9d, 1.1102230246251565E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution14 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 100.0d, (double) (byte) 0, 2.197178925104706d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        long long1 = org.apache.commons.math3.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        try {
            int int20 = randomDataGenerator14.nextInt(50, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (50) must be strictly less than upper bound (6)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextDouble();
        long long15 = well19937c6.nextLong();
        int[] intArray21 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c22 = new org.apache.commons.math3.random.Well19937c(intArray21);
        org.apache.commons.math3.distribution.FDistribution fDistribution26 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c22, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean27 = well19937c22.nextBoolean();
        double double28 = well19937c22.nextDouble();
        well19937c22.clear();
        int[] intArray35 = new int[] { (byte) 0, (short) -1, 10, (byte) 1, (-1) };
        well19937c22.setSeed(intArray35);
        well19937c6.setSeed(intArray35);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2775708784361457d + "'", double14 == 0.2775708784361457d);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-8532818744013321543L) + "'", long15 == (-8532818744013321543L));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.926433545773006d + "'", double28 == 0.926433545773006d);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math3.special.Gamma.trigamma(2.2240228754933433d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5653304610722176d + "'", double1 == 0.5653304610722176d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.408381213480005E-17d + "'", double1 == 6.408381213480005E-17d);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        try {
//            int int9 = randomDataImpl0.nextHypergeometric((int) (byte) 0, 3, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6L + "'", long5 == 6L);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        try {
            double double4 = randomDataImpl0.nextT((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        try {
//            double double6 = randomDataImpl0.nextWeibull((double) 0.0f, (double) 1.4E-45f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9472858385786039d + "'", double3 == 0.9472858385786039d);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(3.0000002f, 50);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.37769999E15f + "'", float2 == 3.37769999E15f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = org.apache.commons.math3.analysis.integration.BaseAbstractUnivariateIntegrator.DEFAULT_MAX_ITERATIONS_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2147483647 + "'", int0 == 2147483647);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeedSecure();
        try {
            double double20 = randomDataGenerator14.nextUniform((double) ' ', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (32) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        try {
            double double5 = randomDataImpl0.nextBeta((double) 6, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.82, 0.18]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1.5395564933646284d, false);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        try {
//            double double8 = randomDataImpl0.nextGaussian((double) (byte) 1, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6L + "'", long5 == 6L);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 52L, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 6L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma(11837.793094904797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99185.71921078372d + "'", double1 == 99185.71921078372d);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double1 = uniformRealDistribution0.getNumericalVariance();
//        double double2 = uniformRealDistribution0.sample();
//        double double3 = uniformRealDistribution0.sample();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4329944622372981d + "'", double2 == 0.4329944622372981d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9797900982776502d + "'", double3 == 0.9797900982776502d);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        try {
            double double13 = fDistribution10.sample();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ConvergenceException; message: illegal state: Continued fraction diverged to NaN for value 0");
        } catch (org.apache.commons.math3.exception.ConvergenceException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        long long7 = randomDataImpl0.nextLong((long) (short) 0, (long) 3);
//        try {
//            double double10 = randomDataImpl0.nextWeibull((double) 52L, (-0.6995216443485196d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0.7)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        double double6 = randomDataImpl0.nextGamma(Double.POSITIVE_INFINITY, 0.3949340668481562d);
//        try {
//            int int9 = randomDataImpl0.nextInt(32, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (32) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9116699661314253d + "'", double3 == 0.9116699661314253d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0, (java.lang.Number) (byte) -1, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        double double6 = randomDataImpl0.nextGamma(Double.POSITIVE_INFINITY, 0.3949340668481562d);
//        try {
//            double double9 = randomDataImpl0.nextUniform((double) 10L, (double) 6);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (10) must be strictly less than upper bound (6)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9505748620792366d + "'", double3 == 0.9505748620792366d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        try {
//            int int8 = randomDataImpl0.nextInt(2147483647, 2147483647);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (2,147,483,647) must be strictly less than upper bound (2,147,483,647)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 13.09710227451163d + "'", double5 == 13.09710227451163d);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(2.197178925104706d, 0.08333333333333333d, 1.323855013488585d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        try {
            int int5 = randomDataImpl0.nextBinomial((int) ' ', (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 35 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = mathInternalError2.getContext();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeed();
        try {
            int[] intArray20 = randomDataGenerator14.nextPermutation((int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (-1");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        randomDataImpl0.reSeedSecure((long) (short) 0);
        try {
            double double6 = randomDataImpl0.nextChiSquare((double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.5)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) 1, 0.926433545773006d, 0.984807753012208d);
        int int4 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math3.util.FastMath.asin(1.5395564933646284d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double20 = randomDataGenerator14.nextUniform(0.0d, 22026.465794806718d, false);
        try {
            double double23 = randomDataGenerator14.nextGamma(3.296908309475615d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11837.793094904797d + "'", double20 == 11837.793094904797d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) Double.POSITIVE_INFINITY);
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathInternalError mathInternalError6 = new org.apache.commons.math3.exception.MathInternalError(localizable4, objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable3, objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, objArray5);
        boolean boolean9 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(0, (double) 3.0000002f, (-57.29577951308232d));
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getEvaluations();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        try {
            double double10 = iterativeLegendreGaussIntegrator3.integrate(0, univariateFunction7, 0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double1 = uniformRealDistribution0.getSupportLowerBound();
        double double2 = uniformRealDistribution0.getNumericalVariance();
        double double4 = uniformRealDistribution0.probability((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08333333333333333d + "'", double2 == 0.08333333333333333d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double2 = uniformRealDistribution0.density(Double.POSITIVE_INFINITY);
        uniformRealDistribution0.reseedRandomGenerator((long) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double2 = org.apache.commons.math3.util.FastMath.log(1.1712659507785417d, (double) (short) -1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double2 = org.apache.commons.math3.util.FastMath.log(1.0E-9d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.19066703818164438d) + "'", double2 == (-0.19066703818164438d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(99185.71921078372d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 10);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        long long7 = randomDataImpl0.nextLong((long) (short) 0, (long) 3);
//        try {
//            double double10 = randomDataImpl0.nextBeta((double) (-1), (double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.357, 0.643]");
//        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(2.197178925104706d, 0.9797900982776502d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1513313686408708d + "'", double2 == 1.1513313686408708d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
        double double19 = randomDataGenerator14.nextBeta((double) 13L, (double) 2147483647);
        double double21 = randomDataGenerator14.nextChiSquare(2.2240228754933433d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 6.271995040159838E-9d + "'", double19 == 6.271995040159838E-9d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.749803534235227d + "'", double21 == 0.749803534235227d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta((double) (short) -1, (-0.026843950388637516d), 10.0d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double2 = org.apache.commons.math3.util.FastMath.pow(1.0436130487672481d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9582095597417402d + "'", double2 == 0.9582095597417402d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double2 = org.apache.commons.math3.special.Beta.logBeta((-0.8414709848078964d), 25.75496032065573d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) Double.POSITIVE_INFINITY);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(3.37769999E15f, (double) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.37769972E15f + "'", float2 == 3.37769972E15f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            double double1 = org.apache.commons.math3.special.Gamma.logGamma1p((double) 52L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (1.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double2 = uniformRealDistribution0.density(Double.POSITIVE_INFINITY);
        boolean boolean3 = uniformRealDistribution0.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution(0.0d, Double.NEGATIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException8);
        boolean boolean10 = numberIsTooLargeException8.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.5653304610722176d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math3.util.FastMath.log10(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49714987269413385d + "'", double1 == 0.49714987269413385d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        well19937c6.setSeed((int) (byte) 0);
        int[] intArray14 = null;
        well19937c6.setSeed(intArray14);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double2 = org.apache.commons.math3.util.FastMath.pow(99185.71921078372d, 0.9582095597417402d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 61326.09864298752d + "'", double2 == 61326.09864298752d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        try {
            double double5 = randomDataImpl0.nextUniform((double) 0L, Double.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: interval bounds must be finite");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextDouble();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator15 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2775708784361457d + "'", double14 == 0.2775708784361457d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.749803534235227d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-15.887498983989955d) + "'", double2 == (-15.887498983989955d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (short) 100, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos(4.7421875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.883769450489952d + "'", double1 == 3.883769450489952d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(22026.465794806718d, (double) 1.1920929E-7f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (22,026.466) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 0.17453292519943295d, 10 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray3);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathIllegalArgumentException4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double3 = org.apache.commons.math3.special.Beta.regularizedBeta(0.4329944622372981d, 1.1712659507785417d, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.006523924199709E-46d + "'", double3 == 6.006523924199709E-46d);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
//        double double1 = well19937c0.nextGaussian();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06557458740714255d + "'", double1 == 0.06557458740714255d);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(1.0E-9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 6L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 3.883769450489952d, 80.3430694304528d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        double double20 = randomDataGenerator14.nextGaussian(0.2775708784361457d, (double) '4');
        try {
            double double22 = randomDataGenerator14.nextT((-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-82.32202111518593d) + "'", double20 == (-82.32202111518593d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.579081227485662d, (double) 0L, 68.8250730633986d, 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int2 = org.apache.commons.math3.util.FastMath.min(1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 50);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.0d + "'", double1 == 50.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((double) 2147483647, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(6.271995040159838E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.271806125530277E-25d + "'", double1 == 8.271806125530277E-25d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) 1, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        boolean boolean1 = uniformRealDistribution0.isSupportConnected();
        double double2 = uniformRealDistribution0.getNumericalMean();
        double double3 = uniformRealDistribution0.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 10.0f, 2.718281828459045d, (double) (-8532818744013321543L));
        boolean boolean4 = fDistribution3.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32, (java.lang.Number) (-0.0d), true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32 + "'", number5.equals(32));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextGaussian();
        byte[] byteArray20 = new byte[] { (byte) 100, (byte) 1, (byte) 1, (byte) 100, (byte) 0 };
        well19937c6.nextBytes(byteArray20);
        double double22 = well19937c6.nextGaussian();
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution26 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 27.75708784361457d, 0.0d, 0.08333333333333333d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.19208726106988616d) + "'", double14 == (-0.19208726106988616d));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0977237767437487d + "'", double22 == 1.0977237767437487d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException(number0);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double1 = uniformRealDistribution0.getNumericalVariance();
//        double double2 = uniformRealDistribution0.sample();
//        double double4 = uniformRealDistribution0.cumulativeProbability(Double.NEGATIVE_INFINITY);
//        double double6 = uniformRealDistribution0.cumulativeProbability(1.1712659507785417d);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8827857294048556d + "'", double2 == 0.8827857294048556d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 16);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 16L + "'", long1 == 16L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextGaussian();
        byte[] byteArray20 = new byte[] { (byte) 100, (byte) 1, (byte) 1, (byte) 100, (byte) 0 };
        well19937c6.nextBytes(byteArray20);
        int int23 = well19937c6.nextInt((int) (short) 10);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.19208726106988616d) + "'", double14 == (-0.19208726106988616d));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.8827857294048556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12467276988103379d) + "'", double1 == (-0.12467276988103379d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        boolean boolean1 = uniformRealDistribution0.isSupportConnected();
        double double2 = uniformRealDistribution0.getNumericalMean();
        boolean boolean3 = uniformRealDistribution0.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32, (java.lang.Number) (-0.0d), true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.0d) + "'", number5.equals((-0.0d)));
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        double double8 = randomDataImpl0.nextF(3.141592653589793d, 0.3949340668481562d);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) (short) 1);
//        try {
//            double double13 = randomDataImpl0.nextF((-0.19066703818164438d), (-0.5440211108893698d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-0.191)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6147953240370183d + "'", double8 == 0.6147953240370183d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6" + "'", str10.equals("6"));
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(99185.71921078372d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1731.1173711867675d + "'", double1 == 1731.1173711867675d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math3.special.Gamma.gamma(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.772453850905516d + "'", double1 == 1.772453850905516d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2184249125858766d + "'", double1 == 1.2184249125858766d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 1, (-8532818744013321543L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8532818744013321543L) + "'", long2 == (-8532818744013321543L));
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        double double6 = randomDataImpl0.nextGamma(Double.POSITIVE_INFINITY, 0.3949340668481562d);
//        try {
//            double double9 = randomDataImpl0.nextGamma(68.8250730633986d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8927185806489993d + "'", double3 == 0.8927185806489993d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-0.026843950388637516d), (java.lang.Number) 35, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 35 + "'", number4.equals(35));
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double1 = uniformRealDistribution0.getNumericalVariance();
//        double double2 = uniformRealDistribution0.sample();
//        double double3 = uniformRealDistribution0.getSupportUpperBound();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16788856803593832d + "'", double2 == 0.16788856803593832d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        boolean boolean13 = fDistribution10.isSupportConnected();
        double double14 = fDistribution10.getNumeratorDegreesOfFreedom();
        double double16 = fDistribution10.density((double) 8.5328188E18f);
        try {
            double[] doubleArray18 = fDistribution10.sample((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ConvergenceException; message: illegal state: Continued fraction diverged to NaN for value 0");
        } catch (org.apache.commons.math3.exception.ConvergenceException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7845295083467018d + "'", double14 == 0.7845295083467018d);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double0 = org.apache.commons.math3.distribution.AbstractRealDistribution.SOLVER_DEFAULT_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-6d + "'", double0 == 1.0E-6d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        randomDataGenerator14.reSeedSecure(6L);
        try {
            long long22 = randomDataGenerator14.nextSecureLong((long) ' ', (long) 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (32) must be strictly less than upper bound (32)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution(0.0d, 3.883769450489952d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(6.006523924199709E-46d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.006523924199709E-46d + "'", double1 == 6.006523924199709E-46d);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        double double8 = randomDataImpl0.nextF(3.141592653589793d, 0.3949340668481562d);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation((int) '4', 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 87.26179521881515d + "'", double8 == 87.26179521881515d);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution(0.9205519333349953d, 0.17453292519943295d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        randomDataGenerator14.reSeedSecure(6L);
        double double22 = randomDataGenerator14.nextCauchy(1.323855013488585d, (double) 32);
        randomDataGenerator14.reSeed((long) '4');
        try {
            double double27 = randomDataGenerator14.nextGamma(0.0d, 2.148892953713321d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.104676167044543d + "'", double22 == 5.104676167044543d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(2.148892953713321d, 1.0E-9d, 0.5444058518112669d, (double) 8.5328188E18f);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.17453292519943295d, 10 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray4);
        org.apache.commons.math3.exception.MathInternalError mathInternalError6 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray4);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathInternalError6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) ' ', (double) 'a', 1.1712659507785417d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator5 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) '4', 3.0d, 1731.1173711867675d, 0, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((-0.8414709848078965d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.1102230246251565E-16d, (double) 3.37769972E15f, (double) 1.4E-45f, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: Continued fraction convergents failed to converge (in less than 0 iterations) for value 3,377,699,720,527,872");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        try {
//            int int8 = randomDataImpl0.nextPascal((int) 'a', (double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -1 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 63.76849625217041d + "'", double5 == 63.76849625217041d);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        well19937c6.setSeed((int) (byte) -1);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeedSecure();
        long long19 = randomDataGenerator14.nextPoisson(10.0d);
        long long21 = randomDataGenerator14.nextPoisson(1.1102230246251565E-16d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 13L + "'", long19 == 13L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        randomDataImpl0.reSeedSecure((long) (short) 0);
        int[] intArray10 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c11 = new org.apache.commons.math3.random.Well19937c(intArray10);
        org.apache.commons.math3.distribution.FDistribution fDistribution15 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c11, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution15.reseedRandomGenerator(0L);
        boolean boolean18 = fDistribution15.isSupportConnected();
        double double19 = fDistribution15.getNumeratorDegreesOfFreedom();
        double double21 = fDistribution15.density((double) 8.5328188E18f);
        try {
            double double22 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) fDistribution15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ConvergenceException; message: illegal state: Continued fraction diverged to NaN for value 0");
        } catch (org.apache.commons.math3.exception.ConvergenceException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.7845295083467018d + "'", double19 == 0.7845295083467018d);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        randomDataImpl0.reSeedSecure(0L);
        try {
            int int8 = randomDataImpl0.nextHypergeometric(0, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double1 = uniformRealDistribution0.getNumericalVariance();
//        double double2 = uniformRealDistribution0.sample();
//        double double4 = uniformRealDistribution0.cumulativeProbability(Double.NEGATIVE_INFINITY);
//        double double5 = uniformRealDistribution0.getSupportLowerBound();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5028800360316223d + "'", double2 == 0.5028800360316223d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        randomDataGenerator14.reSeedSecure(6L);
        double double22 = randomDataGenerator14.nextCauchy(1.323855013488585d, (double) 32);
        randomDataGenerator14.reSeed((long) '4');
        try {
            long long27 = randomDataGenerator14.nextSecureLong(100L, 9L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (9)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.104676167044543d + "'", double22 == 5.104676167044543d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 50);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 50 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 50 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math3.special.Gamma.gamma((-0.12467276988103379d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.737800781375096d) + "'", double1 == (-8.737800781375096d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextDouble();
        well19937c6.setSeed(1L);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2775708784361457d + "'", double14 == 0.2775708784361457d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double19 = randomDataGenerator14.nextGaussian((-0.5440211108893698d), 1.5395564933646284d);
        try {
            double double22 = randomDataGenerator14.nextGamma((-0.5440211108893698d), 0.7996929036670581d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.544)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.9895353071018667d) + "'", double19 == (-2.9895353071018667d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        try {
            int int18 = randomDataGenerator14.nextHypergeometric((int) 'a', 65, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: sample size (100) must be less than or equal to population size (97)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(0.6483608274590866d, 1731.1173711867675d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1731.117492603072d + "'", double2 == 1731.117492603072d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(0, (double) 3.0000002f, (-57.29577951308232d));
        int int4 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getEvaluations();
        int int6 = iterativeLegendreGaussIntegrator3.getIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        double double13 = well19937c6.nextDouble();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2775708784361457d + "'", double13 == 0.2775708784361457d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(32.94631867978169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.0d + "'", double1 == 33.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int1 = org.apache.commons.math3.util.FastMath.round(3.37769972E15f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 16L, 0.8827857294048556d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.999999999999998d + "'", double2 == 15.999999999999998d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 9L, (float) 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 100.0f, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01d + "'", double2 == 0.01d);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        long long7 = randomDataImpl0.nextSecureLong((long) 3, (long) 2147483647);
//        try {
//            double double11 = randomDataImpl0.nextUniform(Double.POSITIVE_INFINITY, (double) (-1.0f), false);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (∞) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2094144379L + "'", long7 == 2094144379L);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(99185.71921078372d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma1p(0.8827857294048556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.045013400852844d) + "'", double1 == (-0.045013400852844d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math3.util.FastMath.atan(1.772453850905516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0571243112754387d + "'", double1 == 1.0571243112754387d);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        long long7 = randomDataImpl0.nextSecureLong((long) 3, (long) 2147483647);
//        double double9 = randomDataImpl0.nextChiSquare(1731.1173711867675d);
//        try {
//            int int12 = randomDataImpl0.nextInt(5, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (5) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1226824399L + "'", long7 == 1226824399L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1687.8298593783145d + "'", double9 == 1687.8298593783145d);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(3.37769972E15f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 51 + "'", int1 == 51);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextGaussian();
        byte[] byteArray20 = new byte[] { (byte) 100, (byte) 1, (byte) 1, (byte) 100, (byte) 0 };
        well19937c6.nextBytes(byteArray20);
        double double22 = well19937c6.nextGaussian();
        long long23 = well19937c6.nextLong();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.19208726106988616d) + "'", double14 == (-0.19208726106988616d));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0977237767437487d + "'", double22 == 1.0977237767437487d);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4114307074210296442L) + "'", long23 == (-4114307074210296442L));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(1.1513313686408708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0730011037463432d + "'", double1 == 1.0730011037463432d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math3.special.Gamma.gamma((double) 50);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.082818640342675E62d + "'", double1 == 6.082818640342675E62d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
        try {
            double double4 = randomDataImpl0.nextChiSquare((-57.29577951308232d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-28.648)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.0d, (double) 16L, (double) 3.37769999E15f);
        double double5 = uniformRealDistribution3.density((double) 35);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        long long7 = randomDataImpl0.nextSecureLong((long) 3, (long) 2147483647);
//        try {
//            long long9 = randomDataImpl0.nextPoisson((-0.8414709848078965d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-0.841)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 361905842L + "'", long7 == 361905842L);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        fDistribution10.reseedRandomGenerator(0L);
        boolean boolean13 = fDistribution10.isSupportConnected();
        double double14 = fDistribution10.getNumeratorDegreesOfFreedom();
        try {
            double double15 = fDistribution10.sample();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ConvergenceException; message: illegal state: Continued fraction diverged to NaN for value 0");
        } catch (org.apache.commons.math3.exception.ConvergenceException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7845295083467018d + "'", double14 == 0.7845295083467018d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999971d + "'", double1 == 0.9999999999999971d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        double double11 = fDistribution10.getSupportUpperBound();
        double double12 = fDistribution10.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 1592091222L, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.59209126E9f + "'", float2 == 1.59209126E9f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.17453292519943295d, 0.4329944622372981d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.17453292519943298d + "'", double2 == 0.17453292519943298d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double1 = uniformRealDistribution0.getNumericalVariance();
        boolean boolean2 = uniformRealDistribution0.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString((int) (short) 10);
//        try {
//            int int7 = randomDataImpl0.nextBinomial((int) (short) -1, 80.3430694304528d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of trials (-1)");
//        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "d257f47c14" + "'", str4.equals("d257f47c14"));
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 65);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.562453851238172d) + "'", double1 == (-0.562453851238172d));
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double7 = randomDataImpl0.nextT(99185.71921078372d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 49.457940388075684d + "'", double5 == 49.457940388075684d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17046344861634313d + "'", double7 == 0.17046344861634313d);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) 1, 0.926433545773006d, 0.984807753012208d);
        int int4 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        try {
            double double10 = iterativeLegendreGaussIntegrator3.integrate(100, univariateFunction7, (double) (byte) 100, 1731.1173711867675d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        float float2 = org.apache.commons.math3.util.FastMath.min(1.1920929E-7f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1920929E-7f + "'", float2 == 1.1920929E-7f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.0f), (double) 5L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.setSeed(0L);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math3.util.FastMath.rint(0.9319894568729709d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(0, (double) 3.0000002f, (-57.29577951308232d));
        int int4 = iterativeLegendreGaussIntegrator3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        well19937c6.setSeed((int) (byte) 0);
        try {
            int int15 = well19937c6.nextInt((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((int) (byte) 0);
        boolean boolean2 = well19937c1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((double) 13L, 0.7845295083467018d, 0.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 11837.793094904797d, (java.lang.Number) 6, true);
        try {
            java.lang.String str5 = numberIsTooLargeException4.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double20 = randomDataGenerator14.nextUniform(0.0d, 22026.465794806718d, false);
        try {
            long long23 = randomDataGenerator14.nextLong((long) 32, (long) 16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (32) must be strictly less than upper bound (16)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11837.793094904797d + "'", double20 == 11837.793094904797d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution(10.0d, 0.9319894568729709d);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double7 = randomDataImpl0.nextT(99185.71921078372d);
//        try {
//            int int10 = randomDataImpl0.nextSecureInt(65, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (65) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 50.74723342713543d + "'", double5 == 50.74723342713543d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.9259353443344966d + "'", double7 == 1.9259353443344966d);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double0 = org.apache.commons.math3.analysis.integration.BaseAbstractUnivariateIntegrator.DEFAULT_RELATIVE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-6d + "'", double0 == 1.0E-6d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(0.06557458740714255d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.001144492455891449d + "'", double1 == 0.001144492455891449d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        int int20 = randomDataGenerator14.nextHypergeometric(100, 3, (int) (byte) 0);
        try {
            double double23 = randomDataGenerator14.nextF(0.001144492455891449d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018267969E13d + "'", double1 == 7.896296018267969E13d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(0.749803534235227d, (double) (-8532818744013321543L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.5328187440133212E18d + "'", double2 == 8.5328187440133212E18d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.3862944207245336d, (java.lang.Number) 32.94631867978169d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeed();
        try {
            randomDataGenerator14.setSecureAlgorithm("e21f1dfaad", "3321d6782f718f292b75c8f96e131e8a365eb2ecb4c7d5faf320fd74ce7a3dd951d2c765bbed422139c6c3c51d7005fd6ceb");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 3321d6782f718f292b75c8f96e131e8a365eb2ecb4c7d5faf320fd74ce7a3dd951d2c765bbed422139c6c3c51d7005fd6ceb");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double21 = randomDataGenerator14.nextGaussian((-0.8414709848078965d), 0.5028800360316223d);
//        try {
//            int int24 = randomDataGenerator14.nextZipf((int) (short) 10, (-0.6995216443485196d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (-0.7)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ca3d6464ba6ad2f69c5941e738536648443e3f1848263b1feacb6f03117dbb61858f2ce27f9caa62e7edaf03d956f407bf0b" + "'", str18.equals("ca3d6464ba6ad2f69c5941e738536648443e3f1848263b1feacb6f03117dbb61858f2ce27f9caa62e7edaf03d956f407bf0b"));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.6402726347684728d) + "'", double21 == (-1.6402726347684728d));
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-57.29577951308232d), (java.lang.Number) 0.6914113787084667d, false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        int[] intArray19 = new int[] { (byte) 0, (short) -1, 10, (byte) 1, (-1) };
        well19937c6.setSeed(intArray19);
        well19937c6.setSeed((long) 50);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math3.util.FastMath.floor(2.471053506302818d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math3.util.FastMath.acos(6.408381213480005E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 10L, (double) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.000001f + "'", float2 == 10.000001f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32, (java.lang.Number) (-0.0d), true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-0.0d) + "'", number6.equals((-0.0d)));
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        double double5 = randomDataImpl0.nextCauchy(1.5395564933646284d, (double) (byte) 100);
//        try {
//            int int8 = randomDataImpl0.nextInt(100, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-33.07636810195365d) + "'", double5 == (-33.07636810195365d));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        randomDataGenerator14.reSeedSecure(6L);
        double double22 = randomDataGenerator14.nextCauchy(1.323855013488585d, (double) 32);
        try {
            int int25 = randomDataGenerator14.nextInt((int) (byte) 1, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (1) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.104676167044543d + "'", double22 == 5.104676167044543d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        try {
            int int5 = randomDataImpl0.nextBinomial(32, 59.43874550876733d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 59.439 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 8.881784197001252E-16d);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 8.881784197001252E-16d + "'", number2.equals(8.881784197001252E-16d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        randomDataImpl0.reSeedSecure(0L);
//        int int7 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 100);
//        try {
//            double double9 = randomDataImpl0.nextChiSquare((-57.29577951308232d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-28.648)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        randomDataGenerator14.reSeedSecure(6L);
        double double22 = randomDataGenerator14.nextCauchy(1.323855013488585d, (double) 32);
        randomDataGenerator14.reSeed((long) '4');
        try {
            double double27 = randomDataGenerator14.nextUniform((double) 9.0f, (double) 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (9) must be strictly less than upper bound (5)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.104676167044543d + "'", double22 == 5.104676167044543d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.4131591025766d + "'", double1 == 148.4131591025766d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math3.util.FastMath.acos((-0.6995216443485196d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.345524211214144d + "'", double1 == 2.345524211214144d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) ' ', (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution3 = new org.apache.commons.math3.distribution.UniformRealDistribution((double) 10.0f, 3.883769450489952d, (double) 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (3.884)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        well19937c6.setSeed(0);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(59.43874550876733d, 6.006523924199709E-46d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 59.43874550876733d + "'", double2 == 59.43874550876733d);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double7 = randomDataImpl0.nextT(99185.71921078372d);
//        try {
//            int int10 = randomDataImpl0.nextPascal(6, (-0.12467276988103379d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -0.125 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.03870518630349d + "'", double5 == 52.03870518630349d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.2024265616032501d + "'", double7 == 1.2024265616032501d);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.926433545773006d, 0.3057575137911129d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9264335457730059d + "'", double2 == 0.9264335457730059d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math3.util.FastMath.log(8.729964732145538d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.166761329997479d + "'", double1 == 2.166761329997479d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        long long1 = org.apache.commons.math3.util.FastMath.round(3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        double double11 = fDistribution10.getSupportUpperBound();
        double double13 = fDistribution10.density((double) 10.0f);
        double double14 = fDistribution10.getSupportUpperBound();
        double double15 = fDistribution10.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 35L, 8.5328188E18f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//        double double2 = randomDataGenerator0.nextExponential(1.0E-9d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.034470991571415E-9d + "'", double2 == 1.034470991571415E-9d);
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        randomDataImpl0.reSeedSecure();
//        double double6 = randomDataImpl0.nextWeibull((double) 1, 0.5028800360316223d);
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl0.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.3139700764343245d + "'", double6 == 1.3139700764343245d);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeedSecure();
        long long19 = randomDataGenerator14.nextPoisson(10.0d);
        try {
            int int22 = randomDataGenerator14.nextInt((int) '4', 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (52) must be strictly less than upper bound (50)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 13L + "'", long19 == 13L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 32, (double) 1.0f, (double) (byte) 1);
        double double4 = fDistribution3.getNumericalVariance();
        boolean boolean5 = fDistribution3.isSupportLowerBoundInclusive();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 6.271995040159838E-9d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double4 = org.apache.commons.math3.special.Beta.logBeta(8.5328187440133212E18d, 33.0d, 0.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math3.util.FastMath.abs(6.271995040159838E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.271995040159838E-9d + "'", double1 == 6.271995040159838E-9d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 1, false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.3862944207245336d, (java.lang.Number) 32.94631867978169d, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1.386 is smaller than, or equal to, the minimum (32.946)" + "'", str4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1.386 is smaller than, or equal to, the minimum (32.946)"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeed();
        double double19 = randomDataGenerator14.nextT(1.1102230246251565E-16d);
        try {
            int int22 = randomDataGenerator14.nextInt((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 6.7039039649712985E153d + "'", double19 == 6.7039039649712985E153d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray1);
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int int17 = randomDataGenerator14.nextInt((int) ' ', (int) 'a');
        try {
            double double20 = randomDataGenerator14.nextGamma((-1.1081889917053853d), 25.75496032065573d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-1.108)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 50 + "'", int17 == 50);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(1731.1173711867675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1731.1173711867677d + "'", double1 == 1731.1173711867677d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        float float12 = well19937c6.nextFloat();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.92643344f + "'", float12 == 0.92643344f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1731.1173711867675d, (java.lang.Number) 0.9582095597417402d, false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 22026.465794806718d);
        java.lang.Throwable[] throwableArray2 = maxCountExceededException1.getSuppressed();
        java.lang.String str3 = maxCountExceededException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (22,026.466) exceeded" + "'", str3.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (22,026.466) exceeded"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-66.96947372144871d), 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.81454966921062784E18d + "'", double2 == 1.81454966921062784E18d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 6, (-4114307074210296442L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4114307074210296442L) + "'", long2 == (-4114307074210296442L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) 1, (int) (byte) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 1 is smaller than, or equal to, the minimum (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(32.0d, 6.271995040159838E-9d, Double.NEGATIVE_INFINITY, (int) (byte) 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 3, 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math3.util.FastMath.abs(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double1 = uniformRealDistribution0.getSupportLowerBound();
        double double2 = uniformRealDistribution0.getNumericalVariance();
        double double3 = uniformRealDistribution0.getNumericalVariance();
        double double4 = uniformRealDistribution0.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08333333333333333d + "'", double2 == 0.08333333333333333d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08333333333333333d + "'", double3 == 0.08333333333333333d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.718281828459045d, 7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(0.17046344861634313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1858543065259476d + "'", double1 == 0.1858543065259476d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 16, 0.7996929036670581d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 11837.793094904797d, (java.lang.Number) 6, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 6 + "'", number5.equals(6));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 97, (java.lang.Number) (-1.1081889917053853d), true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-1.6402726347684728d), 0.5008686546137775d, 0.3057575137911129d, 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(100.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double21 = randomDataGenerator14.nextGaussian((-0.8414709848078965d), 0.5028800360316223d);
//        int[] intArray24 = randomDataGenerator14.nextPermutation(35, 35);
//        int[] intArray27 = randomDataGenerator14.nextPermutation(6, 6);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0cf88dde671402621eb3f37fb963e96c5ee1e29ac848da61b00744f0b56761a231a98b48e3ee0dc43d69bc2b6f2b52f1a55a" + "'", str18.equals("0cf88dde671402621eb3f37fb963e96c5ee1e29ac848da61b00744f0b56761a231a98b48e3ee0dc43d69bc2b6f2b52f1a55a"));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.6402726347684728d) + "'", double21 == (-1.6402726347684728d));
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(intArray27);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.8827857294048556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(100, 181, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 32 is smaller than, or equal to, the minimum (181)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        try {
            org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator(5, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.001144492455891449d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
//        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
//        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
//        boolean boolean11 = well19937c6.nextBoolean();
//        double double12 = well19937c6.nextDouble();
//        well19937c6.clear();
//        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
//        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
//        java.lang.String str18 = randomDataGenerator14.nextSecureHexString((int) (short) 100);
//        double double20 = randomDataGenerator14.nextChiSquare((double) 9L);
//        try {
//            double double23 = randomDataGenerator14.nextCauchy((-15.887498983989955d), (-0.045013400852844d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0.045)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "53f31c48a08ab193334204baf09214d789a82f7847ff389d58edbf94e8f8b64775ea6600caa3f896a14e37e1ffbb77bee37a" + "'", str18.equals("53f31c48a08ab193334204baf09214d789a82f7847ff389d58edbf94e8f8b64775ea6600caa3f896a14e37e1ffbb77bee37a"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.729964732145538d + "'", double20 == 8.729964732145538d);
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        long long8 = randomDataImpl0.nextSecureLong(0L, (long) 10);
//        randomDataImpl0.reSeed();
//        try {
//            int int12 = randomDataImpl0.nextZipf(97, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-202.70059076939842d) + "'", double5 == (-202.70059076939842d));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3L + "'", long8 == 3L);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.436292814753874d + "'", double1 == 7.436292814753874d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException8);
        java.lang.Number number10 = numberIsTooLargeException8.getMax();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-0.0d) + "'", number10.equals((-0.0d)));
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        randomDataImpl0.reSeedSecure();
//        double double6 = randomDataImpl0.nextWeibull((double) 1, 0.5028800360316223d);
//        try {
//            double double9 = randomDataImpl0.nextGamma((-6.7039039649711095E153d), 0.3042952379405594d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-6,703,903,964,971,109,500,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.23508229952995405d + "'", double6 == 0.23508229952995405d);
//    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        double double5 = randomDataImpl0.nextCauchy(1.5395564933646284d, (double) (byte) 100);
//        try {
//            int int8 = randomDataImpl0.nextInt(1, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (1) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 89.13179334478279d + "'", double5 == 89.13179334478279d);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        int int1 = org.apache.commons.math3.util.FastMath.abs(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math3.exception.MathInternalError mathInternalError6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathInternalError6.getContext();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100 + "'", number5.equals(100));
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        double double11 = fDistribution10.getSupportUpperBound();
        double double12 = fDistribution10.getNumericalVariance();
        try {
            double[] doubleArray14 = fDistribution10.sample(1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ConvergenceException; message: illegal state: Continued fraction diverged to NaN for value 0");
        } catch (org.apache.commons.math3.exception.ConvergenceException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        try {
//            int int8 = randomDataImpl0.nextPascal((int) 'a', 54.360088752006774d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 54.36 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 284.3734136725657d + "'", double5 == 284.3734136725657d);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than the maximum (-0)" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than the maximum (-0)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeedSecure();
        int int20 = randomDataGenerator14.nextZipf((int) 'a', (double) 8.5328188E18f);
        try {
            int int24 = randomDataGenerator14.nextHypergeometric((int) (byte) 0, 35, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math3.special.Gamma.digamma(0.08971084836383868d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-11.585525638519265d) + "'", double1 == (-11.585525638519265d));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.3042952379405594d, 0.9582095597417402d, (double) (-1), (-0.19208726106988616d));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 9L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.0f + "'", float1 == 9.0f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double0 = org.apache.commons.math3.distribution.UniformRealDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math3.special.Gamma.invGamma1pm1(6.006523924199709E-46d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4670597006538995E-46d + "'", double1 == 3.4670597006538995E-46d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 32, (java.lang.Number) 3.0000002f, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 32 is larger than, or equal to, the maximum (3)" + "'", str4.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 32 is larger than, or equal to, the maximum (3)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32 + "'", number5.equals(32));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        double double14 = well19937c6.nextGaussian();
        well19937c6.setSeed((long) 10);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.19208726106988616d) + "'", double14 == (-0.19208726106988616d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        try {
            org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution2 = new org.apache.commons.math3.distribution.UniformRealDistribution(0.9205519333349953d, 0.7996929036670581d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0.921) must be strictly less than upper bound (0.8)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double19 = randomDataGenerator14.nextGaussian((-0.5440211108893698d), 1.5395564933646284d);
        double double21 = randomDataGenerator14.nextChiSquare((double) 52.0f);
        try {
            int int24 = randomDataGenerator14.nextPascal(0, 69.44349531847722d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of successes (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.9895353071018667d) + "'", double19 == (-2.9895353071018667d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 59.43874550876733d + "'", double21 == 59.43874550876733d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double4 = org.apache.commons.math3.special.Beta.regularizedBeta(0.49714987269413385d, (-8.737800781375096d), (double) 35L, 2.2240228754933433d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) ' ', 3.377699720543769E15d, (double) 0L);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double7 = randomDataImpl0.nextT(99185.71921078372d);
//        try {
//            double double9 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-399.4672939454619d) + "'", double5 == (-399.4672939454619d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.115033365634987d + "'", double7 == 1.115033365634987d);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) 0);
        randomDataImpl0.reSeedSecure(0L);
        try {
            randomDataImpl0.setSecureAlgorithm("889d524203c865b921b3ec035dd12e27e0874a3c60d27fef410eadc67d25a4110e6642339b692a4037e837273c4cd1bbe589", "org.apache.commons.math3.exception.NumberIsTooSmallException: 1.386 is smaller than, or equal to, the minimum (32.946)");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.NumberIsTooSmallException: 1.386 is smaller than, or equal to, the minimum (32.946)");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.2184249125858766d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeedSecure();
        try {
            double double20 = randomDataGenerator14.nextF(Double.POSITIVE_INFINITY, (-0.8414709848078964d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-0.841)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.0d), (double) (byte) 10);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        int int17 = randomDataGenerator14.nextInt((int) ' ', (int) 'a');
        int int20 = randomDataGenerator14.nextPascal((int) (byte) 1, 0.9075712110370514d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 50 + "'", int17 == 50);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(1.0E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        randomDataImpl0.reSeedSecure(0L);
//        int int7 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 100);
//        try {
//            int int10 = randomDataImpl0.nextBinomial(32, 59.43874550876733d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 59.439 out of [0, 1] range");
//        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 49 + "'", int7 == 49);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double17 = randomDataGenerator14.nextUniform(1.1102230246251565E-16d, 100.0d);
        randomDataGenerator14.reSeedSecure(6L);
        double double22 = randomDataGenerator14.nextCauchy(1.323855013488585d, (double) 32);
        randomDataGenerator14.reSeed((long) '4');
        try {
            int int27 = randomDataGenerator14.nextZipf(100, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.75708784361457d + "'", double17 == 27.75708784361457d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.104676167044543d + "'", double22 == 5.104676167044543d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math3.special.Gamma.gamma((-575.3905953692303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math3.util.FastMath.log10((-2.9895353071018667d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        randomDataGenerator14.reSeedSecure();
        int int20 = randomDataGenerator14.nextZipf((int) 'a', (double) 8.5328188E18f);
        double double23 = randomDataGenerator14.nextCauchy(0.0d, (double) 'a');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-89.15340488104309d) + "'", double23 == (-89.15340488104309d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) (byte) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        int int20 = randomDataGenerator14.nextHypergeometric(100, 3, (int) (byte) 0);
        try {
            long long23 = randomDataGenerator14.nextSecureLong((long) 'a', (long) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (97) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((-2.9895353071018667d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9496891896313345d) + "'", double1 == (-0.9496891896313345d));
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString((int) (byte) 10);
//        try {
//            int int9 = randomDataImpl0.nextHypergeometric(0, 51, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4440cd5c0f" + "'", str5.equals("4440cd5c0f"));
//    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double8 = randomDataImpl0.nextWeibull(0.5008686546137775d, (double) 3.0000002f);
//        try {
//            int int11 = randomDataImpl0.nextInt((int) (byte) 10, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (10) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 40.40281410420545d + "'", double5 == 40.40281410420545d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 13.969614220978809d + "'", double8 == 13.969614220978809d);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(1.3902777590909514d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double1 = uniformRealDistribution0.getNumericalVariance();
//        double double2 = uniformRealDistribution0.sample();
//        double double4 = uniformRealDistribution0.cumulativeProbability(Double.NEGATIVE_INFINITY);
//        try {
//            double double7 = uniformRealDistribution0.probability(99185.71921078372d, 8.881784197001252E-16d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (99,185.719) must be less than or equal to upper endpoint (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.19617066527205096d + "'", double2 == 0.19617066527205096d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double20 = randomDataGenerator14.nextUniform(0.0d, 22026.465794806718d, false);
        try {
            randomDataGenerator14.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooSmallException: 1.386 is smaller than, or equal to, the minimum (32.946)", "org.apache.commons.math3.exception.NumberIsTooLargeException: 32 is larger than, or equal to, the maximum (3)");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.NumberIsTooLargeException: 32 is larger than, or equal to, the maximum (3)");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11837.793094904797d + "'", double20 == 11837.793094904797d);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        double double6 = randomDataImpl0.nextGamma(Double.POSITIVE_INFINITY, 0.3949340668481562d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9412668030724239d + "'", double3 == 0.9412668030724239d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "d9e75d8bcc" + "'", str8.equals("d9e75d8bcc"));
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass9 = numberIsTooLargeException8.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass20 = numberIsTooLargeException19.getClass();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext21 = numberIsTooLargeException19.getContext();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 100.0f, wildcardClass9, "", true, 1, numberIsTooLargeException19 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable3, objArray22);
        org.apache.commons.math3.exception.MathInternalError mathInternalError24 = new org.apache.commons.math3.exception.MathInternalError(localizable2, objArray22);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 1.2112921755133716d, objArray22);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(exceptionContext21);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double2 = org.apache.commons.math3.util.FastMath.pow(1.1712659507785417d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3716.0962449481235d + "'", double2 == 3716.0962449481235d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        try {
            org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(1.81454966921062784E18d, 0.0d, 1.0571243112754387d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 32, (java.lang.Number) 1.0d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math3.analysis.integration.IterativeLegendreGaussIntegrator((int) (short) 1, 0.926433545773006d, 0.984807753012208d);
        int int4 = iterativeLegendreGaussIntegrator3.getMinimalIterationCount();
        int int5 = iterativeLegendreGaussIntegrator3.getMaximalIterationCount();
        int int6 = iterativeLegendreGaussIntegrator3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double8 = randomDataImpl0.nextWeibull(80.3430694304528d, 0.9635992973337606d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 258.91533352550596d + "'", double5 == 258.91533352550596d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9536893818313428d + "'", double8 == 0.9536893818313428d);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double2 = uniformRealDistribution0.density(Double.POSITIVE_INFINITY);
//        boolean boolean3 = uniformRealDistribution0.isSupportLowerBoundInclusive();
//        double double4 = uniformRealDistribution0.getSupportLowerBound();
//        double double5 = uniformRealDistribution0.sample();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9564236239007664d + "'", double5 == 0.9564236239007664d);
//    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double9 = randomDataImpl0.nextUniform(148.4131591025766d, 54.360088752006774d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (148.413) must be strictly less than upper bound (54.36)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6L + "'", long5 == 6L);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 1.2112921755133716d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential((double) 100.0f);
        double double19 = randomDataGenerator14.nextBeta((double) 13L, (double) 2147483647);
        java.lang.String str21 = randomDataGenerator14.nextHexString((int) '#');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 80.3430694304528d + "'", double16 == 80.3430694304528d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 6.271995040159838E-9d + "'", double19 == 6.271995040159838E-9d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "dc49eec3157946bb038b6746060d5138398" + "'", str21.equals("dc49eec3157946bb038b6746060d5138398"));
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        double double7 = randomDataImpl0.nextUniform(0.3057575137911129d, 1.5430806348152437d, false);
//        try {
//            long long10 = randomDataImpl0.nextLong((long) (byte) 100, (long) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9630880983162583d + "'", double3 == 0.9630880983162583d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.40246710029827887d + "'", double7 == 0.40246710029827887d);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double2 = org.apache.commons.math3.special.Beta.logBeta((double) 2L, 2.003677274821031d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7948214260591802d) + "'", double2 == (-1.7948214260591802d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        try {
            double double3 = randomDataGenerator0.nextBeta((double) (byte) -1, 0.7845295083467018d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.175, 0.825]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        java.lang.Class<?> wildcardClass5 = numberIsTooLargeException4.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-0.0d), true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooLargeException9);
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathInternalError mathInternalError14 = new org.apache.commons.math3.exception.MathInternalError(localizable12, objArray13);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException9, localizable11, objArray13);
        org.apache.commons.math3.exception.MathInternalError mathInternalError16 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray13);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.6914113787084667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3690202941402084d) + "'", double1 == (-0.3690202941402084d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 13L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
//        double double2 = uniformRealDistribution0.density(Double.POSITIVE_INFINITY);
//        boolean boolean3 = uniformRealDistribution0.isSupportLowerBoundInclusive();
//        double double4 = uniformRealDistribution0.sample();
//        double double5 = uniformRealDistribution0.sample();
//        double double7 = uniformRealDistribution0.density(0.0d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.24304578269029964d + "'", double4 == 0.24304578269029964d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.753356491091534d + "'", double5 == 0.753356491091534d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) ' ', (double) 3);
//        try {
//            long long6 = randomDataImpl0.nextSecureLong((long) 181, (long) 97);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (181) must be strictly less than upper bound (97)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8956761000003628d + "'", double3 == 0.8956761000003628d);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution(0.5772156649015329d, (double) 16L);
        fDistribution2.reseedRandomGenerator((long) 65);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) -1);
//        double double4 = randomDataImpl0.nextExponential(0.01d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.003476002462657224d + "'", double4 == 0.003476002462657224d);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-0.0d));
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-0.0d) + "'", number2.equals((-0.0d)));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) -1);
        randomDataImpl0.reSeed((long) 1);
        try {
            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooSmallException: 1.386 is smaller than, or equal to, the minimum (32.946)", "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (22,026.466) exceeded");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (22,026.466) exceeded");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((-0.045013400852844d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 1.59209126E9f, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963274230012d + "'", double2 == 1.5707963274230012d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(0.5123616548188537d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5659268413338335d + "'", double1 == 0.5659268413338335d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) 9L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1972245773362196d + "'", double1 == 2.1972245773362196d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        double double11 = fDistribution10.getSupportUpperBound();
        double double13 = fDistribution10.density((double) 10.0f);
        double double14 = fDistribution10.getSupportUpperBound();
        boolean boolean15 = fDistribution10.isSupportConnected();
        boolean boolean16 = fDistribution10.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math3.special.Gamma.logGamma(31.95163256506926d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 77.92539162385854d + "'", double1 == 77.92539162385854d);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        double double5 = randomDataImpl0.nextCauchy((double) '#', (double) 20.0f);
//        double double8 = randomDataImpl0.nextWeibull(0.5008686546137775d, (double) 3.0000002f);
//        double double10 = randomDataImpl0.nextChiSquare(3.141592653589793d);
//        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl0.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.96068987357719d + "'", double5 == 35.96068987357719d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.2490842657264565d + "'", double8 == 1.2490842657264565d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.3879308182597745d + "'", double10 == 4.3879308182597745d);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math3.special.Gamma.lanczos(258.91533352550596d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.043585699161918d + "'", double1 == 1.043585699161918d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int int2 = org.apache.commons.math3.util.FastMath.min(51, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math3.distribution.FDistribution fDistribution2 = new org.apache.commons.math3.distribution.FDistribution(0.5772156649015329d, (double) 16L);
        java.lang.Class<?> wildcardClass3 = fDistribution2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) (short) 0, 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 11837.793094904797d, (java.lang.Number) 6, true);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0.17453292519943295d, 10 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable7, objArray10);
        org.apache.commons.math3.exception.MathInternalError mathInternalError12 = new org.apache.commons.math3.exception.MathInternalError(localizable6, objArray10);
        java.lang.Throwable[] throwableArray13 = mathInternalError12.getSuppressed();
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, localizable5, (java.lang.Object[]) throwableArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 61326.09864298752d, (java.lang.Number) (-0.19066703818164438d), true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double16 = randomDataGenerator14.nextExponential(Double.POSITIVE_INFINITY);
        double double19 = randomDataGenerator14.nextGaussian((-0.5440211108893698d), 1.5395564933646284d);
        try {
            double double21 = randomDataGenerator14.nextChiSquare(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.9895353071018667d) + "'", double19 == (-2.9895353071018667d));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, '4', (short) 0, 0 };
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        org.apache.commons.math3.distribution.FDistribution fDistribution10 = new org.apache.commons.math3.distribution.FDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 0.7845295083467018d, Double.POSITIVE_INFINITY, (double) 3);
        boolean boolean11 = well19937c6.nextBoolean();
        double double12 = well19937c6.nextDouble();
        well19937c6.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        double double15 = well19937c6.nextDouble();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.926433545773006d + "'", double12 == 0.926433545773006d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2775708784361457d + "'", double15 == 0.2775708784361457d);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson(0.17453292519943295d);
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        long long7 = randomDataImpl0.nextSecureLong((long) 3, (long) 2147483647);
//        try {
//            long long10 = randomDataImpl0.nextSecureLong((long) 6, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (6) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 815214463L + "'", long7 == 815214463L);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution(1.5395564933646284d, 1.1712659507785417d, (-0.026843950388637516d));
        boolean boolean4 = fDistribution3.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.000004f + "'", float1 == 35.000004f);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.distribution.FDistribution fDistribution3 = new org.apache.commons.math3.distribution.FDistribution((double) 10.0f, 2.718281828459045d, (double) (-8532818744013321543L));
        double double4 = fDistribution3.getSupportUpperBound();
        double double5 = fDistribution3.getSupportUpperBound();
        try {
            double double8 = fDistribution3.cumulativeProbability((-0.8414709848078964d), (-3.288230404428106d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (-0.841) must be less than or equal to upper endpoint (-3.288)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.distribution.UniformRealDistribution uniformRealDistribution0 = new org.apache.commons.math3.distribution.UniformRealDistribution();
        double double1 = uniformRealDistribution0.getNumericalVariance();
        double double2 = uniformRealDistribution0.getSupportLowerBound();
        double double4 = uniformRealDistribution0.probability((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08333333333333333d + "'", double1 == 0.08333333333333333d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(2.003677274821031d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        randomDataImpl0.reSeedSecure(0L);
//        double double6 = randomDataImpl0.nextT(5.916079783099616d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.1693148998272735d + "'", double6 == 3.1693148998272735d);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 65, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 65L + "'", long2 == 65L);
    }
}

