import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 1, 0.0d, (double) 100.0f);
        harmonicFitter1.addObservedPoint((double) (byte) -1, (double) (-1L));
        harmonicFitter1.addObservedPoint((double) (byte) 100, (double) 10.0f);
        harmonicFitter1.addObservedPoint((double) 0.0f, (double) 100.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint19 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 10L, (double) (byte) 0, (double) 100L);
        harmonicFitter1.addObservedPoint(weightedObservedPoint19);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 100);
        harmonicFitter1.addObservedPoint((double) (short) -1, (double) '#', 97.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException6.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Object obj10 = exceptionContext8.getValue("");
        java.lang.Object obj12 = exceptionContext8.getValue("hi!");
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray20 = numberIsTooSmallException19.getSuppressed();
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray20);
        org.apache.commons.math3.exception.ZeroException zeroException22 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray21);
        exceptionContext8.addMessage(localizable13, objArray21);
        org.apache.commons.math3.exception.ZeroException zeroException24 = new org.apache.commons.math3.exception.ZeroException(localizable1, objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray5 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer6 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter7 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer6);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint11 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter7.addObservedPoint(weightedObservedPoint11);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer13 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter14 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer13);
        harmonicFitter14.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint19 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) ' ', (double) 10.0f, (double) 'a');
        harmonicFitter14.addObservedPoint(weightedObservedPoint19);
        harmonicFitter7.addObservedPoint(weightedObservedPoint19);
        harmonicFitter1.addObservedPoint(weightedObservedPoint19);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint26 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) ' ', (double) 10.0f, (double) 'a');
        harmonicFitter1.addObservedPoint(weightedObservedPoint26);
        org.junit.Assert.assertNotNull(weightedObservedPointArray5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter1.addObservedPoint(weightedObservedPoint5);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer7 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter8 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer7);
        harmonicFitter8.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint13 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) ' ', (double) 10.0f, (double) 'a');
        harmonicFitter8.addObservedPoint(weightedObservedPoint13);
        harmonicFitter1.addObservedPoint(weightedObservedPoint13);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (short) -1, 10.0d, (double) (byte) -1);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric8 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer13 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter14 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer13);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint18 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter14.addObservedPoint(weightedObservedPoint18);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double24 = weightedObservedPoint23.getWeight();
        double double25 = weightedObservedPoint23.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint29 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double30 = weightedObservedPoint29.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint34 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer35 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter36 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer35);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint40 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter36.addObservedPoint(weightedObservedPoint40);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray42 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint12, weightedObservedPoint18, weightedObservedPoint23, weightedObservedPoint29, weightedObservedPoint34, weightedObservedPoint40 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser43 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray42);
        double[] doubleArray44 = parameterGuesser43.guess();
        try {
            double[] doubleArray45 = harmonicFitter1.fit(parametric8, doubleArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric6 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint10 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer11 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter12 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer11);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter12.addObservedPoint(weightedObservedPoint16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double22 = weightedObservedPoint21.getWeight();
        double double23 = weightedObservedPoint21.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double28 = weightedObservedPoint27.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer33 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter34 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer33);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint38 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter34.addObservedPoint(weightedObservedPoint38);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray40 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint10, weightedObservedPoint16, weightedObservedPoint21, weightedObservedPoint27, weightedObservedPoint32, weightedObservedPoint38 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser41 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray40);
        double[] doubleArray42 = parameterGuesser41.guess();
        double[] doubleArray43 = parameterGuesser41.guess();
        try {
            double[] doubleArray44 = harmonicFitter1.fit(parametric6, doubleArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats8, 10, (byte) 0 };
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray11);
        org.apache.commons.math3.exception.ZeroException zeroException14 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray11);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) zeroException14);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        zeroException14.addSuppressed((java.lang.Throwable) numberIsTooSmallException20);
        java.lang.Throwable[] throwableArray22 = numberIsTooSmallException20.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray22);
        java.lang.Throwable[] throwableArray24 = zeroException23.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext25 = zeroException23.getContext();
        java.lang.Number number26 = zeroException23.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(exceptionContext25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0 + "'", number26.equals(0));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object obj8 = exceptionContext6.getValue("");
        java.lang.Class<?> wildcardClass9 = exceptionContext6.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint8 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (byte) 100, (double) (byte) 100, (double) (byte) -1);
        harmonicFitter1.addObservedPoint(weightedObservedPoint8);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric11 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer16 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter17 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter17.addObservedPoint(weightedObservedPoint21);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint26 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double27 = weightedObservedPoint26.getWeight();
        double double28 = weightedObservedPoint26.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double33 = weightedObservedPoint32.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint37 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer38 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter39 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer38);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter39.addObservedPoint(weightedObservedPoint43);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray45 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint15, weightedObservedPoint21, weightedObservedPoint26, weightedObservedPoint32, weightedObservedPoint37, weightedObservedPoint43 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser46 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray45);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser47 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray45);
        double[] doubleArray48 = parameterGuesser47.guess();
        double[] doubleArray49 = parameterGuesser47.guess();
        try {
            double[] doubleArray50 = harmonicFitter1.fit(0, parametric11, doubleArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10, (byte) 0 };
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray5);
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats11, 10, (byte) 0 };
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray15);
        java.lang.Throwable[] throwableArray17 = mathIllegalStateException16.getSuppressed();
        zeroException8.addSuppressed((java.lang.Throwable) mathIllegalStateException16);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) zeroException8);
        java.lang.Object obj21 = exceptionContext19.getValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than, or equal to, the minimum (100)");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats3, 10, (byte) 0 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray6);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        mathIllegalStateException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Number number15 = numberIsTooSmallException13.getArgument();
        java.lang.Throwable[] throwableArray16 = numberIsTooSmallException13.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0d + "'", number15.equals(0.0d));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10, (byte) 0 };
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray5);
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats11, 10, (byte) 0 };
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray15);
        java.lang.Throwable[] throwableArray17 = mathIllegalStateException16.getSuppressed();
        zeroException8.addSuppressed((java.lang.Throwable) mathIllegalStateException16);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) zeroException8);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray24 = numberIsTooSmallException23.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, (java.lang.Number) (byte) -1, (java.lang.Number) 10.0d, false);
        numberIsTooSmallException23.addSuppressed((java.lang.Throwable) numberIsTooSmallException29);
        java.lang.Number number31 = numberIsTooSmallException23.getMin();
        zeroException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException23);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 10.0f + "'", number31.equals(10.0f));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats1, 10, (byte) 0 };
        java.lang.Object[] objArray5 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray4);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        mathIllegalStateException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException11);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = mathIllegalStateException6.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = mathIllegalStateException6.getContext();
        java.lang.Throwable[] throwableArray15 = mathIllegalStateException6.getSuppressed();
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean22 = numberIsTooSmallException21.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray28 = new java.lang.Object[] { localizedFormats25, 10, (byte) 0 };
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray28);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, objArray28);
        org.apache.commons.math3.exception.ZeroException zeroException31 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, objArray28);
        numberIsTooSmallException21.addSuppressed((java.lang.Throwable) zeroException31);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats33, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        zeroException31.addSuppressed((java.lang.Throwable) numberIsTooSmallException37);
        java.lang.Throwable[] throwableArray39 = numberIsTooSmallException37.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException6, localizable16, (java.lang.Object[]) throwableArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray39);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats7, 10, (byte) 0 };
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray11);
        java.lang.Throwable[] throwableArray13 = mathIllegalStateException12.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = mathIllegalStateException14.getContext();
        java.lang.Throwable throwable16 = exceptionContext15.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertNotNull(throwable16);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 1, 0.0d, (double) 100.0f);
        harmonicFitter1.addObservedPoint((double) (byte) -1, (double) (-1L));
        harmonicFitter1.addObservedPoint((double) (byte) 100, (double) 10.0f);
        harmonicFitter1.addObservedPoint((double) 0.0f, (double) 100.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint19 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 10L, (double) (byte) 0, (double) 100L);
        harmonicFitter1.addObservedPoint(weightedObservedPoint19);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 100);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray24 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray24);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray14 = numberIsTooSmallException13.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray14);
        java.lang.Throwable[] throwableArray16 = mathIllegalStateException15.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = mathIllegalStateException15.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray24 = new java.lang.Object[] { localizedFormats21, 10, (byte) 0 };
        java.lang.Object[] objArray25 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, objArray24);
        org.apache.commons.math3.exception.ZeroException zeroException27 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray24);
        java.lang.Throwable throwable28 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray33 = new java.lang.Object[] { localizedFormats30, 10, (byte) 0 };
        java.lang.Object[] objArray34 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray33);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable28, (org.apache.commons.math3.exception.util.Localizable) localizedFormats29, objArray34);
        java.lang.Throwable[] throwableArray36 = mathIllegalStateException35.getSuppressed();
        zeroException27.addSuppressed((java.lang.Throwable) mathIllegalStateException35);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray44 = new java.lang.Object[] { localizedFormats41, 10, (byte) 0 };
        java.lang.Object[] objArray45 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray44);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable39, (org.apache.commons.math3.exception.util.Localizable) localizedFormats40, objArray45);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException47 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException35, (org.apache.commons.math3.exception.util.Localizable) localizedFormats38, objArray45);
        java.lang.Object[] objArray48 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray45);
        java.lang.Object[] objArray49 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray45);
        exceptionContext17.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, objArray45);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray45);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats52, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray57 = numberIsTooSmallException56.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext58 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException56);
        java.lang.Object obj60 = exceptionContext58.getValue("");
        java.lang.Object obj62 = exceptionContext58.getValue("hi!");
        org.apache.commons.math3.exception.util.Localizable localizable63 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException69 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats65, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray70 = numberIsTooSmallException69.getSuppressed();
        java.lang.Object[] objArray71 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray70);
        org.apache.commons.math3.exception.ZeroException zeroException72 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats64, objArray71);
        exceptionContext58.addMessage(localizable63, objArray71);
        java.lang.Object[] objArray74 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray71);
        org.apache.commons.math3.exception.ZeroException zeroException75 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray74);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException76 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray74);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext77 = numberIsTooSmallException3.getContext();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0f + "'", number4.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats40.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats41.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats52.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNull(obj60);
        org.junit.Assert.assertNull(obj62);
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats64.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats65.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(exceptionContext77);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ILL_CONDITIONED_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        java.lang.Class<?> wildcardClass8 = localizedFormats7.getClass();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray18 = new java.lang.Object[] { localizedFormats15, 10, (byte) 0 };
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray18);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray18);
        java.lang.Throwable throwable22 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray27 = new java.lang.Object[] { localizedFormats24, 10, (byte) 0 };
        java.lang.Object[] objArray28 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray27);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable22, (org.apache.commons.math3.exception.util.Localizable) localizedFormats23, objArray28);
        java.lang.Throwable[] throwableArray30 = mathIllegalStateException29.getSuppressed();
        zeroException21.addSuppressed((java.lang.Throwable) mathIllegalStateException29);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable33 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray38 = new java.lang.Object[] { localizedFormats35, 10, (byte) 0 };
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable33, (org.apache.commons.math3.exception.util.Localizable) localizedFormats34, objArray39);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats32, objArray39);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint45 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double46 = weightedObservedPoint45.getWeight();
        java.lang.Object[] objArray47 = new java.lang.Object[] { localizedFormats10, localizedFormats11, localizedFormats12, localizedFormats32, double46 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray47);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException49 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILL_CONDITIONED_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILL_CONDITIONED_OPERATOR));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-1.0d) + "'", double46 == (-1.0d));
        org.junit.Assert.assertNotNull(objArray47);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(97.0d, (double) 100L, (double) 0.0f);
        double double4 = weightedObservedPoint3.getX();
        double double5 = weightedObservedPoint3.getWeight();
        double double6 = weightedObservedPoint3.getWeight();
        double double7 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Number number7 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10, (byte) 0 };
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray5);
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats11, 10, (byte) 0 };
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray15);
        java.lang.Throwable[] throwableArray17 = mathIllegalStateException16.getSuppressed();
        zeroException8.addSuppressed((java.lang.Throwable) mathIllegalStateException16);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable20 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray25 = new java.lang.Object[] { localizedFormats22, 10, (byte) 0 };
        java.lang.Object[] objArray26 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray25);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable20, (org.apache.commons.math3.exception.util.Localizable) localizedFormats21, objArray26);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException16, (org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray26);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext29 = mathIllegalStateException16.getContext();
        org.apache.commons.math3.exception.util.Localizable localizable30 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats31, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray36 = numberIsTooSmallException35.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext37 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException35);
        java.lang.Object obj39 = exceptionContext37.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats41, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray46 = numberIsTooSmallException45.getSuppressed();
        java.lang.Object[] objArray47 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray46);
        exceptionContext37.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats40, objArray47);
        exceptionContext29.addMessage(localizable30, objArray47);
        java.util.Set<java.lang.String> strSet50 = exceptionContext29.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(exceptionContext29);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats40.equals(org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats41.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(strSet50);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        try {
            double[] doubleArray6 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 0 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0d, (java.lang.Number) 0L, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats7, 10, (byte) 0 };
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray11);
        java.lang.Throwable[] throwableArray13 = mathIllegalStateException12.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = mathIllegalStateException14.getContext();
        java.lang.Object obj17 = exceptionContext15.getValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than, or equal to, the minimum (100)");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray29 = new java.lang.Object[] { localizedFormats26, 10, (byte) 0 };
        java.lang.Object[] objArray30 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable24, (org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray30);
        java.lang.Throwable[] throwableArray32 = mathIllegalStateException31.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException22, (org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Object[]) throwableArray32);
        exceptionContext15.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        java.lang.Number number40 = numberIsTooSmallException39.getArgument();
        java.lang.String str41 = numberIsTooSmallException39.toString();
        exceptionContext15.setValue("points {0} and {1} are not strictly decreasing ({2} <= {3})", (java.lang.Object) numberIsTooSmallException39);
        java.lang.Number number43 = numberIsTooSmallException39.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0.0f + "'", number40.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)" + "'", str41.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)"));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0f + "'", number43.equals(0.0f));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 100.0d, false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint8 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer9 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter10 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer9);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter10.addObservedPoint(weightedObservedPoint14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint19 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double20 = weightedObservedPoint19.getWeight();
        double double21 = weightedObservedPoint19.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint25 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double26 = weightedObservedPoint25.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint30 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer31 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter32 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer31);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint36 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter32.addObservedPoint(weightedObservedPoint36);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray38 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint8, weightedObservedPoint14, weightedObservedPoint19, weightedObservedPoint25, weightedObservedPoint30, weightedObservedPoint36 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser39 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray38);
        double[] doubleArray40 = parameterGuesser39.guess();
        double[] doubleArray41 = parameterGuesser39.guess();
        try {
            double[] doubleArray42 = harmonicFitter1.fit(doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray14 = numberIsTooSmallException13.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats18, 10, (byte) 0 };
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray21);
        exceptionContext15.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray21);
        java.util.Set<java.lang.String> strSet25 = exceptionContext15.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        exceptionContext15.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray27);
        org.apache.commons.math3.exception.ZeroException zeroException29 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray27);
        java.lang.Object[] objArray30 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(strSet25);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), 0.0d);
        harmonicFitter1.addObservedPoint((double) 1, (double) 0L, (double) ' ');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer13 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter14 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer13);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint18 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter14.addObservedPoint(weightedObservedPoint18);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double24 = weightedObservedPoint23.getWeight();
        double double25 = weightedObservedPoint23.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint29 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double30 = weightedObservedPoint29.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint34 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer35 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter36 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer35);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint40 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter36.addObservedPoint(weightedObservedPoint40);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray42 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint12, weightedObservedPoint18, weightedObservedPoint23, weightedObservedPoint29, weightedObservedPoint34, weightedObservedPoint40 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser43 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray42);
        double[] doubleArray44 = parameterGuesser43.guess();
        double[] doubleArray45 = parameterGuesser43.guess();
        double[] doubleArray46 = parameterGuesser43.guess();
        try {
            double[] doubleArray47 = harmonicFitter1.fit(doubleArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException6.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        java.lang.Throwable[] throwableArray9 = mathIllegalStateException8.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException8.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats14, 10, (byte) 0 };
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray17);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray17);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats23, 10, (byte) 0 };
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable21, (org.apache.commons.math3.exception.util.Localizable) localizedFormats22, objArray27);
        java.lang.Throwable[] throwableArray29 = mathIllegalStateException28.getSuppressed();
        zeroException20.addSuppressed((java.lang.Throwable) mathIllegalStateException28);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable32 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray37 = new java.lang.Object[] { localizedFormats34, 10, (byte) 0 };
        java.lang.Object[] objArray38 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray37);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable32, (org.apache.commons.math3.exception.util.Localizable) localizedFormats33, objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException28, (org.apache.commons.math3.exception.util.Localizable) localizedFormats31, objArray38);
        java.lang.Object[] objArray41 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        java.lang.Object[] objArray42 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        exceptionContext10.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats9, 10, (byte) 0 };
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER;
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats18, 10, (byte) 0 };
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable16, (org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, objArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray22);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext26 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext27 = numberIsTooSmallException4.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(exceptionContext26);
        org.junit.Assert.assertNotNull(exceptionContext27);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint(0.0d, (double) (byte) 0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint7 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint7);
        harmonicFitter1.addObservedPoint((double) 10, (double) (byte) 1);
        harmonicFitter1.addObservedPoint((double) 10L, (double) 100L, 100.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats7, 10, (byte) 0 };
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray10);
        org.apache.commons.math3.exception.ZeroException zeroException13 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray10);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) zeroException13);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        zeroException13.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats22, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray27 = numberIsTooSmallException26.getSuppressed();
        java.lang.Object[] objArray28 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray27);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException19, (org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) throwableArray27);
        java.lang.Object[] objArray30 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray27);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint6 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1.0f), (-1.0d), 1.0d);
        harmonicFitter1.addObservedPoint(weightedObservedPoint6);
        harmonicFitter1.addObservedPoint(32.0d, (double) 100);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10, (byte) 0 };
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray5);
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats11, 10, (byte) 0 };
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray15);
        java.lang.Throwable[] throwableArray17 = mathIllegalStateException16.getSuppressed();
        zeroException8.addSuppressed((java.lang.Throwable) mathIllegalStateException16);
        java.lang.Throwable[] throwableArray19 = mathIllegalStateException16.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray29 = new java.lang.Object[] { localizedFormats26, 10, (byte) 0 };
        java.lang.Object[] objArray30 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray29);
        org.apache.commons.math3.exception.ZeroException zeroException32 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, objArray29);
        java.lang.Throwable throwable33 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray38 = new java.lang.Object[] { localizedFormats35, 10, (byte) 0 };
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable33, (org.apache.commons.math3.exception.util.Localizable) localizedFormats34, objArray39);
        java.lang.Throwable[] throwableArray41 = mathIllegalStateException40.getSuppressed();
        zeroException32.addSuppressed((java.lang.Throwable) mathIllegalStateException40);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable44 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray49 = new java.lang.Object[] { localizedFormats46, 10, (byte) 0 };
        java.lang.Object[] objArray50 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray49);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException51 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable44, (org.apache.commons.math3.exception.util.Localizable) localizedFormats45, objArray50);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException52 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException40, (org.apache.commons.math3.exception.util.Localizable) localizedFormats43, objArray50);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint56 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double57 = weightedObservedPoint56.getWeight();
        java.lang.Object[] objArray58 = new java.lang.Object[] { localizedFormats21, localizedFormats22, localizedFormats23, localizedFormats43, double57 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, objArray58);
        mathIllegalStateException16.addSuppressed((java.lang.Throwable) mathIllegalArgumentException59);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer62 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter63 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer62);
        harmonicFitter63.clearObservations();
        harmonicFitter63.clearObservations();
        harmonicFitter63.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray67 = harmonicFitter63.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException68 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException16, (org.apache.commons.math3.exception.util.Localizable) localizedFormats61, (java.lang.Object[]) weightedObservedPointArray67);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats43.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats46.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + (-1.0d) + "'", double57 == (-1.0d));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats61.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertNotNull(weightedObservedPointArray67);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer4 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter5 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer4);
        harmonicFitter5.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint10 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) ' ', (double) 10.0f, (double) 'a');
        harmonicFitter5.addObservedPoint(weightedObservedPoint10);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats1, localizedFormats2, localizedFormats3, weightedObservedPoint10, ' ', localizedFormats13 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = mathIllegalStateException15.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = mathIllegalStateException15.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(exceptionContext16);
        org.junit.Assert.assertNotNull(exceptionContext17);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 0, number2, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        java.lang.String str6 = localizedFormats5.getSourceString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats9, 10, (byte) 0 };
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray12);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats18, 10, (byte) 0 };
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable16, (org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalStateException23.getSuppressed();
        zeroException15.addSuppressed((java.lang.Throwable) mathIllegalStateException23);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray32 = new java.lang.Object[] { localizedFormats29, 10, (byte) 0 };
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable27, (org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray33);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException23, (org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray33);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray42 = new java.lang.Object[] { localizedFormats39, 10, (byte) 0 };
        java.lang.Object[] objArray43 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray42);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats38, objArray42);
        org.apache.commons.math3.exception.ZeroException zeroException45 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats37, objArray42);
        java.lang.Throwable throwable46 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray51 = new java.lang.Object[] { localizedFormats48, 10, (byte) 0 };
        java.lang.Object[] objArray52 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray51);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException53 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable46, (org.apache.commons.math3.exception.util.Localizable) localizedFormats47, objArray52);
        java.lang.Throwable[] throwableArray54 = mathIllegalStateException53.getSuppressed();
        zeroException45.addSuppressed((java.lang.Throwable) mathIllegalStateException53);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable57 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray62 = new java.lang.Object[] { localizedFormats59, 10, (byte) 0 };
        java.lang.Object[] objArray63 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray62);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException64 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable57, (org.apache.commons.math3.exception.util.Localizable) localizedFormats58, objArray63);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException65 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException53, (org.apache.commons.math3.exception.util.Localizable) localizedFormats56, objArray63);
        java.lang.Object[] objArray66 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray63);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException67 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray66);
        java.lang.Throwable throwable68 = null;
        try {
            mathIllegalStateException67.addSuppressed(throwable68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0} values have been added before statistic is configured" + "'", str6.equals("{0} values have been added before statistic is configured"));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats39.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats47.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats48.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats56.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats58.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats59.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 0, (double) 100.0f);
        java.lang.Class<?> wildcardClass9 = harmonicFitter1.getClass();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint13 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(0.0d, 32.0d, (double) (byte) 10);
        harmonicFitter1.addObservedPoint(weightedObservedPoint13);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats7, 10, (byte) 0 };
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray11);
        java.lang.Throwable[] throwableArray13 = mathIllegalStateException12.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = mathIllegalStateException14.getContext();
        java.lang.Object obj17 = exceptionContext15.getValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than, or equal to, the minimum (100)");
        java.util.Set<java.lang.String> strSet18 = exceptionContext15.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.apache.commons.math3.exception.util.Localizable localizable20 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats23, 10, (byte) 0 };
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats22, objArray26);
        org.apache.commons.math3.exception.ZeroException zeroException29 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, objArray26);
        org.apache.commons.math3.exception.ZeroException zeroException30 = new org.apache.commons.math3.exception.ZeroException(localizable20, objArray26);
        exceptionContext15.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray26);
        java.util.Set<java.lang.String> strSet32 = exceptionContext15.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(strSet32);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint4 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer5 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter6 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer5);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint10 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter6.addObservedPoint(weightedObservedPoint10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double16 = weightedObservedPoint15.getWeight();
        double double17 = weightedObservedPoint15.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double22 = weightedObservedPoint21.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint26 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer27 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter28 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer27);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter28.addObservedPoint(weightedObservedPoint32);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray34 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint4, weightedObservedPoint10, weightedObservedPoint15, weightedObservedPoint21, weightedObservedPoint26, weightedObservedPoint32 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser35 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray34);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser36 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray34);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser37 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray34);
        org.apache.commons.math3.exception.ZeroException zeroException38 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray34);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser39 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray34);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 1, 0.0d, (double) 100.0f);
        harmonicFitter1.addObservedPoint(100.0d, (double) '#');
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 0, (double) 100.0f);
        java.lang.Class<?> wildcardClass9 = harmonicFitter1.getClass();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter1.getObservations();
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray10);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (-1L), (double) 'a', (double) 1.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 0, (double) 100.0f);
        java.lang.Class<?> wildcardClass9 = harmonicFitter1.getClass();
        harmonicFitter1.addObservedPoint(10.0d, (double) 100L, (double) (-1.0f));
        harmonicFitter1.addObservedPoint((double) (byte) 100, (double) 0, (double) '4');
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException6.getSuppressed();
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.ZeroException zeroException9 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) (byte) -1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException5.getContext();
        boolean boolean7 = numberIsTooSmallException5.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats10, 10, (byte) 0 };
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray13);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER;
        java.lang.Throwable throwable17 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray22 = new java.lang.Object[] { localizedFormats19, 10, (byte) 0 };
        java.lang.Object[] objArray23 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable17, (org.apache.commons.math3.exception.util.Localizable) localizedFormats18, objArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray23);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext28 = mathIllegalStateException27.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(exceptionContext28);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats9, 10, (byte) 0 };
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray12);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray12);
        java.util.Set<java.lang.String> strSet16 = exceptionContext6.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray18);
        java.lang.Object obj21 = exceptionContext6.getValue("{0} values have been added before statistic is configured");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException7.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray8);
        java.lang.Throwable[] throwableArray10 = mathIllegalStateException9.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathIllegalStateException9.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray18 = new java.lang.Object[] { localizedFormats15, 10, (byte) 0 };
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray18);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray18);
        java.lang.Throwable throwable22 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray27 = new java.lang.Object[] { localizedFormats24, 10, (byte) 0 };
        java.lang.Object[] objArray28 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray27);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable22, (org.apache.commons.math3.exception.util.Localizable) localizedFormats23, objArray28);
        java.lang.Throwable[] throwableArray30 = mathIllegalStateException29.getSuppressed();
        zeroException21.addSuppressed((java.lang.Throwable) mathIllegalStateException29);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable33 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray38 = new java.lang.Object[] { localizedFormats35, 10, (byte) 0 };
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable33, (org.apache.commons.math3.exception.util.Localizable) localizedFormats34, objArray39);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats32, objArray39);
        java.lang.Object[] objArray42 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        java.lang.Object[] objArray43 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        exceptionContext11.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray39);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray39);
        org.apache.commons.math3.exception.ZeroException zeroException46 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray39);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer47 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter48 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer47);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint52 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter48.addObservedPoint(weightedObservedPoint52);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray54 = harmonicFitter48.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray55 = harmonicFitter48.getObservations();
        java.lang.Object[] objArray56 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray55);
        java.lang.Object[] objArray57 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray56);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray56);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(weightedObservedPointArray54);
        org.junit.Assert.assertNotNull(weightedObservedPointArray55);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray57);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object obj8 = exceptionContext6.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray15 = numberIsTooSmallException14.getSuppressed();
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray15);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray16);
        java.lang.Throwable throwable18 = exceptionContext6.getThrowable();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable18);
        java.util.Set<java.lang.String> strSet20 = exceptionContext19.getKeys();
        java.util.Set<java.lang.String> strSet21 = exceptionContext19.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Number number28 = numberIsTooSmallException27.getMin();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        numberIsTooSmallException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException33);
        java.lang.Throwable[] throwableArray35 = numberIsTooSmallException33.getSuppressed();
        exceptionContext19.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats22, (java.lang.Object[]) throwableArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwable18);
        org.junit.Assert.assertNotNull(strSet20);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1L + "'", number28.equals(1L));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double4 = weightedObservedPoint3.getY();
        double double5 = weightedObservedPoint3.getY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer5 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter6 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer5);
        harmonicFitter6.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint11 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) ' ', (double) 10.0f, (double) 'a');
        harmonicFitter6.addObservedPoint(weightedObservedPoint11);
        double double13 = weightedObservedPoint11.getX();
        harmonicFitter1.addObservedPoint(weightedObservedPoint11);
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 100.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double22 = weightedObservedPoint21.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint21);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) '4', 0.0d, (double) 0L);
        harmonicFitter1.addObservedPoint((double) 100L, 97.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        java.lang.Throwable[] throwableArray8 = mathIllegalStateException7.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException7.getContext();
        java.lang.Class<?> wildcardClass10 = mathIllegalStateException7.getClass();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathIllegalStateException7.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 1, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer13 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter14 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer13);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint18 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter14.addObservedPoint(weightedObservedPoint18);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double24 = weightedObservedPoint23.getWeight();
        double double25 = weightedObservedPoint23.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint29 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double30 = weightedObservedPoint29.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint34 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer35 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter36 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer35);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint40 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter36.addObservedPoint(weightedObservedPoint40);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray42 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint12, weightedObservedPoint18, weightedObservedPoint23, weightedObservedPoint29, weightedObservedPoint34, weightedObservedPoint40 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser43 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray42);
        double[] doubleArray44 = parameterGuesser43.guess();
        double[] doubleArray45 = parameterGuesser43.guess();
        try {
            double[] doubleArray46 = harmonicFitter1.fit(doubleArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        boolean boolean8 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), 0.0d);
        harmonicFitter1.addObservedPoint((double) 1, (double) 0L, (double) ' ');
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric9 = null;
        double[] doubleArray11 = new double[] { (byte) 0 };
        try {
            double[] doubleArray12 = harmonicFitter1.fit(parametric9, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.MEAN;
        exceptionContext5.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)", (java.lang.Object) localizedFormats7);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray19 = numberIsTooSmallException18.getSuppressed();
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray19);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, objArray20);
        org.apache.commons.math3.exception.ZeroException zeroException22 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray20);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, objArray24);
        zeroException22.addSuppressed((java.lang.Throwable) mathIllegalStateException25);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext27 = mathIllegalStateException25.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext34 = numberIsTooSmallException33.getContext();
        java.lang.Number number35 = numberIsTooSmallException33.getArgument();
        java.lang.Number number36 = numberIsTooSmallException33.getMin();
        exceptionContext27.setValue("crossover rate ({0})", (java.lang.Object) number36);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MEAN + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertNotNull(exceptionContext27);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(exceptionContext34);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 100.0f + "'", number35.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 10.0f + "'", number36.equals(10.0f));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer2 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter3 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer2);
        harmonicFitter3.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter3.clearObservations();
        harmonicFitter3.addObservedPoint((double) (byte) 0, (double) 100.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray11 = harmonicFitter3.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray11);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertNotNull(weightedObservedPointArray11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats4, 10, (byte) 0 };
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable2, (org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray8);
        java.lang.Throwable[] throwableArray10 = mathIllegalStateException9.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray10);
        java.lang.Throwable[] throwableArray13 = mathIllegalStateException12.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10, (byte) 0 };
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray5);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f, (java.lang.Number) (byte) 100, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats5, 10, (byte) 0 };
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray9);
        java.lang.Throwable[] throwableArray11 = mathIllegalStateException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 1, 0.0d);
        try {
            double[] doubleArray9 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 1 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint8 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (byte) 100, (double) (byte) 100, (double) (byte) -1);
        harmonicFitter1.addObservedPoint(weightedObservedPoint8);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric10 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer15 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter16 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter16.addObservedPoint(weightedObservedPoint20);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint25 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double26 = weightedObservedPoint25.getWeight();
        double double27 = weightedObservedPoint25.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint31 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double32 = weightedObservedPoint31.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint36 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer37 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter38 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer37);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint42 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter38.addObservedPoint(weightedObservedPoint42);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray44 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint14, weightedObservedPoint20, weightedObservedPoint25, weightedObservedPoint31, weightedObservedPoint36, weightedObservedPoint42 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser45 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray44);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser46 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray44);
        double[] doubleArray47 = parameterGuesser46.guess();
        try {
            double[] doubleArray48 = harmonicFitter1.fit(parametric10, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), 0.0d);
        harmonicFitter1.clearObservations();
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 100.0f, 1.0d, (double) (byte) 10);
        double[] doubleArray15 = new double[] { 1.0f, ' ', (-1) };
        try {
            double[] doubleArray16 = harmonicFitter1.fit(doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 1, 0.0d, (double) 100.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray7 = harmonicFitter1.getObservations();
        try {
            org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser8 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 1 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats4, 10, (byte) 0 };
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable2, (org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray8);
        java.lang.Throwable[] throwableArray10 = mathIllegalStateException9.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean17 = numberIsTooSmallException16.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray23 = new java.lang.Object[] { localizedFormats20, 10, (byte) 0 };
        java.lang.Object[] objArray24 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray23);
        org.apache.commons.math3.exception.ZeroException zeroException26 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, objArray23);
        numberIsTooSmallException16.addSuppressed((java.lang.Throwable) zeroException26);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        zeroException26.addSuppressed((java.lang.Throwable) numberIsTooSmallException32);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats35, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray40 = numberIsTooSmallException39.getSuppressed();
        java.lang.Object[] objArray41 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray40);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException42 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException32, (org.apache.commons.math3.exception.util.Localizable) localizedFormats34, (java.lang.Object[]) throwableArray40);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer43 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter44 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer43);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint48 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter44.addObservedPoint(weightedObservedPoint48);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray50 = harmonicFitter44.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray51 = harmonicFitter44.getObservations();
        java.lang.Object[] objArray52 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray51);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException53 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException12, (org.apache.commons.math3.exception.util.Localizable) localizedFormats34, (java.lang.Object[]) weightedObservedPointArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(weightedObservedPointArray50);
        org.junit.Assert.assertNotNull(weightedObservedPointArray51);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0, (java.lang.Number) (short) 0, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray10 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats14, 10, (byte) 0 };
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray17);
        exceptionContext11.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray17);
        java.util.Set<java.lang.String> strSet21 = exceptionContext11.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        exceptionContext11.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats22, objArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, localizable4, objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException5);
        java.lang.Object obj9 = exceptionContext7.getValue("");
        java.lang.Object obj11 = exceptionContext7.getValue("hi!");
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray19 = numberIsTooSmallException18.getSuppressed();
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray20);
        exceptionContext7.addMessage(localizable12, objArray20);
        java.lang.Object[] objArray23 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math3.exception.ZeroException zeroException24 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray5 = harmonicFitter1.getObservations();
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric7 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint11 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer12 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter13 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer12);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint17 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter13.addObservedPoint(weightedObservedPoint17);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double23 = weightedObservedPoint22.getWeight();
        double double24 = weightedObservedPoint22.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint28 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double29 = weightedObservedPoint28.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint33 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer34 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter35 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer34);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint39 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter35.addObservedPoint(weightedObservedPoint39);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray41 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint11, weightedObservedPoint17, weightedObservedPoint22, weightedObservedPoint28, weightedObservedPoint33, weightedObservedPoint39 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser42 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray41);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser43 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray41);
        double[] doubleArray44 = parameterGuesser43.guess();
        double[] doubleArray45 = parameterGuesser43.guess();
        try {
            double[] doubleArray46 = harmonicFitter1.fit((int) (byte) 0, parametric7, doubleArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray5);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-1.0d) + "'", double29 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer4 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter5 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer4);
        harmonicFitter5.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint10 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) ' ', (double) 10.0f, (double) 'a');
        harmonicFitter5.addObservedPoint(weightedObservedPoint10);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats1, localizedFormats2, localizedFormats3, weightedObservedPoint10, ' ', localizedFormats13 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray14);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray20 = new java.lang.Object[] { localizedFormats17, 10, (byte) 0 };
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray20);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        mathIllegalStateException22.addSuppressed((java.lang.Throwable) numberIsTooSmallException27);
        boolean boolean29 = numberIsTooSmallException27.getBoundIsAllowed();
        mathIllegalStateException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException27);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats33, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray38 = numberIsTooSmallException37.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats32, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException15, (org.apache.commons.math3.exception.util.Localizable) localizedFormats31, (java.lang.Object[]) throwableArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray38);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray4 = harmonicFitter1.getObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 10, (double) (byte) 100);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric10 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint14 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer15 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter16 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer15);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter16.addObservedPoint(weightedObservedPoint20);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint25 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double26 = weightedObservedPoint25.getWeight();
        double double27 = weightedObservedPoint25.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint31 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double32 = weightedObservedPoint31.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint36 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer37 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter38 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer37);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint42 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter38.addObservedPoint(weightedObservedPoint42);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray44 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint14, weightedObservedPoint20, weightedObservedPoint25, weightedObservedPoint31, weightedObservedPoint36, weightedObservedPoint42 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser45 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray44);
        double[] doubleArray46 = parameterGuesser45.guess();
        double[] doubleArray47 = parameterGuesser45.guess();
        double[] doubleArray48 = parameterGuesser45.guess();
        double[] doubleArray49 = parameterGuesser45.guess();
        try {
            double[] doubleArray50 = harmonicFitter1.fit(parametric10, doubleArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray4);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray5 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray6 = harmonicFitter1.getObservations();
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray5);
        org.junit.Assert.assertNotNull(weightedObservedPointArray6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats1, 10, (byte) 0 };
        java.lang.Object[] objArray5 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray4);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        mathIllegalStateException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.Number number13 = numberIsTooSmallException11.getArgument();
        java.lang.Throwable[] throwableArray14 = numberIsTooSmallException11.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray21 = numberIsTooSmallException20.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException11, (org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray28 = numberIsTooSmallException27.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext29 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException27);
        java.lang.Object obj31 = exceptionContext29.getValue("");
        java.lang.Object obj33 = exceptionContext29.getValue("hi!");
        java.lang.Object obj35 = exceptionContext29.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint41 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer42 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter43 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer42);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint47 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter43.addObservedPoint(weightedObservedPoint47);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint52 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double53 = weightedObservedPoint52.getWeight();
        double double54 = weightedObservedPoint52.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint58 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double59 = weightedObservedPoint58.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint63 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer64 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter65 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer64);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint69 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter65.addObservedPoint(weightedObservedPoint69);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray71 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint41, weightedObservedPoint47, weightedObservedPoint52, weightedObservedPoint58, weightedObservedPoint63, weightedObservedPoint69 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser72 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray71);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException73 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats37, (java.lang.Object[]) weightedObservedPointArray71);
        exceptionContext29.setValue("org.apache.commons.math3.exception.MathIllegalStateException: unknown parameter NUMBER_OF_SAMPLES", (java.lang.Object) localizedFormats37);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats75 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats76 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats77 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray80 = new java.lang.Object[] { localizedFormats77, 10, (byte) 0 };
        java.lang.Object[] objArray81 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray80);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException82 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats76, objArray80);
        org.apache.commons.math3.exception.ZeroException zeroException83 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats75, objArray80);
        java.lang.Throwable throwable84 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats85 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats86 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray89 = new java.lang.Object[] { localizedFormats86, 10, (byte) 0 };
        java.lang.Object[] objArray90 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray89);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException91 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable84, (org.apache.commons.math3.exception.util.Localizable) localizedFormats85, objArray90);
        java.lang.Throwable[] throwableArray92 = mathIllegalStateException91.getSuppressed();
        zeroException83.addSuppressed((java.lang.Throwable) mathIllegalStateException91);
        java.lang.Throwable[] throwableArray94 = mathIllegalStateException91.getSuppressed();
        java.lang.Object[] objArray95 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray94);
        java.lang.Object[] objArray96 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray94);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException97 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException11, (org.apache.commons.math3.exception.util.Localizable) localizedFormats37, (java.lang.Object[]) throwableArray94);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNull(obj33);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + (-1.0d) + "'", double53 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + (-1.0d) + "'", double59 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray71);
        org.junit.Assert.assertTrue("'" + localizedFormats75 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats75.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats76 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats76.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats77 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats77.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertTrue("'" + localizedFormats85 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats85.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats86 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats86.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(throwableArray92);
        org.junit.Assert.assertNotNull(throwableArray94);
        org.junit.Assert.assertNotNull(objArray95);
        org.junit.Assert.assertNotNull(objArray96);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer8 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter9 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer8);
        harmonicFitter9.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter9.clearObservations();
        harmonicFitter9.addObservedPoint((double) (byte) 0, (double) 100.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter9.addObservedPoint(weightedObservedPoint20);
        harmonicFitter1.addObservedPoint(weightedObservedPoint20);
        harmonicFitter1.addObservedPoint(100.0d, (double) (byte) 0, (double) (-1));
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric27 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint31 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer32 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter33 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer32);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint37 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter33.addObservedPoint(weightedObservedPoint37);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint42 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double43 = weightedObservedPoint42.getWeight();
        double double44 = weightedObservedPoint42.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint48 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double49 = weightedObservedPoint48.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint53 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer54 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter55 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer54);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint59 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter55.addObservedPoint(weightedObservedPoint59);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray61 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint31, weightedObservedPoint37, weightedObservedPoint42, weightedObservedPoint48, weightedObservedPoint53, weightedObservedPoint59 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser62 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray61);
        double[] doubleArray63 = parameterGuesser62.guess();
        try {
            double[] doubleArray64 = harmonicFitter1.fit(parametric27, doubleArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-1.0d) + "'", double49 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Throwable[] throwableArray12 = numberIsTooSmallException10.getSuppressed();
        boolean boolean13 = numberIsTooSmallException10.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1.0f), (-1.0d), 1.0d);
        double double4 = weightedObservedPoint3.getWeight();
        java.lang.Class<?> wildcardClass5 = weightedObservedPoint3.getClass();
        double double6 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats1, 10, (byte) 0 };
        java.lang.Object[] objArray5 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray4);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray4);
        java.lang.String str7 = mathIllegalStateException6.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = mathIllegalStateException6.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException6.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math3.exception.MathIllegalStateException: NUMBER_OF_SAMPLESx10 and 0x{3} matrices are not multiplication compatible" + "'", str7.equals("org.apache.commons.math3.exception.MathIllegalStateException: NUMBER_OF_SAMPLESx10 and 0x{3} matrices are not multiplication compatible"));
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 100, (java.lang.Number) 0.0d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException4.getContext();
        java.lang.Object obj8 = exceptionContext6.getValue("org.apache.commons.math3.exception.MathIllegalStateException: unknown parameter NUMBER_OF_SAMPLES");
        java.lang.Throwable throwable9 = exceptionContext6.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(throwable9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = mathIllegalStateException7.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) ' ', (double) 10.0f, (double) 'a');
        double double4 = weightedObservedPoint3.getY();
        double double5 = weightedObservedPoint3.getWeight();
        double double6 = weightedObservedPoint3.getWeight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        java.lang.Throwable throwable7 = exceptionContext5.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(throwable7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter1.addObservedPoint(weightedObservedPoint5);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer7 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter8 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer7);
        harmonicFitter8.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint13 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) ' ', (double) 10.0f, (double) 'a');
        harmonicFitter8.addObservedPoint(weightedObservedPoint13);
        harmonicFitter1.addObservedPoint(weightedObservedPoint13);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric17 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer22 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter23 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter23.addObservedPoint(weightedObservedPoint27);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double33 = weightedObservedPoint32.getWeight();
        double double34 = weightedObservedPoint32.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint38 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double39 = weightedObservedPoint38.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer44 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter45 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer44);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint49 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter45.addObservedPoint(weightedObservedPoint49);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray51 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint21, weightedObservedPoint27, weightedObservedPoint32, weightedObservedPoint38, weightedObservedPoint43, weightedObservedPoint49 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser52 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray51);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser53 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray51);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser54 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray51);
        double[] doubleArray55 = parameterGuesser54.guess();
        try {
            double[] doubleArray56 = harmonicFitter1.fit((int) (short) 0, parametric17, doubleArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-1.0d) + "'", double39 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException4.getSuppressed();
        java.lang.Number number8 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Throwable throwable14 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizedFormats16, 10, (byte) 0 };
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable14, (org.apache.commons.math3.exception.util.Localizable) localizedFormats15, objArray20);
        java.lang.Throwable[] throwableArray22 = mathIllegalStateException21.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException12, (org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) throwableArray22);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalStateException23);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 100.0f, 1.0d, (double) (byte) 10);
        harmonicFitter1.clearObservations();
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10, (byte) 0 };
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        mathIllegalStateException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Throwable[] throwableArray14 = mathIllegalStateException7.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) 0.0f, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        boolean boolean7 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats3, 10, (byte) 0 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray6);
        org.apache.commons.math3.exception.ZeroException zeroException9 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray6);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray15 = new java.lang.Object[] { localizedFormats12, 10, (byte) 0 };
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable10, (org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray16);
        java.lang.Throwable[] throwableArray18 = mathIllegalStateException17.getSuppressed();
        zeroException9.addSuppressed((java.lang.Throwable) mathIllegalStateException17);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats23, 10, (byte) 0 };
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable21, (org.apache.commons.math3.exception.util.Localizable) localizedFormats22, objArray27);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException17, (org.apache.commons.math3.exception.util.Localizable) localizedFormats20, objArray27);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext30 = mathIllegalStateException17.getContext();
        org.apache.commons.math3.exception.util.Localizable localizable31 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats32, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray37 = numberIsTooSmallException36.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext38 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException36);
        java.lang.Object obj40 = exceptionContext38.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats42, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray47 = numberIsTooSmallException46.getSuppressed();
        java.lang.Object[] objArray48 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray47);
        exceptionContext38.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats41, objArray48);
        exceptionContext30.addMessage(localizable31, objArray48);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException51 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray48);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer52 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter53 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer52);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint57 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter53.addObservedPoint(weightedObservedPoint57);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray59 = harmonicFitter53.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray60 = harmonicFitter53.getObservations();
        java.lang.Object[] objArray61 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray60);
        java.lang.Object[] objArray62 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray61);
        org.apache.commons.math3.exception.ZeroException zeroException63 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray61);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(exceptionContext30);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNull(obj40);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats41.equals(org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats42.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(weightedObservedPointArray59);
        org.junit.Assert.assertNotNull(weightedObservedPointArray60);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray62);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats7, 10, (byte) 0 };
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray10);
        org.apache.commons.math3.exception.ZeroException zeroException13 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray10);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) zeroException13);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        zeroException13.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats22, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray27 = numberIsTooSmallException26.getSuppressed();
        java.lang.Object[] objArray28 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray27);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException19, (org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext30 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number31 = numberIsTooSmallException19.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 100.0f + "'", number31.equals(100.0f));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 1, 0.0d, (double) 100.0f);
        harmonicFitter1.addObservedPoint((double) (byte) -1, (double) (-1L));
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint13 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double14 = weightedObservedPoint13.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint13);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer16 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter17 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer16);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint21 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter17.addObservedPoint(weightedObservedPoint21);
        harmonicFitter1.addObservedPoint(weightedObservedPoint21);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer28 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter29 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer28);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint33 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter29.addObservedPoint(weightedObservedPoint33);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint38 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double39 = weightedObservedPoint38.getWeight();
        double double40 = weightedObservedPoint38.getX();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint44 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        double double45 = weightedObservedPoint44.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint49 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 100.0f, (double) ' ', (double) (-1));
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer50 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter51 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer50);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint55 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter51.addObservedPoint(weightedObservedPoint55);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray57 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint27, weightedObservedPoint33, weightedObservedPoint38, weightedObservedPoint44, weightedObservedPoint49, weightedObservedPoint55 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser58 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray57);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser59 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray57);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser60 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray57);
        double[] doubleArray61 = parameterGuesser60.guess();
        try {
            double[] doubleArray62 = harmonicFitter1.fit(doubleArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-1.0d) + "'", double39 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-1.0d) + "'", double45 == (-1.0d));
        org.junit.Assert.assertNotNull(weightedObservedPointArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 0, number2, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        java.lang.String str6 = localizedFormats5.getSourceString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats9, 10, (byte) 0 };
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray12);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats18, 10, (byte) 0 };
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable16, (org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalStateException23.getSuppressed();
        zeroException15.addSuppressed((java.lang.Throwable) mathIllegalStateException23);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray32 = new java.lang.Object[] { localizedFormats29, 10, (byte) 0 };
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable27, (org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray33);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException23, (org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray33);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray42 = new java.lang.Object[] { localizedFormats39, 10, (byte) 0 };
        java.lang.Object[] objArray43 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray42);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats38, objArray42);
        org.apache.commons.math3.exception.ZeroException zeroException45 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats37, objArray42);
        java.lang.Throwable throwable46 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray51 = new java.lang.Object[] { localizedFormats48, 10, (byte) 0 };
        java.lang.Object[] objArray52 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray51);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException53 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable46, (org.apache.commons.math3.exception.util.Localizable) localizedFormats47, objArray52);
        java.lang.Throwable[] throwableArray54 = mathIllegalStateException53.getSuppressed();
        zeroException45.addSuppressed((java.lang.Throwable) mathIllegalStateException53);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable57 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray62 = new java.lang.Object[] { localizedFormats59, 10, (byte) 0 };
        java.lang.Object[] objArray63 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray62);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException64 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable57, (org.apache.commons.math3.exception.util.Localizable) localizedFormats58, objArray63);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException65 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException53, (org.apache.commons.math3.exception.util.Localizable) localizedFormats56, objArray63);
        java.lang.Object[] objArray66 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray63);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException67 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray66);
        java.lang.String str68 = numberIsTooSmallException4.toString();
        boolean boolean69 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0} values have been added before statistic is configured" + "'", str6.equals("{0} values have been added before statistic is configured"));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats39.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats47.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats48.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats56.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats58.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats59.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: population limit has to be positive" + "'", str68.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: population limit has to be positive"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object obj8 = exceptionContext6.getValue("");
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats14, 10, (byte) 0 };
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray17);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray17);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats23, 10, (byte) 0 };
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable21, (org.apache.commons.math3.exception.util.Localizable) localizedFormats22, objArray27);
        java.lang.Throwable[] throwableArray29 = mathIllegalStateException28.getSuppressed();
        zeroException20.addSuppressed((java.lang.Throwable) mathIllegalStateException28);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable32 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray37 = new java.lang.Object[] { localizedFormats34, 10, (byte) 0 };
        java.lang.Object[] objArray38 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray37);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable32, (org.apache.commons.math3.exception.util.Localizable) localizedFormats33, objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException28, (org.apache.commons.math3.exception.util.Localizable) localizedFormats31, objArray38);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException42 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray38);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray46 = new java.lang.Object[] { localizedFormats43, 10, (byte) 0 };
        java.lang.Object[] objArray47 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray46);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray47);
        java.util.Locale locale49 = null;
        try {
            java.lang.String str50 = localizedFormats10.getLocalizedString(locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats43.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray47);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_LEFT;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100, number2, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_LEFT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_LEFT));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats1, 10, (byte) 0 };
        java.lang.Object[] objArray5 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray4);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        mathIllegalStateException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException11);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = mathIllegalStateException6.getContext();
        java.lang.Throwable throwable14 = exceptionContext13.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertNotNull(throwable14);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(97.0d, (double) 100L, (double) 0.0f);
        double double4 = weightedObservedPoint3.getX();
        double double5 = weightedObservedPoint3.getWeight();
        double double6 = weightedObservedPoint3.getWeight();
        double double7 = weightedObservedPoint3.getWeight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        java.lang.String str6 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 1, 0.0d, (double) 100.0f);
        harmonicFitter1.addObservedPoint((double) (byte) -1, (double) (-1L));
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint13 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double14 = weightedObservedPoint13.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint13);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter1.getObservations();
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint(10.0d, (double) (byte) 1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint13 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 0, (double) 10.0f, 10.0d);
        harmonicFitter1.addObservedPoint(weightedObservedPoint13);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats7, 10, (byte) 0 };
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray10);
        org.apache.commons.math3.exception.ZeroException zeroException13 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray10);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) zeroException13);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        java.util.Set<java.lang.String> strSet16 = exceptionContext15.getKeys();
        java.util.Set<java.lang.String> strSet17 = exceptionContext15.getKeys();
        java.lang.Object obj19 = exceptionContext15.getValue("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot substitute an element from an empty array");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertNull(obj19);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 0, (double) 100.0f);
        java.lang.Class<?> wildcardClass9 = harmonicFitter1.getClass();
        harmonicFitter1.addObservedPoint((double) (-1), (double) 100);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0.0f, (double) ' ', (double) (short) 0);
        double double17 = weightedObservedPoint16.getX();
        harmonicFitter1.addObservedPoint(weightedObservedPoint16);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 32.0d + "'", double17 == 32.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats9, 10, (byte) 0 };
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray12);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray12);
        java.util.Set<java.lang.String> strSet16 = exceptionContext6.getKeys();
        java.lang.Object obj18 = exceptionContext6.getValue("");
        java.util.Set<java.lang.String> strSet19 = exceptionContext6.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(strSet19);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats1, 10, (byte) 0 };
        java.lang.Object[] objArray5 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray4);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray4);
        java.lang.Class<?> wildcardClass7 = mathIllegalStateException6.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException7.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray8);
        java.lang.Throwable[] throwableArray10 = mathIllegalStateException9.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathIllegalStateException9.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray18 = new java.lang.Object[] { localizedFormats15, 10, (byte) 0 };
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray18);
        org.apache.commons.math3.exception.ZeroException zeroException21 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray18);
        java.lang.Throwable throwable22 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray27 = new java.lang.Object[] { localizedFormats24, 10, (byte) 0 };
        java.lang.Object[] objArray28 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray27);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable22, (org.apache.commons.math3.exception.util.Localizable) localizedFormats23, objArray28);
        java.lang.Throwable[] throwableArray30 = mathIllegalStateException29.getSuppressed();
        zeroException21.addSuppressed((java.lang.Throwable) mathIllegalStateException29);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable33 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray38 = new java.lang.Object[] { localizedFormats35, 10, (byte) 0 };
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable33, (org.apache.commons.math3.exception.util.Localizable) localizedFormats34, objArray39);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats32, objArray39);
        java.lang.Object[] objArray42 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        java.lang.Object[] objArray43 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        exceptionContext11.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray39);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray39);
        org.apache.commons.math3.exception.ZeroException zeroException46 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray43);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Object obj8 = exceptionContext6.getValue("{0} method needs at least two previous points");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Throwable throwable14 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizedFormats16, 10, (byte) 0 };
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable14, (org.apache.commons.math3.exception.util.Localizable) localizedFormats15, objArray20);
        java.lang.Throwable[] throwableArray22 = mathIllegalStateException21.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException12, (org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Throwable throwable29 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray34 = new java.lang.Object[] { localizedFormats31, 10, (byte) 0 };
        java.lang.Object[] objArray35 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray34);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException36 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray35);
        java.lang.Throwable[] throwableArray37 = mathIllegalStateException36.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException27, (org.apache.commons.math3.exception.util.Localizable) localizedFormats28, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext39 = mathIllegalStateException38.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats40, (java.lang.Number) (byte) 100, (java.lang.Number) 0.0d, false);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext49 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException48);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math3.exception.util.LocalizedFormats.MEAN;
        exceptionContext49.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)", (java.lang.Object) localizedFormats51);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats53, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats58, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray63 = numberIsTooSmallException62.getSuppressed();
        java.lang.Object[] objArray64 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray63);
        exceptionContext49.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats53, objArray64);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException66 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException38, (org.apache.commons.math3.exception.util.Localizable) localizedFormats40, objArray64);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext67 = mathIllegalStateException38.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats68 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer69 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter70 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer69);
        harmonicFitter70.clearObservations();
        harmonicFitter70.clearObservations();
        harmonicFitter70.addObservedPoint(0.0d, (double) (byte) 0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint76 = null;
        harmonicFitter70.addObservedPoint(weightedObservedPoint76);
        harmonicFitter70.addObservedPoint((double) 10, (double) (byte) 1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray81 = harmonicFitter70.getObservations();
        exceptionContext67.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats68, (java.lang.Object[]) weightedObservedPointArray81);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) weightedObservedPointArray81);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(exceptionContext39);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats40.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MEAN + "'", localizedFormats51.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats53.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats58.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(exceptionContext67);
        org.junit.Assert.assertTrue("'" + localizedFormats68 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats68.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
        org.junit.Assert.assertNotNull(weightedObservedPointArray81);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        harmonicFitter2.clearObservations();
        harmonicFitter2.clearObservations();
        harmonicFitter2.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray6 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.ZeroException zeroException7 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(weightedObservedPointArray6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10, (byte) 0 };
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        mathIllegalStateException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Number number14 = numberIsTooSmallException12.getArgument();
        java.lang.Throwable[] throwableArray15 = numberIsTooSmallException12.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext21 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException20);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.MEAN;
        exceptionContext21.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)", (java.lang.Object) localizedFormats23);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray31 = numberIsTooSmallException30.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, (java.lang.Object[]) throwableArray31);
        java.lang.Throwable[] throwableArray33 = mathIllegalStateException32.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException16, (org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats35, (java.lang.Number) (byte) -1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext40 = numberIsTooSmallException39.getContext();
        boolean boolean41 = numberIsTooSmallException39.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray42 = numberIsTooSmallException39.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray47 = new java.lang.Object[] { localizedFormats44, 10, (byte) 0 };
        java.lang.Object[] objArray48 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray47);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException49 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats43, objArray47);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER;
        java.lang.Throwable throwable51 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray56 = new java.lang.Object[] { localizedFormats53, 10, (byte) 0 };
        java.lang.Object[] objArray57 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray56);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException58 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable51, (org.apache.commons.math3.exception.util.Localizable) localizedFormats52, objArray57);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException59 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats50, objArray57);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException60 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException39, (org.apache.commons.math3.exception.util.Localizable) localizedFormats43, objArray57);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext61 = numberIsTooSmallException39.getContext();
        mathIllegalStateException16.addSuppressed((java.lang.Throwable) numberIsTooSmallException39);
        boolean boolean63 = numberIsTooSmallException39.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MEAN + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats43.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats44.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER + "'", localizedFormats50.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats52.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats53.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(exceptionContext61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException4.getContext();
        java.lang.Number number7 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) -1 + "'", number7.equals((byte) -1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10, (byte) 0 };
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray5);
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats11, 10, (byte) 0 };
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray15);
        java.lang.Throwable[] throwableArray17 = mathIllegalStateException16.getSuppressed();
        zeroException8.addSuppressed((java.lang.Throwable) mathIllegalStateException16);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable20 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray25 = new java.lang.Object[] { localizedFormats22, 10, (byte) 0 };
        java.lang.Object[] objArray26 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray25);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable20, (org.apache.commons.math3.exception.util.Localizable) localizedFormats21, objArray26);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException16, (org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray26);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, (java.lang.Number) 0, (java.lang.Number) 0.0f, false);
        mathIllegalStateException28.addSuppressed((java.lang.Throwable) numberIsTooSmallException33);
        java.lang.Number number35 = numberIsTooSmallException33.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 0 + "'", number35.equals(0));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 100L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats8, 10, (byte) 0 };
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable6, (org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray12);
        java.lang.Throwable[] throwableArray14 = mathIllegalStateException13.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = mathIllegalStateException15.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, (java.lang.Number) (byte) 100, (java.lang.Number) 0.0d, false);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext26 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.MEAN;
        exceptionContext26.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)", (java.lang.Object) localizedFormats28);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats35, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray40 = numberIsTooSmallException39.getSuppressed();
        java.lang.Object[] objArray41 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray40);
        exceptionContext26.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray41);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException15, (org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray41);
        org.apache.commons.math3.exception.ZeroException zeroException44 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(exceptionContext16);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MEAN + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(objArray41);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray5 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray6 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint10 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(97.0d, 0.0d, 10.0d);
        harmonicFitter1.addObservedPoint(weightedObservedPoint10);
        org.junit.Assert.assertNotNull(weightedObservedPointArray5);
        org.junit.Assert.assertNotNull(weightedObservedPointArray6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object obj8 = exceptionContext6.getValue("");
        java.lang.Object obj10 = exceptionContext6.getValue("hi!");
        java.lang.Object obj12 = exceptionContext6.getValue("");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer14 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter15 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer14);
        harmonicFitter15.clearObservations();
        harmonicFitter15.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray18 = harmonicFitter15.getObservations();
        exceptionContext6.setValue("crossover rate ({0})", (java.lang.Object) harmonicFitter15);
        harmonicFitter15.clearObservations();
        harmonicFitter15.clearObservations();
        harmonicFitter15.addObservedPoint(97.0d, (double) 1.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray25 = harmonicFitter15.getObservations();
        harmonicFitter15.addObservedPoint((double) (short) 100, 0.0d);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric30 = null;
        double[] doubleArray37 = new double[] { 10L, 32.0d, '4', (byte) -1, 32.0d, 10.0d };
        try {
            double[] doubleArray38 = harmonicFitter15.fit((int) (byte) 100, parametric30, doubleArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(weightedObservedPointArray18);
        org.junit.Assert.assertNotNull(weightedObservedPointArray25);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray9 = numberIsTooSmallException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats18, 10, (byte) 0 };
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray21);
        org.apache.commons.math3.exception.ZeroException zeroException24 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray21);
        java.lang.Throwable throwable25 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray30 = new java.lang.Object[] { localizedFormats27, 10, (byte) 0 };
        java.lang.Object[] objArray31 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray30);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable25, (org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray31);
        java.lang.Throwable[] throwableArray33 = mathIllegalStateException32.getSuppressed();
        zeroException24.addSuppressed((java.lang.Throwable) mathIllegalStateException32);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray41 = new java.lang.Object[] { localizedFormats38, 10, (byte) 0 };
        java.lang.Object[] objArray42 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray41);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable36, (org.apache.commons.math3.exception.util.Localizable) localizedFormats37, objArray42);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException32, (org.apache.commons.math3.exception.util.Localizable) localizedFormats35, objArray42);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint48 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double49 = weightedObservedPoint48.getWeight();
        java.lang.Object[] objArray50 = new java.lang.Object[] { localizedFormats13, localizedFormats14, localizedFormats15, localizedFormats35, double49 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray50);
        java.lang.Object[] objArray52 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray50);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException53 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray52);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext54 = mathIllegalStateException53.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-1.0d) + "'", double49 == (-1.0d));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(exceptionContext54);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray5 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray6 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray7 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray5);
        org.junit.Assert.assertNotNull(weightedObservedPointArray6);
        org.junit.Assert.assertNotNull(weightedObservedPointArray7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object obj8 = exceptionContext6.getValue("");
        java.lang.Object obj10 = exceptionContext6.getValue("hi!");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray17 = numberIsTooSmallException16.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException16);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 100L, false);
        java.lang.Number number24 = numberIsTooSmallException23.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext25 = numberIsTooSmallException23.getContext();
        exceptionContext18.setValue("org.apache.commons.math3.exception.MathIllegalStateException: number of polynomial interpolants must match the number of segments ({0} != {1} - 1)", (java.lang.Object) numberIsTooSmallException23);
        exceptionContext6.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)", (java.lang.Object) exceptionContext18);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 100L + "'", number24.equals(100L));
        org.junit.Assert.assertNotNull(exceptionContext25);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        harmonicFitter1.addObservedPoint(weightedObservedPoint5);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray7 = harmonicFitter1.getObservations();
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (byte) -1, 97.0d, (double) (-1));
        harmonicFitter1.addObservedPoint(weightedObservedPoint12);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray7);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 1, (double) 100.0f, (double) 10.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint(0.0d, (double) (byte) 0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint7 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint7);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray9 = harmonicFitter1.getObservations();
        double[] doubleArray16 = new double[] { (-1), (byte) 0, (short) 10, 10.0f, (byte) 1, (short) 10 };
        try {
            double[] doubleArray17 = harmonicFitter1.fit(doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100, (java.lang.Number) 100, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException4.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(exceptionContext6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.MEAN;
        exceptionContext4.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)", (java.lang.Object) localizedFormats6);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray18 = numberIsTooSmallException17.getSuppressed();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray19);
        java.util.Set<java.lang.String> strSet21 = exceptionContext4.getKeys();
        java.lang.Throwable throwable22 = exceptionContext4.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Number) (byte) -1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext29 = numberIsTooSmallException28.getContext();
        boolean boolean30 = numberIsTooSmallException28.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray31 = numberIsTooSmallException28.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray36 = new java.lang.Object[] { localizedFormats33, 10, (byte) 0 };
        java.lang.Object[] objArray37 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray36);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats32, objArray36);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER;
        java.lang.Throwable throwable40 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray45 = new java.lang.Object[] { localizedFormats42, 10, (byte) 0 };
        java.lang.Object[] objArray46 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray45);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException47 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable40, (org.apache.commons.math3.exception.util.Localizable) localizedFormats41, objArray46);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException48 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats39, objArray46);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException49 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException28, (org.apache.commons.math3.exception.util.Localizable) localizedFormats32, objArray46);
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, objArray46);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        java.lang.Object[] objArray52 = null;
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats51, objArray52);
        java.util.Set<java.lang.String> strSet54 = exceptionContext4.getKeys();
        java.lang.Class<?> wildcardClass55 = exceptionContext4.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MEAN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertNotNull(throwable22);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER + "'", localizedFormats39.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats41.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats42.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats51.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertNotNull(strSet54);
        org.junit.Assert.assertNotNull(wildcardClass55);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException4.getSuppressed();
        boolean boolean8 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number9 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0d + "'", number9.equals(10.0d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        boolean boolean6 = numberIsTooSmallException5.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats9, 10, (byte) 0 };
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray12);
        numberIsTooSmallException5.addSuppressed((java.lang.Throwable) zeroException15);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        zeroException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray29 = numberIsTooSmallException28.getSuppressed();
        java.lang.Object[] objArray30 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException21, (org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math3.exception.ZeroException zeroException32 = new org.apache.commons.math3.exception.ZeroException(localizable1, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math3.exception.ZeroException zeroException33 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 1, 0.0d, (double) 100.0f);
        harmonicFitter1.addObservedPoint((double) (byte) -1, (double) (-1L));
        harmonicFitter1.addObservedPoint((double) (-1L), 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10, (byte) 0 };
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray5);
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats11, 10, (byte) 0 };
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray15);
        java.lang.Throwable[] throwableArray17 = mathIllegalStateException16.getSuppressed();
        zeroException8.addSuppressed((java.lang.Throwable) mathIllegalStateException16);
        java.lang.Throwable[] throwableArray19 = mathIllegalStateException16.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray29 = new java.lang.Object[] { localizedFormats26, 10, (byte) 0 };
        java.lang.Object[] objArray30 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray29);
        org.apache.commons.math3.exception.ZeroException zeroException32 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, objArray29);
        java.lang.Throwable throwable33 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray38 = new java.lang.Object[] { localizedFormats35, 10, (byte) 0 };
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable33, (org.apache.commons.math3.exception.util.Localizable) localizedFormats34, objArray39);
        java.lang.Throwable[] throwableArray41 = mathIllegalStateException40.getSuppressed();
        zeroException32.addSuppressed((java.lang.Throwable) mathIllegalStateException40);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable44 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray49 = new java.lang.Object[] { localizedFormats46, 10, (byte) 0 };
        java.lang.Object[] objArray50 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray49);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException51 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable44, (org.apache.commons.math3.exception.util.Localizable) localizedFormats45, objArray50);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException52 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException40, (org.apache.commons.math3.exception.util.Localizable) localizedFormats43, objArray50);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint56 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1), 0.0d, (double) (byte) 1);
        double double57 = weightedObservedPoint56.getWeight();
        java.lang.Object[] objArray58 = new java.lang.Object[] { localizedFormats21, localizedFormats22, localizedFormats23, localizedFormats43, double57 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, objArray58);
        mathIllegalStateException16.addSuppressed((java.lang.Throwable) mathIllegalArgumentException59);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        java.lang.Number number63 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException65 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats61, (java.lang.Number) 100.0d, number63, true);
        mathIllegalArgumentException59.addSuppressed((java.lang.Throwable) numberIsTooSmallException65);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats43.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats46.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + (-1.0d) + "'", double57 == (-1.0d));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats61.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) ' ', (double) (-1.0f), (double) (-1.0f));
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint7 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object obj8 = exceptionContext6.getValue("");
        java.lang.Object obj10 = exceptionContext6.getValue("hi!");
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray18 = numberIsTooSmallException17.getSuppressed();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray19);
        exceptionContext6.addMessage(localizable11, objArray19);
        java.lang.Object obj23 = exceptionContext6.getValue("array sizes should have difference 1 ({0} != {1} + 1)");
        java.lang.Class<?> wildcardClass24 = exceptionContext6.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.MEAN;
        exceptionContext4.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)", (java.lang.Object) localizedFormats6);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray18 = numberIsTooSmallException17.getSuppressed();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray19);
        java.util.Set<java.lang.String> strSet21 = exceptionContext4.getKeys();
        java.lang.Throwable throwable22 = exceptionContext4.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Number) (byte) 1, (java.lang.Number) 0.0f, false);
        boolean boolean29 = numberIsTooSmallException28.getBoundIsAllowed();
        exceptionContext4.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than the minimum (10)", (java.lang.Object) numberIsTooSmallException28);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        exceptionContext4.setValue("org.apache.commons.math3.exception.MathIllegalStateException: NUMBER_OF_SAMPLESx10 and 0x{3} matrices are not multiplication compatible", (java.lang.Object) localizedFormats32);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MEAN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertNotNull(throwable22);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats9, 10, (byte) 0 };
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER;
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats18, 10, (byte) 0 };
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable16, (org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, objArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray22);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext26 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.Localizable localizable27 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray35 = new java.lang.Object[] { localizedFormats32, 10, (byte) 0 };
        java.lang.Object[] objArray36 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray35);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable30, (org.apache.commons.math3.exception.util.Localizable) localizedFormats31, objArray36);
        java.lang.Throwable[] throwableArray38 = mathIllegalStateException37.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, localizable27, (java.lang.Object[]) throwableArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(exceptionContext26);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(throwableArray38);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1L, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray15 = numberIsTooSmallException14.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.Object obj18 = exceptionContext16.getValue("");
        java.lang.Object obj20 = exceptionContext16.getValue("hi!");
        java.lang.Object obj22 = exceptionContext16.getValue("");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer24 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter25 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer24);
        harmonicFitter25.clearObservations();
        harmonicFitter25.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter25.getObservations();
        exceptionContext16.setValue("crossover rate ({0})", (java.lang.Object) harmonicFitter25);
        harmonicFitter25.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray31 = harmonicFitter25.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) weightedObservedPointArray31);
        numberIsTooSmallException8.addSuppressed((java.lang.Throwable) mathIllegalStateException32);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalStateException32);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertNotNull(weightedObservedPointArray31);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, number2, (java.lang.Number) (byte) -1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats8, 10, (byte) 0 };
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray11);
        org.apache.commons.math3.exception.ZeroException zeroException14 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray11);
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray20 = new java.lang.Object[] { localizedFormats17, 10, (byte) 0 };
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable15, (org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray21);
        java.lang.Throwable[] throwableArray23 = mathIllegalStateException22.getSuppressed();
        zeroException14.addSuppressed((java.lang.Throwable) mathIllegalStateException22);
        java.lang.Throwable[] throwableArray25 = mathIllegalStateException22.getSuppressed();
        java.lang.Object[] objArray26 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray25);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.0f, (java.lang.Number) (byte) 0, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) 1, 0.0d, (double) 100.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray7 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray8 = harmonicFitter1.getObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray7);
        org.junit.Assert.assertNotNull(weightedObservedPointArray8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1L), (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (byte) 0, (double) 100.0f);
        java.lang.Class<?> wildcardClass9 = harmonicFitter1.getClass();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (-1), (double) '#', (-1.0d));
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint18 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (byte) 10, (double) (byte) 10, 10.0d);
        double double19 = weightedObservedPoint18.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint18);
        double double21 = weightedObservedPoint18.getWeight();
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException6.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        java.lang.Throwable[] throwableArray9 = mathIllegalStateException8.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException8.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats14, 10, (byte) 0 };
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray17);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray17);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats23, 10, (byte) 0 };
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable21, (org.apache.commons.math3.exception.util.Localizable) localizedFormats22, objArray27);
        java.lang.Throwable[] throwableArray29 = mathIllegalStateException28.getSuppressed();
        zeroException20.addSuppressed((java.lang.Throwable) mathIllegalStateException28);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED;
        java.lang.Throwable throwable32 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray37 = new java.lang.Object[] { localizedFormats34, 10, (byte) 0 };
        java.lang.Object[] objArray38 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray37);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable32, (org.apache.commons.math3.exception.util.Localizable) localizedFormats33, objArray38);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException28, (org.apache.commons.math3.exception.util.Localizable) localizedFormats31, objArray38);
        java.lang.Object[] objArray41 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        java.lang.Object[] objArray42 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray38);
        exceptionContext10.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray38);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray38);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats45, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray50 = numberIsTooSmallException49.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext51 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException49);
        java.lang.Object obj53 = exceptionContext51.getValue("");
        java.lang.Object obj55 = exceptionContext51.getValue("hi!");
        org.apache.commons.math3.exception.util.Localizable localizable56 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats58, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray63 = numberIsTooSmallException62.getSuppressed();
        java.lang.Object[] objArray64 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray63);
        org.apache.commons.math3.exception.ZeroException zeroException65 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats57, objArray64);
        exceptionContext51.addMessage(localizable56, objArray64);
        java.lang.Object[] objArray67 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray64);
        org.apache.commons.math3.exception.ZeroException zeroException68 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray67);
        java.lang.Class<?> wildcardClass69 = localizedFormats0.getClass();
        java.lang.Class<?> wildcardClass70 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertNull(obj55);
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats57.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats58.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(wildcardClass70);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Throwable[] throwableArray14 = numberIsTooSmallException13.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = mathIllegalArgumentException16.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(exceptionContext17);
    }
}

