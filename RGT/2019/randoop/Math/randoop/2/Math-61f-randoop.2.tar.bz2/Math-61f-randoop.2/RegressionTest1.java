import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.cos(76.71788878403689d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24849986246761402d + "'", double1 == 0.24849986246761402d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 52.0f, 15.82089653389908d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.82089653389908d + "'", double2 == 15.82089653389908d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-5911.214367279622d), (double) 0, 1.5582767461240283d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-4.693025966998126d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-54.586952933209844d) + "'", double1 == (-54.586952933209844d));
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextSecureInt((int) (short) 1, 87);
//        double double6 = randomDataImpl1.nextT(1.0d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double9 = randomDataImpl1.nextChiSquare((double) (byte) 0);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3726635760979488d + "'", double6 == 0.3726635760979488d);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1.0f), localizedFormats13, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), localizedFormats21, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1.0f), localizedFormats30, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1.0f), localizedFormats38, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException34, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException9, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray41);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats50, objArray56);
        java.lang.NullPointerException nullPointerException58 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray56);
        java.util.NoSuchElementException noSuchElementException59 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats48, objArray56);
        java.lang.IllegalStateException illegalStateException60 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException9, (org.apache.commons.math.exception.util.Localizable) localizedFormats46, objArray56);
        java.util.NoSuchElementException noSuchElementException62 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray56);
        java.io.EOFException eOFException63 = org.apache.commons.math.MathRuntimeException.createEOFException("scale must be positive ({0})", objArray56);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(nullPointerException58);
        org.junit.Assert.assertNotNull(noSuchElementException59);
        org.junit.Assert.assertNotNull(illegalStateException60);
        org.junit.Assert.assertNotNull(noSuchElementException62);
        org.junit.Assert.assertNotNull(eOFException63);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 83L, 7.105427357601002E-15d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.Object[] objArray1 = null;
        java.lang.IllegalArgumentException illegalArgumentException2 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray1);
        org.junit.Assert.assertNotNull(illegalArgumentException2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double2 = org.apache.commons.math.util.FastMath.min(32.0d, (double) 48L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 'a');
//        double double5 = normalDistributionImpl4.getStandardDeviation();
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double7 = normalDistributionImpl4.getStandardDeviation();
//        double[] doubleArray9 = normalDistributionImpl4.sample((int) (byte) 1);
//        java.lang.Class<?> wildcardClass10 = normalDistributionImpl4.getClass();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-82.62453753894556d) + "'", double6 == (-82.62453753894556d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
//        org.junit.Assert.assertNotNull(doubleArray9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 'a');
//        double double5 = normalDistributionImpl4.getStandardDeviation();
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double7 = normalDistributionImpl4.getStandardDeviation();
//        double double9 = normalDistributionImpl4.cumulativeProbability((double) 0.0f);
//        double double11 = normalDistributionImpl4.cumulativeProbability(62.07382940829115d);
//        double double12 = normalDistributionImpl4.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-77.40404074133224d) + "'", double6 == (-77.40404074133224d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5041127341632512d + "'", double9 == 0.5041127341632512d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.7422332255416261d + "'", double11 == 0.7422332255416261d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-84.8165763284111d) + "'", double12 == (-84.8165763284111d));
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double2 = org.apache.commons.math.util.FastMath.pow(7.896296018268069E13d, 73.6309117594686d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats2, 10L, localizedFormats4 };
        java.util.NoSuchElementException noSuchElementException6 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray5);
        java.io.EOFException eOFException7 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) eOFException7, (-22.02115087434479d));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(noSuchElementException6);
        org.junit.Assert.assertNotNull(eOFException7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextPascal(32, (-82.62453753894556d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 'a');
//        double double5 = normalDistributionImpl4.getStandardDeviation();
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) 'a');
//        randomDataImpl1.reSeed((-1L));
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl((-6.053272382792838d), (double) 48L);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl19 = new org.apache.commons.math.distribution.PoissonDistributionImpl(61.01671866837644d, (double) 14, (int) (byte) 0);
//        try {
//            int int20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl19);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.FunctionEvaluationException; message: maximal number of iterations (0) exceeded");
//        } catch (org.apache.commons.math.FunctionEvaluationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-78.02939972655773d) + "'", double6 == (-78.02939972655773d));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "e75efe33f79a06c0f478b74aca57b8cae5f58f26e3afdd3739a4f1c6c9fee86878528f7079719ef3998eac4c079b2d7bc" + "'", str8.equals("e75efe33f79a06c0f478b74aca57b8cae5f58f26e3afdd3739a4f1c6c9fee86878528f7079719ef3998eac4c079b2d7bc"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-41.01687541102901d) + "'", double15 == (-41.01687541102901d));
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double[] doubleArray5 = new double[] { 0.0d, 1L, 10.0d, 100.0d };
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        java.lang.ArithmeticException arithmeticException16 = org.apache.commons.math.MathRuntimeException.createArithmeticException("48cb487e3bb11713765b7202371c2d57d197235a6f50d139b1b515f2cee081000f77837bd9a43afb48a8b6d70a9febf04", objArray13);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(arithmeticException16);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0f), localizedFormats4, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray7);
        java.lang.IllegalStateException illegalStateException9 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray7);
        java.lang.ArithmeticException arithmeticException10 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) arithmeticException10);
        java.lang.Object[] objArray12 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable13 = mathRuntimeException11.getLocalizablePattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(illegalStateException9);
        org.junit.Assert.assertNotNull(arithmeticException10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 10, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ALPHA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ALPHA));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1.0f), localizedFormats11, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray14);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1.0f), localizedFormats19, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1.0f), localizedFormats28, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray31);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1.0f), localizedFormats36, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException32, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("hi!", objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException7, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray39);
        java.lang.Object[] objArray44 = mathRuntimeException7.getArguments();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0, 78.31981459106831d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0f), localizedFormats12, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1.0f), localizedFormats20, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1.0f), localizedFormats29, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray32);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1.0f), localizedFormats37, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException33, (org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray40);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException8, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray40);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray55);
        java.lang.NullPointerException nullPointerException57 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats48, objArray55);
        java.util.NoSuchElementException noSuchElementException58 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats47, objArray55);
        java.lang.IllegalStateException illegalStateException59 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray55);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException8, (org.apache.commons.math.exception.util.Localizable) localizedFormats45, objArray55);
        java.util.NoSuchElementException noSuchElementException61 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray55);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException65 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 23.37487144346031d, (java.lang.Number) (-1), true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(nullPointerException57);
        org.junit.Assert.assertNotNull(noSuchElementException58);
        org.junit.Assert.assertNotNull(illegalStateException59);
        org.junit.Assert.assertNotNull(noSuchElementException61);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) '#', (long) 52);
//        java.lang.String str6 = randomDataImpl1.nextHexString(1);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) '4');
//        double double11 = randomDataImpl1.nextF(1.0812189417858096d, (double) 6L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 48L + "'", long4 == 48L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5" + "'", str6.equals("5"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "85e8d98d714cf068b8b0dcef73a9d69f22f86567e77703ab9f2c" + "'", str8.equals("85e8d98d714cf068b8b0dcef73a9d69f22f86567e77703ab9f2c"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.24276295402535178d + "'", double11 == 0.24276295402535178d);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.floor(43.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.0d + "'", double1 == 43.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0f), localizedFormats4, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0f), localizedFormats12, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException8, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray15);
        double[] doubleArray19 = new double[] { 0 };
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray27 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException17, doubleArray19, localizable20, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1.0f), localizedFormats33, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray36);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException17, localizable30, objArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((double) 43L, "org.apache.commons.math.MathRuntimeException: array sizes should have difference 1 (-1 != 1 + 1)", objArray36);
        java.lang.Throwable[] throwableArray40 = functionEvaluationException39.getSuppressed();
        double[] doubleArray41 = functionEvaluationException39.getArgument();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(doubleArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.22563753946563211d), (-4.693025966998125d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.693025966998125d) + "'", double2 == (-4.693025966998125d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.43772926947700075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4518424614804031d + "'", double1 == 0.4518424614804031d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Object[] objArray1 = null;
        java.lang.IllegalStateException illegalStateException2 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray1);
        java.io.IOException iOException3 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) illegalStateException2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1.0f), localizedFormats8, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1.0f), localizedFormats16, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException12, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalStateException2, "org.apache.commons.math.MathRuntimeException$10: ", objArray19);
        org.junit.Assert.assertNotNull(illegalStateException2);
        org.junit.Assert.assertNotNull(iOException3);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 43L, number1, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1.0f), localizedFormats10, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray13);
        java.lang.IllegalStateException illegalStateException15 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray13);
        java.lang.ArithmeticException arithmeticException16 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        java.lang.IllegalStateException illegalStateException17 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray13);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, "8af34f3b53fc9d7df3f9956c255cefe3a6c6f7b3239f3cea70a5f3be46342d78d9399be7832623757acdf28", objArray13);
        java.lang.String str19 = numberIsTooSmallException3.toString();
        java.lang.Number number20 = numberIsTooSmallException3.getArgument();
        boolean boolean21 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(illegalStateException15);
        org.junit.Assert.assertNotNull(arithmeticException16);
        org.junit.Assert.assertNotNull(illegalStateException17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 43 is smaller than, or equal to, the minimum (null)" + "'", str19.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 43 is smaller than, or equal to, the minimum (null)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 43L + "'", number20.equals(43L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0f), localizedFormats4, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray7);
        java.lang.IllegalStateException illegalStateException9 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray7);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("8af34f3b53fc9d7df3f9956c255cefe3a6c6f7b3239f3cea70a5f3be46342d78d9399be7832623757acdf28", objArray7);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(illegalStateException9);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.43772926947700075d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException((double) '4');
        java.lang.Throwable[] throwableArray4 = functionEvaluationException3.getSuppressed();
        java.text.ParseException parseException5 = org.apache.commons.math.MathRuntimeException.createParseException((int) '#', (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(parseException5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.7458972020383894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.323860408520522d + "'", double1 == 1.323860408520522d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl(61.01671866837644d, (double) 14, (int) (byte) 0);
        double double5 = poissonDistributionImpl3.cumulativeProbability((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.896296018268069E13d, (-33.33587468088087d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 'a');
//        double double5 = normalDistributionImpl4.getStandardDeviation();
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) 'a');
//        randomDataImpl1.reSeed((-1L));
//        int[] intArray13 = randomDataImpl1.nextPermutation((int) (byte) 10, 8);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 60.17299927222719d + "'", double6 == 60.17299927222719d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "77c6c42c9ed01395939fc57b1187aeda4ee5720784e0a056092bf0172169f6b9ddb3f8f859434763defca60c1a8588767" + "'", str8.equals("77c6c42c9ed01395939fc57b1187aeda4ee5720784e0a056092bf0172169f6b9ddb3f8f859434763defca60c1a8588767"));
//        org.junit.Assert.assertNotNull(intArray13);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 52.0f, (java.lang.Number) 1979372.4877712526d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.40215490264273146d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9202196975162944d + "'", double1 == 0.9202196975162944d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray9);
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        java.util.NoSuchElementException noSuchElementException12 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        java.util.ConcurrentModificationException concurrentModificationException13 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("8af34f3b53fc9d7df3f9956c255cefe3a6c6f7b3239f3cea70a5f3be46342d78d9399be7832623757acdf28", objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(nullPointerException11);
        org.junit.Assert.assertNotNull(noSuchElementException12);
        org.junit.Assert.assertNotNull(concurrentModificationException13);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 'a');
//        double double5 = normalDistributionImpl4.getStandardDeviation();
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) 'a');
//        randomDataImpl1.reSeed((-1L));
//        double double13 = randomDataImpl1.nextF(1.5582767461240283d, 73.6309117594686d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl14.setStandardDeviation(1.4210854715202007E-14d);
//        double double18 = normalDistributionImpl14.cumulativeProbability((double) (short) -1);
//        normalDistributionImpl14.reseedRandomGenerator((long) (short) 10);
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double22 = normalDistributionImpl14.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.74724175446523d + "'", double6 == 57.74724175446523d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "e7d1aec1c87368b2c396628f634ed4d838614a49fd63efe94feec3354ed9af9cd9fa5a6567457849657620b1d82601041" + "'", str8.equals("e7d1aec1c87368b2c396628f634ed4d838614a49fd63efe94feec3354ed9af9cd9fa5a6567457849657620b1d82601041"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.24015850068729672d + "'", double13 == 0.24015850068729672d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-8.169359046175018E-10d) + "'", double21 == (-8.169359046175018E-10d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.2429934722692516E-14d + "'", double22 == 1.2429934722692516E-14d);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1.0f), localizedFormats13, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), localizedFormats21, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1.0f), localizedFormats30, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1.0f), localizedFormats38, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException34, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException9, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray41);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats50, objArray56);
        java.lang.NullPointerException nullPointerException58 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray56);
        java.util.NoSuchElementException noSuchElementException59 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats48, objArray56);
        java.lang.IllegalStateException illegalStateException60 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException9, (org.apache.commons.math.exception.util.Localizable) localizedFormats46, objArray56);
        java.util.NoSuchElementException noSuchElementException62 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray56);
        java.lang.NullPointerException nullPointerException63 = org.apache.commons.math.MathRuntimeException.createNullPointerException("3c8f14c1bbde520271663cd27337dfb43164fe331d833a31ffa48f0feffd2e3f3a066dd9fdc61d3fe0bb80934805c07d4", objArray56);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(nullPointerException58);
        org.junit.Assert.assertNotNull(noSuchElementException59);
        org.junit.Assert.assertNotNull(illegalStateException60);
        org.junit.Assert.assertNotNull(noSuchElementException62);
        org.junit.Assert.assertNotNull(nullPointerException63);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1.0f), localizedFormats3, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1.0f), localizedFormats11, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray14);
        double[] doubleArray18 = new double[] { 0 };
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException16, doubleArray18, localizable19, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1.0f), localizedFormats32, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, objArray35);
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException16, localizable29, objArray35);
        java.lang.Object[] objArray38 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray35);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1.0f), localizedFormats14, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray17);
        java.lang.IllegalStateException illegalStateException19 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray17);
        java.lang.ArithmeticException arithmeticException20 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray17);
        java.lang.IllegalStateException illegalStateException21 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray17);
        double[] doubleArray26 = new double[] { 0.0d, 1L, 10.0d, 100.0d };
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1.0f), localizedFormats40, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) illegalStateException21, doubleArray26, (org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException7, "9", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(illegalStateException19);
        org.junit.Assert.assertNotNull(arithmeticException20);
        org.junit.Assert.assertNotNull(illegalStateException21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray43);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 43L, number3, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0f), localizedFormats12, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray15);
        java.lang.IllegalStateException illegalStateException17 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray15);
        java.lang.ArithmeticException arithmeticException18 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        java.lang.IllegalStateException illegalStateException19 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray15);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException5, "8af34f3b53fc9d7df3f9956c255cefe3a6c6f7b3239f3cea70a5f3be46342d78d9399be7832623757acdf28", objArray15);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray15);
        java.io.EOFException eOFException22 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(illegalStateException17);
        org.junit.Assert.assertNotNull(arithmeticException18);
        org.junit.Assert.assertNotNull(illegalStateException19);
        org.junit.Assert.assertNotNull(eOFException22);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException(0.7422332255416261d);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 'a');
//        double double5 = normalDistributionImpl4.getStandardDeviation();
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) 'a');
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl11 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, 1.0d);
//        double double13 = poissonDistributionImpl11.probability(0.6321205588285574d);
//        poissonDistributionImpl11.reseedRandomGenerator(0L);
//        double double17 = poissonDistributionImpl11.normalApproximateProbability(100);
//        int int18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl11);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 37.61113856717908d + "'", double6 == 37.61113856717908d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "c9f4b8fa567b433de903a6c60237fa5288fafb43196b37b9c7945500e9f941b15499122e01d4a422dbc1e4deded409eec" + "'", str8.equals("c9f4b8fa567b433de903a6c60237fa5288fafb43196b37b9c7945500e9f941b15499122e01d4a422dbc1e4deded409eec"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double[] doubleArray6 = new double[] { 0.0d, 1L, 10.0d, 100.0d };
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray14);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException17 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("c", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("3c8f14c1bbde520271663cd27337dfb43164fe331d833a31ffa48f0feffd2e3f3a066dd9fdc61d3fe0bb80934805c07d4", objArray14);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException17);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats5, 10L, localizedFormats7 };
        java.util.NoSuchElementException noSuchElementException9 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(0.0d, "85e8d98d714cf068b8b0dcef73a9d69f22f86567e77703ab9f2c", objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(noSuchElementException9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 10, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1.0f), localizedFormats13, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), localizedFormats21, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1.0f), localizedFormats30, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1.0f), localizedFormats38, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException34, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException9, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray41);
        java.lang.String str46 = mathRuntimeException9.toString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1.0f), localizedFormats51, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray54);
        java.lang.IllegalStateException illegalStateException56 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException9, "", objArray54);
        org.apache.commons.math.MathRuntimeException mathRuntimeException58 = new org.apache.commons.math.MathRuntimeException("9", objArray54);
        java.io.EOFException eOFException59 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray54);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "org.apache.commons.math.MathRuntimeException: array sizes should have difference 1 (-1 != 1 + 1)" + "'", str46.equals("org.apache.commons.math.MathRuntimeException: array sizes should have difference 1 (-1 != 1 + 1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(illegalStateException56);
        org.junit.Assert.assertNotNull(eOFException59);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian(0.6931471805599453d, 0.017453292519943295d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 'a');
//        double double10 = normalDistributionImpl9.getStandardDeviation();
//        double double11 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double13 = normalDistributionImpl9.inverseCumulativeProbability(4.9E-324d);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double16 = normalDistributionImpl9.density((java.lang.Double) 0.4530715758459752d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6665684038505633d + "'", double4 == 0.6665684038505633d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 42.51911769240737d + "'", double11 == 42.51911769240737d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 54.4938592191372d + "'", double14 == 54.4938592191372d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.004112345575213398d + "'", double16 == 0.004112345575213398d);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1.0f), localizedFormats9, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1.0f), localizedFormats17, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException13, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray20);
        java.text.ParseException parseException23 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 1, "", objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray32);
        java.lang.NullPointerException nullPointerException34 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray32);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1.0f), localizedFormats38, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray41);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1.0f), localizedFormats46, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException42, (org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray49);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) parseException23, (double) 0L, (org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray49);
        java.lang.UnsupportedOperationException unsupportedOperationException54 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray49);
        java.lang.IllegalArgumentException illegalArgumentException55 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.MathRuntimeException: array sizes should have difference 1 (-1 != 1 + 1)", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.MathRuntimeException(throwable1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray49);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray49);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(parseException23);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(nullPointerException34);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(unsupportedOperationException54);
        org.junit.Assert.assertNotNull(illegalArgumentException55);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1.0f), localizedFormats11, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray14);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1.0f), localizedFormats19, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray22);
        java.text.ParseException parseException25 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 1, "", objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray34);
        java.lang.NullPointerException nullPointerException36 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1.0f), localizedFormats40, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray43);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1.0f), localizedFormats48, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats46, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException44, (org.apache.commons.math.exception.util.Localizable) localizedFormats45, objArray51);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("hi!", objArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) parseException25, (double) 0L, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray51);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("63149a4681ed4f17f7987c35539b65eeb3cbf4d7501adcdc66b1", objArray51);
        org.apache.commons.math.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) numberIsTooLargeException4, "org.apache.commons.math.MathRuntimeException$10: ", objArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(parseException25);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(nullPointerException36);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Object[] objArray0 = null;
        java.lang.Object[] objArray1 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray0);
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.3440585709080678E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0f), localizedFormats4, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0f), localizedFormats12, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException8, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray15);
        double[] doubleArray23 = new double[] { 0.0d, 1L, 10.0d, 100.0d };
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray31);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray31);
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException17, "", objArray31);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray43);
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray43);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray52 = new java.lang.Object[] { (-1.0f), localizedFormats49, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException53 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats47, objArray52);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1.0f), localizedFormats57, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats55, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException53, (org.apache.commons.math.exception.util.Localizable) localizedFormats54, objArray60);
        double[] doubleArray64 = new double[] { 0 };
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats66 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats66, objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException62, doubleArray64, localizable65, objArray72);
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats76 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats78 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray81 = new java.lang.Object[] { (-1.0f), localizedFormats78, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException82 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats76, objArray81);
        org.apache.commons.math.MathRuntimeException mathRuntimeException83 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException62, localizable75, objArray81);
        java.lang.Object[] objArray84 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray81);
        java.text.ParseException parseException85 = org.apache.commons.math.MathRuntimeException.createParseException((int) (short) 100, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray84);
        java.lang.IllegalArgumentException illegalArgumentException86 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("89e5fae193d7bef7ff314ac83763e8eafbee1b29e3916ad5795f440704e2ca5a68db65a52388ad68619328196880fec14", objArray84);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats54.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + localizedFormats66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats66.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + localizedFormats76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats76.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats78.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(parseException85);
        org.junit.Assert.assertNotNull(illegalArgumentException86);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.004112588463181002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004112600056233798d + "'", double1 == 0.004112600056233798d);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 'a');
//        double double5 = normalDistributionImpl4.getStandardDeviation();
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) 'a');
//        randomDataImpl1.reSeed((-1L));
//        double double13 = randomDataImpl1.nextF(1.5582767461240283d, 73.6309117594686d);
//        try {
//            int int17 = randomDataImpl1.nextHypergeometric(0, 83, (int) (byte) 10);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 126.95027193576476d + "'", double6 == 126.95027193576476d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5f703c87587c21033be0777e013d2dbe8f2772b046ac83caa4041940bb5aea3a8c31c4bdabffbd05ee2e62471275cc770" + "'", str8.equals("5f703c87587c21033be0777e013d2dbe8f2772b046ac83caa4041940bb5aea3a8c31c4bdabffbd05ee2e62471275cc770"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.24015850068729672d + "'", double13 == 0.24015850068729672d);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl(0.22789274007256666d);
        try {
            double double4 = poissonDistributionImpl1.cumulativeProbability(87, 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 'a');
//        double double5 = normalDistributionImpl4.getStandardDeviation();
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double7 = normalDistributionImpl4.getStandardDeviation();
//        double[] doubleArray9 = normalDistributionImpl4.sample((int) (byte) 1);
//        double double11 = normalDistributionImpl4.inverseCumulativeProbability(0.0d);
//        try {
//            double double13 = normalDistributionImpl4.inverseCumulativeProbability((-0.40215490264273146d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 126.07172176331815d + "'", double6 == 126.07172176331815d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
//        org.junit.Assert.assertNotNull(doubleArray9);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        double double5 = randomDataImpl1.nextCauchy((double) ' ', (double) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (-1));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 64.0536792603861d + "'", double5 == 64.0536792603861d);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.017453292519943295d, (double) 100.0f);
//        double double5 = normalDistributionImpl4.getStandardDeviation();
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 131.3376741934173d + "'", double6 == 131.3376741934173d);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 57.74724175446523d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1.0f), localizedFormats15, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray18);
        java.lang.IllegalStateException illegalStateException20 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray18);
        java.lang.ArithmeticException arithmeticException21 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray18);
        java.lang.IllegalStateException illegalStateException22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray18);
        double[] doubleArray27 = new double[] { 0.0d, 1L, 10.0d, 100.0d };
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, (org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-1.0f), localizedFormats41, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) illegalStateException22, doubleArray27, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray44);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException8, "9", objArray44);
        java.io.EOFException eOFException48 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray44);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(illegalStateException20);
        org.junit.Assert.assertNotNull(arithmeticException21);
        org.junit.Assert.assertNotNull(illegalStateException22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(eOFException48);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException(doubleArray0);
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException1, "", objArray3);
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1.0f), localizedFormats13, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), localizedFormats21, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1.0f), localizedFormats30, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1.0f), localizedFormats38, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException34, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException9, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray41);
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats48, objArray54);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException45, doubleArray46, "hi!", objArray54);
        java.lang.IllegalArgumentException illegalArgumentException57 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray54);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray54);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray66 = new java.lang.Object[] { localizedFormats63, 10L, localizedFormats65 };
        java.util.NoSuchElementException noSuchElementException67 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray66);
        java.util.ConcurrentModificationException concurrentModificationException68 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats61, objArray66);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((double) 100, "51763de8881e0221e9105c5e3f9be4f1d468e486615749f114326f29bdfa5b4552e5799f4a8a2a55dd334b9c2928e76ab", objArray66);
        org.apache.commons.math.MathRuntimeException mathRuntimeException70 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray66);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(illegalArgumentException57);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats61.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE));
        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats63.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(noSuchElementException67);
        org.junit.Assert.assertNotNull(concurrentModificationException68);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl(0.22789274007256666d);
        poissonDistributionImpl1.reseedRandomGenerator((long) 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 46L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2635.6058576017867d + "'", double1 == 2635.6058576017867d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.atan(60.17299927222719d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5541791070052693d + "'", double1 == 1.5541791070052693d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, 1.0d);
        double double4 = poissonDistributionImpl2.cumulativeProbability((double) (short) 0);
        double double6 = poissonDistributionImpl2.probability(8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6321205588285574d + "'", double4 == 0.6321205588285574d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.123994076672692E-6d + "'", double6 == 9.123994076672692E-6d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-6.053272382792838d), (double) 100);
        double double4 = normalDistributionImpl2.cumulativeProbability(44.375215798264094d);
        double double5 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6929694001349015d + "'", double4 == 0.6929694001349015d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray11);
        java.lang.NullPointerException nullPointerException13 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray11);
        java.util.NoSuchElementException noSuchElementException14 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(throwable0, localizable1, objArray11);
        java.lang.Object[] objArray17 = mathException16.getArguments();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(nullPointerException13);
        org.junit.Assert.assertNotNull(noSuchElementException14);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray10);
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray10);
        java.util.NoSuchElementException noSuchElementException13 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray10);
        java.lang.IllegalStateException illegalStateException14 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1.0f), localizedFormats27, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1.0f), localizedFormats35, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray38);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1.0f), localizedFormats44, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1.0f), localizedFormats52, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats50, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException48, (org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray55);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("hi!", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException23, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray55);
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalStateException14, "d", objArray55);
        java.lang.ArithmeticException arithmeticException61 = org.apache.commons.math.MathRuntimeException.createArithmeticException("3c8f14c1bbde520271663cd27337dfb43164fe331d833a31ffa48f0feffd2e3f3a066dd9fdc61d3fe0bb80934805c07d4", objArray55);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(nullPointerException12);
        org.junit.Assert.assertNotNull(noSuchElementException13);
        org.junit.Assert.assertNotNull(illegalStateException14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(arithmeticException61);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, 1.0d);
        double double4 = poissonDistributionImpl2.cumulativeProbability((double) (short) 0);
        double double7 = poissonDistributionImpl2.cumulativeProbability(52, (int) '4');
        double double9 = poissonDistributionImpl2.cumulativeProbability(14);
        double double11 = poissonDistributionImpl2.probability(100);
        try {
            double double14 = poissonDistributionImpl2.cumulativeProbability((double) 'a', 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6321205588285574d + "'", double4 == 0.6321205588285574d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9999999999997187d + "'", double9 == 0.9999999999997187d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.941866060050443E-159d + "'", double11 == 3.941866060050443E-159d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 100L, 0.8452767940881093d);
        double[] doubleArray4 = normalDistributionImpl2.sample(0);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 100, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats3, 10L, localizedFormats5 };
        java.util.NoSuchElementException noSuchElementException7 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray6);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(noSuchElementException7);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray4 = new double[] { 0.0d, 1L, 10.0d, 100.0d };
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1.0f), localizedFormats17, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1.0f), localizedFormats25, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException21, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray28);
        double[] doubleArray32 = new double[] { 0 };
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException30, doubleArray32, localizable33, objArray40);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray50 = new java.lang.Object[] { localizedFormats47, 10L, localizedFormats49 };
        java.util.NoSuchElementException noSuchElementException51 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray50);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException(32, (org.apache.commons.math.exception.util.Localizable) localizedFormats45, objArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException14, doubleArray32, "scale must be positive ({0})", objArray50);
        java.lang.Throwable[] throwableArray54 = functionEvaluationException14.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(noSuchElementException51);
        org.junit.Assert.assertNotNull(throwableArray54);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1.0f), localizedFormats14, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1.0f), localizedFormats22, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1.0f), localizedFormats31, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1.0f), localizedFormats39, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException35, (org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray42);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("hi!", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException10, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray42);
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException46, doubleArray47, "hi!", objArray55);
        java.lang.IllegalArgumentException illegalArgumentException58 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray55);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats62 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray68 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats62, objArray68);
        java.lang.NullPointerException nullPointerException70 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats61, objArray68);
        java.util.NoSuchElementException noSuchElementException71 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats60, objArray68);
        java.lang.IllegalStateException illegalStateException72 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray68);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException73 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray68);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException74 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("scale must be positive ({0})", objArray68);
        java.io.EOFException eOFException75 = org.apache.commons.math.MathRuntimeException.createEOFException("85e8d98d714cf068b8b0dcef73a9d69f22f86567e77703ab9f2c", objArray68);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(illegalArgumentException58);
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats61.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats62.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(nullPointerException70);
        org.junit.Assert.assertNotNull(noSuchElementException71);
        org.junit.Assert.assertNotNull(illegalStateException72);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException73);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException74);
        org.junit.Assert.assertNotNull(eOFException75);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) '4');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1.0f), localizedFormats6, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1.0f), localizedFormats14, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray17);
        double[] doubleArray25 = new double[] { 0.0d, 1L, 10.0d, 100.0d };
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25, (org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException19, "", objArray33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException2, "48cb487e3bb11713765b7202371c2d57d197235a6f50d139b1b515f2cee081000f77837bd9a43afb48a8b6d70a9febf04", objArray33);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException38 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("c", objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException38);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray9);
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        java.util.NoSuchElementException noSuchElementException12 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        java.lang.IllegalStateException illegalStateException13 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1.0f), localizedFormats26, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray29);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (-1.0f), localizedFormats34, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException30, (org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray37);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1.0f), localizedFormats43, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray46);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1.0f), localizedFormats51, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException47, (org.apache.commons.math.exception.util.Localizable) localizedFormats48, objArray54);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("hi!", objArray54);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException22, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray54);
        org.apache.commons.math.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalStateException13, "d", objArray54);
        java.lang.Object[] objArray60 = mathRuntimeException59.getArguments();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(nullPointerException11);
        org.junit.Assert.assertNotNull(noSuchElementException12);
        org.junit.Assert.assertNotNull(illegalStateException13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (byte) 0 + "'", number2.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException(75.50639459282515d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1.0f), localizedFormats2, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray5);
        java.lang.String str7 = mathRuntimeException6.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "index {0} out of allowed range [{1}, {2}]" + "'", str7.equals("index {0} out of allowed range [{1}, {2}]"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, 1.0d);
        double double4 = poissonDistributionImpl2.probability(0.6321205588285574d);
        double double6 = poissonDistributionImpl2.cumulativeProbability(1);
        double double8 = poissonDistributionImpl2.normalApproximateProbability(32);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8160602794142788d + "'", double6 == 0.8160602794142788d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, 1.0d);
        double double4 = poissonDistributionImpl2.cumulativeProbability((double) (short) 0);
        double double7 = poissonDistributionImpl2.cumulativeProbability(52, (int) '4');
        double double9 = poissonDistributionImpl2.cumulativeProbability(14);
        double double11 = poissonDistributionImpl2.probability(100);
        double double13 = poissonDistributionImpl2.probability((int) (short) -1);
        double double15 = poissonDistributionImpl2.normalApproximateProbability(1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6321205588285574d + "'", double4 == 0.6321205588285574d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9999999999997187d + "'", double9 == 0.9999999999997187d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.941866060050443E-159d + "'", double11 == 3.941866060050443E-159d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.691462461274013d + "'", double15 == 0.691462461274013d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0d), 1.0d, (byte) 0, 1, (short) 0 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0f), localizedFormats12, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1.0f), localizedFormats20, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1.0f), localizedFormats29, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray32);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1.0f), localizedFormats37, 1.0f, 10 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException33, (org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray40);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException8, (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray40);
        java.lang.String str45 = mathRuntimeException8.toString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray52 = new java.lang.Object[] { localizedFormats49, 10L, localizedFormats51 };
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray52);
        java.io.EOFException eOFException54 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException8, "org.apache.commons.math.exception.NumberIsTooSmallException: 43 is smaller than, or equal to, the minimum (null)", objArray52);
        java.util.ConcurrentModificationException concurrentModificationException56 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("overflow in subtraction: {0} - {1}", objArray52);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.apache.commons.math.MathRuntimeException: array sizes should have difference 1 (-1 != 1 + 1)" + "'", str45.equals("org.apache.commons.math.MathRuntimeException: array sizes should have difference 1 (-1 != 1 + 1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertNotNull(eOFException54);
        org.junit.Assert.assertNotNull(concurrentModificationException56);
    }
}

