import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray11 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray4, orderDirection10, doubleArray11);
        double[] doubleArray16 = new double[] { 20L, 1.3440585709080678E43d, 5.916079783099616d };
        double[] doubleArray21 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean26 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection23, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray28 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray21, orderDirection27, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray21);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray21);
        double[] doubleArray36 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean41 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection38, false, false);
        try {
            boolean boolean44 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection38, true, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly decreasing (10 <= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1173821313 + "'", int22 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1173821313 + "'", int37 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 108L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.3752998404656145d + "'", double1 == 5.3752998404656145d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1, (long) 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(101.0d, (double) 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 55.0d + "'", double2 == 55.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (-1.0f), 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.cosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double2 = org.apache.commons.math.util.FastMath.scalb(35.553480614894134d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2216082919995222E12d + "'", double2 == 1.2216082919995222E12d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double2 = org.apache.commons.math.util.MathUtils.log(24.887921886238782d, (-309.410778200998d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.resetCount();
        int int3 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1173821313, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.3796077390275217d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.347642624E10d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.20941767543251008d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.util.MathUtils.round((-1.0d), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        float float2 = org.apache.commons.math.util.FastMath.scalb(0.0f, 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 107, 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.391406280535837d) + "'", double2 == (-7.391406280535837d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(24.887921886238782d, 1.0000000000000013d, 5.3752998404656145d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-7.391406280535837d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-423.4963845411932d) + "'", double1 == (-423.4963845411932d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver0.solve((int) (byte) 10, univariateRealFunction4, (double) 32.000004f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0f + "'", float1 == 6.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1076101120L + "'", long2 == 1076101120L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 0.2990780352269423d, 1.6704649792860586d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 100L);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getEvaluations();
        int int5 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        try {
            double double9 = regulaFalsiSolver2.solve(0, univariateRealFunction7, (double) 6.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray11 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray4, orderDirection10, doubleArray11);
        double[] doubleArray13 = null;
        try {
            double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 9.536743E-7f, (double) (-1022));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1024.1592041165982d) + "'", double2 == (-1024.1592041165982d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math.exception.MathIllegalStateException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, number3, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = mathIllegalStateException0.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext12);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray10 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray10);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1173821313 + "'", int11 == 1173821313);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1173821313 + "'", int13 == 1173821313);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1022), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-810548224) + "'", int2 == (-810548224));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 20L, 0.2990780352269423d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(20L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 72L + "'", long2 == 72L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (short) 0, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 10, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 1.3440585709080678E43d, 19.999999999999996d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 8170176069297290577L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.24016931380205d + "'", double1 == 44.24016931380205d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) '4', 0.0f, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) -1, 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray11 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 101L, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray13);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.798179868358115d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6465285558685404d + "'", double1 == 0.6465285558685404d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 32L, 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double2 = regulaFalsiSolver1.getStartValue();
        double double3 = regulaFalsiSolver1.getStartValue();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double10 = regulaFalsiSolver1.solve(0, univariateRealFunction6, 0.0d, (double) 1173821313, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        int int3 = regulaFalsiSolver0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '#', 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 6.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(100, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, 20.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950547536867305d + "'", double1 == 0.9950547536867305d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.2990780352269423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0450582013846992d + "'", double1 == 1.0450582013846992d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double7 = regulaFalsiSolver0.solve((int) ' ', univariateRealFunction3, 19.999999999999996d, 35.553480614894134d, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1173821313, 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 3.689503868988906d, (-0.8813735870195429d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-35L), (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-35.0d) + "'", double2 == (-35.0d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 3L, 32.0d, 0.0d, 3845.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 96.0d + "'", double4 == 96.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray12 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, number7, objArray12);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException15 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 2.2250738585072014E-308d, objArray12);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 1173821313, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        java.lang.String str19 = mathIllegalStateException18.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.MathIllegalStateException: whole format" + "'", str19.equals("org.apache.commons.math.exception.MathIllegalStateException: whole format"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.000000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.543080634815245d + "'", double1 == 1.543080634815245d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 167.04649792860587d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double2 = org.apache.commons.math.util.FastMath.scalb(1.6704649792860586d, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6704649792860586d + "'", double2 == 1.6704649792860586d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 3, 0.0f, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.rint(24.887921886238782d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.0d + "'", double1 == 25.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.abs(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.705429428472229d + "'", double1 == 0.705429428472229d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.544068044350276d + "'", double1 == 1.544068044350276d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double[] doubleArray3 = new double[] { 20L, 1.3440585709080678E43d, 5.916079783099616d };
        double[] doubleArray8 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray15 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray8, orderDirection14, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray8);
        double[] doubleArray22 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray28 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray28);
        double[] doubleArray35 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray41 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray41);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1173821313 + "'", int9 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1173821313 + "'", int23 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1173821313 + "'", int29 == 1173821313);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1173821313 + "'", int36 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1173821313 + "'", int42 == 1173821313);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.3440585709080678E43d + "'", double45 == 1.3440585709080678E43d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(0.0d, (double) 1348863081);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.744315405E8d + "'", double2 == 6.744315405E8d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 108L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.3690626E32f + "'", float2 == 1.3690626E32f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 101L, (float) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 1.0d, 96.0d, 1.0E-14d, 1.7453292519943295d, (double) 32L, 0.0d, (double) 107);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 55.850536063819504d + "'", double8 == 55.850536063819504d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 100L);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        double double4 = regulaFalsiSolver2.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver2.solve(100, univariateRealFunction6, 0.0d, (double) 97.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1076101120);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(108L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 118L + "'", long2 == 118L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '4', (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 3.2537765234981815d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179586d + "'", double2 == 6.283185307179586d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 35, 1.3690626E32f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1024.1592041165982d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1024.0d) + "'", double1 == (-1024.0d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray10 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray10);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray19 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray26 = new double[] { 1.1102230246251565E-16d, 2.0d, 32.000004f };
        double[] doubleArray30 = new double[] { 1.1102230246251565E-16d, 2.0d, 32.000004f };
        double[][] doubleArray31 = new double[][] { doubleArray26, doubleArray30 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray19, orderDirection22, doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1173821313 + "'", int11 == 1173821313);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1173821313 + "'", int20 == 1173821313);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int int2 = org.apache.commons.math.util.MathUtils.pow(6, (long) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60466176 + "'", int2 == 60466176);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.067661995777765d + "'", double1 == 10.067661995777765d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.0f), (float) 8170176069297290577L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1022));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5430806348152437d, (-1.0d), 5.3752998404656145d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        float float1 = org.apache.commons.math.util.FastMath.abs(2.34764262E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.34764262E9f + "'", float1 == 2.34764262E9f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 1076101120, (double) '#', 100.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.6895038689889077d, 0.705429428472229d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3818774166709604d + "'", double2 == 1.3818774166709604d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 100, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) -1, 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 10, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 90, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, 72L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 72L + "'", long2 == 72L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(10, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.8066624897703196d + "'", double2 == 3.8066624897703196d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { (byte) 100 };
        int[] intArray7 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        try {
            int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 118L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(6.283185307179586d, 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int1 = org.apache.commons.math.util.FastMath.abs(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray6 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray6);
        int[] intArray9 = new int[] { (byte) 100 };
        int[] intArray14 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray14);
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray16);
        int[] intArray19 = new int[] { (byte) 100 };
        int[] intArray24 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray24);
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray19);
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray26);
        int[] intArray29 = new int[] { (byte) 100 };
        int[] intArray34 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray34);
        int[] intArray37 = new int[] { (byte) 100 };
        int[] intArray42 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray42);
        int[] intArray44 = org.apache.commons.math.util.MathUtils.copyOf(intArray37);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray44);
        int[] intArray48 = new int[] { (byte) 100 };
        int[] intArray53 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray53);
        int[] intArray56 = new int[] { (byte) 100 };
        int[] intArray61 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int[] intArray63 = org.apache.commons.math.util.MathUtils.copyOf(intArray56);
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray63);
        int[] intArray66 = new int[] { (byte) 100 };
        int[] intArray71 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray71);
        int[] intArray73 = org.apache.commons.math.util.MathUtils.copyOf(intArray66);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray73);
        int[] intArray76 = new int[] { (byte) 100 };
        int[] intArray81 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray76, intArray81);
        int[] intArray84 = new int[] { (byte) 100 };
        int[] intArray89 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray84, intArray89);
        int[] intArray91 = org.apache.commons.math.util.MathUtils.copyOf(intArray84);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray91);
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray91);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray91);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 60466176);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0466176E7f + "'", float1 == 6.0466176E7f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 20.0f, 3.141592653589793d, 0.798179868358115d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.35226421010312625d + "'", double3 == 0.35226421010312625d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1125899906842624L, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.102016471589204E38d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 167.04649792860587d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.13354756621883E-310d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0646819084678927E-155d + "'", double1 == 1.0646819084678927E-155d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int2 = org.apache.commons.math.util.FastMath.max(6, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(4.68213122712422d, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6010540800553663d) + "'", double2 == (-1.6010540800553663d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1022), 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, objArray9);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.2250738585072014E-308d, objArray9);
        java.lang.Throwable[] throwableArray14 = maxCountExceededException13.getSuppressed();
        java.lang.Number number15 = maxCountExceededException13.getMax();
        java.lang.Number number16 = maxCountExceededException13.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 2.2250738585072014E-308d + "'", number15.equals(2.2250738585072014E-308d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.2250738585072014E-308d + "'", number16.equals(2.2250738585072014E-308d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 100.0f, (double) 2.34764262E9f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 100L);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getEvaluations();
        int int5 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        try {
            double double9 = regulaFalsiSolver2.solve((int) (short) 100, univariateRealFunction7, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(167.04649792860587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.91551139278006d + "'", double1 == 2.91551139278006d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.2216082919995222E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1105263.9015183307d + "'", double1 == 1105263.9015183307d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.7853981633974488d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double4 = regulaFalsiSolver3.getStartValue();
        double double5 = regulaFalsiSolver3.getStartValue();
        double double6 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = null;
        try {
            double double11 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(60466176, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, 0.798179868358115d, 107.0d, (double) 107, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.util.MathUtils.checkFinite(0.9950547536867305d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1, 3845.0d, (-810548224));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double7 = regulaFalsiSolver1.solve(90, univariateRealFunction3, (double) 9, 0.9950547536867305d, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution6 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution6.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 101L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 90);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.102016471589204E38d + "'", double1 == 6.102016471589204E38d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 970, (double) 108L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(21.576677523750607d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 100, (int) (byte) 10, 1076101120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,076,101,120, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.0d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(0.35226421010312625d, (-0.5063656411097588d), 2.347642624E10d, (double) 1, 2.91551139278006d, (double) 2.5353012E31f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.391699534059768E31d + "'", double6 == 7.391699534059768E31d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 2, 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(1.0E-6d, 1.3440585709080678E43d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double[] doubleArray6 = new double[] { 5.916079783099616d, 2.34764262E9f, 100L, 90.0d, 100, 20L };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        double[] doubleArray12 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection14, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray19 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, orderDirection18, doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double[] doubleArray26 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection28, false, false);
        double[] doubleArray36 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean41 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection38, false, false);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray36);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray36);
        try {
            double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1173821313 + "'", int13 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1173821313 + "'", int27 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1173821313 + "'", int37 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9542425094393249d + "'", double1 == 0.9542425094393249d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) (-1), 5.3752998404656145d, 1.0E-6d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 10, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.791759469228055d + "'", double1 == 1.791759469228055d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int2 = org.apache.commons.math.util.MathUtils.pow(35, 100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-86196911) + "'", int2 == (-86196911));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 10, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.000000000000001d, (java.lang.Number) 19.999999999999996d, (int) (short) 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(0.0f, 107.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 118L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 118.00001f + "'", float1 == 118.00001f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 100.00001f, (double) 32L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(60466176);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray10 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray10);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray19 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray19);
        double[] doubleArray26 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray32 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray32);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray26);
        double[] doubleArray41 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray47 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray47);
        double[] doubleArray54 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        double[] doubleArray60 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray60);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray54);
        double double64 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1173821313 + "'", int11 == 1173821313);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1173821313 + "'", int20 == 1173821313);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1173821313 + "'", int27 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1173821313 + "'", int33 == 1173821313);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1173821313 + "'", int35 == 1173821313);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1173821313 + "'", int42 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1173821313 + "'", int48 == 1173821313);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1173821313 + "'", int55 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1173821313 + "'", int61 == 1173821313);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 10201.0d + "'", double64 == 10201.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 97.0f, 107.0d, (double) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray15 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray15);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException17 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, number10, objArray15);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 2.2250738585072014E-308d, objArray15);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 1173821313, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray15);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 360.0d, objArray15);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException22 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (byte) -1, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double[] doubleArray6 = new double[] { 5.916079783099616d, 2.34764262E9f, 100L, 90.0d, 100, 20L };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        double[] doubleArray12 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection14, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray19 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, orderDirection18, doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0E-6d, (java.lang.Number) 1.0E-6d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException25.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection26, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (2,347,642,624 > 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1173821313 + "'", int13 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 1.3690626E32f, (-1.6010540800553663d), (double) 97.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [136,906,264,824,648,780,000,000,000,000,000, -1.601]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1L, 1.0646819084678927E-155d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (short) 10, 1.6704649792860586d, 6.283185307179586d, (double) (short) 100);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getFLo();
        java.lang.Throwable[] throwableArray7 = noBracketingException4.getSuppressed();
        double double8 = noBracketingException4.getHi();
        double double9 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.283185307179586d + "'", double6 == 6.283185307179586d);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.6704649792860586d + "'", double8 == 1.6704649792860586d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.283185307179586d + "'", double9 == 6.283185307179586d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(21.576677523750607d, (double) (-1022), (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 107, 1.3818774166709604d, 1.3818774166709604d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 1L, (java.lang.Number) 1.5440680443502757d, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) '#', (int) (short) 10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(Double.POSITIVE_INFINITY, 2.91551139278006d, 10.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 102.20142989415943d, (java.lang.Number) (-1L), (int) (byte) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(4.68213122712422d, 2.718281828459045d, (double) 0L, 0.0d, 0.9542425094393249d, 7.391699534059768E31d, (double) 1348863081, 2.347642624E10d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.053473912405848E31d + "'", double8 == 7.053473912405848E31d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2204460492503136E-16d + "'", double1 == 2.2204460492503136E-16d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1348863081, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        double[] doubleArray16 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean21 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection18, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray23 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray16, orderDirection22, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) mathIllegalArgumentException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) doubleArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1173821313 + "'", int17 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1L), (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(3, (-10));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray6 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray6);
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray10 = new int[] { (byte) 100 };
        int[] intArray15 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray15);
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray10);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, 6);
        int[] intArray23 = new int[] { (byte) 100 };
        int[] intArray28 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray30 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        int[] intArray32 = new int[] { (byte) 100 };
        int[] intArray37 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray37);
        int[] intArray39 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray32);
        try {
            double double41 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-423.4963845411932d), (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1022));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1022L + "'", long1 == 1022L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 100, 101L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double[] doubleArray6 = new double[] { 5.916079783099616d, 2.34764262E9f, 100L, 90.0d, 100, 20L };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        double[] doubleArray12 = new double[] { 20L, 1.3440585709080678E43d, 5.916079783099616d };
        double[] doubleArray17 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection19, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray24 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray17, orderDirection23, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        double[] doubleArray31 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false, false);
        double[] doubleArray41 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection43, false, false);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray41);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray41);
        try {
            double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1173821313 + "'", int18 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1173821313 + "'", int32 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1173821313 + "'", int42 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.3440585709080678E43d + "'", double48 == 1.3440585709080678E43d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(10.0d, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, 10]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1173821313);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.signum(5.3752998404656145d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100, 107);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) (-810548224), (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1125899906842624L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(1.543080634815245d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.45691936518475496d) + "'", double2 == (-0.45691936518475496d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 10.0f);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        float float2 = org.apache.commons.math.util.FastMath.max(20.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.220446049250313E-16d, (double) (-35L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.util.MathUtils.checkFinite(7.391699534059768E31d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(32.000004f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 'a', (float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, objArray9);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.2250738585072014E-308d, objArray9);
        java.lang.Throwable[] throwableArray14 = maxCountExceededException13.getSuppressed();
        java.lang.Object[] objArray15 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 102.20142989415943d, (java.lang.Number) (-1L), (int) (byte) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1715.9216470410527d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1022));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 140L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 100L);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((int) '4', univariateRealFunction6, 2.91551139278006d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (byte) 100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 10);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4771212547196624d + "'", double1 == 1.4771212547196624d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.9541180407703d + "'", double1 == 349.9541180407703d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) 100, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) (short) 10, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        long long2 = org.apache.commons.math.util.FastMath.max(2758547353515625L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2758547353515625L + "'", long2 == 2758547353515625L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 2, (float) 1076101120, Float.NaN);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.91551139278006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.707486864599567d + "'", double1 == 1.707486864599567d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1125899906842624L, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43107595064559234d + "'", double1 == 0.43107595064559234d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray7 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 101L, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = localizedFormats1.getLocalizedString(locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 60466176, 3.6895038689889077d, (double) 8170176069297290577L, 0.0d);
        double double5 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.6895038689889077d + "'", double5 == 3.6895038689889077d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray10 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1173821313 + "'", int11 == 1173821313);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double8 = regulaFalsiSolver0.solve(0, univariateRealFunction3, (double) 194.0f, 3.689503868988906d, (double) 52L, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 100L);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((-1), univariateRealFunction6, 44.24016931380205d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002E-6d + "'", double1 == 1.0000000000000002E-6d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) 'a', (-10));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 52L, (double) 194.0f, 9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-10), 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1, n = -10");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1022L, 24.887921886238782d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1022.0d + "'", double2 == 1022.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(9, (int) (short) 1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1022));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.498680848794509d) + "'", double1 == (-1.498680848794509d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 100L);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        double double4 = regulaFalsiSolver2.getMax();
        double double5 = regulaFalsiSolver2.getMin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 1125899906842624L, (double) (-1), 10.0d, 24.887921886238782d);
        java.lang.String str5 = noBracketingException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [1,125,899,906,842,624, -1], values: [10, 24.888]" + "'", str5.equals("org.apache.commons.math.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [1,125,899,906,842,624, -1], values: [10, 24.888]"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 118L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.2250738585072014E-308d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.sinh(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 267.74489404101644d + "'", double1 == 267.74489404101644d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.000004f + "'", float1 == 32.000004f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1348863081, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.6483608274590866d, 3.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (short) 100, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381855d + "'", double1 == 0.5585053606381855d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 2.34764262E9f, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3476426239999995E9d + "'", double2 == 2.3476426239999995E9d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 20L, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.999999999999996d + "'", double2 == 19.999999999999996d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 100);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray16);
        java.lang.Object[] objArray18 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException(localizable0, (java.lang.Number) bigInteger11, objArray18);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (byte) 100);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 6);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.8414709848078965d), (java.lang.Number) bigInteger12, true);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(12.924646916980203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22557764335903877d + "'", double1 == 0.22557764335903877d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-1022), (float) (-10));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 35, (double) 118L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3418333569476515d + "'", double2 == 1.3418333569476515d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 7.391699534059768E31d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 349.9541180407703d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-10));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-572.9577951308232d) + "'", double1 == (-572.9577951308232d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) '4', 1076101120);
        java.lang.Number number5 = dimensionMismatchException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 52 + "'", number5.equals(52));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(5.298342365610589d, (double) 100.00001f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        double[] doubleArray6 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray12 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray12);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray15);
        double[] doubleArray21 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray21);
        double[] doubleArray28 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray34 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray34);
        double[] doubleArray41 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection43, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray48 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray41, orderDirection47, doubleArray48);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray34, doubleArray48);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, doubleArray48);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException52 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.6704649792860586d, (java.lang.Object[]) doubleArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1173821313 + "'", int7 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1173821313 + "'", int13 == 1173821313);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1173821313 + "'", int22 == 1173821313);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1173821313 + "'", int29 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1173821313 + "'", int35 == 1173821313);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1173821313 + "'", int42 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 140L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (-35L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        float[] floatArray5 = new float[] { 1173821313, 'a', Float.POSITIVE_INFINITY, (-1), 0 };
        float[] floatArray10 = new float[] { (byte) 0, 1, (short) 1, 1.0f };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray5, floatArray10);
        float[] floatArray13 = new float[] { 1173821313 };
        float[] floatArray15 = new float[] { (byte) 100 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(floatArray10, floatArray13);
        float[] floatArray23 = new float[] { 1173821313, 'a', Float.POSITIVE_INFINITY, (-1), 0 };
        float[] floatArray28 = new float[] { (byte) 0, 1, (short) 1, 1.0f };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray23, floatArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(floatArray10, floatArray23);
        float[] floatArray32 = new float[] { 30 };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray10, floatArray32);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.2204460492503136E-16d, 360.0d, 9.765625E-4d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 102.20142989415943d, (java.lang.Number) (-1L), (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8745129512124437d + "'", double1 == 0.8745129512124437d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) (short) 100, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = numberIsTooLargeException3.getContext();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) (short) 100, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = numberIsTooLargeException3.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("org.apache.commons.math.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [1,125,899,906,842,624, -1], values: [10, 24.888]");
        java.lang.Object obj8 = exceptionContext4.getValue("hi!");
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.65823634883017d + "'", double1 == 74.65823634883017d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 107);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 107.00001f + "'", float1 == 107.00001f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 90.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.798179868358115d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8934091270846269d + "'", double1 == 0.8934091270846269d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.8934091270846269d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.0466176E7f, Float.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(267.74489404101644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.362912150378868d + "'", double1 == 16.362912150378868d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-35L), 1022L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 90);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.102016471589204E38d + "'", double1 == 6.102016471589204E38d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.3690626E32f, (float) 140L, (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray10 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray10);
        double[] doubleArray17 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection19, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray24 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray17, orderDirection23, doubleArray24);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray24);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 0.0018745918058523658d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1173821313 + "'", int11 == 1173821313);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1173821313 + "'", int18 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1173821313 + "'", int27 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 20L, 9.765625E-4d, (double) 72L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.atan(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 5.3752998404656145d, (java.lang.Number) 1.4E-45f, true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.347642624E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, (-10));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 72L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 72.00001f + "'", float1 == 72.00001f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (short) 10, 0.0d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1.3690626E32f, (-1024.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-423.4963845411932d));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 3, 6.0f, (float) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.45691936518475496d), (double) 3L, 74.65823634883017d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 100L);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getEvaluations();
        double double5 = regulaFalsiSolver2.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double11 = regulaFalsiSolver2.solve((int) '#', univariateRealFunction7, 1.0450582013846992d, 1.3440585709080678E43d, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1076101120, (long) (-1022));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1022L) + "'", long2 == (-1022L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount(0);
        incrementor0.setMaximalCount(35);
        try {
            incrementor0.incrementCount(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (35) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (short) 10, 2.5353012E31f, 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 107.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 108.0d + "'", double1 == 108.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 100, (long) 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5380505600L + "'", long2 == 5380505600L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(0.0d, (double) 7L, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8813735870195429d + "'", double3 == 0.8813735870195429d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 3845.0d, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (byte) 1, (float) 1, 9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 107, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107L + "'", long2 == 107L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.2990780352269423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.30832635076156983d + "'", double1 == 0.30832635076156983d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 'a', (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.00001f);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(4.68213122712422d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [4.682, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 167.04649792860587d);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) tooManyEvaluationsException1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 167.04649792860587d + "'", number2.equals(167.04649792860587d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 8170176069297290577L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray10 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray10);
        double[] doubleArray17 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray23 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        double[] doubleArray33 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean38 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray33, orderDirection39, doubleArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, (java.lang.Object[]) doubleArray40);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray4, orderDirection27, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1173821313 + "'", int11 == 1173821313);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1173821313 + "'", int18 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1173821313 + "'", int24 == 1173821313);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1173821313 + "'", int34 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.2216082919995222E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.831189378647476d + "'", double1 == 27.831189378647476d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.3796077390275217d, (java.lang.Number) 3.8834864931005E-310d, (int) (byte) -1, orderDirection3, true);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException5.getContext();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 3.8834864931005E-310d + "'", number8.equals(3.8834864931005E-310d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double2 = org.apache.commons.math.util.FastMath.max(1.4771212547196624d, 44.24016931380205d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.24016931380205d + "'", double2 == 44.24016931380205d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(100.0f, (-1024.0d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.99999f + "'", float2 == 99.99999f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, 2.34764262E9f, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(1.544068044350276d, 1.3440585709080678E43d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.544068044350276d + "'", double3 == 1.544068044350276d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray6 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray6);
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray10 = new int[] { (byte) 100 };
        int[] intArray15 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray15);
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray10);
        int[] intArray23 = new int[] { (byte) 100, (byte) 100, '4', (-1) };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray23);
        int[] intArray26 = new int[] { (byte) 100 };
        int[] intArray31 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray31);
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray35 = new int[] { (byte) 100 };
        int[] intArray40 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray40);
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray35);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray35);
        int[] intArray44 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray44, 6);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray46);
        int[] intArray49 = new int[] { (byte) 100 };
        int[] intArray54 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray54);
        int[] intArray56 = org.apache.commons.math.util.MathUtils.copyOf(intArray49);
        int[] intArray58 = new int[] { (byte) 100 };
        int[] intArray63 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray63);
        int[] intArray65 = org.apache.commons.math.util.MathUtils.copyOf(intArray58);
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray58);
        int[] intArray67 = org.apache.commons.math.util.MathUtils.copyOf(intArray49);
        int[] intArray69 = org.apache.commons.math.util.MathUtils.copyOf(intArray67, 6);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray69);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double[] doubleArray6 = new double[] { 100, (byte) 0, 3.689503868988906d, 6.0466176E7f, 1.5440680443502757d, 25.0d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 6.046617600008799E7d + "'", double7 == 6.046617600008799E7d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1730938075 + "'", int8 == 1730938075);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 5380505600L, (-1.498680848794509d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.3805056E9d + "'", double2 == 5.3805056E9d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (-86196911));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86196911L + "'", long2 == 86196911L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(100.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 3.8146973E-6f, 1.000000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.814697265625001E-6d + "'", double2 == 3.814697265625001E-6d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4142135623730951d + "'", double1 == 1.4142135623730951d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        float float1 = org.apache.commons.math.util.FastMath.ulp(99.99999f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.707486864599567d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7074868645995671d + "'", double1 == 1.7074868645995671d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 55.0d, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-423.4963845411932d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1);
        java.lang.Throwable[] throwableArray3 = notPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 1348863081);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double3 = org.apache.commons.math.util.MathUtils.round(3.2537765234981815d, 9, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.253776524d + "'", double3 == 3.253776524d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection7, false, false);
        double[] doubleArray15 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray21 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray21);
        double[] doubleArray24 = null;
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray24);
        double[] doubleArray30 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray30);
        double[] doubleArray37 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray43 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray43);
        double[] doubleArray50 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection52, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray57 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray50, orderDirection56, doubleArray57);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray43, doubleArray57);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray21, doubleArray57);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, doubleArray57);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1173821313 + "'", int6 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1173821313 + "'", int16 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1173821313 + "'", int22 == 1173821313);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1173821313 + "'", int31 == 1173821313);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1173821313 + "'", int38 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1173821313 + "'", int44 == 1173821313);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1173821313 + "'", int51 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + orderDirection56 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection56.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1L, (double) 107);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray10 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray10);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (10 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1173821313 + "'", int11 == 1173821313);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 10, 107L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-97L) + "'", long2 == (-97L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.43107595064559234d, 107);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.43107595064559234d + "'", double2 == 0.43107595064559234d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(44.24016931380205d, 5.3805056E9d, 102.0d, 360.0d, 0.705429428472229d, 0.0d, (double) 3L, 10201.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.3803454606086008E11d + "'", double8 == 2.3803454606086008E11d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 118L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.sinh(16.362912150378868d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6386934.452312991d + "'", double1 == 6386934.452312991d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 720L + "'", long1 == 720L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 3.8834864931005E-310d, (double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (short) 10, 1.6704649792860586d, 6.283185307179586d, (double) (short) 100);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getHi();
        double double7 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.6704649792860586d + "'", double6 == 1.6704649792860586d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) '4', 1076101120);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 7L);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 0L, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.cosh(55.850536063819504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.00636675445679E23d + "'", double1 == 9.00636675445679E23d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray6 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray6);
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray10 = new int[] { (byte) 100 };
        int[] intArray15 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray15);
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray10);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, 6);
        int[] intArray23 = new int[] { (byte) 100 };
        int[] intArray28 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray31 = new int[] { (byte) 100 };
        int[] intArray36 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray36);
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray31);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray38);
        int[] intArray41 = new int[] { (byte) 100 };
        int[] intArray46 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray46);
        int[] intArray48 = org.apache.commons.math.util.MathUtils.copyOf(intArray41);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray48);
        int[] intArray51 = new int[] { (byte) 100 };
        int[] intArray56 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray56);
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray51);
        int[] intArray60 = new int[] { (byte) 100 };
        int[] intArray65 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray65);
        int[] intArray67 = org.apache.commons.math.util.MathUtils.copyOf(intArray60);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray60);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray60);
        int[] intArray71 = org.apache.commons.math.util.MathUtils.copyOf(intArray23, (int) (short) 10);
        int[] intArray73 = new int[] { (byte) 100 };
        int[] intArray78 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray73, intArray78);
        int[] intArray80 = org.apache.commons.math.util.MathUtils.copyOf(intArray73);
        int[] intArray82 = new int[] { (byte) 100 };
        int[] intArray87 = new int[] { (short) 100, 1, (byte) 10, 1173821313 };
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray82, intArray87);
        int[] intArray89 = org.apache.commons.math.util.MathUtils.copyOf(intArray82);
        int int90 = org.apache.commons.math.util.MathUtils.distanceInf(intArray73, intArray82);
        int[] intArray95 = new int[] { (byte) 100, (byte) 100, '4', (-1) };
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray82, intArray95);
        int int97 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray95);
        int int98 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-1.6010540800553663d), 0.705429428472229d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 5.916079783099616d, (double) 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.3818774166709604d, (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-35.0d), 3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-17) + "'", int1 == (-17));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-97L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-97.0f) + "'", float2 == (-97.0f));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-10));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -10");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(118.00001f, 0.0f, 6.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(118L, 101L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 3L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double2 = regulaFalsiSolver1.getStartValue();
        double double3 = regulaFalsiSolver1.getStartValue();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        int int5 = regulaFalsiSolver1.getMaxEvaluations();
        double double6 = regulaFalsiSolver1.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        try {
            double double10 = regulaFalsiSolver1.solve((-10), univariateRealFunction8, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) 100, true);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "minimal step size ({0,number,0.00E00}) reached, integration needs {1,number,0.00E00}" + "'", str1.equals("minimal step size ({0,number,0.00E00}) reached, integration needs {1,number,0.00E00}"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 90, 194.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 90.0f + "'", float2 == 90.0f);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 86196911L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) 'a', (int) (short) 0);
        int int4 = dimensionMismatchException3.getDimension();
        int int5 = dimensionMismatchException3.getDimension();
        int int6 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.705429428472229d, 0, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 72L, (float) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 9.536743E-7f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-97.0f));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '4', 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1326L + "'", long2 == 1326L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.0d, 167.04649792860587d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 35, 0);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = dimensionMismatchException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        exceptionContext4.setValue("org.apache.commons.math.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [1,125,899,906,842,624, -1], values: [10, 24.888]", (java.lang.Object) localizedFormats6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        double[] doubleArray6 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray12 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray12);
        double[] doubleArray19 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray25 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray25);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray19);
        double[] doubleArray34 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray40 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray40);
        double[] doubleArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray43);
        double[] doubleArray49 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray49);
        double[] doubleArray56 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double[] doubleArray62 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray62);
        double[] doubleArray69 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean74 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection71, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray76 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray69, orderDirection75, doubleArray76);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray62, doubleArray76);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray76);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException80 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 108L, (java.lang.Object[]) doubleArray76);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray19, doubleArray76);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException82 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) doubleArray76);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException83 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) doubleArray76);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1173821313 + "'", int7 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1173821313 + "'", int13 == 1173821313);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1173821313 + "'", int20 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1173821313 + "'", int26 == 1173821313);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1173821313 + "'", int35 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1173821313 + "'", int41 == 1173821313);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1173821313 + "'", int50 == 1173821313);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1173821313 + "'", int57 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1173821313 + "'", int63 == 1173821313);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1173821313 + "'", int70 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection71.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray76);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(10L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1024.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9873536182198484d + "'", double1 == 0.9873536182198484d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6288497379225589E156d + "'", double1 == 1.6288497379225589E156d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(100.0d, (double) 0.0f, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(5.916079783099616d, 12.924646916980203d, (-4.758040356943821E15d), (double) 2758547353515625L, (double) 720L, 0.9542425094393249d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.3125279634567917E31d) + "'", double6 == (-1.3125279634567917E31d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray11 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 101L, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.FastMath.abs(102.20142989415943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 102.20142989415943d + "'", double1 == 102.20142989415943d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        long long2 = org.apache.commons.math.util.FastMath.min(72L, 1125899906842624L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 72L + "'", long2 == 72L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        int int3 = incrementor0.getCount();
        int int4 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 60466176);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray7 = new java.lang.Object[] { "", (-1), 1 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) mathIllegalArgumentException12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 4.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        float[] floatArray5 = new float[] { 1173821313, 'a', Float.POSITIVE_INFINITY, (-1), 0 };
        float[] floatArray10 = new float[] { (byte) 0, 1, (short) 1, 1.0f };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray5, floatArray10);
        float[] floatArray18 = new float[] { 100.0f, 0L, (byte) -1, (-1L), (short) 100, 1173821313 };
        float[] floatArray20 = new float[] { 1173821313 };
        float[] floatArray22 = new float[] { (byte) 100 };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(floatArray20, floatArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray18, floatArray22);
        float[] floatArray26 = new float[] { 1173821313 };
        float[] floatArray28 = new float[] { (byte) 100 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(floatArray26, floatArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray22, floatArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(floatArray10, floatArray22);
        float[] floatArray37 = new float[] { 1173821313, 'a', Float.POSITIVE_INFINITY, (-1), 0 };
        float[] floatArray42 = new float[] { (byte) 0, 1, (short) 1, 1.0f };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray37, floatArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(floatArray10, floatArray37);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 90, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 90.0f + "'", float2 == 90.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 101L, (float) (-10), (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 108L, 4.68213122712422d);
        double double3 = regulaFalsiSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 0);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = notStrictlyPositiveException2.getContext();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 0, 1.2216082919995222E12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 0);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.35226421010312625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3599892903239888d + "'", double1 == 0.3599892903239888d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-7.930067261567154E14d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-35.0d) + "'", double1 == (-35.0d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 101L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double1 = org.apache.commons.math.util.FastMath.rint(167.04649792860587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 167.0d + "'", double1 == 167.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3028848683749714d + "'", double2 == 0.3028848683749714d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.0E-15d, (-35.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-37.69911184307752d) + "'", double2 == (-37.69911184307752d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 6.0466176E7f, (-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.046617600000001E7d + "'", double2 == 6.046617600000001E7d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) bigInteger1, 107, orderDirection5, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException7.getDirection();
        java.lang.Number number9 = nonMonotonousSequenceException7.getPrevious();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 0, (double) (byte) 1);
        double double3 = regulaFalsiSolver2.getMin();
        double double4 = regulaFalsiSolver2.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver2.solve(6, univariateRealFunction6, (double) 0L, 0.705429428472229d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 8170176069297290577L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 720L, (-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 359.4123994031781d + "'", double2 == 359.4123994031781d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 0, (double) (byte) 1);
        double double3 = regulaFalsiSolver2.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double9 = regulaFalsiSolver2.solve((-1), univariateRealFunction5, (double) 72.00001f, 19.999999999999996d, 9.765625E-4d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 1125899906842624L, (double) (-1), 10.0d, 24.887921886238782d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        noBracketingException4.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.3796077390275217d, (java.lang.Number) 3.8834864931005E-310d, (int) (byte) -1, orderDirection3, true);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-97L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0.3599892903239888d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-17));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(12.924646916980203d, (double) (byte) 1, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592638688632d + "'", double1 == 3.141592638688632d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 100L);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getEvaluations();
        int int5 = regulaFalsiSolver2.getMaxEvaluations();
        double double6 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution12 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double13 = regulaFalsiSolver2.solve(0, univariateRealFunction8, (double) 100L, (-5.1386835854989664E17d), (double) (-10), allowedSolution12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution12 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution12.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1326L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(118L, 140L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-22L) + "'", long2 == (-22L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double[] doubleArray4 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray10 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray10);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray19 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray19);
        double[] doubleArray26 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection28, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray33 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray26, orderDirection32, doubleArray33);
        double[] doubleArray38 = new double[] { 20L, 1.3440585709080678E43d, 5.916079783099616d };
        double[] doubleArray43 = new double[] { (byte) 1, (short) 10, (short) 10, (short) 100 };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean48 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection45, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[][] doubleArray50 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray43, orderDirection49, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray43);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray43);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1173821313 + "'", int5 == 1173821313);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1173821313 + "'", int11 == 1173821313);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1173821313 + "'", int20 == 1173821313);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1173821313 + "'", int27 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1173821313 + "'", int44 == 1173821313);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 198.0d + "'", double54 == 198.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(21.576677523750607d, 0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver2.solve(52, univariateRealFunction4, 1.0000000000000013d, (-309.410778200998d), 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(8, (-810548224));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 35.553480614894134d, 3.689503868988906d, (double) 90);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException(localizable0, (java.lang.Number) (-7.391406280535837d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(16.362912150378868d, (double) 140L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 72.00001f, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math.util.FastMath.sinh(360.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1091326487692777E156d + "'", double1 == 1.1091326487692777E156d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double2 = org.apache.commons.math.util.MathUtils.log(167.0d, 359.4123994031781d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.149761154412715d + "'", double2 == 1.149761154412715d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }
}

