import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(6.15731635293503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4813940341942935d + "'", double1 == 2.4813940341942935d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.cosh(103.99523603307d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.303434819937185E44d + "'", double1 == 7.303434819937185E44d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4056476493802699d + "'", double1 == 1.4056476493802699d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.abs((-4.440892098500626E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long long1 = org.apache.commons.math.util.FastMath.abs(4L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        long long1 = org.apache.commons.math.util.FastMath.abs(49L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 49L + "'", long1 == 49L);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure(7L);
//        double double7 = randomDataImpl1.nextBeta(9.915235972776214d, (double) 52L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.16769434568932873d + "'", double7 == 0.16769434568932873d);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.cos(9.951677163786831d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.864370476345139d) + "'", double1 == (-0.864370476345139d));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 47L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 47 + "'", int1 == 47);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6143234935396069d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010721967634620255d + "'", double1 == 0.010721967634620255d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(10.669031621848436d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 611.2904834235311d + "'", double1 == 611.2904834235311d);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGamma(44.0d, 13.019699760953051d);
//        randomDataImpl1.reSeedSecure(105L);
//        long long13 = randomDataImpl1.nextLong(0L, 33L);
//        try {
//            double double15 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.98777561881591d + "'", double4 == 9.98777561881591d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 718.4627352526896d + "'", double8 == 718.4627352526896d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 6L + "'", long13 == 6L);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Class<?> wildcardClass23 = outOfRangeException22.getClass();
        java.lang.Number number24 = outOfRangeException22.getLo();
        org.apache.commons.math.exception.util.Localizable localizable25 = outOfRangeException22.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable21, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "", objArray25);
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("", objArray30);
        maxIterationsExceededException28.addSuppressed((java.lang.Throwable) convergenceException31);
        java.lang.Object[] objArray33 = maxIterationsExceededException28.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException28.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(localizable34);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        double double5 = randomDataImpl0.nextBeta(9.925100554614186d, 0.5754992848055241d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl0.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 47L + "'", long2 == 47L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8693367537448555d + "'", double5 == 0.8693367537448555d);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9930351740989346d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7586535573063318d + "'", double1 == 0.7586535573063318d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.atan(9.906571838448365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.470194006551064d + "'", double1 == 1.470194006551064d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0213144232784423E-8d, 31.72451022810671d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.219322901866572E-10d + "'", double2 == 3.219322901866572E-10d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("hi!", objArray3);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number13 = outOfRangeException12.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number18 = numberIsTooSmallException17.getMin();
        java.lang.Number number19 = numberIsTooSmallException17.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("hi!", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("hi!", objArray35);
        java.lang.Object[] objArray38 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException24, localizable31, objArray38);
        java.lang.Object[] objArray43 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable31, objArray43);
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException17, localizable31, objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray53 = numberIsTooLargeException52.getSuppressed();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException12, localizable31, (java.lang.Object[]) throwableArray53);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, "", (java.lang.Object[]) throwableArray53);
        java.lang.String str56 = mathException55.toString();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1 + "'", number13.equals(1));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) 0 + "'", number18.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (byte) 0 + "'", number19.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.apache.commons.math.MathException: " + "'", str56.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        double double6 = randomDataImpl0.nextCauchy((double) 10, (double) 5);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl0.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0657735885088044d + "'", double3 == 1.0657735885088044d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.137484598469925d + "'", double6 == 8.137484598469925d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math.util.FastMath.min(9.874944390863288d, 9.891165073496994d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.874944390863288d + "'", double2 == 9.874944390863288d);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        long long5 = randomDataImpl1.nextSecureLong(2L, (long) '#');
//        double double7 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        int int10 = randomDataImpl1.nextBinomial(7, 0.6483608274590866d);
//        try {
//            int int13 = randomDataImpl1.nextPascal(44, 10.015952019922548d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10.016 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 13L + "'", long5 == 13L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.10074254454361127d + "'", double7 == 0.10074254454361127d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) (short) 100, (java.lang.Number) 100.0f, true);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException50);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGamma(44.0d, 13.019699760953051d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString(4);
//        try {
//            double double13 = randomDataImpl1.nextUniform(100.0d, 6.523017628717626d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (6.523): lower bound (100) must be strictly less than upper bound (6.523)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.042384922624674d + "'", double4 == 10.042384922624674d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 329.39699353476385d + "'", double8 == 329.39699353476385d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6298" + "'", str10.equals("6298"));
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 5, 2.302585092994046d, 10.0d);
        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 10);
        normalDistributionImpl3.reseedRandomGenerator((long) '4');
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 56L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.483314773547883d + "'", double1 == 7.483314773547883d);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.0d), (double) 1L, (-1.0d));
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.4300855241517956d + "'", double4 == 0.4300855241517956d);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable11, objArray18);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable11, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable35, objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable42, objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("hi!", objArray43);
        java.lang.Object[] objArray46 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException32, localizable39, objArray46);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable39, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable26, objArray51);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException56);
        mathIllegalArgumentException55.addSuppressed((java.lang.Throwable) convergenceException57);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException57);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.930874936879059d, Double.POSITIVE_INFINITY, 0.6483608274590866d);
        double double5 = normalDistributionImpl3.cumulativeProbability(88.53074452756374d);
        double double7 = normalDistributionImpl3.cumulativeProbability((-0.7266275237111985d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        double double6 = randomDataImpl0.nextCauchy((double) 10, (double) 5);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        try {
//            double double10 = randomDataImpl0.nextWeibull(0.6060928282773596d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.285930565716563d + "'", double3 == 2.285930565716563d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.647333473822728d + "'", double6 == 6.647333473822728d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.atan(14.778425287217077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5032331107358354d + "'", double1 == 1.5032331107358354d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0.0f, (double) 10);
        double[] doubleArray4 = normalDistributionImpl2.sample((int) (short) 100);
        double double6 = normalDistributionImpl2.density((double) 4L);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.03682701403033233d + "'", double6 == 0.03682701403033233d);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.getStandardDeviation();
//        double double6 = normalDistributionImpl3.sample();
//        double double8 = normalDistributionImpl3.inverseCumulativeProbability(0.6060572774393056d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 11.769364224633007d + "'", double4 == 11.769364224633007d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.718281828459045d + "'", double5 == 2.718281828459045d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.021415081967401d + "'", double6 == 12.021415081967401d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.731374076881645d + "'", double8 == 10.731374076881645d);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        randomDataImpl0.reSeed();
//        long long5 = randomDataImpl0.nextPoisson(1.1914250602725112d);
//        int int8 = randomDataImpl0.nextZipf(44, (double) ' ');
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 46L + "'", long2 == 46L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.588815668294669d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        double double6 = randomDataImpl0.nextGaussian((double) 10.0f, (double) 89.0f);
//        int int9 = randomDataImpl0.nextZipf((int) (byte) 1, 3.5403322559833335d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.930874936879059d, Double.POSITIVE_INFINITY, 0.6483608274590866d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.296658758684874d + "'", double3 == 2.296658758684874d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-41.31262915366854d) + "'", double6 == (-41.31262915366854d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.930874936879059d + "'", double14 == 0.930874936879059d);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure(50L);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.040845294960537d + "'", double4 == 10.040845294960537d);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 62L, (float) 7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.6935133704001326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.438554835847282d + "'", double1 == 5.438554835847282d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.8252965301121045d, 1.4056476493802699d, 1.5118463698653086d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray3);
        java.lang.Object[] objArray5 = maxIterationsExceededException4.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        long long5 = randomDataImpl1.nextSecureLong(2L, (long) '#');
//        double double7 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        int int10 = randomDataImpl1.nextBinomial(7, 0.6483608274590866d);
//        double double12 = randomDataImpl1.nextExponential((double) 89.0f);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.28405687568054316d + "'", double7 == 0.28405687568054316d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 367.79272319474615d + "'", double12 == 367.79272319474615d);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, localizable54, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("hi!", objArray55);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException57.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable61, objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("hi!", objArray62);
        java.lang.Object[] objArray65 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException51, localizable58, objArray65);
        java.lang.Object[] objArray70 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable58, objArray70);
        org.apache.commons.math.exception.util.Localizable localizable73 = maxIterationsExceededException72.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = maxIterationsExceededException72.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, localizable77, objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("hi!", objArray78);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable74, objArray78);
        org.apache.commons.math.exception.util.Localizable localizable82 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable82, (java.lang.Number) 32.49723192432058d, (java.lang.Number) 8.578046339417144d, false);
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException86);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNull(localizable73);
        org.junit.Assert.assertNotNull(localizable74);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.getStandardDeviation();
//        double double6 = normalDistributionImpl3.getMean();
//        normalDistributionImpl3.reseedRandomGenerator(12L);
//        double double10 = normalDistributionImpl3.cumulativeProbability(0.4174421516698077d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 11.456682182014305d + "'", double4 == 11.456682182014305d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.718281828459045d + "'", double5 == 2.718281828459045d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.1156080071949024E-4d + "'", double10 == 2.1156080071949024E-4d);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, localizable54, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("hi!", objArray55);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException57.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable61, objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("hi!", objArray62);
        java.lang.Object[] objArray65 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException51, localizable58, objArray65);
        java.lang.Object[] objArray70 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable58, objArray70);
        org.apache.commons.math.exception.util.Localizable localizable73 = maxIterationsExceededException72.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = maxIterationsExceededException72.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, localizable77, objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("hi!", objArray78);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable74, objArray78);
        org.apache.commons.math.exception.util.Localizable localizable82 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable82, (java.lang.Number) 32.49723192432058d, (java.lang.Number) 8.578046339417144d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException90 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable82, (java.lang.Number) 0.010721967634620255d, (java.lang.Number) 9.946054089648355d, false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNull(localizable73);
        org.junit.Assert.assertNotNull(localizable74);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6133776958784604d, 4.9E-324d);
        normalDistributionImpl2.reseedRandomGenerator(62L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.6004871325643916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 50.670473550949964d, (java.lang.Number) 1.7467135528742547E19d, (java.lang.Number) 0.6104267705666283d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.6104267705666283d + "'", number4.equals(0.6104267705666283d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 105L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105.0d + "'", double1 == 105.0d);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGamma(44.0d, 13.019699760953051d);
//        randomDataImpl1.reSeedSecure(105L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("ab285dc08b", "org.apache.commons.math.MaxIterationsExceededException: ");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MaxIterationsExceededException: ");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.037935029911608d + "'", double4 == 10.037935029911608d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 634.1246338910217d + "'", double8 == 634.1246338910217d);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 54L);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.acos(31.8147365078235d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 47L, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.6052975674015244d, (java.lang.Number) 1.0842021724855044E-19d, true);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        randomDataImpl0.reSeedSecure();
//        int int7 = randomDataImpl0.nextZipf(2, 38.9674278934767d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.6144978306828235d + "'", double3 == 2.6144978306828235d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.7615941559557649d, (double) 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.10837289398634067d + "'", double2 == 0.10837289398634067d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.floor(644.1650679589596d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 644.0d + "'", double1 == 644.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 47);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12452756813273719d) + "'", double1 == (-0.12452756813273719d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        float float2 = org.apache.commons.math.util.FastMath.min(89.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-5.128235259690005d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.3372821588006802d) + "'", double1 == (-2.3372821588006802d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.special.Erf.erf(1.6317992286964826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9789848732098868d + "'", double1 == 0.9789848732098868d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.0003900267283883d, (java.lang.Number) 12476.0d, (java.lang.Number) 56.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 45L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.floor(11.117017115913347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) 49L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1.0f), (double) 6);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0f + "'", number6.equals(1.0f));
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        double double13 = randomDataImpl1.nextBeta((double) 10L, 0.609408042920473d);
//        int int16 = randomDataImpl1.nextSecureInt((int) (byte) 10, 34);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.01935560659281d + "'", double4 == 10.01935560659281d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6140726837114169d + "'", double7 == 0.6140726837114169d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9903198146817117d + "'", double13 == 0.9903198146817117d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 17 + "'", int16 == 17);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        double double6 = randomDataImpl0.nextCauchy((double) 10, (double) 5);
//        double double8 = randomDataImpl0.nextT(10.172028608154612d);
//        double double11 = randomDataImpl0.nextGaussian(33.55452857985193d, (double) 56L);
//        int int14 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.922833191421013d + "'", double3 == 2.922833191421013d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 18.307562070961733d + "'", double6 == 18.307562070961733d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.7322713496110318d + "'", double8 == 1.7322713496110318d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 36.23236667962482d + "'", double11 == 36.23236667962482d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.6483608274590866d, (double) 56L, 1.0842021724855044E-19d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.312710663001983E-26d + "'", double4 == 8.312710663001983E-26d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) (short) 100, (java.lang.Number) 100.0f, true);
        java.lang.Number number52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 0.6104267705666283d, number52, true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 54L);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 1.0213144232784423E-8d);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.930874936879059d, Double.POSITIVE_INFINITY, 0.6483608274590866d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 1);
        double[] doubleArray7 = normalDistributionImpl3.sample(6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGamma(44.0d, 13.019699760953051d);
//        randomDataImpl1.reSeedSecure(105L);
//        randomDataImpl1.reSeed();
//        double double14 = randomDataImpl1.nextBeta(0.6077970268926886d, 0.6077970268926886d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.002775080969027d + "'", double4 == 10.002775080969027d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 524.7774349550805d + "'", double8 == 524.7774349550805d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.685658411213344d + "'", double14 == 0.685658411213344d);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.0d, (double) 56.0f, (int) (short) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure(50L);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl1.getClass();
//        double double10 = randomDataImpl1.nextF(14.778425287217077d, 0.5d);
//        int int13 = randomDataImpl1.nextInt(0, (int) (byte) 1);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.001727494505435d + "'", double4 == 10.001727494505435d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 12.371979047656062d + "'", double10 == 12.371979047656062d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int2 = org.apache.commons.math.util.FastMath.max(47, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47 + "'", int2 == 47);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.floor(9.944681656281887d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        double double13 = randomDataImpl1.nextBeta((double) 10L, 0.609408042920473d);
//        double double16 = randomDataImpl1.nextBeta((double) 97L, 1.6649055706799991d);
//        try {
//            double double18 = randomDataImpl1.nextChiSquare((-57.29577951308232d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -28.648 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.000948095059663d + "'", double4 == 10.000948095059663d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5846192800780907d + "'", double7 == 0.5846192800780907d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9628071250974957d + "'", double13 == 0.9628071250974957d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9927921101822255d + "'", double16 == 0.9927921101822255d);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 9.978593096205453d, true);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 9.978593096205453d + "'", number5.equals(9.978593096205453d));
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        long long7 = randomDataImpl0.nextPoisson(1.1712659507785417d);
//        long long9 = randomDataImpl0.nextPoisson((double) 100.0f);
//        double double12 = randomDataImpl0.nextWeibull(12.482146690578855d, 12476.200989019926d);
//        randomDataImpl0.reSeedSecure(7L);
//        try {
//            int int17 = randomDataImpl0.nextBinomial(0, 7.486140176170906d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 7.486 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51L + "'", long2 == 51L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 96L + "'", long9 == 96L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11628.130722109288d + "'", double12 == 11628.130722109288d);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0.0f, (double) 10);
        double double4 = normalDistributionImpl2.cumulativeProbability((double) 103L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.rint(9.965310062286884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5754992848055241d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.758616691620692d + "'", double1 == 0.758616691620692d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray9);
        java.lang.Class<?> wildcardClass11 = convergenceException10.getClass();
        java.lang.Object[] objArray12 = convergenceException10.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "9d14d5de30aff8768f38ad5cbafc0d7093d", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "7aa3", objArray12);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(objArray12);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        double double5 = randomDataImpl0.nextBeta(9.925100554614186d, 0.5754992848055241d);
//        long long8 = randomDataImpl0.nextSecureLong(0L, 61L);
//        randomDataImpl0.reSeed();
//        try {
//            int int12 = randomDataImpl0.nextPascal(47, 49.98984243963481d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 49.99 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9199424963243708d + "'", double5 == 0.9199424963243708d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 37L + "'", long8 == 37L);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 37L, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 37.0f + "'", float2 == 37.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 17, 57L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 57L + "'", long2 == 57L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.special.Gamma.digamma(10.669031621848436d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3197492352202556d + "'", double1 == 2.3197492352202556d);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure(50L);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl1.getClass();
//        try {
//            double double10 = randomDataImpl1.nextWeibull(0.0d, 0.758616691620692d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.012089509935802d + "'", double4 == 10.012089509935802d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(449.63942240330573d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 449.6394224033058d + "'", double1 == 449.6394224033058d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6060572774393056d, 0.6145031101040538d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7784786385992329d + "'", double2 == 0.7784786385992329d);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Object[] objArray14 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
//        java.lang.Number number20 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator23);
//        double double27 = randomDataImpl24.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double30 = randomDataImpl24.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double33 = randomDataImpl24.nextGaussian((double) ' ', 2.302585092994046d);
//        randomDataImpl24.reSeedSecure((long) 1);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { randomDataImpl24, ' ' };
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable10, objArray37);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 52L);
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.011205649187485d + "'", double27 == 10.011205649187485d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.6130033444122d + "'", double30 == 0.6130033444122d);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 28.80998837059415d + "'", double33 == 28.80998837059415d);
//        org.junit.Assert.assertNotNull(objArray37);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.log1p(8.312710663001983E-26d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.312710663001983E-26d + "'", double1 == 8.312710663001983E-26d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long1 = org.apache.commons.math.util.FastMath.round(9.951677163786831d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.8496550830689211d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(5);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray19);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 1.0E-9d, number22, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number25, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException28.getSpecificPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number34 = numberIsTooSmallException33.getMin();
        java.lang.Number number35 = numberIsTooSmallException33.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, localizable50, objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray51);
        java.lang.Object[] objArray54 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException40, localizable47, objArray54);
        java.lang.Object[] objArray59 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable47, objArray59);
        java.lang.Object[] objArray62 = null;
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException33, localizable47, objArray62);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, localizable70, objArray71);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("hi!", objArray71);
        org.apache.commons.math.exception.util.Localizable localizable74 = mathException73.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, localizable77, objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("hi!", objArray78);
        java.lang.Object[] objArray81 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException67, localizable74, objArray81);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, objArray81);
        java.lang.Class<?> wildcardClass84 = objArray81.getClass();
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, localizable29, objArray81);
        org.apache.commons.math.exception.util.Localizable localizable86 = mathException85.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (byte) 0 + "'", number34.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (byte) 0 + "'", number35.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(localizable74);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNull(localizable86);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        java.lang.String str12 = randomDataImpl1.nextHexString(10);
//        double double14 = randomDataImpl1.nextChiSquare(14.778425287217077d);
//        int int17 = randomDataImpl1.nextPascal(35, 0.01801558118013052d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.101054447685279d + "'", double4 == 10.101054447685279d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6056222690238551d + "'", double7 == 0.6056222690238551d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "e5308d087d" + "'", str12.equals("e5308d087d"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 12.525572103854852d + "'", double14 == 12.525572103854852d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1866 + "'", int17 == 1866);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt(5, (int) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        long long9 = randomDataImpl0.nextSecureLong(50L, 100L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 77L + "'", long9 == 77L);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable11, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable11, objArray17);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number25 = numberIsTooSmallException24.getMin();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable40, objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable44 = mathException43.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable44, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("hi!", objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException36, localizable44, objArray50);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException24, localizable32, objArray50);
        boolean boolean55 = numberIsTooSmallException24.getBoundIsAllowed();
        mathException20.addSuppressed((java.lang.Throwable) numberIsTooSmallException24);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, localizable65, objArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("hi!", objArray66);
        org.apache.commons.math.exception.util.Localizable localizable69 = mathException68.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable71, localizable72, objArray73);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException("hi!", objArray73);
        java.lang.Object[] objArray76 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException62, localizable69, objArray76);
        java.lang.Object[] objArray81 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray81);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable69, objArray81);
        org.apache.commons.math.exception.util.Localizable localizable84 = maxIterationsExceededException83.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable85 = maxIterationsExceededException83.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable89 = null;
        org.apache.commons.math.exception.util.Localizable localizable90 = null;
        java.lang.Object[] objArray91 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable89, localizable90, objArray91);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException("hi!", objArray91);
        org.apache.commons.math.exception.util.Localizable localizable94 = mathException93.getGeneralPattern();
        java.lang.Object[] objArray95 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable94, objArray95);
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException83, "", objArray95);
        org.apache.commons.math.MathException mathException98 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException20, localizable57, objArray95);
        org.apache.commons.math.exception.util.Localizable localizable99 = mathException20.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (byte) 0 + "'", number25.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(localizable69);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNull(localizable84);
        org.junit.Assert.assertNotNull(localizable85);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertNotNull(localizable94);
        org.junit.Assert.assertNotNull(objArray95);
        org.junit.Assert.assertNull(localizable99);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Class<?> wildcardClass23 = outOfRangeException22.getClass();
        java.lang.Number number24 = outOfRangeException22.getLo();
        java.lang.Number number25 = outOfRangeException22.getHi();
        java.lang.Number number26 = outOfRangeException22.getLo();
        java.lang.Class<?> wildcardClass27 = outOfRangeException22.getClass();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 10.124725369816879d + "'", number25.equals(10.124725369816879d));
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        double double6 = randomDataImpl0.nextCauchy((double) 10, (double) 5);
//        double double8 = randomDataImpl0.nextT(10.172028608154612d);
//        double double11 = randomDataImpl0.nextGaussian(33.55452857985193d, (double) 56L);
//        try {
//            int int14 = randomDataImpl0.nextInt(5, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than, or equal to, the maximum (1): lower bound (5) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1585334999727871d + "'", double3 == 0.1585334999727871d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.480083382856867d + "'", double6 == 10.480083382856867d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.2475890305704644d) + "'", double8 == (-1.2475890305704644d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.667967739447565d + "'", double11 == 5.667967739447565d);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.9930351740989346d, 103.99523603307d, 7.483314773547883d, 7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        randomDataImpl0.reSeed((long) (-1));
//        double double7 = randomDataImpl0.nextCauchy(0.018017530612444158d, (double) 56L);
//        double double10 = randomDataImpl0.nextUniform(0.0d, 1.6898464671044491E-4d);
//        try {
//            int int13 = randomDataImpl0.nextSecureInt(44, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 44 is larger than, or equal to, the maximum (32): lower bound (44) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 47L + "'", long2 == 47L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.68420393244495d) + "'", double7 == (-49.68420393244495d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0734385601034926E-6d + "'", double10 == 2.0734385601034926E-6d);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextInt((int) 'a', 44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (44): lower bound (97) must be strictly less than upper bound (44)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.8633047912461438d, 1.6649055706799991d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable23, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException15, localizable23, objArray29);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable11, objArray29);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray42);
        org.apache.commons.math.exception.util.Localizable localizable45 = mathException44.getGeneralPattern();
        java.lang.Object[] objArray46 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable45, objArray46);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, localizable50, objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray51);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException37, localizable45, objArray51);
        java.lang.Throwable throwable56 = null;
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl61 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
        double[] doubleArray63 = normalDistributionImpl61.sample(10);
        java.lang.Object[] objArray65 = new java.lang.Object[] { normalDistributionImpl61, 10.0d };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(throwable56, "hi!", objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray65);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable45, objArray65);
        org.apache.commons.math.exception.util.Localizable localizable69 = mathException68.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNull(localizable69);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.5954049265143959d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable11, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable20, objArray24);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("", objArray24);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray24);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.getStandardDeviation();
//        double double6 = normalDistributionImpl3.getMean();
//        double double7 = normalDistributionImpl3.getMean();
//        double double9 = normalDistributionImpl3.density(32.22885768115818d);
//        double double12 = normalDistributionImpl3.cumulativeProbability((-4.9E-324d), 8.520185096803155d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.213703467366687d + "'", double4 == 7.213703467366687d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.718281828459045d + "'", double5 == 2.718281828459045d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.4209068369658063E-16d + "'", double9 == 4.4209068369658063E-16d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2929681963563674d + "'", double12 == 0.2929681963563674d);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
//        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Object[] objArray14 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
//        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        java.lang.Object[] objArray26 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray26);
//        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        java.lang.Object[] objArray33 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, objArray33);
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { "hi!" };
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException22, localizable29, objArray36);
//        java.lang.Number number39 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 1.0E-9d, number39, (java.lang.Number) 10.124725369816879d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator42 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator42);
//        double double46 = randomDataImpl43.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double49 = randomDataImpl43.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double52 = randomDataImpl43.nextGaussian((double) ' ', 2.302585092994046d);
//        randomDataImpl43.reSeedSecure((long) 1);
//        java.lang.Object[] objArray56 = new java.lang.Object[] { randomDataImpl43, ' ' };
//        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable29, objArray56);
//        java.lang.Object[] objArray58 = null;
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable29, objArray58);
//        java.lang.Object[] objArray60 = convergenceException59.getArguments();
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(localizable10);
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(localizable29);
//        org.junit.Assert.assertNotNull(objArray33);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 9.809206058042738d + "'", double46 == 9.809206058042738d);
//        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.6126386164434181d + "'", double49 == 0.6126386164434181d);
//        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 32.877531960758894d + "'", double52 == 32.877531960758894d);
//        org.junit.Assert.assertNotNull(objArray56);
//        org.junit.Assert.assertNotNull(objArray60);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        randomDataImpl0.reSeed((long) (-1));
//        double double7 = randomDataImpl0.nextCauchy(0.018017530612444158d, (double) 56L);
//        java.lang.String str9 = randomDataImpl0.nextSecureHexString(17);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl0.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59L + "'", long2 == 59L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-49.68420393244495d) + "'", double7 == (-49.68420393244495d));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9a79556469868bdfe" + "'", str9.equals("9a79556469868bdfe"));
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double7 = randomDataImpl1.nextT(0.6483608274590866d);
//        long long10 = randomDataImpl1.nextSecureLong(3L, 50L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.741590063987363d + "'", double4 == 9.741590063987363d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.6278482410542565d) + "'", double7 == (-1.6278482410542565d));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 19L + "'", long10 == 19L);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.1776722445204377d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 105L, (java.lang.Number) 359.1342053695754d, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextF((double) 46L, 1.7481880270062005d);
//        double double9 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double12 = randomDataImpl1.nextBeta((double) 6, (double) (short) 100);
//        try {
//            int int16 = randomDataImpl1.nextHypergeometric((int) (byte) -1, (int) (short) -1, 5);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.763190997708573d + "'", double4 == 9.763190997708573d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.9105140406501784d + "'", double7 == 2.9105140406501784d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.2515042162935006d + "'", double9 == 1.2515042162935006d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.07931296681125867d + "'", double12 == 0.07931296681125867d);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable11, objArray18);
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.0E-9d, number21, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, number24, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException27.getSpecificPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable28, (java.lang.Number) 9.906571838448365d, (java.lang.Number) 4.096082362535825d, (java.lang.Number) 12L);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable40, objArray41);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("hi!", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable53 = mathException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable56, objArray57);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("hi!", objArray57);
        java.lang.Object[] objArray60 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException46, localizable53, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable28, objArray60);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, 2.718281828459045d, (double) (short) -1);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 100);
        double double7 = normalDistributionImpl3.cumulativeProbability(0.03682701403033233d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.2355022803334226E-4d + "'", double7 == 1.2355022803334226E-4d);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGamma(44.0d, 13.019699760953051d);
//        randomDataImpl1.reSeedSecure(105L);
//        double double12 = randomDataImpl1.nextExponential(22025.465794806718d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.078574917307204d + "'", double4 == 10.078574917307204d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 541.1534431930372d + "'", double8 == 541.1534431930372d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 25915.825835026622d + "'", double12 == 25915.825835026622d);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        java.lang.String str7 = randomDataImpl0.nextHexString((int) (short) 10);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextWeibull((double) 33L, 2.718281828459045d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 61L + "'", long2 == 61L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "cc2cc17c0e" + "'", str7.equals("cc2cc17c0e"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.782151614228722d + "'", double11 == 2.782151614228722d);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        long long1 = org.apache.commons.math.util.FastMath.round(2.1936431338076545E-8d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure();
//        long long8 = randomDataImpl0.nextPoisson((double) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0.0f, (double) 10);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 46L + "'", long2 == 46L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.6518662204117425d) + "'", double12 == (-1.6518662204117425d));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        long long2 = org.apache.commons.math.util.FastMath.max(55L, 94L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable7, objArray8);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.930874936879059d, (java.lang.Number) 0.01801558118013052d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable21, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException18, localizable25, objArray32);
        java.lang.Object[] objArray37 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException39.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = maxIterationsExceededException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("hi!", objArray47);
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getGeneralPattern();
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable50, objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException39, "", objArray51);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable7, objArray51);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNull(localizable40);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 7L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6457513110645907d + "'", double1 == 2.6457513110645907d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        long long7 = randomDataImpl0.nextPoisson(1.1712659507785417d);
//        double double10 = randomDataImpl0.nextUniform((double) (-1), 10.669031621848436d);
//        try {
//            double double13 = randomDataImpl0.nextGamma((-17.095892353902908d), (-0.4458178502007277d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -17.096 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43L + "'", long2 == 43L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4L + "'", long7 == 4L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0361979233246559d + "'", double10 == 1.0361979233246559d);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6130033444122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010698926685729674d + "'", double1 == 0.010698926685729674d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.atanh(13.5147944917561d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        long long1 = org.apache.commons.math.util.FastMath.abs(54L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 54L + "'", long1 == 54L);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGamma(44.0d, 13.019699760953051d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString(4);
//        randomDataImpl1.reSeed(100L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.ConvergenceException: hi!", "937e8eb1ed731009f690186a0624c61f13");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 937e8eb1ed731009f690186a0624c61f13");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.629608041799179d + "'", double4 == 9.629608041799179d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 430.3474493089252d + "'", double8 == 430.3474493089252d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c7e9" + "'", str10.equals("c7e9"));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5484194618947535d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6161181258700372d + "'", double1 == 0.6161181258700372d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, number23, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getSpecificPattern();
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) 9.946054089648355d, number29, false);
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable27, objArray32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 9.965310062286884d, (java.lang.Number) 2.0d, false);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '#');
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5370829735576599d, 20489.396604684087d);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        java.lang.String str7 = randomDataImpl0.nextHexString((int) (short) 10);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextBeta(0.018017530612444158d, 0.9999999999999996d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "6f2f671be2" + "'", str7.equals("6f2f671be2"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08736323281102461d + "'", double11 == 0.08736323281102461d);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, number23, (java.lang.Number) 2.718281828459045d, true);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, number27, (java.lang.Number) 0.5d, true);
        java.lang.Class<?> wildcardClass31 = numberIsTooLargeException30.getClass();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double10 = randomDataImpl1.nextGaussian((double) ' ', 2.302585092994046d);
//        randomDataImpl1.reSeedSecure((long) 1);
//        double double15 = randomDataImpl1.nextUniform(0.9999999999999996d, (double) 4);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.116603250494308d + "'", double4 == 10.116603250494308d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5954585449732175d + "'", double7 == 0.5954585449732175d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 34.67531448394862d + "'", double10 == 34.67531448394862d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0796093957089477d + "'", double15 == 1.0796093957089477d);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.47256291379017856d, 0.9973256296165959d);
//        double double3 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8987213252900811d + "'", double3 == 0.8987213252900811d);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray19);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 1.0E-9d, number22, (java.lang.Number) 10.124725369816879d);
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number25, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException28.getSpecificPattern();
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) 9.946054089648355d, number31, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) 100.0f, (java.lang.Number) 0.0414241752022797d, true);
        java.lang.Throwable[] throwableArray38 = numberIsTooSmallException37.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "", (java.lang.Object[]) throwableArray38);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(throwableArray38);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable23, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException15, localizable23, objArray29);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable11, objArray29);
        boolean boolean34 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean35 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Object[] objArray36 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(objArray36);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 1, (double) 1.0f);
//        double double6 = randomDataImpl0.nextCauchy(100.0d, 5.181751987126265d);
//        double double9 = randomDataImpl0.nextF(11.769364224633007d, 7.483314773547883d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.22231203742305072d + "'", double3 == 0.22231203742305072d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 96.98038345729455d + "'", double6 == 96.98038345729455d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.320956457099858d + "'", double9 == 1.320956457099858d);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt((int) (byte) 0, (int) (byte) 10);
//        try {
//            int int8 = randomDataImpl0.nextZipf((int) (short) -1, (double) 17);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 46L + "'", long2 == 46L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3, (java.lang.Number) (-6.494941051394773d), false);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextF((double) 46L, 1.7481880270062005d);
//        double double9 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double12 = randomDataImpl1.nextBeta((double) 6, (double) (short) 100);
//        try {
//            int int15 = randomDataImpl1.nextBinomial((int) ' ', (-4.440892098500626E-16d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.09252044412564d + "'", double4 == 10.09252044412564d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.721166583297048d + "'", double7 == 1.721166583297048d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2983967354153118d + "'", double9 == 0.2983967354153118d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0723838107296676d + "'", double12 == 0.0723838107296676d);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable19, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        java.lang.Object[] objArray27 = convergenceException25.getArguments();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.521967400326553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray27);
        java.lang.Object[] objArray30 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16, localizable23, objArray30);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable23, objArray35);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException9, localizable23, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) (byte) 1, (java.lang.Number) 10L, true);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable23, (java.lang.Object[]) throwableArray45);
        java.lang.Number number47 = outOfRangeException4.getLo();
        java.lang.Number number48 = outOfRangeException4.getLo();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 1.0d + "'", number47.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 1.0d + "'", number48.equals(1.0d));
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int[] intArray5 = randomDataImpl0.nextPermutation(1, (int) (short) 1);
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(34);
//        double double10 = randomDataImpl0.nextGaussian(0.607603175551665d, 52.02805828290602d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "e1cd6a592cf8ad33ba2c023605e2cd37af" + "'", str7.equals("e1cd6a592cf8ad33ba2c023605e2cd37af"));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-56.829087388072196d) + "'", double10 == (-56.829087388072196d));
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3, (java.lang.Number) (-0.764876066248559d), false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.asinh(9.85885477206232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9840794217646445d + "'", double1 == 2.9840794217646445d);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double7 = randomDataImpl1.nextT(0.6483608274590866d);
//        long long10 = randomDataImpl1.nextSecureLong((long) 2, (long) (short) 100);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.86831997501556d + "'", double4 == 9.86831997501556d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.21010353563605536d) + "'", double7 == (-0.21010353563605536d));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 17L + "'", long10 == 17L);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.60455101031527d, 5.829280371880436E-4d, 9.978593096205453d, 44);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.012389137722658579d + "'", double4 == 0.012389137722658579d);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        long long5 = randomDataImpl1.nextSecureLong(2L, (long) '#');
//        double double7 = randomDataImpl1.nextChiSquare((double) 100L);
//        double double9 = randomDataImpl1.nextT(0.4300855241517956d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 23L + "'", long5 == 23L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 89.47832555167491d + "'", double7 == 89.47832555167491d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.0859183276250213d) + "'", double9 == (-2.0859183276250213d));
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.010721967634620255d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01072217306975523d + "'", double1 == 0.01072217306975523d);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextGamma(44.0d, 13.019699760953051d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString(4);
//        try {
//            double double13 = randomDataImpl1.nextBeta(2.3646530938701806d, (-0.16239025956232522d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.659");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.87844298580786d + "'", double4 == 9.87844298580786d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 549.3223914828608d + "'", double8 == 549.3223914828608d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a530" + "'", str10.equals("a530"));
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double7 = randomDataImpl1.nextWeibull((double) 'a', 0.6098494453571889d);
//        int int10 = randomDataImpl1.nextSecureInt((-1), 0);
//        long long12 = randomDataImpl1.nextPoisson(10.124725369816879d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("10247a8637", "b00a");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: b00a");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.876205925831497d + "'", double4 == 9.876205925831497d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6116454190184732d + "'", double7 == 0.6116454190184732d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 6L + "'", long12 == 6L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable7, objArray8);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.930874936879059d, (java.lang.Number) 0.01801558118013052d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable21, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException18, localizable25, objArray32);
        java.lang.Object[] objArray37 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException46.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable47, objArray48);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable56, objArray57);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("hi!", objArray57);
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException59.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable63, objArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("hi!", objArray64);
        java.lang.Object[] objArray67 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException53, localizable60, objArray67);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException53, localizable69, objArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable47, objArray73);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable7, objArray73);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray73);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) '4');
//        int int5 = randomDataImpl0.nextInt(5, (int) (short) 10);
//        double double8 = randomDataImpl0.nextWeibull(1.1554843637161998d, 0.03682701403033233d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 63L + "'", long2 == 63L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0325186250519384d + "'", double8 == 0.0325186250519384d);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 1.0E-9d, number20, (java.lang.Number) 10.124725369816879d);
        java.lang.Class<?> wildcardClass23 = outOfRangeException22.getClass();
        java.lang.Number number24 = outOfRangeException22.getHi();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 10.124725369816879d + "'", number24.equals(10.124725369816879d));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray19);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray21);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.017453292519943295d), (java.lang.Number) (byte) 0, false);
        java.lang.Number number28 = numberIsTooSmallException27.getMin();
        java.lang.Number number29 = numberIsTooSmallException27.getMin();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray45);
        java.lang.Object[] objArray48 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException34, localizable41, objArray48);
        java.lang.Object[] objArray53 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray53);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable41, objArray53);
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException27, localizable41, objArray56);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray65);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("hi!", objArray65);
        org.apache.commons.math.exception.util.Localizable localizable68 = mathException67.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, localizable71, objArray72);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("hi!", objArray72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException61, localizable68, objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.ConvergenceException: convergence failed", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(localizable12, objArray75);
        java.lang.Throwable throwable81 = null;
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl86 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
        double[] doubleArray88 = normalDistributionImpl86.sample(10);
        java.lang.Object[] objArray90 = new java.lang.Object[] { normalDistributionImpl86, 10.0d };
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException(throwable81, "hi!", objArray90);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException("", objArray90);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(localizable12, objArray90);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException(5, "org.apache.commons.math.MathException: hi!", objArray90);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (byte) 0 + "'", number28.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 0 + "'", number29.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(localizable68);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(objArray90);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-49.68420393244495d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.890364748375361E21d + "'", double1 == 1.890364748375361E21d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.221812407418454d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6543168277622217d + "'", double1 == 0.6543168277622217d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.exp(24.69151889734563d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.289205086650646E10d + "'", double1 == 5.289205086650646E10d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray18);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException7, localizable14, objArray21);
        java.lang.Object[] objArray26 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable14, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable38, objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray39);
        org.apache.commons.math.exception.util.Localizable localizable42 = mathException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable45, objArray46);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("hi!", objArray46);
        java.lang.Object[] objArray49 = new java.lang.Object[] { "hi!" };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35, localizable42, objArray49);
        java.lang.Object[] objArray54 = new java.lang.Object[] { 3.141592653589793d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray54);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable42, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable29, objArray54);
        java.lang.Throwable[] throwableArray59 = mathIllegalArgumentException58.getSuppressed();
        java.lang.Object[] objArray60 = mathIllegalArgumentException58.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable2, objArray60);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 47, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 0.930874936879059d, (double) (byte) -1);
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            int int8 = randomDataImpl0.nextPascal(0, (double) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.2461787337143881d) + "'", double5 == (-1.2461787337143881d));
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Object[] objArray8 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
//        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray8);
//        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
//        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
//        java.lang.Object[] objArray18 = new java.lang.Object[] { "hi!" };
//        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable11, objArray18);
//        java.lang.Number number21 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.0E-9d, number21, (java.lang.Number) 10.124725369816879d);
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, number24, (java.lang.Number) 2.718281828459045d, true);
//        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException27.getSpecificPattern();
//        java.lang.Number number30 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 9.946054089648355d, number30, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (byte) -1, (java.lang.Number) 2.718281828459045d);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Object[] objArray40 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray40);
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("hi!", objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable43 = mathException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        java.lang.Object[] objArray47 = new java.lang.Object[] {};
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray47);
//        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("hi!", objArray47);
//        java.lang.Object[] objArray50 = new java.lang.Object[] { "hi!" };
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException36, localizable43, objArray50);
//        java.lang.Number number53 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) 1.0E-9d, number53, (java.lang.Number) 10.124725369816879d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator56 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl57 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator56);
//        double double60 = randomDataImpl57.nextWeibull((double) (short) 100, (double) 10.0f);
//        double double63 = randomDataImpl57.nextWeibull((double) 'a', 0.6098494453571889d);
//        double double66 = randomDataImpl57.nextGaussian((double) ' ', 2.302585092994046d);
//        randomDataImpl57.reSeedSecure((long) 1);
//        java.lang.Object[] objArray70 = new java.lang.Object[] { randomDataImpl57, ' ' };
//        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable43, objArray70);
//        java.lang.Class<?> wildcardClass72 = convergenceException71.getClass();
//        java.lang.Object[] objArray73 = convergenceException71.getArguments();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray73);
//        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException("68a9dae8282db87ca06c3a0b90371ce4c5b87c042514c464fe91", objArray73);
//        org.junit.Assert.assertNotNull(objArray8);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertNotNull(objArray18);
//        org.junit.Assert.assertNotNull(localizable28);
//        org.junit.Assert.assertNotNull(objArray40);
//        org.junit.Assert.assertNotNull(localizable43);
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertNotNull(objArray50);
//        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 9.938925943262877d + "'", double60 == 9.938925943262877d);
//        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.6125720782246726d + "'", double63 == 0.6125720782246726d);
//        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 35.497343332557314d + "'", double66 == 35.497343332557314d);
//        org.junit.Assert.assertNotNull(objArray70);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(objArray73);
//    }
//}

